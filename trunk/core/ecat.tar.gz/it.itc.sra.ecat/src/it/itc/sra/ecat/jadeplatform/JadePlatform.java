package it.itc.sra.ecat.jadeplatform;

import java.io.File;
import java.util.List;

import it.itc.sra.ecat.ECATPlugIn;
import it.itc.sra.ecat.core.Synchronizer;
import it.itc.sra.ecat.core.executor.CentralExecutorAgent;
import it.itc.sra.ecat.core.monitor.CentralMonitorAgent;
import it.itc.sra.ecat.core.tester.TesterAgent;
import it.itc.sra.ecat.util.GeneralLogger;
import it.itc.sra.ecat.util.LauchingUtil;
import jade.core.Profile;
import jade.core.ProfileImpl;
import jade.core.Runtime;
import jade.wrapper.AgentContainer;
import jade.wrapper.AgentController;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.Path;
import org.eclipse.debug.core.ILaunchConfiguration;
import org.eclipse.debug.core.ILaunchConfigurationWorkingCopy;
import org.eclipse.debug.core.ILaunchManager;
import org.eclipse.debug.ui.DebugUITools;
import org.eclipse.debug.ui.IDebugUIConstants;
import org.eclipse.jdt.launching.*;
import org.eclipse.jface.dialogs.MessageDialog;

/**
 * @author cunduy
 */
public class JadePlatform implements IJavaLaunchConfigurationConstants {

	private GeneralLogger logger = GeneralLogger.getInstance();
	private static JadePlatform instance = null;

	private JadePlatform() {
	}

	/**
	 * @return Returns the instance.
	 * @uml.property name="instance"
	 */
	public static JadePlatform getInstance() {
		if (instance == null)
			instance = new JadePlatform();
		return instance;
	}

	/**
	 * Start the tester agent !!! Presume that JADE platform has been already
	 * started
	 */
	synchronized public void starteCAT() {
		// Get a hold on JADE runtime
		Runtime jadeRunTime = Runtime.instance();

		// Create a default profile
		Profile jadeProfile = new ProfileImpl(false);
		jadeProfile.setParameter(Profile.MAIN_HOST, ECATPlugIn.getHost());
		jadeProfile.setParameter(Profile.MAIN_PORT, ECATPlugIn.getPort());

		// Create a new non-main container, connecting to the default main
		// container (i.e. on this host, port 1099)
		AgentContainer newContainer = jadeRunTime.createAgentContainer(jadeProfile);
		try {
			// Create the object used to synchronize the starting of the
			// Plugin and the Tester Agent
			Object arg[] = new Object[1];
			Synchronizer synchronizer = new Synchronizer();
			arg[0] = synchronizer;

			// Create the Tester Agent and pass it the synchronizing object
			// as argument
			AgentController theTesterAgent = newContainer.createNewAgent("TesterAgent", TesterAgent.class.getName(),
					arg);
			// AgentController theMonitor =
			// newContainer.createNewAgent("eCATMonitor",
			// JADEMonitorAgent.class.getName(), arg);
			AgentController theCentralMonitor = newContainer.createNewAgent("CentralMonitor", CentralMonitorAgent.class
					.getName(), arg);

			AgentController theCentralExecutor = newContainer.createNewAgent("CentralExecutor",
					CentralExecutorAgent.class.getName(), arg);

			// Start the Tester Agent
			theTesterAgent.start();

			// Start the monitor
			// theMonitor.start();

			theCentralMonitor.start();

			// Start the executor
			theCentralExecutor.start();

			// Wait for synchronization signal
			synchronizer.waitOn();

			// Sleep 1000 ms to wait for the monitor to be ready
			Thread.sleep(1000);

			// Monitoring the TesterAgent ;-)
			// ECATPlugIn.getDefault().getMonitorAgent().startMonirotingAgent(new
			// JADEAgent("TesterAgent"));

			ECATPlugIn.getDefault().setTesterReady(true);
		} catch (Exception e) {
			ECATPlugIn.getDefault().setTesterReady(false);
			e.printStackTrace(logger.getOut());
		}
	}

	/**
	 * Shutdown JADE platform
	 */
	synchronized public void shutdown() {
		String ejadeHome = ECATPlugIn.getDefault().getHome();
		try {
			// Create new launching configuration
			ILaunchConfigurationWorkingCopy workingCopy =  LauchingUtil.prepareWorkingConfig("Shutdown eCAT-JADE");
			if (workingCopy == null)
				return;
			
			workingCopy.setAttribute(ATTR_MAIN_TYPE_NAME, "jade.Boot");
			workingCopy.setAttribute(ATTR_PROGRAM_ARGUMENTS, " -container" + LauchingUtil.launchingParams() + " KillerAgent:" + KillerAgent.class.getName());

			String[] libPaths = new String[] { "lib"};
			List<String> classpath = LauchingUtil.prepareClasspath(null,
					libPaths);

			if (classpath == null) {
				ECATPlugIn.getDefault().getWorkbench().getDisplay().asyncExec(new Runnable(){
					public void run() {
						MessageDialog.openError(ECATPlugIn.getDefault().getWorkbench()
								.getActiveWorkbenchWindow().getShell(),
								"Error",
								"Can not build classpath, please check JADE lib directory in the plugin home");	
					}
				});
				return;
			}
			
			IPath path = ECATPlugIn.getDefault().getPluginPath();
			IRuntimeClasspathEntry pathEntry;
			IPath pathElement = path.append("ecat.jar");
			pathEntry = JavaRuntime.newArchiveRuntimeClasspathEntry(pathElement);
			pathEntry.setClasspathProperty(IRuntimeClasspathEntry.USER_CLASSES);
			classpath.add(pathEntry.getMemento());

			workingCopy.setAttribute(ATTR_CLASSPATH, classpath);
			workingCopy.setAttribute(ATTR_DEFAULT_CLASSPATH, false);

			File workingDir = (new Path(ejadeHome)).toFile();
			workingCopy.setAttribute(ATTR_WORKING_DIRECTORY, workingDir
					.getAbsolutePath());

			// Save configuration and launch JADE
			ILaunchConfiguration configuration;

			configuration = workingCopy.doSave();
			DebugUITools.launch(configuration, ILaunchManager.RUN_MODE);
		} catch (CoreException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Start JADE
	 * @return
	 */
	synchronized public boolean start() {

		String ejadeHome = ECATPlugIn.getDefault().getHome();
		try {
			// Create new launching configuration
			ILaunchConfigurationWorkingCopy workingCopy =  LauchingUtil.prepareWorkingConfig("Start eCAT-JADE");
			if (workingCopy == null)
				return false;
			
			workingCopy.setAttribute(ATTR_MAIN_TYPE_NAME, "jade.Boot");
			
			if (ECATPlugIn.getDefault().isShowGUI())
				workingCopy.setAttribute(ATTR_PROGRAM_ARGUMENTS, " -gui" +  LauchingUtil.launchingParams());
			else 
				workingCopy.setAttribute(ATTR_PROGRAM_ARGUMENTS, " " + LauchingUtil.launchingParams());

			String[] libPaths = new String[] { "lib"};
			List<String> classpath = LauchingUtil.prepareClasspath(null,
					libPaths);

			if (classpath == null) {
				ECATPlugIn.getDefault().getWorkbench().getDisplay().asyncExec(new Runnable(){
					public void run() {
						MessageDialog.openError(ECATPlugIn.getDefault().getWorkbench()
								.getActiveWorkbenchWindow().getShell(),
								"Error",
								"Can not build classpath, please check JADE lib directory in the plugin home");	
					}
				});
				return false;
			}

			workingCopy.setAttribute(ATTR_CLASSPATH, classpath);
			workingCopy.setAttribute(ATTR_DEFAULT_CLASSPATH, false);

			File workingDir = (new Path(ejadeHome)).toFile();
			workingCopy.setAttribute(ATTR_WORKING_DIRECTORY, workingDir
					.getAbsolutePath());

			// Save configuration and launch JADE
			ILaunchConfiguration configuration;
			workingCopy.setAttribute(IDebugUIConstants.ATTR_LAUNCH_IN_BACKGROUND, true);

			configuration = workingCopy.doSave();
			DebugUITools.launch(configuration, ILaunchManager.RUN_MODE);
			
		} catch (CoreException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
}
