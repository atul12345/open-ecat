package it.itc.sra.ecat.util;

/**
 * @author  cunduy
 */
public abstract class Logger {

	protected int logLevel;
	public static final int LEVEL_VERBOSE = 4;
	public static final int LEVEL_DEBUG = 3;
	public static final int LEVEL_ERROR = 2;
	public static final int LEVEL_INFO = 1;
	public static final int LEVEL_OFF = 0;

	abstract public void log(String log);
	abstract public void log(int level, String log);

	/**
	 * @return  Returns the logLevel.
	 * @uml.property  name="logLevel"
	 */
	public int getLogLevel() {
		return logLevel;
	}

	/**
	 * @param logLevel  The logLevel to set.
	 * @uml.property  name="logLevel"
	 */
	public void setLogLevel(int property1) {
		this.logLevel = property1;
	}

}
