/**
 * <copyright>
 *
 * eCAT - Tool for Continuous Testing Agent for the JADE/Eclipse Platform
 * Copyright (C) ITC-IRST, Trento, Italy
 * Authors: Duy Cu Nguyen
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 * The electronic copy of the license can be found here:
 * http://sra.itc.it/tools/taom/freesoftware/gpl.txt
 *
 * The contact information:
 * e-mail: cunduy@itc.it
 * site: http://sra.itc.it
 *
 * </copyright>
 */

package it.itc.sra.ecat.ontobase;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Generate random english string
 * @author cunduy
 *
 */
public class EnDictionary implements IDictionary {

	private static EnDictionary instance = new EnDictionary();
	private List<String> enWords;
	private Random selector;
	
	synchronized public static EnDictionary getIntance(){
		return instance;
	}
	
	private EnDictionary() {
		enWords = new ArrayList<String>();
		enWords.add("");
		selector = new Random();
	}

	public String nextExpression() {
		return enWords.get(selector.nextInt(enWords.size()));
	}

	public String nextExpression(String pattern) {
		return "";
	}

}
