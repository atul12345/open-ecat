package it.itc.sra.ecat.core.monitor.onto;


import jade.content.*;
import jade.util.leap.*;
import jade.core.*;

/**
* Protege name: Stop
* @author ontology bean generator
* @version 2007/10/12, 20:00:38
*/
public class Stop implements AgentAction {

   /**
* Protege name: param
   */
   private String param;
   public void setParam(String value) { 
    this.param=value;
   }
   public String getParam() {
     return this.param;
   }

}
