/**
 * <copyright>
 *
 * eCAT - Tool for Continuous Testing Agent for the JADE/Eclipse Platform
 * Copyright (C) ITC-IRST, Trento, Italy
 * Authors: Duy Cu Nguyen
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 * The electronic copy of the license can be found here:
 * http://sra.itc.it/tools/taom/freesoftware/gpl.txt
 *
 * The contact information:
 * e-mail: cunduy@itc.it
 * site: http://sra.itc.it
 *
 * </copyright>
 */

package it.itc.sra.ecat.core;

import it.itc.sra.ecat.core.monitor.RemoteMonitoringLogs;
import it.itc.sra.ecat.testsuiteman.testconfig.NodeType;
import it.itc.sra.ecat.testsuiteman.testconfig.TestConfig;
import it.itc.sra.ecat.util.CommonUtil;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;


public class MonitoringModel {

	private ArrayList<MonitoringNodeModel> objects;
	
	private HashMap<String, RemoteMonitoringLogs> remoteLoggers;
	private HashMap<String, NodeType> remoteNodes;

	private static MonitoringModel instance;
	
	public RemoteMonitoringLogs getRemoteLogger(String key) {
		return remoteLoggers.get(key);
	}

	public NodeType getRemoteNode(String key) {
		return remoteNodes.get(key);
	}
	
	public synchronized void putLogger(String key, RemoteMonitoringLogs logger){
		remoteLoggers.put(key, logger);
	}
	
	public synchronized void putNode(String key, NodeType node){
		remoteNodes.put(key, node);
	}
	
	public synchronized static MonitoringModel getInstance() {
		if (instance == null) {
			synchronized (MonitoringModel.class) {
				if (instance == null) {
					instance = new MonitoringModel();
				}
			}
		}
		return instance;
	}

	private MonitoringModel() {
		objects = new ArrayList<MonitoringNodeModel>();
		
		remoteLoggers = new HashMap<String, RemoteMonitoringLogs>();
		remoteNodes = new HashMap<String, NodeType>(); 
	}

	public Object[] getContents() {
		return objects.toArray();
	}
	
	public synchronized void reset(){
		objects.clear();
		remoteLoggers.clear();
		remoteNodes.clear();
	}
	
	public synchronized void resetRemoteTrace(){
		Iterator<String> iter = remoteLoggers.keySet().iterator();
		while (iter.hasNext()){
			RemoteMonitoringLogs r = remoteLoggers.get(iter.next());
			r.resetMonitor();
		}
	}
	
	public synchronized void update(TestConfig testConfig){
		// Clear all data
		reset();
		
		if (testConfig != null){
			if (testConfig.getDitributedNodeConfig() != null){
				List<NodeType> nodes = testConfig.getDitributedNodeConfig().getNode();
				Iterator<NodeType> iter = nodes.iterator();
				while (iter.hasNext()){
					NodeType node = (NodeType)iter.next();
					
					String key = CommonUtil.getRemoteMonitoringAgentGUID(node);
					RemoteMonitoringLogs logger = new RemoteMonitoringLogs();
					
					putLogger(key, logger);
					putNode(key, node);
					
					MonitoringNodeModel nodeModel = new MonitoringNodeModel(node, logger, key);
					
					objects.add(nodeModel);
					
				}
			}
		}

	}
	
}
