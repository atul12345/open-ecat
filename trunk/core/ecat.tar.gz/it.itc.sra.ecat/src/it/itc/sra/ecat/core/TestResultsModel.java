/**
 * <copyright>
 *
 * eCAT - Tool for Continuous Testing Agent for the JADE/Eclipse Platform
 * Copyright (C) ITC-IRST, Trento, Italy
 * Authors: Duy Cu Nguyen
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 * The electronic copy of the license can be found here:
 * http://sra.itc.it/tools/taom/freesoftware/gpl.txt
 *
 * The contact information:
 * e-mail: cunduy@itc.it
 * site: http://sra.itc.it
 *
 * </copyright>
 */

package it.itc.sra.ecat.core;
import it.itc.sra.ecat.ecatplugin.views.ITestModelListener;
import it.itc.sra.ecat.testsuiteman.JADETestSuites;
import it.itc.sra.ecat.testsuiteman.TestSuitesStorage;
import it.itc.sra.ecat.testsuiteman.testconfig.NodeType;
import it.itc.sra.ecat.testsuiteman.testconfig.TestConfig;
import it.itc.sra.ecat.testsuiteman.testsuite.TestCaseType;
import it.itc.sra.ecat.testsuiteman.testsuite.TestSuite;
import it.itc.sra.ecat.util.CommonUtil;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;

public class TestResultsModel {
	
	private ArrayList<ITestModelListener> modelListeners;
	private static volatile TestResultsModel instance;
	private Map<Object, Vector<NodeTestStatus>> resultMap;
	private TestConfig testConfig;
	private List<Object> keyObjects;
	
	private int testCycle = 0; 
	private int numTestCase = 0;
	
	public static TestResultsModel getInstance(){
		if (instance == null){
			synchronized (TestResultsModel.class) {
				if (instance == null)
					instance = new TestResultsModel();
			}
		}
		return instance;
	}
	
	
	private TestResultsModel() {
		modelListeners = new ArrayList<ITestModelListener>();
		resultMap = new HashMap<Object, Vector<NodeTestStatus>>();
		keyObjects = new ArrayList<Object>();
	}

	
	public Object[] getKeyObjects(){
		return keyObjects.toArray();
	}
	
	
	/**
	 * Update testing status of one test case on one node
	 * @param tc
	 * @param node
	 * @param testingStatus
	 * @param lastMsg
	 */
	public synchronized void updateStatus(TestCaseType tc, NodeType node, String testingStatus, Object lastMsg){
		Vector<NodeTestStatus> v = resultMap.get(tc);
		if (v != null){
			Iterator<NodeTestStatus> iter = v.iterator();
			while (iter.hasNext()){
				NodeTestStatus elem = (NodeTestStatus)iter.next();
				if (elem.getNode().getNodeHap().equals(node.getNodeHap())){
					elem.setLastMsg(lastMsg);
					elem.setState(testingStatus);
					
					fireModelChanged(tc, testingStatus, ITestModelListener.PROPERTY_RESULT); // fire changes
					break;
				}
			}
		}
		
	}
	
	public synchronized void updateStatus(TestCaseType tc, NodeType node, String testingStatus, Object lastMsg, String failedState, String failedSeqID){
		Vector<NodeTestStatus> v = resultMap.get(tc);
		if (v != null){
			Iterator<NodeTestStatus> iter = v.iterator();
			while (iter.hasNext()){
				NodeTestStatus elem = (NodeTestStatus)iter.next();
				if (elem.getNode().getNodeHap().equals(node.getNodeHap())){
					elem.setLastMsg(lastMsg);
					elem.setState(testingStatus);
					elem.setFailedSeqID(failedSeqID);
					elem.setFailedState(failedState);
					
					fireModelChanged(tc, testingStatus, ITestModelListener.PROPERTY_RESULT); // fire changes
					break;
				}
			}
		}
	}
	
	
	/**
	 * Get test information for a test case on a specific node 
	 */
	public NodeTestStatus getNodeTestStatus(TestCaseType tc, NodeType node){
		Vector<NodeTestStatus> v = resultMap.get(tc);
		if (v != null){
			Iterator<NodeTestStatus> iter = v.iterator();
			while (iter.hasNext()){
				NodeTestStatus elem = (NodeTestStatus)iter.next();
				if (elem.getNode().getNodeHap().equals(node.getNodeHap())){
					return elem;
				}
			}
		}
		
		return null;
	}
	
	/**
	 * Get the whole vector
	 * @param tc
	 * @return
	 */
	public Vector<NodeTestStatus> getNodesTestStatus(TestCaseType tc){
		return resultMap.get(tc);
	}
	
	
	/**
	 * Init all data based on test configuration
	 * @param ts
	 */
	public void init(TestConfig ts){
		this.testConfig = ts;
		resultMap.clear(); // Clear previous test if any
		keyObjects.clear();
		
		if (testConfig != null && testConfig.getDitributedNodeConfig() != null){
			numTestCase = 0;
		
			JADETestSuites jadeTestSuites = JADETestSuites.getInstance();
			TestSuitesStorage storage = jadeTestSuites.getSuitesStorage();
			Iterator<TestSuite> iterator = storage.iterator();
			List<NodeType> nodes =  testConfig.getDitributedNodeConfig().getNode();
			
			while (iterator.hasNext()) {
				TestSuite suite = (TestSuite) iterator.next();
		
				Iterator<NodeType> iterNode = nodes.iterator();
				Vector<NodeTestStatus> v = new Vector<NodeTestStatus>();
				while (iterNode.hasNext()){
					NodeType node = (NodeType)iterNode.next();
					v.add(new NodeTestStatus(node));
				}
				
				resultMap.put(suite, v);
				keyObjects.add(suite); 
				
				List<TestCaseType> tcList = suite.getTestCase();
				Iterator<TestCaseType> iter = tcList.iterator();
				while (iter.hasNext()) {
					
					TestCaseType tc = iter.next();
					iterNode = nodes.iterator();
					v = new Vector<NodeTestStatus> ();
					while (iterNode.hasNext()){
						NodeType node = (NodeType)iterNode.next();
						v.add(new NodeTestStatus(node, ITestModelListener.STATE_INITIAL, null));
					}	
					
					resultMap.put(tc, v);
					keyObjects.add(tc);
					
					numTestCase += 1;
				}
	
			}

		}
	}
	
	public  synchronized void addTestCase(TestCaseType tc) {
		if (testConfig != null && testConfig.getDitributedNodeConfig() != null) {
			List<NodeType> nodes =  testConfig.getDitributedNodeConfig().getNode();
			Iterator<NodeType> iterNode = nodes.iterator();
			Vector<NodeTestStatus> v = new Vector<NodeTestStatus> ();
			while (iterNode.hasNext()){
				NodeType node = (NodeType)iterNode.next();
				v.add(new NodeTestStatus(node, ITestModelListener.STATE_INITIAL, null));
			}	
			
			keyObjects.add(tc);
			resultMap.put(tc, v);
			
			numTestCase += 1;
			
			fireModelChanged(tc, ITestModelListener.STATE_INITIAL, ITestModelListener.PROPERTY_ADDNEW); // fire changes
			
		}
	}
	
	public synchronized void addTestCase(List<TestCaseType> list){
		if (list == null) return;
		for (TestCaseType tc : list){
			addTestCase(tc);
		}
	}
	
	public synchronized void removeTestCase(TestCaseType tc) {
		if (keyObjects.contains(tc)) {
			keyObjects.remove(tc);
			resultMap.remove(tc);
			if (numTestCase > 0)
				numTestCase -= 1;
			fireModelChanged(tc, ITestModelListener.STATE_FINAL, ITestModelListener.PROPERTY_REMOVE); // fire changes
		}
	}
	

	public void addModelListener(ITestModelListener listener) {
		if (!modelListeners.contains(listener))
			modelListeners.add(listener);
	}

	public void removeModelListener(ITestModelListener listener) {
		modelListeners.remove(listener);
	}

	public synchronized void fireModelChanged(TestCaseType tc, String state, String property) {
		for (int i = 0; i < modelListeners.size(); i++) {
			((ITestModelListener) modelListeners.get(i)).modelChanged(tc, state, property);
		}
	}

	
	
	/**
	 * Inerclass that represents testing status of a node
	 * @author cunduy
	 *
	 */
	public class NodeTestStatus{
		private NodeType node;
		private String testingStatus;
		private Object lastMsg;
		private String failedSeqID; // 
		private String failedState; //
		
		
		public NodeTestStatus(NodeType node, String testingStatus, Object lastMsg) {
			super();
			this.node = node;
			this.testingStatus = testingStatus;
			this.lastMsg = lastMsg;
		}
		
		/**
		 * Build a report about testing result for this node
		 * @return
		 */
		public String getNodeReport(){
			StringBuffer buff = new StringBuffer();
			
			//buff.append("<p>");
			//buff.append("<li style=\"text\" bindent=\"20\" indent=\"40\">" +
			//		"Node: " + node.getNodeHap() +
			//		"</li>");
			buff.append("<p><img href=\"node\"/>" +
					" <b>Node: " + node.getNodeHap()  + "</b></p>");
			
			buff.append("<p>");
			if (testingStatus.equals(ITestModelListener.STATE_FINAL)){
				buff.append("Test result: <span color=\"passed\" font=\"header\">PASSED</span></p>");
			} else if (testingStatus.equals(ITestModelListener.STATE_DUM_FINAL)){
				buff.append("Test result: <span color=\"failed\" font=\"header\">FAILED</span></p>");
				buff.append("<p>Failed at Action: <b>" + failedSeqID+ "</b></p>");
				buff.append("<p>Type: <b>" + failedState + "</b></p>");

				if (lastMsg != null){
					buff.append("<p>Last message processed:</p>");
					buff.append("<p><span font=\"code\" color=\"code\">");
					buff.append(CommonUtil.normalizeXML(lastMsg.toString()));		
					buff.append("</span></p>");
				} else if (failedState.equals("communication-receive")){
					buff.append("<p>Failure:</p>");
					buff.append("<p><span font=\"code\" color=\"failed\">");
					buff.append("Timeout!");		
					buff.append("</span></p>");
				}
				
			} else {
				buff.append(" ...<b>Testing</b>....</p>");
				if (lastMsg != null){
					buff.append("<p>Last message processed:</p>");
					buff.append("<p><span font=\"code\">");
					buff.append(CommonUtil.normalizeXML(lastMsg.toString()));		
					buff.append("</span></p>");
				}
			}
			
			//buff.append("</p>");
			return buff.toString();
		}
		
		public NodeTestStatus(NodeType node2) {
			this.node = node2;
		}
		public Object getLastMsg() {
			return lastMsg;
		}
		public void setLastMsg(Object lastMsg) {
			this.lastMsg = lastMsg;
		}
		public NodeType getNode() {
			return node;
		}
		public void setNode(NodeType node) {
			this.node = node;
		}
		public String getState() {
			return testingStatus;
		}
		public void setState(String testingStatus) {
			this.testingStatus = testingStatus;
		}
		public String getTestingStatus() {
			return testingStatus;
		}
		public void setTestingStatus(String testingStatus) {
			this.testingStatus = testingStatus;
		}
		public String getFailedSeqID() {
			return failedSeqID;
		}
		public void setFailedSeqID(String failedSeqID) {
			this.failedSeqID = failedSeqID;
		}
		public String getFailedState() {
			return failedState;
		}
		public void setFailedState(String failedState) {
			this.failedState = failedState;
		}
	}

	/**
	 * build a test report
	 * @return
	 */
	public synchronized String getTestReport(){
		StringBuffer buff = new StringBuffer();
		buff.append("<form>");
		
		Iterator<Object> iter = keyObjects.iterator();
		while (iter.hasNext()){
			Object obj = iter.next();
			if (obj instanceof TestSuite) {
				TestSuite ts = (TestSuite) obj;
				buff.append("<p>");
				buff.append("<span color=\"header\" font=\"header\">" +
						"Test Suite: " + ts.getID() + " - " + ts.getName()
						+ "</span>");
				buff.append("</p>");
				
			} else if (obj instanceof TestCaseType) {
				TestCaseType tc = (TestCaseType) obj;
				
				buff.append("<li style=\"image\" value=\"image\">" +
						"<span color=\"tcheader\" font=\"header\">" + tc.getID()+ " - " + tc.getName() + 
						"</span></li>");
								
				Vector<NodeTestStatus> nodeStatus = getNodesTestStatus(tc);
				for (NodeTestStatus node : nodeStatus){
					buff.append(node.getNodeReport());
					buff.append("<p></p>");
				}
				buff.append("<p></p>");
			}
		}
		
		buff.append("</form>");
		return buff.toString();
	}
	
	public TestConfig getTestConfig() {
		return testConfig;
	}


	public synchronized void setTestCycle(int testCycle) {
		this.testCycle = testCycle;
		fireModelChanged(null, "", ITestModelListener.PROPERTY_CYCLE);
	}


	public synchronized int getTestCycle() {
		return testCycle + 1;
	}


	public synchronized int getNumTestCase() {
		return numTestCase;
	}

//	public void setNumTestCase(int numTestCase) {
//		this.numTestCase = numTestCase;
//	}
	
}
