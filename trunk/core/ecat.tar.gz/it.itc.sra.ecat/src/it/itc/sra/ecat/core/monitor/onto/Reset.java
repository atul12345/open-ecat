package it.itc.sra.ecat.core.monitor.onto;


import jade.content.*;
import jade.util.leap.*;
import jade.core.*;

/**
* Protege name: Reset
* @author ontology bean generator
* @version 2007/10/12, 20:00:38
*/
public class Reset implements AgentAction {

   /**
* Protege name: param
   */
   private String param;
   public void setParam(String value) { 
    this.param=value;
   }
   public String getParam() {
     return this.param;
   }

}
