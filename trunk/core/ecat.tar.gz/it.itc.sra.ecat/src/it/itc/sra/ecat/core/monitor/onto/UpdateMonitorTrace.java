package it.itc.sra.ecat.core.monitor.onto;


import jade.content.*;
import jade.util.leap.*;
import jade.core.*;

/**
* Protege name: UpdateMonitorTrace
* @author ontology bean generator
* @version 2007/10/12, 20:00:38
*/
public class UpdateMonitorTrace implements AgentAction {

   /**
* Protege name: sessionID
   */
   private String sessionID;
   public void setSessionID(String value) { 
    this.sessionID=value;
   }
   public String getSessionID() {
     return this.sessionID;
   }

   /**
* Protege name: sessionTrace
   */
   private String sessionTrace;
   public void setSessionTrace(String value) { 
    this.sessionTrace=value;
   }
   public String getSessionTrace() {
     return this.sessionTrace;
   }

}
