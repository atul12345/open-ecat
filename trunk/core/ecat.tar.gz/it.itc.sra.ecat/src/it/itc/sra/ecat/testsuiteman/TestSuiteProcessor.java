/**
 * <copyright>
 *
 * eCAT - Tool for Continuous Testing Agent for the JADE/Eclipse Platform
 * Copyright (C) ITC-IRST, Trento, Italy
 * Authors: Duy Cu Nguyen
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 * The electronic copy of the license can be found here:
 * http://sra.itc.it/tools/taom/freesoftware/gpl.txt
 *
 * The contact information:
 * e-mail: cunduy@itc.it
 * site: http://sra.itc.it
 *
 * </copyright>
 */

package it.itc.sra.ecat.testsuiteman;

import java.util.Calendar;
import javax.xml.bind.JAXBException;
import javax.xml.datatype.XMLGregorianCalendar;

import it.itc.sra.ecat.core.ECATExeption;
import it.itc.sra.ecat.testsuiteman.testsuite.*;
import it.itc.sra.ecat.util.*;

public class TestSuiteProcessor extends ObjectFactory {

	public TestSuite load(String xmlFile) throws ECATExeption {
		return (TestSuite) JAXBUtil.loadJAXBFromFile(
				GlobalConstants.TESTSUITE_PACKAGE_STUBS, xmlFile);
	}

	public void saveTo(TestSuite ts, String xmlFile) throws ECATExeption {
		JAXBUtil.saveJAXBToFile(GlobalConstants.TESTSUITE_PACKAGE_STUBS, ts,
				xmlFile);
	}

	// //////////////////////////////////////////////
	// Example code
	public static void main(String[] args) {
		TestSuiteProcessor processor = new TestSuiteProcessor();

		// Create a new xml file

		// 1. Create a test suite
		TestSuite ts = processor.createTestSuite();

		// 2. Create the general part
		ts.setCreatedBy("A");
		// tg.setCreatedDate(new XMLGregorianCalendar());
		ts.setDescription("Test");
		ts.setID("1");
		ts.setName("Test suite 1");
		ts.setVersion("0.1");

		
		// 3. Create the functional part

		TargetType tf = processor.createTargetType();
		tf.setAgent("Mr Bean");
		// ....

		// Create a goal-plan
		GoalPlanType gp = processor.createGoalPlanType();
		gp.setGoal("G1");
		gp.setPlan("P1");
		gp.setRelationship("Means-End");

		// add gp to the functional part
		tf.getGoalPlan().add(gp);

		// 4. Create test case
		TestCaseType tc = processor.createTestCaseType();
		ts.getTestCase().add(tc); // Add test case to the list of test case

		tc.setActive(true);
		tc.setID("TC1");
		tc.setName("Test Case 1");
		tc.setPriority(0.1);
		tc.setDescription("This is a test case");

		// 5. Create test scenario
		TestScenarioType tsce = processor.createTestScenarioType();
		tc.setScenario(tsce); // Add the scenario to the test case

		// 6. create test actions
		TActionType seq1 = processor.createTActionType();
		TActionType seq2 = processor.createTActionType();
		
		// Add the action to the test scenario
		tsce.getTestAction().add(seq1);
		tsce.getTestAction().add(seq2);

		seq1.setID("TC1001");
		seq1.setInitiator("Initiator");
		seq1.setResponder("Responder");
		seq1.setActType(AType.INITIAL);
		seq1.setTimeout(500);

		FipaMessageType messageContent = new FipaMessageType();
		seq1.setMessage(messageContent);
		seq1.setNextAction(seq2);

		seq2.setID("TC1002");
		seq2.setInitiator("Initiator");
		seq2.setResponder("Responder");
		seq2.setActType(AType.CHECKPOINT);
		seq2.setTimeout(500);
		messageContent = new FipaMessageType();
		seq1.setMessage(messageContent);

		// Save test suite to a file

		try {
			processor.saveTo(ts, "testsuite1.xml");

			// Load test suite from file
			TestSuite ts2 = processor.load("testsuite1.xml");

			// Print test suite to screen
			System.out.println(JAXBUtil.transformJAXBToString(
					GlobalConstants.TESTSUITE_PACKAGE_STUBS, ts2));

			// 7. Modify a value
			ts2.setCreatedBy("Giuseppe");
			// Print test suite to screen
			System.out.println(JAXBUtil.transformJAXBToString(
					GlobalConstants.TESTSUITE_PACKAGE_STUBS, ts2));

		} catch (ECATExeption e) {
			e.printStackTrace();
		}

	}

}
