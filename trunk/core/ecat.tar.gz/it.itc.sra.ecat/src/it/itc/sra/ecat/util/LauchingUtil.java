package it.itc.sra.ecat.util;

import it.itc.sra.ecat.ECATPlugIn;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.Path;
import org.eclipse.debug.core.DebugPlugin;
import org.eclipse.debug.core.ILaunchConfiguration;
import org.eclipse.debug.core.ILaunchConfigurationType;
import org.eclipse.debug.core.ILaunchConfigurationWorkingCopy;
import org.eclipse.debug.core.ILaunchManager;
import org.eclipse.jdt.core.IClasspathEntry;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.launching.IJavaLaunchConfigurationConstants;
import org.eclipse.jdt.launching.IRuntimeClasspathEntry;
import org.eclipse.jdt.launching.JavaRuntime;

public class LauchingUtil {

	/**
	 * Prepare a launching configuration
	 * 
	 * @param configDesc
	 * @return
	 */
	public static ILaunchConfigurationWorkingCopy prepareWorkingConfig(
			String configDesc) {
		ILaunchManager manager = DebugPlugin.getDefault().getLaunchManager();
		ILaunchConfigurationType type = manager
				.getLaunchConfigurationType(IJavaLaunchConfigurationConstants.ID_JAVA_APPLICATION);

		// Remove old launching configuration
		ILaunchConfiguration configurations[];
		try {
			configurations = manager.getLaunchConfigurations(type);
			for (int i = 0; i < configurations.length; i++) {
				ILaunchConfiguration configuration = configurations[i];
				if (!configuration.getName().equals(configDesc))
					continue;
				configuration.delete();
				break;
			}

			// Create new launching configuration
			ILaunchConfigurationWorkingCopy workingCopy = type.newInstance(
					null, configDesc);

			return workingCopy;
		} catch (CoreException e) {
			return null;
		}
	}

	/**
	 * Add all jar files into classpath
	 * 
	 * @param myJavaProject
	 * @return
	 * @throws CoreException
	 */
	public static List<String> prepareClasspath(IJavaProject myJavaProject,
			String libPaths[]) throws CoreException {

		String home = ECATPlugIn.getDefault().getHome();
		List<String> classpath = new ArrayList<String>();

		IPath homePath = new Path(home);
		if (!homePath.isValidPath(home)) {
			return null;
		}

		IRuntimeClasspathEntry pathEntry;

		for (String libPath : libPaths) {
			IPath pathElement = homePath.append(libPath);
			File file = pathElement.toFile();

			// Scan jar files in the lib folder and add them to the classpath
			File fileList[] = file.listFiles();
			for (int i = 0; i < fileList.length; i++) {
				File jarFile = fileList[i];
				if (jarFile.getName().indexOf("jar") > 0) {
					pathElement = (new Path(home)).append(libPath).append(
							jarFile.getName());
					pathEntry = JavaRuntime
							.newArchiveRuntimeClasspathEntry(pathElement);
					pathEntry
							.setClasspathProperty(IRuntimeClasspathEntry.USER_CLASSES);
					classpath.add(pathEntry.getMemento());
				}
			}
		}

		// Add the outputFolder
		if (myJavaProject != null) {
			// Add necessary lib for the deployed agent
			IClasspathEntry entry[] = myJavaProject.getResolvedClasspath(true);
			for (int i = 0; i < entry.length; i++) {

				if (entry[i].getEntryKind() == IClasspathEntry.CPE_LIBRARY) {
					pathEntry = JavaRuntime
							.newArchiveRuntimeClasspathEntry(entry[i].getPath());
				} else {
					pathEntry = JavaRuntime
							.newVariableRuntimeClasspathEntry(entry[i]
									.getPath());
				}
				pathEntry
						.setClasspathProperty(IRuntimeClasspathEntry.USER_CLASSES);
				classpath.add(pathEntry.getMemento());
			}

			// Add the output folder where the agent lies in
			pathEntry = JavaRuntime
					.newArchiveRuntimeClasspathEntry(myJavaProject
							.getOutputLocation());
			pathEntry.setClasspathProperty(IRuntimeClasspathEntry.USER_CLASSES);
			classpath.add(pathEntry.getMemento());

		}

		// System libs
		IPath systemLibsPath = new Path(JavaRuntime.JRE_CONTAINER);
		IRuntimeClasspathEntry systemLibsEntry = JavaRuntime
				.newRuntimeContainerClasspathEntry(systemLibsPath,
						IRuntimeClasspathEntry.STANDARD_CLASSES);
		classpath.add(systemLibsEntry.getMemento());

		return classpath;
	}

	/**
	 * Prepare the source list
	 * 
	 * @param myJavaProject
	 * @return
	 * @throws CoreException
	 */
	public static List<String> prepareSourcePath(IJavaProject myJavaProject)
			throws CoreException {

		List<String> sourcepath = new ArrayList<String>();
		IRuntimeClasspathEntry pathEntry;

		// Add the source
		if (myJavaProject != null) {
			// Add necessary lib for the deployed agent
			IClasspathEntry[] entry = myJavaProject.getResolvedClasspath(true);
			for (int i = 0; i < entry.length; i++) {
				if (entry[i].getEntryKind() == IClasspathEntry.CPE_SOURCE) {
					pathEntry = JavaRuntime
							.newVariableRuntimeClasspathEntry(entry[i]
									.getPath());
					sourcepath.add(pathEntry.getMemento());
				}
			}
		}
		return sourcepath;
	}

	/**
	 * Get launching port and host
	 * @return
	 */
	public static String launchingParams() {
		String ret;
		String port = ECATPlugIn.getPort();
		String host = ECATPlugIn.getHost();
		String customParams = ECATPlugIn.getDefault().getJADEParams();
		ret = " -port " + port + " -host " + host + " " + customParams + " ";
		return ret;
	}
}
