package it.itc.sra.ecat.jadeplatform;

import jade.content.ContentManager;
import jade.content.lang.Codec;
import jade.content.lang.sl.SLCodec;
import jade.content.onto.basic.Action;
import jade.core.Agent;
import jade.domain.FIPANames;
import jade.domain.JADEAgentManagement.JADEManagementOntology;
import jade.domain.JADEAgentManagement.ShutdownPlatform;
import jade.lang.acl.ACLMessage;
import jade.proto.SimpleAchieveREInitiator;


public class KillerAgent extends Agent {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8302502224739164115L;

	@Override
	protected void setup() {

		ShutdownPlatform sp = new ShutdownPlatform();
		try {
			Action a = new Action();
			a.setActor(getAMS());
			a.setAction(sp);
			
			Codec codec = new SLCodec();
			ContentManager manager = (ContentManager) getContentManager();
			manager.registerLanguage(codec, FIPANames.ContentLanguage.FIPA_SL);
			manager.registerOntology(JADEManagementOntology.getInstance());
			
			ACLMessage requestMsg = new ACLMessage(ACLMessage.REQUEST);
			requestMsg.setSender(getAID());
			requestMsg.addReceiver(getAMS());
			requestMsg.setProtocol(FIPANames.InteractionProtocol.FIPA_REQUEST);
			requestMsg.setLanguage(codec.getName());
			requestMsg.setOntology(JADEManagementOntology.NAME);
			manager.fillContent(requestMsg, a);
			addBehaviour(new SimpleAchieveREInitiator(this, requestMsg));
		}
		catch(Exception fe) {
			fe.printStackTrace();
		}
		
	}

}
