/**
 * <copyright>
 *
 * eCAT - Tool for Continuous Testing Agent for the JADE/Eclipse Platform
 * Copyright (C) ITC-IRST, Trento, Italy
 * Authors: Duy Cu Nguyen
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 * The electronic copy of the license can be found here:
 * http://sra.itc.it/tools/taom/freesoftware/gpl.txt
 *
 * The contact information:
 * e-mail: cunduy@itc.it
 * site: http://sra.itc.it
 *
 * </copyright>
 */

package it.itc.sra.ecat.core;

import it.itc.sra.ecat.ecatplugin.views.MonitoringLogsView;

import java.io.Serializable;

/**
 * @author  cunduy
 */
public class ECATExeption extends Exception implements Serializable {

    private String errorCode;
    private String message;
    
    public static final String ERROR_NOINFECT = "noinfect";
    public static final String ERROR_SYSTEM = "system";
    public static final String ERROR_FATAL = "fatal";
	/**
	 * 
	 */
	private static final long serialVersionUID = 5588393415070314317L;

	public ECATExeption() {
		super();

	}

	public ECATExeption(String arg0, Throwable arg1) {
		super(arg0, arg1);

	}

	public ECATExeption(Throwable arg0) {
		super(arg0);

	}

	public ECATExeption(String errorCode, String message) {
		this.errorCode = errorCode;
		this.message = message;
	}

	public ECATExeption(String message) {
		this.message = message;
	}

	/**
	 * @return  Returns the errorCode.
	 * @uml.property  name="errorCode"
	 */
	public String getErrorCode() {
		return errorCode;
	}

	/**
	 * @param errorCode  The errorCode to set.
	 * @uml.property  name="errorCode"
	 */
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	/**
	 * @return  Returns the message.
	 * @uml.property  name="message"
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * @param message  The message to set.
	 * @uml.property  name="message"
	 */
	public void setMessage(String message) {
		this.message = message;
	}
	
	
	

}
