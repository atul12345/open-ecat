/**
 * <copyright>
 *
 * eCAT - Tool for Continuous Testing Agent for the JADE/Eclipse Platform
 * Copyright (C) ITC-IRST, Trento, Italy
 * Authors: Duy Cu Nguyen
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 * The electronic copy of the license can be found here:
 * http://sra.itc.it/tools/taom/freesoftware/gpl.txt
 *
 * The contact information:
 * e-mail: cunduy@itc.it
 * site: http://sra.itc.it
 *
 * </copyright>
 */

package it.itc.sra.ecat.ecatplugin.views;

import it.itc.sra.ecat.ECATPlugIn;
import it.itc.sra.ecat.core.MonitoringNodeModel;

import org.eclipse.jface.resource.JFaceResources;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.forms.IDetailsPage;
import org.eclipse.ui.forms.IFormPart;
import org.eclipse.ui.forms.IManagedForm;
import org.eclipse.ui.forms.widgets.FormText;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.forms.widgets.Section;
import org.eclipse.ui.forms.widgets.TableWrapData;
import org.eclipse.ui.forms.widgets.TableWrapLayout;

public class DetailsLogPage implements IDetailsPage, IModelListener {

	private IManagedForm mform;

	// private Text textTrace;
	private FormText textTrace;

	private Text textLogs;
	private MonitoringNodeModel input;
	Composite parent;

	public void createContents(Composite parent) {
		this.parent = parent;

		//GridLayout layout = new GridLayout();
		TableWrapLayout layout = new TableWrapLayout();
		layout.numColumns = 1;
		//layout.marginRight = 10;
		//layout.marginBottom = 10;
		parent.setLayout(layout);
		
		TableWrapData td = new TableWrapData(TableWrapData.FILL_GRAB);
		parent.setLayoutData(td);

		FormToolkit toolkit = mform.getToolkit();

		Section s1 = toolkit.createSection(parent, Section.EXPANDED);
		s1.setText("Monitoring Traces");
		// s1.setDescription("Communication and Event Trace");

		td = new TableWrapData(TableWrapData.FILL_GRAB);
		s1.setLayoutData(td);

		toolkit.createCompositeSeparator(s1);

		Composite client1 = toolkit.createComposite(s1, SWT.TOP);
		client1.setLayout(new TableWrapLayout());

		// textTrace = toolkit.createText(client1, "", SWT.V_SCROLL | SWT.MULTI
		// | SWT.BORDER);
		textTrace = toolkit.createFormText(client1, false);
		TableWrapData wtd = new TableWrapData(TableWrapData.FILL_GRAB);
		// td.heightHint = 300;
		textTrace.setLayoutData(wtd);

		textTrace.setImage("image", ECATPlugIn.getDefault().getImageRegistry().get(ECATPlugIn.IMG_CHECKED));
		textTrace.setImage("node", ECATPlugIn.getDefault().getImageRegistry().get(ECATPlugIn.IMG_NODE));

		Color headerColor = toolkit.getColors().createColor("header", 0, 0, 255);
		textTrace.setColor("header", headerColor);

		Color tcheaderColor = toolkit.getColors().createColor("tcheader", 255, 0, 0);
		textTrace.setColor("tcheader", tcheaderColor);

		Color passedColor = toolkit.getColors().createColor("ok", 8, 80, 10);
		textTrace.setColor("ok", passedColor);

		Color failedColor = toolkit.getColors().createColor("nok", 255, 0, 0);
		textTrace.setColor("nok", failedColor);

		Color codeColor = toolkit.getColors().createColor("code", 112, 92, 92);
		textTrace.setColor("code", codeColor);

		
		//textTrace.setFont("header", JFaceResources.getHeaderFont());
		textTrace.setFont("header", JFaceResources.getBannerFont());
		textTrace.setFont("code", JFaceResources.getTextFont());

		toolkit.paintBordersFor(client1);
		s1.setClient(client1);

		// Execution Log
		Section s2 = toolkit.createSection(parent, Section.TWISTIE | Section.EXPANDED);
		s2.setText("Execution Logs");

		td = new TableWrapData(TableWrapData.FILL_GRAB);
		s2.setLayoutData(td);

		toolkit.createCompositeSeparator(s2);

		Composite client2 = toolkit.createComposite(s2);
		client2.setLayout(new TableWrapLayout());

		textLogs = toolkit.createText(client2, "", SWT.V_SCROLL | SWT.MULTI);
		toolkit.paintBordersFor(client2);
		s2.setClient(client2);
	}

/*	private void createSpacer(FormToolkit toolkit, Composite parent, int span) {
		Label spacer = toolkit.createLabel(parent, "");
		TableWrapData gd = new TableWrapData();
		//gd.horizontalSpan = span;
		spacer.setLayoutData(gd);
	}*/

	public void commit(boolean onSave) {
	}

	public void dispose() {
		if (input != null && input instanceof MonitoringNodeModel)
			input.removeModelListener(this);
	}

	public void initialize(IManagedForm form) {
		this.mform = form;
	}

	public boolean isDirty() {
		return false;
	}

	public boolean isStale() {
		return false;
	}

	public void refresh() {
	}

	public void setFocus() {
	}

	public boolean setFormInput(Object input) {
		return false;
	}

	public void selectionChanged(IFormPart part, ISelection selection) {
		IStructuredSelection ssel = (IStructuredSelection) selection;
		if (ssel.size() == 1) {
			input = (MonitoringNodeModel) ssel.getFirstElement();
			input.addModelListener(this);
		} else
			input = null;
		update();
	}

	private void update() {
		textTrace.setText(input != null && input.getMonitorLogs() != null ? input.getMonitorLogs() : "", true, false);
		textLogs.setText(input != null && input.getLogs() != null ? input.getLogs() : "");
	}

	public void modelChanged(final String type, String property) {
		parent.getDisplay().asyncExec(new Runnable() {
			public void run() {
				if (type.equals(IModelListener.LOGS))
					textLogs.setText(input != null && input.getLogs() != null ? input.getLogs() : "");
				else
					textTrace.setText(input != null && input.getMonitorLogs() != null ? input.getMonitorLogs() : "", true, false);
			}
		});
	}
}
