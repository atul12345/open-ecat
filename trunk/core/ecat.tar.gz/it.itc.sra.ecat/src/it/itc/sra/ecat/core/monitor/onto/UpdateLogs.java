package it.itc.sra.ecat.core.monitor.onto;


import jade.content.*;
import jade.util.leap.*;
import jade.core.*;

/**
* Protege name: UpdateLogs
* @author ontology bean generator
* @version 2007/10/12, 20:00:38
*/
public class UpdateLogs implements AgentAction {

   /**
* Protege name: logs
   */
   private String logs;
   public void setLogs(String value) { 
    this.logs=value;
   }
   public String getLogs() {
     return this.logs;
   }

}
