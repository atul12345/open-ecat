package it.itc.sra.ecat.ecatplugin.preferences;

import it.itc.sra.ecat.ECATPlugIn;

import org.eclipse.core.runtime.preferences.AbstractPreferenceInitializer;
import org.eclipse.jface.preference.IPreferenceStore;

public class PreferenceInitializer extends AbstractPreferenceInitializer
{

    public PreferenceInitializer()
    {
    }

    public void initializeDefaultPreferences()
    {
        IPreferenceStore store = ECATPlugIn.getDefault().getPreferenceStore();
        
        store.setDefault(PreferenceConstants.P_PORT, "1100");
        store.setDefault(PreferenceConstants.P_HOST, "localhost");
        String defaultLogFile = ECATPlugIn.getDefault().getPluginPath().toOSString() + "log.txt"; 
        store.setDefault(PreferenceConstants.P_LOG, defaultLogFile);
        
        store.setDefault(PreferenceConstants.P_MAX_MONITORING_LOG, 200);
        store.setDefault(PreferenceConstants.P_ENABLE_MONITORING, true);
        
        store.setDefault(PreferenceConstants.P_SHOW_GUI, false);
        store.setDefault(PreferenceConstants.P_RUN_SEPARATE_JADE, true);
        store.setDefault(PreferenceConstants.P_JADE_PARAM, "");
    }
}
