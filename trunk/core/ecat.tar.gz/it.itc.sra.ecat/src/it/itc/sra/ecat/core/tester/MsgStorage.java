/**
 * <copyright>
 *
 * eCAT - Tool for Continuous Testing Agent for the JADE/Eclipse Platform
 * Copyright (C) ITC-IRST, Trento, Italy
 * Authors: Duy Cu Nguyen
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 * The electronic copy of the license can be found here:
 * http://sra.itc.it/tools/taom/freesoftware/gpl.txt
 *
 * The contact information:
 * e-mail: cunduy@itc.it
 * site: http://sra.itc.it
 *
 * </copyright>
 */

package it.itc.sra.ecat.core.tester;

import it.itc.sra.ecat.core.ECATExeption;
import it.itc.sra.ecat.testsuiteman.domaindata.DomainData;
import it.itc.sra.ecat.testsuiteman.domaindata.DomainData.DataElement;
import it.itc.sra.ecat.testsuiteman.testsuite.ContentType;
import it.itc.sra.ecat.testsuiteman.testsuite.FipaMessageType;
import it.itc.sra.ecat.testsuiteman.testsuite.ObjectFactory;
import it.itc.sra.ecat.util.CommonUtil;
import it.itc.sra.ecat.util.GlobalConstants;
import it.itc.sra.ecat.util.JAXBUtil;

import jade.lang.acl.ACLMessage;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

public class MsgStorage {
	private ArrayList<FipaMessageType> msgStorage;
	private ArrayList<String> key;

	
	public MsgStorage() {
		msgStorage = new ArrayList<FipaMessageType>();
		key = new ArrayList<String>();
	}
	
	
	/**
	 * Add a message in my customized format FipaMessage
	 * @param msg
	 */
	public void add(FipaMessageType msg){
		
		String tmp = (msg != null) ? msg.getContent().getValue() : null;
		if (tmp != null && !key.contains(tmp)){
			msgStorage.add(msg);
			key.add(tmp);
		}
	}
	
	/**
	 * Add an ACLMessage
	 * @param msg
	 */
	public void add(ACLMessage msg){
		// Transform ACLMessage to FipaMessage
		
		if (msg == null) return;
		
		String tmp = msg.getContent();
		if (tmp != null && !key.contains(tmp)){
			
			ObjectFactory testCaseFactory = new ObjectFactory();
			Random ran = new Random();
			String perf[] = ACLMessage.getAllPerformativeNames();
			
			FipaMessageType targetMsg;
			targetMsg = testCaseFactory.createFipaMessageType();

			// 2 possibilities here: get the performative returned or pick a random one				
			// targetMsg.setAct(ACLMessage.getPerformative(msg.getPerformative()) );
			targetMsg.setAct(perf[ran.nextInt(perf.length)]);
			
			//targetMsg.setConversationId(msg.getConversationId());

			targetMsg.setConversationId(msg.getConversationId());
			
			ContentType c = new ContentType();
			c.setValue(msg.getContent());
			c.setClazz("String");
			targetMsg.setContent(c);
			
			if (msg.getLanguage() != null) {
				targetMsg.setLanguage(msg.getLanguage());
			}
			
			if (msg.getOntology() != null){
				targetMsg.setOntology(msg.getOntology());
			}
			
			msgStorage.add(targetMsg);
			key.add(tmp);
		}
	}
	
	/**
	 * Get the size of the storage
	 * @return
	 */
	public int size(){
		return msgStorage.size();
	}
	
	
	/**
	 * Get an item according to a specific index
	 * @param index
	 * @return
	 */
	public FipaMessageType get(int index){
		if (index >=0 && index < msgStorage.size()){
			return msgStorage.get(index);
		}
		return null;
	}
	
	/**
	 * Add a list of ACLMessage to the storage
	 * @param aclList
	 */
	public void add(List<ACLMessage> aclList){
		if (aclList != null){
			Iterator<ACLMessage> iter = aclList.iterator();
			while (iter.hasNext()){
				ACLMessage msg = iter.next();
				add(msg);
			}
		}
	}
	
	/**
	 * Init the storage based on predefined messages database
	 * @param dbPath
	 */
	public void init(String dbPath){
		try {
			DomainData domainData = (DomainData) JAXBUtil.loadJAXBFromFile(GlobalConstants.DOMAINDATA_PKG, dbPath);
			Random ran = new Random();
			String perf[] = ACLMessage.getAllPerformativeNames();
 			
			if (domainData.getDataElement() != null){
				Iterator<DataElement> iter = domainData.getDataElement().iterator();
				
				while (iter.hasNext()){
					DataElement dataElement = iter.next();
					String content = (String)dataElement.getContent();
					
					//if (content != null && !key.contains(content))
					ObjectFactory testCaseFactory = new ObjectFactory();
					
					FipaMessageType targetMsg;
					targetMsg = testCaseFactory.createFipaMessageType();
					
					// Randomly picked
					targetMsg.setAct(perf[ran.nextInt(perf.length)]);
					
					//targetMsg.setConversationId(CommonUtil.generateId("DD"));

					targetMsg.setConversationId(CommonUtil.generateId("DD"));
					// Interesting part, pick randomly a data
					
					if (domainData.getComInfo() != null){
						if (domainData.getComInfo().getOntology() != null){
							targetMsg.setOntology(domainData.getComInfo().getOntology());
						}
						
						if (domainData.getComInfo().getLanguage() != null){
							targetMsg.setLanguage(domainData.getComInfo().getLanguage());
						}
					}
					ContentType c = new ContentType();
					c.setValue(content);
					c.setClazz("String");
					targetMsg.setContent(c);
										
					// Assume that domain data is consistent (no redundant or repeated data)
					key.add(content);
					msgStorage.add(targetMsg);
				}
			}
			
		} catch (ECATExeption e) {
			e.printStackTrace();
		}
	}
}
