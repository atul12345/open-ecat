/**
 * <copyright>
 *
 * eCAT - Tool for Continuous Testing Agent for the JADE/Eclipse Platform
 * Copyright (C) ITC-IRST, Trento, Italy
 * Authors: Duy Cu Nguyen
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 * The electronic copy of the license can be found here:
 * http://sra.itc.it/tools/taom/freesoftware/gpl.txt
 *
 * The contact information:
 * e-mail: cunduy@itc.it
 * site: http://sra.itc.it
 *
 * </copyright>
 */

package it.itc.sra.ecat.ecatplugin.views;

import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import javax.xml.bind.JAXBElement;

import it.itc.sra.ecat.ECATPlugIn;
import it.itc.sra.ecat.core.ECATExeption;
import it.itc.sra.ecat.core.TestResultsModel;
import it.itc.sra.ecat.core.TestResultsModel.NodeTestStatus;
import it.itc.sra.ecat.testsuiteman.testconfig.NodeType;
import it.itc.sra.ecat.testsuiteman.testconfig.TestConfig;
import it.itc.sra.ecat.testsuiteman.testsuite.ObjectFactory;
import it.itc.sra.ecat.testsuiteman.testsuite.TestCaseType;
import it.itc.sra.ecat.testsuiteman.testsuite.TestSuite;
import it.itc.sra.ecat.util.GlobalConstants;
import it.itc.sra.ecat.util.JAXBUtil;

import org.eclipse.jface.resource.JFaceResources;
import org.eclipse.jface.viewers.DoubleClickEvent;
import org.eclipse.jface.viewers.IDoubleClickListener;
import org.eclipse.jface.viewers.IStructuredContentProvider;
import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseListener;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.forms.widgets.FormText;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.forms.widgets.ScrolledForm;
import org.eclipse.ui.forms.widgets.Section;
import org.eclipse.ui.forms.widgets.TableWrapData;
import org.eclipse.ui.forms.widgets.TableWrapLayout;
import org.eclipse.ui.part.ViewPart;

public class TestResultView extends ViewPart implements ITestModelListener {

	private TestResultsModel model;

	private TableViewer viewer;
	private ScrolledForm form;
	private Composite parent;
	private FormText detailedResults;
	private Section detailedSection;
	
	Label labelGenOrCycle;
	Label labelNumberOfTestCase;
	
	private static final String numberFormat = "00000";

	public TestResultView() {
		super();
		model = ECATPlugIn.getDefault().getTestResultModel();
		model.addModelListener(this);
	}

	
	private String formatNumber(int value){
		
		String tmp = String.valueOf(value);
		if (tmp.length() > numberFormat.length()) 
			return tmp;
		
		return numberFormat.substring(0, numberFormat.length() - tmp.length()) + tmp;
		
	}
	
	@Override
	public void createPartControl(Composite parent) {
		
		this.parent = parent;
		
		FormToolkit toolkit = new FormToolkit(parent.getDisplay());
		form = toolkit.createScrolledForm(parent);
		form.setText("ECAT Testing Results");
		form.setBackgroundImage(ECATPlugIn.getDefault().getImage(
				ECATPlugIn.IMG_FORM_BG));
		//form.getBody().setLayout(new GridLayout(4, true));
		TableWrapLayout layout = new TableWrapLayout();
		layout.numColumns = 4;
		layout.makeColumnsEqualWidth = true;
		
		
		form.getBody().setLayout(layout);

		// Show general information
		Label label = toolkit.createLabel(form.getBody(), "Generation / Cycle: ");
		//GridData gd = new GridData(GridData.BEGINNING);
		TableWrapData td = new TableWrapData(TableWrapData.RIGHT);
		
		label.setLayoutData(td);
		
		String tmp = numberFormat;
		if (model != null)
			tmp = formatNumber(model.getTestCycle());
		
		labelGenOrCycle = toolkit.createLabel(form.getBody(), tmp, SWT.FILL);
		//gd = new GridData(GridData.BEGINNING | GridData.FILL_HORIZONTAL);
		td = new TableWrapData(TableWrapData.LEFT);
		td.grabHorizontal = true;
		labelGenOrCycle.setLayoutData(td);
		
		label = toolkit.createLabel(form.getBody(), "Number of test cases: ");
		//gd = new GridData(GridData.BEGINNING);
		td = new TableWrapData(TableWrapData.RIGHT);
		label.setLayoutData(td);
		
		tmp = numberFormat;
		if (model != null)
			tmp = formatNumber(model.getNumTestCase());
		
		
		labelNumberOfTestCase = toolkit.createLabel(form.getBody(), tmp, SWT.FILL);
		//gd = new GridData(GridData.BEGINNING | GridData.FILL_HORIZONTAL);
		td = new TableWrapData(TableWrapData.LEFT);
		td.grabHorizontal = true;
		labelNumberOfTestCase.setLayoutData(td);
		
		// Detailed results
		
		Table t = toolkit.createTable(form.getBody(), SWT.NONE);
		//gd = new GridData(GridData.FILL_HORIZONTAL);
		//gd.heightHint = 300;
		//gd.horizontalSpan = 4;
		td = new TableWrapData(TableWrapData.FILL_GRAB);
		td.heightHint = 300;
		td.colspan = 4;
		t.setLayoutData(td);

		viewer = new TableViewer(t);
		TableColumn column = new TableColumn(viewer.getTable(), SWT.LEFT);
		column.setText("Test case");
		column.setWidth(250);

		TestConfig testConfig = model.getTestConfig();
		
		if (testConfig != null && testConfig.getDitributedNodeConfig() != null){
			List nodes =  testConfig.getDitributedNodeConfig().getNode();
			Iterator iter = nodes.iterator();
			while (iter.hasNext()){
				NodeType node = (NodeType)iter.next();
				column = new TableColumn(viewer.getTable(), SWT.LEFT);
				column.setText("Node: " + node.getNodeHap());
				column.setWidth(100);
			}
		}

		viewer.getTable().setHeaderVisible(true);
		
		/*
		viewer.addSelectionChangedListener(new ISelectionChangedListener() {
			public void selectionChanged(SelectionChangedEvent event) {
				// managedForm.fireSelectionChanged(spart,
				// event.getSelection());
			}
		});
		*/
		viewer.addDoubleClickListener(new IDoubleClickListener() {

			public void doubleClick(DoubleClickEvent event) {
				Object obj = event.getSelection();
				if (obj instanceof StructuredSelection) {
					StructuredSelection selectedObj = (StructuredSelection)obj;
					Object xmlObject = selectedObj.getFirstElement();
					if (xmlObject != null){
						
						if (xmlObject instanceof TestSuite) {
							displayXmlObject(xmlObject);
						} else if (xmlObject instanceof TestCaseType){
							ObjectFactory factory = new ObjectFactory();
							JAXBElement<TestCaseType> testCaseRoot = factory.createTestCase((TestCaseType) xmlObject);
							displayXmlObject(testCaseRoot);
						}
					}
					
				}
			}
			
		});
		
		
		viewer.setContentProvider(new TableContentProvider());
		viewer.setLabelProvider(new TableLabelProvider());

		viewer.setInput(model);
		//viewer.refresh();
		
		////////////////////////////////////////////////////////////////////////
		// Text model
		
		detailedSection = toolkit.createSection(form.getBody(), Section.TWISTIE);
		detailedSection.setText("Detailed results");

		//GridData td = new GridData(GridData.FILL_HORIZONTAL);
		td = new TableWrapData(TableWrapData.FILL_GRAB);
		td.colspan = 4;
		td.grabHorizontal = true;
		td.grabVertical = true;
		//td.horizontalSpan = 4;
		//td.heightHint = 300;
		detailedSection.setLayoutData(td);
		detailedSection.addMouseListener(new MouseListener(){

			public void mouseDoubleClick(MouseEvent e) {
			}

			public void mouseDown(MouseEvent e) {
				//if (detailedSection.isExpanded()){
					detailedResults.setText(model.getTestReport(), true, false);
				//}
			}

			public void mouseUp(MouseEvent e) {
				detailedResults.setText(model.getTestReport(), true, false);
			}
			
		});
		
		toolkit.createCompositeSeparator(detailedSection);

		Composite client1 = toolkit.createComposite(detailedSection, SWT.TOP | SWT.BORDER);
		client1.setLayout(new TableWrapLayout());
		//client1.setLayoutData(td);

		detailedResults = toolkit.createFormText(client1, false);
		//TableWrapData twd  = new TableWrapData(TableWrapData.FILL);
		//twd.heightHint = 300;
		td = new TableWrapData(TableWrapData.FILL_GRAB);
		//td.heightHint = 300;
		td.grabHorizontal = true;
		td.grabVertical = true;
		detailedResults.setLayoutData(td);
		
		detailedResults.setImage("image", ECATPlugIn.getDefault().getImageRegistry().get(ECATPlugIn.IMG_CHECKED));
		detailedResults.setImage("node", ECATPlugIn.getDefault().getImageRegistry().get(ECATPlugIn.IMG_NODE));
		
		Color headerColor = toolkit.getColors().createColor("header", 0, 0, 255);
		detailedResults.setColor("header", headerColor);
		
		Color tcheaderColor = toolkit.getColors().createColor("tcheader", 255, 0, 0);
		detailedResults.setColor("tcheader", tcheaderColor);
		
		Color passedColor = toolkit.getColors().createColor("passed", 8, 80, 10);
		detailedResults.setColor("passed", passedColor);
		
		Color failedColor = toolkit.getColors().createColor("failed", 255, 0, 0);
		detailedResults.setColor("failed", failedColor);
		
		Color codeColor = toolkit.getColors().createColor("code", 112, 92, 92);
		detailedResults.setColor("code", codeColor);
		
		detailedResults.setFont("header", JFaceResources.getTextFont());
		detailedResults.setFont("code", JFaceResources.getTextFont());
		
		
		// Initial report
		detailedResults.setText(model.getTestReport(), true, false);
		toolkit.paintBordersFor(client1);
		detailedSection.setClient(client1);
		
	}

	@Override
	public void setFocus() {
		viewer.refresh();
	}

	public class TableContentProvider implements IStructuredContentProvider {

		public Object[] getElements(Object inputElement) {

			if (inputElement != null && inputElement instanceof TestResultsModel) {
				/*
				List list = new ArrayList();
				JADETestSuites jadeTestSuites = JADETestSuites.getInstance();
				TestSuitesStorage storage = jadeTestSuites.getSuitesStorage();
				Iterator iterator = storage.iterator();

				while (iterator.hasNext()) {
					TestSuite suite = (TestSuite) iterator.next();
					list.add(suite);

					List tc = suite.getTestCase();
					Iterator iter = tc.iterator();
					while (iter.hasNext()) {
						list.add((TestCase) iter.next());
					}

				}
				*/

				return ((TestResultsModel)inputElement).getKeyObjects();

			}
			return new Object[0];
		}

		public void dispose() {
		}

		public void inputChanged(Viewer viewer, Object oldInput, Object newInput) {
		}

	}

	public class TableLabelProvider extends LabelProvider implements
			ITableLabelProvider {

		public Image getColumnImage(Object element, int columnIndex) {
			
			if (columnIndex == 0){
				if (element instanceof TestSuite) {
					return ECATPlugIn.getDefault().getImage(
							ECATPlugIn.IMG_TESTSUITE);
				} else if (element instanceof TestCaseType) {
					return ECATPlugIn.getDefault()
							.getImage(ECATPlugIn.IMG_TESTCASE);
				}
			} else {
				if (element instanceof TestCaseType) {
					TestCaseType tc = (TestCaseType) element;
					if (model != null){
						Vector v = model.getNodesTestStatus(tc);
						if (!(columnIndex > v.size())){
							NodeTestStatus nodeTestStatus = (NodeTestStatus) v.get(columnIndex - 1);
							if (nodeTestStatus.getState().equals(ITestModelListener.STATE_INITIAL)){
								return ECATPlugIn.getDefault().getImage(ECATPlugIn.IMG_TEST_WAIT);
							} else if (nodeTestStatus.getState().equals(ITestModelListener.STATE_FINAL)){
								return ECATPlugIn.getDefault().getImage(ECATPlugIn.IMG_TEST_OK);
							} else if (nodeTestStatus.getState().equals(ITestModelListener.STATE_DUM_FINAL)){
								return ECATPlugIn.getDefault().getImage(ECATPlugIn.IMG_TEST_FAILED);
							}
						}
					}
				}
				
			}
			
			return ECATPlugIn.getDefault().getImage(ECATPlugIn.IMG_TEST_TS_DEFAULT);
		}

		public String getColumnText(Object element, int columnIndex) {
			if (columnIndex == 0) {
				if (element instanceof TestSuite) {
					TestSuite ts = (TestSuite) element;
					return ts.getID() + ": " + ts.getName();
				} else if (element instanceof TestCaseType) {
					TestCaseType tc = (TestCaseType) element;
					return "  " + tc.getID() + ": " + tc.getName();
				}
			} else {
				if (element instanceof TestCaseType) {
					TestCaseType tc = (TestCaseType) element;
					if (model != null){
						Vector v = model.getNodesTestStatus(tc);
						if (!(columnIndex > v.size())){
							NodeTestStatus nodeTestStatus = (NodeTestStatus) v.get(columnIndex - 1);
							if (nodeTestStatus.getState().equals(ITestModelListener.STATE_INITIAL)){
								return " testing...";
							} else if (nodeTestStatus.getState().equals(ITestModelListener.STATE_FINAL)){
								return " PASSED";
							} else if (nodeTestStatus.getState().equals(ITestModelListener.STATE_DUM_FINAL)){
								return " FAILED";
							}
						}
					}
				}
			}
			return "";
		}

	}

	
	/** 
	 * Handle test change
	 */
	public void modelChanged(final TestCaseType tc, String state, String propery) {
		if (propery.equals(ITestModelListener.PROPERTY_RESULT)) {
			parent.getDisplay().asyncExec(new Runnable(){
	
				public void run() {
					//viewer.update(tc, null);
					//form.redraw();
					viewer.refresh(tc, true);
					if (detailedSection.isExpanded()){
						detailedResults.setText(model.getTestReport(), true, false);
					}
				}
				
			});
		} else if (propery.equals(ITestModelListener.PROPERTY_CYCLE)) {
			parent.getDisplay().asyncExec(new Runnable(){

				public void run() {
					labelGenOrCycle.setText(formatNumber(model.getTestCycle()));
					labelNumberOfTestCase.setText(formatNumber(model.getNumTestCase()));
				}
				
			});
		} else if (propery.equals(ITestModelListener.PROPERTY_ADDNEW) 
				|| propery.equals(ITestModelListener.PROPERTY_REMOVE)) {
			parent.getDisplay().asyncExec(new Runnable(){

				public void run() {
					viewer.refresh(); // Refresh all
				}
				
			});
		}
	}

	@Override
	public void dispose() {
		model.removeModelListener(this);
		super.dispose();
	}
	
	private void displayXmlObject(final Object xmlObject) {
		String stubPackage = GlobalConstants.TESTSUITE_PACKAGE_STUBS;
		try {
			
			final String xmlString = JAXBUtil.transformJAXBToString(stubPackage, xmlObject);
				
			final IWorkbenchPage page = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();
			parent.getDisplay().asyncExec(new Runnable() {

				public void run() {
					IWorkbenchPart ev = page.findView("it.itc.sra.ecat.ecatplugin.views.TestDataView");
	    			if (ev == null) {
	    				try {
							page.showView("it.itc.sra.ecat.ecatplugin.views.TestDataView");
							ev = page.findView("it.itc.sra.ecat.ecatplugin.views.TestDataView");
						} catch (PartInitException e) {
							e.printStackTrace();
						}
	    			}
	    			
	    			if (ev != null) {
						final TestDataView p = (TestDataView) ev.getAdapter(TestDataView.class);
						
						String title = "";
						if (xmlObject instanceof TestCaseType) {
							title = "Test Case: " + ((TestCaseType)xmlObject).getName();
						} else if (xmlObject instanceof TestSuite){
							title = "Test Suite: " + ((TestSuite)xmlObject).getName();
						}
						
	    				if (!title.equals("")) {
	    					p.setText(title, xmlString);
	    				} else {
	    					p.setText(xmlString);
	    				}
	    				
	    				p.setFocus();
	    			}

				}
				
			});
			
		} catch (ECATExeption e) {
			e.printStackTrace();
		}
		
	}
}
