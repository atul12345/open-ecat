/**
 * <copyright>
 *
 * eCAT - Tool for Continuous Testing Agent for the JADE/Eclipse Platform
 * Copyright (C) ITC-IRST, Trento, Italy
 * Authors: Duy Cu Nguyen
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 * The electronic copy of the license can be found here:
 * http://sra.itc.it/tools/taom/freesoftware/gpl.txt
 *
 * The contact information:
 * e-mail: cunduy@itc.it
 * site: http://sra.itc.it
 *
 * </copyright>
 */

package it.itc.sra.ecat.core.monitor;


import it.itc.sra.ecat.ECATPlugIn;
import it.itc.sra.ecat.core.MonitoringNodeModel;
import it.itc.sra.ecat.ecatplugin.preferences.PreferenceConstants;
import it.itc.sra.ecat.ecatplugin.views.IModelListener;
import it.itc.sra.ecat.monitordata.EventType;
import it.itc.sra.ecat.monitordata.KindType;
import it.itc.sra.ecat.monitordata.MonitoringTrace;
import it.itc.sra.ecat.monitordata.SessionType;
import it.itc.sra.ecat.util.CommonUtil;
import it.itc.sra.ecat.util.MonitorLogger;

import java.io.StringWriter;
import java.util.List;

public class RemoteMonitoringLogs {
	
	private static int maxLogLength = ECATPlugIn.getDefault().getPluginPreferences().getInt(PreferenceConstants.P_MAX_MONITORING_LOG);
	
	static {
		if (maxLogLength < 10){
			maxLogLength = 100; // default
		}
	}
	
	MonitoringNodeModel nodeModel;
	MonitorLogger logger = MonitorLogger.getInstance();
	
	private StringWriter out = null;
    private MonitoringTrace monitorTrace = null;
    
	public RemoteMonitoringLogs() {
		out = new StringWriter();
		monitorTrace = new MonitoringTrace();
	}

	public synchronized void log(String logMsg) {
		 out.write(logMsg + "\n");
		 out.write("--------------------\n");
		 nodeModel.fireModelChanged(IModelListener.LOGS, "");
	}
	
	public String getLogs(){
		return out.toString();
	}
	
	public void resetLog(){
		out.getBuffer().setLength(0);
	}
	
	public synchronized void monitor(SessionType sessionTrace) {
		monitorTrace.getSession().add(sessionTrace);
		nodeModel.fireModelChanged(IModelListener.REPORTS, "");
	}
	
	public String getMonitorLogs(){
		StringBuffer buff = new StringBuffer();
		buff.append("<form>");
		
		List<SessionType> list =  monitorTrace.getSession();
		for (SessionType s : list){
			//buff.append("<p>");
			//buff.append("<span color=\"header\" font=\"header\">" +
			//		"Session: " + s.getId() + " - TS: " + s.getTestSuiteID()+ " - TC: " + s.getTestCaseID() + "</span>");
			//buff.append("</p>");
			buff.append("<li>" + // style=\"image\" value=\"image\
				"<span color=\"header\" font=\"header\">" );
			buff.append("TS: " + s.getTestSuiteID()+ " - TC: " + s.getTestCaseID() + " / Session: " + s.getId());
			buff.append("</span></li>");
			
			List<EventType> events = s.getEvent();
			for (EventType e : events){
				buff.append("<p>");
				if (e.getKind().equals(KindType.AGENTBORN)){
					buff.append("<span color=\"ok\" font=\"header\">Agent born</span></p>");
				} else if (e.getKind().equals(KindType.AGENTDEAD)){
					buff.append("<span color=\"nok\" font=\"header\">Agent dead</span></p>");
				} else if (e.getKind().equals(KindType.AGENTMOVE)){
					buff.append("<span color=\"ok\" font=\"header\">Agent move</span></p>");
				} else if (e.getKind().equals(KindType.CONSTRAINT_VIOLATED)){
					buff.append("<span color=\"nok\" font=\"header\">Constraint violated</span></p>");
				} else if (e.getKind().equals(KindType.COMMUNICATION)){
					buff.append("<span color=\"ok\" font=\"header\">Interaction</span></p>");
				} else if (e.getKind().equals(KindType.NEWSTATE)){
					buff.append("<span color=\"ok\" font=\"header\">New state</span></p>");
				} else if (e.getKind().equals(KindType.TRANSITION)){
					buff.append("<span color=\"ok\" font=\"header\">Transition</span></p>");	
				} else {
					// Exception
					buff.append("<span color=\"nok\" font=\"header\">Exception occurs</span></p>");
				}
				buff.append("<p>When: <b>" + e.getWhen() + "</b></p>");
				if (e.getKind().equals(KindType.COMMUNICATION)){
					buff.append("<p>From: <b>" + e.getSender() + "</b>");
					buff.append(" To: <b>" + e.getReceiver() + "</b></p>");
				} else if (e.getKind().equals(KindType.AGENTMOVE)){
					buff.append("<p>From: <b>" + e.getWhere() + "</b>");
					buff.append(" To: <b>" + e.getTowhere() + "</b></p>");
				} else if (e.getWhere() != null) {
					buff.append("<p>Where: <b>" + e.getWhere() + "</b></p>");
				}
				buff.append("<p><b>Event details:</b></p>");
				buff.append("<p><span font=\"code\" color=\"code\">");
				
				// Extract one part of the content
				String str = e.getContent();
				if (str.length() > maxLogLength && e.getKind().equals(KindType.COMMUNICATION)){
					str = str.substring(0, maxLogLength);
				}
				
				buff.append(CommonUtil.normalizeXML(str));		
				buff.append("</span></p>");
			}
		}
		
		buff.append("</form>");
		return buff.toString();
	}
	
	public void resetMonitor(){
		monitorTrace.getSession().clear();
	}
	
	public void setNodeModel(MonitoringNodeModel nodeView) {
		this.nodeModel = nodeView;
	}

	public SessionType getSessionType(String sessionID){
		List<SessionType> list = monitorTrace.getSession();
		for (SessionType s : list){
			if (s.getId().equals(sessionID))
				return s;
		}
		return null;
	}
}
