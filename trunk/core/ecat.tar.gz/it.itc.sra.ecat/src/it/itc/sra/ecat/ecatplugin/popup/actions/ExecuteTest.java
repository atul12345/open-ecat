/**
 * <copyright>
 *
 * eCAT - Tool for Continuous Testing Agent for the JADE/Eclipse Platform
 * Copyright (C) ITC-IRST, Trento, Italy
 * Authors: Duy Cu Nguyen
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 * The electronic copy of the license can be found here:
 * http://sra.itc.it/tools/taom/freesoftware/gpl.txt
 *
 * The contact information:
 * e-mail: cunduy@itc.it
 * site: http://sra.itc.it
 *
 * </copyright>
 */

package it.itc.sra.ecat.ecatplugin.popup.actions;

import it.itc.sra.ecat.ECATPlugIn;
import it.itc.sra.ecat.core.ECATExeption;
import it.itc.sra.ecat.core.Interaction;
import it.itc.sra.ecat.ecatplugin.views.MonitoringLogsView;
import it.itc.sra.ecat.ecatplugin.views.TestResultView;
import it.itc.sra.ecat.testsuiteman.JADETestSuites;
import it.itc.sra.ecat.testsuiteman.testconfig.TestConfig;
import it.itc.sra.ecat.util.GeneralLogger;
import it.itc.sra.ecat.util.JAXBUtil;
import it.itc.sra.ecat.util.Validator;

import java.util.ArrayList;
import java.util.Iterator;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.ui.IObjectActionDelegate;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PartInitException;


public class ExecuteTest implements IObjectActionDelegate {

	/** workbench part owing action selection element */
	private IWorkbenchPart targetPart;
	private IFile[] selectedFiles; // Selected file to proceed
	private String PACKAGE_STUBS = "it.itc.sra.ecat.testsuiteman.testconfig";
	private GeneralLogger logger = GeneralLogger.getInstance();

	
	
	public ExecuteTest() {
		super();
		// logger.log(GeneralLogger.LEVEL_INFO, "Launch ExecuteTest !");
	}

	public void setActivePart(IAction action, IWorkbenchPart targetPart) {
		this.targetPart = targetPart;
	}

	public void run(IAction action) {

		if (!ECATPlugIn.getDefault().isTesterReady()) {
			MessageDialog.openInformation(targetPart.getSite().getShell(), "Not Ready",
					"The tester agent has not been ready yet, Please start it!");
			return;
		}
		
		if (selectedFiles != null) {
			ClassLoader cl = Thread.currentThread().getContextClassLoader();
			try {
				Thread.currentThread().setContextClassLoader(
						getClass().getClassLoader());
				Thread t = new Thread(new Runnable() {
					public void run() {
						for (int i = 0; i < selectedFiles.length; i++) {
							IFile file = selectedFiles[i];
							try {
								
								if (ECATPlugIn.getDefault().getTesterAgent().isRunningTest()){
									targetPart.getSite().getShell().getDisplay().asyncExec(new Runnable(){
										public void run() {
												MessageDialog.openWarning(targetPart.getSite().getShell(), "Warning!",
												"Another test in under execution!");
										}
									});
									return;
								}
								
								TestConfig testConfig = (TestConfig) JAXBUtil.loadJAXBFromFile(
										PACKAGE_STUBS,
										file.getLocation().toString());
								
								// validate test configuration
								if (!Validator.validate(testConfig)){
									targetPart.getSite().getShell().getDisplay().asyncExec(new Runnable(){
										public void run() {
											MessageDialog.openError(targetPart.getSite().getShell(), "Error", 
													Validator.errorMessage);
										}
									});
									return;
								}
								
								// Load test suites
								JADETestSuites jadeTestSuites = JADETestSuites.getInstance();
								jadeTestSuites.loadTestSuites(testConfig);
								
								// Set the TestConfig to the current test
								// configuration
								ECATPlugIn.getDefault().setTestConfig(testConfig);

								// update test result model
								ECATPlugIn.getDefault().getTestResultModel().init(testConfig);
								
								// Update monitoring model data
								ECATPlugIn.getDefault().getMonitorModel().update(testConfig);
								refreshView();
								
								
								// Start monitoring
								ECATPlugIn.getDefault().getMonitorAgent().restartMonitoring(testConfig);

								// Perform the test
								Interaction interact = new Interaction(testConfig);
								ECATPlugIn.getDefault().getTesterAgent().performTest(interact);

							} catch (ECATExeption e) {
								e.printStackTrace();
							}
						}
					}
				});
				t.start();
			} catch (Exception e) {
				e.printStackTrace(logger.getOut());
			} finally {
				Thread.currentThread().setContextClassLoader(cl);
			}
		}
	}

	public void selectionChanged(IAction action, ISelection selection) {
		ArrayList newFiles = new ArrayList();
		IFile file = null;
		if (selection != null && selection instanceof IStructuredSelection) {
			IStructuredSelection ss = (IStructuredSelection) selection;

			for (Iterator iter = ss.iterator(); iter.hasNext();) {
				Object obj = iter.next();
				if (obj instanceof IFile) {
					file = (IFile) obj;
				} else if (obj instanceof IAdaptable) {
					IAdaptable a = (IAdaptable) obj;
					IResource res = (IResource) a.getAdapter(IResource.class);
					if (res instanceof IFile) {
						file = (IFile) res;
					}
				}

				if (file != null && file.isSynchronized(IResource.DEPTH_ZERO)) {
					newFiles.add(file);
				} else if (!file.isSynchronized(IResource.DEPTH_ZERO)) {
					MessageDialog.openInformation(targetPart.getSite().getShell(), "Synchronization error",
					"The selected file is not synchronized with the system file, please refresh the project!");
				}
			}
		}

		if (newFiles.isEmpty()) {
			selectedFiles = null;
			// action.setEnabled(false);
		} else {
			selectedFiles = (IFile[]) newFiles.toArray(new IFile[newFiles.size()]);
			// action.setEnabled(true);
		}
	}

	// @Override
	/*
	 * public void init(IAction action) { //if
	 * (ECATPlugIn.getDefault().isTesterReady()){ action.setEnabled(true); //} }
	 */
	
	public boolean refreshView() {
    	// IWorkbench workbench = PlatformUI.getWorkbench();
    	// IWorkbenchWindow window = workbench.getActiveWorkbenchWindow();
    	
    	IWorkbenchWindow window = targetPart.getSite().getWorkbenchWindow();
    	final String monitoringViewID = "it.itc.sra.ecat.ecatplugin.views.MonitoringLogsView";
    	final String resultsViewID = "it.itc.sra.ecat.ecatplugin.views.TestResultView";
    	
    	if (window != null) {
    		final IWorkbenchPage page = window.getActivePage();
    		if (page != null) {
    			window.getShell().getDisplay().asyncExec(new Runnable(){
					public void run() {
						IWorkbenchPart ev;
						if (ECATPlugIn.getDefault().isMonitoringEnable()){
							ev = page.findView(monitoringViewID);
			    			if (ev == null) {
			    				
								try {
									page.showView(monitoringViewID);
								} catch (PartInitException e) {
									e.printStackTrace();
								}
			    			} else {
			    				final MonitoringLogsView p = (MonitoringLogsView) ev.getAdapter(MonitoringLogsView.class);
			    				try {
									// p.dispose();
									page.hideView(p);
									page.showView(monitoringViewID);
								} catch (PartInitException e) {
									e.printStackTrace();
								}
			    			}
						}
		    			// Refresh test result view
		    			ev = page.findView(resultsViewID);
		    			if (ev != null) {
		    				TestResultView resultView = (TestResultView)ev.getAdapter(TestResultView.class);
		    				page.hideView(resultView);
		    				try {
								page.showView(resultsViewID);
							} catch (PartInitException e) {
								e.printStackTrace();
							}
		    				//resultView.setTestConfig(ECATPlugIn.getDefault().getTestConfig());
		    			} else {
		    				try {
								page.showView(resultsViewID);
							} catch (PartInitException e) {
								e.printStackTrace();
							}
		    			}
					}
						
				});
    		}
    		return false;
    	}
    	return false;
    }


}
