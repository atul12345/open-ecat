/**
 * <copyright>
 *
 * eCAT - Tool for Continuous Testing Agent for the JADE/Eclipse Platform
 * Copyright (C) ITC-IRST, Trento, Italy
 * Authors: Duy Cu Nguyen
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 * The electronic copy of the license can be found here:
 * http://sra.itc.it/tools/taom/freesoftware/gpl.txt
 *
 * The contact information:
 * e-mail: cunduy@itc.it
 * site: http://sra.itc.it
 *
 * </copyright>
 */

package it.itc.sra.ecat.ecatplugin.generatewizards;

import java.io.File;
import java.util.Map;

import it.itc.sra.ecat.ECATPlugIn;
import it.itc.sra.ecat.core.ECATExeption;
import it.itc.sra.ecat.ecatplugin.preferences.PreferenceConstants;
import it.itc.sra.ecat.testsuiteman.generation.ManualGenerator;
import it.itc.sra.ecat.testsuiteman.protocollist.ProtocolType;
import it.itc.sra.ecat.testsuiteman.testsuite.TestCaseType;
import it.itc.sra.ecat.testsuiteman.testsuite.TestSuite;
import it.itc.sra.ecat.util.CommonUtil;
import it.itc.sra.ecat.util.GlobalConstants;
import it.itc.sra.ecat.util.JAXBUtil;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.INewWizard;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.dialogs.WizardNewFileCreationPage;

public class CreateTestSuite extends Wizard implements INewWizard {

	private String autName = ""; // agent under test
	private ScenariosPage scenarioPage;
	private SuiteFileCreationPage filePage;

	protected IStructuredSelection selection;
	protected IWorkbench workbench;

	@Override
	public boolean performFinish() {
		// save info

		ECATPlugIn.getDefault().getPreferenceStore().setValue(
				PreferenceConstants.P_AGENT_UT, autName);

		if (autName == null || autName.equals("")) {
			MessageDialog.openInformation(null, "Agent under test identifier",
					" ID of the agent under test cannot be null");
			return false;
		}
		final String tsFile = filePage.getSuiteFile();
		Job generateJob = new Job("Create test suite ...") {

			@Override
			protected IStatus run(IProgressMonitor monitor) {

				Map<ProtocolType, Boolean> selectedScenarios = scenarioPage
						.getSelectedScenarios();
				
				IPath path = ECATPlugIn.getDefault().getPluginPath();
				IPath scenarioTemplatesPath  =  path.append("data").append("protocol").append("ProtocolList.xml");

				ManualGenerator generator = new ManualGenerator();
				generator.resetCounter();

				TestSuite ts = generator.createTestSuite(autName,
						"unspecified", "unspecified", "Means-End");

				if (selectedScenarios.size() > 0) {
					monitor.beginTask("Creating test suite...", selectedScenarios.size());
					for (ProtocolType proto : selectedScenarios.keySet()) {
						monitor.worked(1);
						if (selectedScenarios.get(proto).booleanValue()) {

							monitor.setTaskName(proto.getName());
							
							String scenarioPath = proto.getPath();
							String absolutePath = "";
							// Auto detect if the path is relative or
							// absolute
							if (scenarioPath.indexOf(File.separatorChar) >= 0
									&& (scenarioPath.indexOf(".") != 0)) {
								// absolute
								absolutePath = scenarioPath;
							} else if (scenarioPath.indexOf(File.separatorChar) >= 0
									&& scenarioPath.indexOf(".") == 0) {
								// relative
								absolutePath = scenarioTemplatesPath
										.removeLastSegments(1).append(
												scenarioPath.substring(1))
										.toOSString();
							} else {
								// relative
								absolutePath = scenarioTemplatesPath
										.removeLastSegments(1).append(
												scenarioPath).toOSString();
							}

							TestCaseType tc = generator.createTestCase(autName,
									"TesterAgent", "To-be-specified",
									absolutePath);
							CommonUtil.createLinks(tc);
							ts.getTestCase().add(tc);
						}
					}
				} else { // Default scenario
					TestCaseType tc = generator.createPilotTestCase(
							autName, "TesterAgent", "To-be-specified");

					CommonUtil.createLinks(tc);
					ts.getTestCase().add(tc);
				}

				// Save test suite
				
				

				try {
					JAXBUtil.saveJAXBToFile(
							GlobalConstants.TESTSUITE_PACKAGE_STUBS, ts,
							tsFile);
				} catch (ECATExeption e) {
					e.printStackTrace();
				}

				return new Status(IStatus.OK, "eCAT Plugin", IStatus.OK,
						"Finish Generating Test Suites!", null);
			}

		};

		generateJob.schedule();

		return true;
	}

	public void init(IWorkbench workbench, IStructuredSelection selection) {
		this.selection = selection;
		this.workbench = workbench;

		setWindowTitle("Create test suite wizard");
		ImageDescriptor imgDes = ECATPlugIn.getDefault().getImageDescriptor(
				ECATPlugIn.IMG_WIZARD_BG);
		setDefaultPageImageDescriptor(imgDes);

		autName = ECATPlugIn.getDefault().getPreferenceStore().getString(
				PreferenceConstants.P_AGENT_UT);
		
		needsProgressMonitor();
	}

	@Override
	public void addPages() {

		filePage = new SuiteFileCreationPage("Suite file and Agent ID",
				selection);
		filePage
				.setDescription("Choose file name and specify ID of the agent under test");

		scenarioPage = new ScenariosPage("scenarioPage");
		scenarioPage.setTitle("Select Scenario Templates");

		IPath path = ECATPlugIn.getDefault().getPluginPath();
		path = path.append("data").append("protocol")
				.append("ProtocolList.xml");
		String tmp = path.toOSString();
		// Default built-in
		scenarioPage.setPath(tmp);

		addPage(filePage);
		addPage(scenarioPage);

	}

	
	


	/**
	 * To get test suite file
	 * 
	 * @author cuduynguyen
	 * 
	 */
	public class SuiteFileCreationPage extends WizardNewFileCreationPage {

		public SuiteFileCreationPage(String pageName,
				IStructuredSelection selection) {
			super(pageName, selection);
		}

		@Override
		protected void createAdvancedControls(Composite parent) {
			super.createAdvancedControls(parent);
			Composite composite = new Composite(parent, SWT.NONE);
			GridLayout layout = new GridLayout(2, true);
			composite.setLayout(layout);

			Label label = new Label(composite, SWT.NONE);
			label.setText("ID of agent under test:");
			final Text agentID = new Text(composite, SWT.BORDER | SWT.SINGLE);
			agentID.setText(autName);

			GridData layoutData = new GridData(GridData.FILL_BOTH);
			agentID.setLayoutData(layoutData);

			agentID.addModifyListener(new ModifyListener() {

				public void modifyText(ModifyEvent e) {
					autName = agentID.getText();
				}

			});
		}

		@Override
		protected boolean validatePage() {
			if (super.validatePage()) {
				String requiredExt = "suite";
				String enteredExt = new Path(getFileName()).getFileExtension();
				if (enteredExt == null || !enteredExt.equals(requiredExt)) {
					setErrorMessage("Suite extension .suite");
					return false;
				}
			}

			return true;
		}

		public String getSuiteFile() {
			IFile file = ResourcesPlugin.getWorkspace().getRoot().getFile(getContainerFullPath().append(getFileName()));
			return file.getLocation().toOSString(); 
		}
	}

}
