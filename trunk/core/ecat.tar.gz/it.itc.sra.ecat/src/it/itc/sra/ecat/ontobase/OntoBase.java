/**
 * <copyright>
 *
 * eCAT - Tool for Continuous Testing Agent for the JADE/Eclipse Platform
 * Copyright (C) ITC-IRST, Trento, Italy
 * Authors: Duy Cu Nguyen
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 * The electronic copy of the license can be found here:
 * http://sra.itc.it/tools/taom/freesoftware/gpl.txt
 *
 * The contact information:
 * e-mail: cunduy@itc.it
 * site: http://sra.itc.it
 *
 * </copyright>
 */

package it.itc.sra.ecat.ontobase;

import it.itc.sra.ecat.core.ECATExeption;
import it.itc.sra.ecat.testsuiteman.testconfig.ClassPathType;
import it.itc.sra.ecat.testsuiteman.testconfig.CodecType;
import it.itc.sra.ecat.testsuiteman.testconfig.InputGenType;
import it.itc.sra.ecat.testsuiteman.testconfig.OntologyType;
import it.itc.sra.ecat.testsuiteman.testconfig.TestConfig;
import it.itc.sra.ecat.testsuiteman.testconfig.JavaPathType.Classpathentry;
import it.itc.sra.ecat.testsuiteman.testsuite.ContentType;
import it.itc.sra.ecat.testsuiteman.testsuite.FipaMessageType;
import it.itc.sra.ecat.testsuiteman.testsuite.AType;
import it.itc.sra.ecat.testsuiteman.testsuite.TActionType;
import it.itc.sra.ecat.testsuiteman.testsuite.TestCaseType;
import it.itc.sra.ecat.testsuiteman.testsuite.TestScenarioType;
import it.itc.sra.ecat.util.CommonUtil;
import it.itc.sra.ecat.util.GeneralLogger;
import it.itc.sra.ecat.util.GlobalConstants;
import jadex.runtime.IContentCodec;
import jadex.util.DynamicURLClassLoader;

import java.beans.BeanInfo;
import java.beans.Beans;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Array;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import edu.stanford.smi.protege.model.Cls;
import edu.stanford.smi.protege.model.Instance;
import edu.stanford.smi.protege.model.KnowledgeBase;
import edu.stanford.smi.protege.model.Project;
import edu.stanford.smi.protege.model.Slot;
import edu.stanford.smi.protege.model.ValueType;

/**
 * Work with ontologies that are supported by Protege 3.3.1
 * 
 * @author cunduy
 * 
 */
public class OntoBase {

	private static final String BEANYNIZER_CLASS = "BEANYNIZER-CLASS";
	private static final String BEANYNIZER_SLOT = "BEANYNIZER-SLOT";
//	private static final String AGENT_ACTION = "AgentAction";

	public static final Boolean VALUE_VALID = Boolean.TRUE;
	public static final Boolean VALUE_INVALID = Boolean.FALSE;

	private KnowledgeBase protegeKb;
	private String workingPackage = null;
	private IContentCodec codec;
	
	private InputGenType inputDataType;
	private InputGenType lastGenType = InputGenType.IN_VALID;

	private List<Slot> uSlots; // User defined slots
	private Map<String, Cls> uCls; // User defined classes
//	private Map<String, Cls> actionCls; // User defined AgentAction classes

	// Possible invalid values, map all to string so that it can store
	// invalid value and make it easy to manipulate message content
	private Map<Slot, List<SlotValue>> possibleSlotValues;
	private Map<String, List<ClazzValue>> possibleClsValues;

	private static GeneralLogger logger = GeneralLogger.getInstance();
	private DynamicURLClassLoader loader;
	private EnDictionary enDict = EnDictionary.getIntance();
	
	private Map<String, Integer> numValid; 	// Number of valid inputs generated, for statistic purpose
	private Map<String, Integer> numInValid;	// Number of invalid inputs generated,
	private Map<String, Integer> coverStat;
	
	
	public OntoBase() {
		loader = new DynamicURLClassLoader(this.getClass().getClassLoader());
	}

	/**
	 * Initiate all the required values 
	 * @param tconfig
	 * @return
	 */
	public boolean init(TestConfig tconfig){
		
		OntologyType oSettings =  tconfig.getOntologySetting();
		
		// For statistic purpose
		numValid = new HashMap<String, Integer>();
		numInValid  = new HashMap<String, Integer>();
		coverStat = new HashMap<String, Integer>();
		
		if (oSettings == null)
			return false;
		try {
			
			workingPackage = oSettings.getOntologyPackage();
			inputDataType = oSettings.getInputType();
			
			// TODO Initiate classpaths automatically from project setting
			List<Classpathentry> listEntries =  oSettings.getClasspath().getClasspathentry();
			for (Classpathentry entry : listEntries){
				String path = entry.getPath();
				if (entry.getKind().equals(ClassPathType.JAR)){
					try {
						URL url = new URL(path);
						loader.addURL(url);
					} catch (MalformedURLException e) {
						e.printStackTrace();
					}
				} else {
					// TODO when classpath is not a jar file
				}
			}
			
			//String ontoName = oSettings.getOntologyName();
			codec = CodecFactory.createCodec(oSettings.getCodec(), loader);
			
			// Backup current classloader
			//ClassLoader currentCl =  Thread.currentThread().getContextClassLoader();
			Thread.currentThread().setContextClassLoader(loader);
			
			String ontoPath = oSettings.getProtegeOntologyPath();
			if (!loadOntology(ontoPath))
				return false;

			// restore classloader
			// Thread.currentThread().setContextClassLoader(currentCl);
			
		} catch (ECATExeption e) {
			e.printStackTrace(logger.getOut());
			return false;
		}
		
		return true;
	}
	
	/**
	 * Load protege Ontology into the knowledge base
	 * 
	 * @param ontoPath
	 * @return
	 */
	private boolean loadOntology(String ontoPath) {
		Collection errors = new ArrayList();
		Project project = new Project(ontoPath, errors);
		if (errors.size() == 0) {
			protegeKb = project.getKnowledgeBase();

			initGenerator(); // initiate the generator
			return true;
		} else {
			// Alert user and print errors if failed to load ontology
			for (Object obj : errors){
				System.out.println(obj);
			}
		}

		return false;
	}

	/**
	 * Initialize generator for generating invalid data
	 */
	private void initGenerator() {
		uSlots = new ArrayList<Slot>();
		uCls = new HashMap<String, Cls>();
		//actionCls = new HashMap<String, Cls>();

		possibleSlotValues = new HashMap<Slot, List<SlotValue>>();
		possibleClsValues = new HashMap<String, List<ClazzValue>>();

		// Initialize all kind of classes
		if (protegeKb == null)
			return;

		Collection<Cls> clses = protegeKb.getClses();
		Iterator<Cls> iter = clses.iterator();
		while (iter.hasNext()) {
			Cls cls = (Cls) iter.next();
			if (cls.getDirectType().getName().equals(BEANYNIZER_CLASS)) {
				uCls.put(cls.getName(), cls);
				
				// Prepare possible values for this kind of class
				List<ClazzValue> valueList = getValidContents(cls);
				possibleClsValues.put(cls.getName(), valueList);
			}
		}

		// AgentAction sub class
//		Cls aCls = protegeKb.getCls(AGENT_ACTION);
//		if (aCls != null) {
//			Collection<Cls> subCls = aCls.getSubclasses();
//			Iterator<Cls> iterSubCls = subCls.iterator();
//			while (iterSubCls.hasNext()) {
//				Cls c = iterSubCls.next();
//				actionCls.put(c.getName(), c);
//			}
//		}

		// Initialize slots
		Collection<Slot> slots = protegeKb.getSlots();
		Iterator<Slot> iterSlot = slots.iterator();
		while (iterSlot.hasNext()) {
			Slot s = iterSlot.next();
			if (s.getDirectType().getName().equals(BEANYNIZER_SLOT)) {
				uSlots.add(s);

				// s.getAllowedValues()
				// s.getMaximumCardinality()
				// s.getMinimumCardinality()
				// s.getMaximumValue()
				// s.getMinimumValue()
				// s.getValues()
				// s.getDefaultValues()

				// GENERATE VALUES
				List<SlotValue> values = new ArrayList<SlotValue>();
				possibleSlotValues.put(s, values);

				// Generate valid values from specified values and default
				// values
				Collection<Cls> listDomain = s.getDomain();
				for (Cls domain : listDomain) {
					// Get instances from that domain
					Collection<Instance> ins = protegeKb.getInstances(domain);
					Iterator<Instance> insIter = ins.iterator();
					while (insIter.hasNext()) {
						Instance i = insIter.next();
						Object v = i.getOwnSlotValue(s);
						SlotValue pValue = new SlotValue(v, VALUE_VALID, 0);
						putValue(values, pValue);
					}
				}

				Collection<Object> listValue = s.getDefaultValues();
				for (Object v : listValue) {
					SlotValue pValue = new SlotValue(v, VALUE_VALID, 0);
					putValue(values, pValue);				}

				listValue = s.getAllowedValues();
				for (Object v : listValue) {
					SlotValue pValue = new SlotValue(v, VALUE_VALID, 0);
					putValue(values, pValue);
				}
				
				// TODO deal with slots of type Instance that don't have valid data

				Random ran = new Random();

				// Generate random valid + invalid value
				SlotValue pValue;

				ValueType type = s.getValueType();
				if (type.equals(ValueType.BOOLEAN)) {
					// Valid
					pValue = new SlotValue(Boolean.FALSE, VALUE_VALID, 0);
					putValue(values, pValue);

					pValue = new SlotValue(Boolean.TRUE, VALUE_VALID, 0);
					putValue(values, pValue);

					// invalid
					pValue = new SlotValue(Integer.valueOf(2), VALUE_INVALID, 0);
					putValue(values, pValue);

				} else if (type.equals(ValueType.FLOAT)) {
					// valid
					pValue = new SlotValue(Float.valueOf(0), VALUE_VALID, 0);
					putValue(values, pValue);

					float f = ran.nextFloat();
					// possitive
					pValue = new SlotValue(Float.valueOf(f), VALUE_VALID, 0);
					putValue(values, pValue);

					// negative
					pValue = new SlotValue(Float.valueOf(-f), VALUE_VALID, 0);
					putValue(values, pValue);

					// invalid
					if (s.getMaximumValue() != null){
						pValue = new SlotValue(Float.valueOf(s.getMaximumValue().floatValue() + 1)
								, VALUE_INVALID, 0);
						putValue(values, pValue);
					}
					
					if (s.getMinimumValue() != null){
						pValue = new SlotValue(Float.valueOf(s.getMinimumValue().floatValue() - 1)
								, VALUE_INVALID, 0);
						putValue(values, pValue);
					}
					
					
					String tmp = "1" + String.valueOf(Float.MAX_VALUE); // upper
																		// overflow
					pValue = new SlotValue(tmp, VALUE_INVALID, 0);
					putValue(values, pValue);

					tmp = "0" + String.valueOf(Float.MIN_VALUE).substring(1); // under
																				// overflow
					pValue = new SlotValue(tmp, VALUE_INVALID, 0);
					putValue(values, pValue);

				} else if (type.equals(ValueType.INTEGER)) {
					// Valid
					pValue = new SlotValue(Integer.valueOf(0), VALUE_VALID, 0);
					putValue(values, pValue);

					int i = ran.nextInt();
					pValue = new SlotValue(Integer.valueOf(i), VALUE_VALID, 0);
					putValue(values, pValue);

					pValue = new SlotValue(Integer.valueOf(-i), VALUE_VALID, 0);
					putValue(values, pValue);
					
					// invalid
					if (s.getMaximumValue() != null){
						pValue = new SlotValue(Integer.valueOf(s.getMaximumValue().intValue() + 1)
								, VALUE_INVALID, 0);
						putValue(values, pValue);
					}
					
					if (s.getMinimumValue() != null){
						pValue = new SlotValue(Integer.valueOf(s.getMinimumValue().intValue() - 1)
								, VALUE_INVALID, 0);
						putValue(values, pValue);
					}
					
					String tmp = "1" + String.valueOf(Integer.MAX_VALUE);
					pValue = new SlotValue(tmp, VALUE_INVALID, 0);
					putValue(values, pValue);

					tmp = "-1" + String.valueOf(Integer.MAX_VALUE);
					pValue = new SlotValue(tmp, VALUE_INVALID, 0);
					putValue(values, pValue);

				} else if (type.equals(ValueType.STRING)) {
					// 3 valid data
					pValue = new SlotValue(enDict.nextExpression(), VALUE_VALID, 0);
					putValue(values, pValue);

					pValue = new SlotValue(enDict.nextExpression(), VALUE_VALID, 0);
					putValue(values, pValue);

					pValue = new SlotValue(enDict.nextExpression(), VALUE_VALID, 0);
					putValue(values, pValue);
				} else if (type.equals(ValueType.INSTANCE)) {
					// skip this
				} else if (type.equals(ValueType.CLS)) {
					// skip this
				}
				// null is almost invalid for every variable :-)
				pValue = new SlotValue(null, VALUE_INVALID, 0);
				putValue(values, pValue);
			}
		}

	}
	
	/**
	 * Put value in the values list, avoid duplicate
	 */ 
	private void putValue(List<SlotValue> values, SlotValue v){
		boolean found = false;
		for (SlotValue s : values){
			if (s.getValue() == null && v.getValue() == null)
				found = true;
			else if (s.getValue() != null && v != null &&
					s.getValue().equals(v.getValue())){
				found = true;
			}
		}
		
		if (!found){
			values.add(v);
		}
	}

	/**
	 * Fetch content 
	 * @param tc
	 */
	public void fetchContents(TestCaseType tc){
		if (tc == null)
			return;
		
		TestScenarioType ts = tc.getScenario();
		
		List<TActionType> actsList = ts.getTestAction();
		for (TActionType s : actsList){
			if (s.getActType().equals(AType.COMMUNICATION)){
				if (s.getInitiator() != null && 
						s.getInitiator().equals(GlobalConstants.TESTER_AGENT_NAME)){
					FipaMessageType msg = s.getMessage();
					if (msg != null){
						ContentType content = msg.getContent();
						if (content != null){
							// deal with the case when content is a reference
							if (content.getValueref() != null)
								break; // skip 
							
							String clazzName = (content.getClazz() != null) 
											? content.getClazz() : content.getValue();
											
							if (clazzName.equalsIgnoreCase("STRING")){
								// TODO class is string, don't have to fetch, check this if necessary
							} else {
								
								// statistic
								Integer stat = coverStat.get(clazzName);
								if (stat == null){
									coverStat.put(clazzName, 1);
								} else {
									coverStat.put(clazzName, stat + 1);
								}
								
								if (inputDataType.equals(InputGenType.VALID)){
									String tmp = nextValidContent(clazzName);
									if (tmp!= null)
										content.setValue(tmp);
									//else 
									//	content.setValue(enDict.nextExpression()); // Random
								} else if (inputDataType.equals(InputGenType.IN_VALID)) {
									String tmp = nextInvalidContent(clazzName);
									if (tmp!= null)
										content.setValue(tmp);
									else 
										content.setValue(enDict.nextExpression()); // Random
									
								} else if (inputDataType.equals(InputGenType.RANDOM)){
									Random ran = new Random();
									String tmp;
									if (ran.nextBoolean()){
										tmp = nextValidContent(clazzName);
									} else {
										tmp = nextInvalidContent(clazzName);
									}
									content.setValue(tmp);
								} else if (inputDataType.equals(InputGenType.INTERLEAVING)){
									String tmp;
									if (lastGenType.equals(InputGenType.VALID)){
										lastGenType = InputGenType.IN_VALID;
										tmp = nextInvalidContent(clazzName);
									} else {
										lastGenType = InputGenType.VALID;
										tmp = nextValidContent(clazzName);
									}
									content.setValue(tmp);
								}
							}
						}
					}
				}
			}
		}
	}
	
	
	/**
	 * Validate content if it satisfies codec and ontology 
	 * @param content
	 * @param beanClazzName
	 * @return
	 */
	public boolean isValidate(String content, String beanClazzName){
		// content validator
		if (content == null)
			return false;
		
		if (codec != null){
			try { 
				Object obj = codec.decode(content);
				if (obj.getClass().getName().equals(workingPackage + "." + beanClazzName)){
					// TODO implement ontology validate data
					return true;
				} else {
					return false;
				}
			} catch (Exception e){
				// can not be decode, error
				return false;
			}
		}
		
		return true;
	}
	
	/*
	 * private String convert(ValueType type, Object value){ if
	 * (type.equals(ValueType.STRING)){ return (String)value; } else if
	 * (type.equals(ValueType.BOOLEAN)){ return ((Boolean)value).toString(); }
	 * else if (type.equals(ValueType.FLOAT)){ return ((Float)value).toString(); }
	 * else if (type.equals(ValueType.INTEGER)){ return
	 * ((Integer)value).toString(); } else if (type.equals(ValueType.CLS)){
	 *  } else if (type.equals(ValueType.INSTANCE)){
	 *  } return ""; }
	 */

	/**
	 * Generate a list of valid contents for a given class
	 * 
	 * @param className
	 * @return
	 */
	private List<ClazzValue> getValidContents(Cls cls) {
		List<ClazzValue> list = new ArrayList<ClazzValue>();

		if (checkValid()) {
			if (cls != null) {
				Collection<Instance> ins = protegeKb.getInstances(cls);
				Iterator<Instance> insIter = ins.iterator();
				while (insIter.hasNext()) {
					Instance i = insIter.next();
					//Object beanObj = generateBean(i);
					//if (beanObj != null) {
					//	String content = codec.encode(beanObj);
					ClazzValue value = new ClazzValue(i);
					list.add(value);
					//}
				}
			}
		}

		return list;
	}
	
	/**
	 * Get a content that has not been used
	 * @param clazzName
	 * @return
	 */
	private Instance getValidContent(String clazzName){
		List<ClazzValue> list = possibleClsValues.get(clazzName);
		if (list == null)
			return null;
		else {
			for (ClazzValue v : list){
				if (!v.isUsed()){
					v.setUsed(true);
					return v.getValue();
				}
			}
		}
		return null;
	}

	/**
	 * Generate randomly a valid content
	 * 
	 * @param className
	 * @return
	 */
	public String nextValidContent(String className) {
		
		// For coverage statistic 
		Integer stat = numValid.get(className);
		if (stat == null){
			numValid.put(className, 1);
		} else {
			numValid.put(className, stat + 1);
		}
		
		Instance pValue = getValidContent(className);
		if (pValue != null){
			Object beanObj = generateBean(pValue);
			if (beanObj != null) {
				String content = codec.encode(beanObj);
				return content;
			}
		} else if (checkValid()) {
			Cls cls = protegeKb.getCls(className);
			if (cls != null) {
				//Instance ins = cls.createDirectInstance(CommonUtil.generateId(className + "_ins_valid_"));
				// fetch slot value
				Instance ins = protegeKb.createInstance(CommonUtil.generateId(className + "_ins_valid_"), cls);
				
				fetchSlotValue(ins);
				Object beanObj = generateBean(ins);
				if (beanObj != null) {
					String content = codec.encode(beanObj);
					return content;
				}
			}
		}
		return null;
	}

	/**
	 * Generate randomly an invalid content with one invalid slot value
	 * 
	 * @param className
	 * @return
	 */
	public String nextInvalidContent(String className) {
		// For coverage statistic
		Integer stat = numInValid.get(className);
		if (stat == null){
			numInValid.put(className, 1);
		} else {
			numInValid.put(className, stat + 1);
		}
		
		if (checkValid()) {
			Cls cls = protegeKb.getCls(className);
			if (cls != null) {
				Instance ins = cls.createDirectInstance(CommonUtil.generateId(className + "_ins_invalid_"));
				// fetch slot value

				fetchSlotValue(ins);
				Object beanObj = generateBean(ins);
				if (beanObj != null) {
					String content = codec.encode(beanObj);

					Collection<Slot> slots = ins.getOwnSlots();
					Iterator<Slot> iter = slots.iterator();
					Random ran = new Random();
					int selectedInx = ran.nextInt(slots.size() - 2); // skip spec-required slots
					if (iter.hasNext()){
						Slot s = iter.next(); // first element
						int i = 0;
						while (i < selectedInx && iter.hasNext()) {
							s = iter.next();
							if (isPrimitive(s) || s.getValueType().equals(ValueType.INSTANCE)) // skip spec-required slots
								i++;
						}
	
						ValueType type = s.getValueType();
						if (type.equals(ValueType.INSTANCE)){
							// try to find a primitive slot
							Collection<Cls> allowedCls = s.getAllowedClses();
							if (allowedCls != null){
								Iterator<Cls> allowedIter = allowedCls.iterator();
								if (allowedIter.hasNext()){
									Cls firstCls = allowedIter.next(); // first class
									Collection<Slot> subSlots = firstCls.getTemplateSlots();
									String subClassName =  firstCls.getName();
									// TODO For statistic purpose, remove when done
									stat = numInValid.get(subClassName);
									if (stat == null){
										numInValid.put(subClassName, 1);
									} else {
										numInValid.put(subClassName, stat + 1);
									}
									for (Slot s1 : subSlots){
										if (isPrimitive(s1)){
											// Fist one found
											Object obj = getRandomValue(s1, VALUE_INVALID);
											content = subtituteContent(content, subClassName, s1.getName(), obj);
											break;
										}
									}
									
								}
							}
						} else {
							// Primitive type, can be replate directly
							Object obj = getRandomValue(s, VALUE_INVALID);
							content = subtituteContent(content, className, s.getName(), obj);
						}
					}
					return content;
				}
			}
		}
		return null;
	}

	/**
	 * Substitute value 
	 * @param className
	 * @param slotName
	 * @param value
	 * @return
	 */
	private String subtituteContent(String content, String className, String slotName, Object value){
		String ret = content;
		StringBuffer buff = new StringBuffer(); 
		// Find the first instance of the class appeared in the content
		int clzIndex = content.indexOf(className);
		int slotIndex = content.indexOf(slotName, clzIndex);
		int startValIndex = content.indexOf("=\"", slotIndex);
		int endValIndex = content.indexOf("\"", startValIndex + 2);
		
		//if (endValIndex == -1 && slotIndex != -1) // last slot
		//	endValIndex = content.indexOf("\"/>", slotIndex);
		
		if (clzIndex == -1 || slotIndex == -1)
			return ret; // give up
		
		try{
			if (value != null){
				// head part
				buff.append(content.substring(0, slotIndex + slotName.length() + 2)); // until ="
				buff.append(value.toString());
				
				// tail
				buff.append(content.substring(endValIndex, content.length() - 1));
			} else {
				// remove the slot in the content
				
				buff.append(content.substring(0, slotIndex - 1)); // until ="
				//buff.append("null");
				buff.append(content.substring(endValIndex + 1, content.length() - 1));
			}
			ret = buff.toString();
		} catch (IndexOutOfBoundsException e){
			return content; // give up, dont change any
		}
		return ret;
	}
	
	/**
	 * Fetch values to slots of the instance
	 * 
	 * @param ins
	 */
	private void fetchSlotValue(Instance ins) {
		Collection<Slot> slots = ins.getOwnSlots();
		for (Slot s : slots) {
			if (isPrimitive(s)) {
				Object o = getRandomValue(s, VALUE_VALID);

				// if (!s.getAllowsMultipleValues())
				// TODO see what I can do with multiple value
				
				if (o != null)
					ins.setOwnSlotValue(s, o); // only one value
				
			} else if (s.getValueType().equals(ValueType.INSTANCE)) {
				Collection<Cls> allowedCls =  s.getAllowedClses();
				if (allowedCls != null && allowedCls.size() > 0){
					// TODO deal with the case when there are more than one class allowed 
					Cls cls = allowedCls.iterator().next(); // first class
					Instance subIns = getValidContent(cls.getName());
					if (subIns == null){
						subIns = cls.createDirectInstance(CommonUtil.generateId("sub_ins_"));

						// TODO For statistic purpose, remove when done
						String className = cls.getName();
						Integer stat = coverStat.get(className);
						if (stat == null){
							coverStat.put(className, 1);
						} else {
							coverStat.put(className, stat + 1);
						}
						stat = numValid.get(className);
						if (stat == null){
							numValid.put(className, 1);
						} else {
							numValid.put(className, stat + 1);
						}
						
						fetchSlotValue(subIns); // call this recursively
					}
					ins.setOwnSlotValue(s, subIns); // add reference
				}
			}
		}
	}

	/**
	 * Randomly get a valid value, taking into account number of usage
	 * 
	 * @param s
	 * @return
	 */
	private Object getRandomValue(Slot s, Boolean type) {
		List<SlotValue> values = possibleSlotValues.get(s);

		if (values != null) {
			Collections.sort(values); // sort value and pick the least used
			for (SlotValue v : values) {
				if (v.getType().equals(type)) {
					v.setUsage(v.getUsage() + 1);
					return v.getValue();
				}
			}
		}
		return null;
	}

	/**
	 * Check if a Slot is a primitive slot
	 * 
	 * @param t
	 * @return
	 */
	private boolean isPrimitive(Slot s) {
		ValueType t = s.getValueType();
		if (t.equals(ValueType.BOOLEAN) || t.equals(ValueType.FLOAT) || t.equals(ValueType.INTEGER)
				|| t.equals(ValueType.STRING)){
			if (s.getName().indexOf(":") != 0) // Ontology slot
				return true;
		}
			
		return false;
	}

	/**
	 * Recursively generate a Java bean from instances
	 * 
	 * @param ontoInstance
	 * @return
	 */
	private Object generateBean(Instance ontoInstance) {

		if (!checkValid()) {
			return null;
		} else {
			try {
				String className = ontoInstance.getDirectType().getName();
				//Class<?> javaCls = Class.forName(workingPackage + "." + className);
				// use dynamic classloader
				Class<?> javaCls = loader.loadClass(workingPackage + "." + className);

				Object obj = Beans.instantiate(javaCls.getClassLoader(), javaCls.getName());

				BeanInfo beanInfo = Introspector.getBeanInfo(javaCls);
				PropertyDescriptor[] pds = beanInfo.getPropertyDescriptors();

				for (PropertyDescriptor pd : pds) {
					String slotName = pd.getName();
					Method method = pd.getWriteMethod();

					Collection<Slot> slots = ontoInstance.getOwnSlots();
					Iterator<Slot> slotIter = slots.iterator();

					while (slotIter.hasNext()) {
						Slot s = slotIter.next();
						if (s.getName().equals(slotName)) {

							ValueType type = ontoInstance.getOwnSlotValueType(s);
							if (type.equals(ValueType.CLS)) {
								// TODO Handle the case when slot value is a class

							} else if (type.equals(ValueType.INSTANCE)) {
								List<Instance> insValues = ontoInstance.getDirectOwnSlotValues(s);
								List<Object> objIns = new ArrayList<Object>();
								if (insValues != null && insValues.size() > 0) {
									for (Instance ins : insValues) {
										Object o = generateBean(ins);
										if (o != null) {
											objIns.add(o);
										}
									}

									// Used for cast, since insValues <> null
									// and has size > 0, this call is save
									//Class<?> castCls = Class.forName(workingPackage + "."
									//		+ insValues.get(0).getDirectType().getName());
									
									// 
									Class<?> castCls = loader.loadClass(workingPackage + "."
											+ insValues.get(0).getDirectType().getName());
									
									Class<?>[] types = method.getParameterTypes();
									if (types != null && types.length > 0) {
										Class<?> t = types[0]; // Know that
										// bean always
										// has one
										// argument

										// Transfer array arguments
										if (t.isArray()) {
											Object arg1 = Array.newInstance(castCls, objIns.size());
											for (int i = 0; i < objIns.size(); i++)
												Array.set(arg1, i, objIns.get(i));

											Object[] args = new Object[1];
											args[0] = arg1;

											method.invoke(obj, args);
										} else if (objIns.size() > 0) {
											// Should be only one element
											method.invoke(obj, objIns.get(0));
										}
									}
								}

							} else {
								Object value = ontoInstance.getDirectOwnSlotValue(s);
								method.invoke(obj, value);
							}
							break;
						}
					}
				}
				return obj;
			} catch (Exception e) {
				return null;
			}
		}
	}
	
	
	public String getWorkingPackage() {
		return workingPackage;
	}

	public void setWorkingPackage(String workingPackage) {
		this.workingPackage = workingPackage;
	}

	public IContentCodec getCodec() {
		return codec;
	}

	public void setCodec(IContentCodec codec) {
		this.codec = codec;
	}

	/**
	 * Check if all required attributes are ready
	 * 
	 * @return true if all attributes are set
	 */
	private boolean checkValid() {
		if (protegeKb == null || workingPackage == null || codec == null)
			return false;

		return true;
	}

	/**
	 * Internal class for storing value of slot
	 * 
	 * @author cunduy
	 * 
	 */
	private class SlotValue implements Comparable<SlotValue> {
		private Object value;
		private Boolean type;
		private int usage;

		private SlotValue(Object value, Boolean type, int usage) {
			super();
			this.value = value;
			this.type = type;
			this.usage = usage;
		}

		public Object getValue() {
			return value;
		}

		public void setValue(Object value) {
			this.value = value;
		}

		public Boolean getType() {
			return type;
		}

		public void setType(Boolean type) {
			this.type = type;
		}

		public int getUsage() {
			return usage;
		}

		public void setUsage(int usage) {
			this.usage = usage;
		}

		public int compareTo(SlotValue o) {
			if (usage < o.getUsage())
				return -1;
			else if (usage > o.getUsage())
				return 1;

			return 0;
		}
	}

	/**
	 * Class that store and mark the used of class content
	 * @author cunduy
	 *
	 */
	private class ClazzValue {
		private Instance value;
		private boolean used;
		public Instance getValue() {
			return value;
		}
		public void setValue(Instance value) {
			this.value = value;
		}
		public boolean isUsed() {
			return used;
		}
		public void setUsed(boolean used) {
			this.used = used;
		}
		private ClazzValue(Instance value) {
			used = false;
			this.value = value;
		}
	}
	
	/**
	 * Print statistic information
	 */
	public void printStatistic(){
		
		// 1. Statistic about coverage
		if (coverStat != null && coverStat.size() > 0){
			logger.log("Coverage information");
			logger.log("Number of covered classes: " + coverStat.size());
			for (String clzz : coverStat.keySet()){
				logger.log("Class: " + clzz + " / number of using times: " + coverStat.get(clzz));
				logger.log("\t Valid : " + numValid.get(clzz));
				logger.log("\t Invalid: " + numInValid.get(clzz));
			}
		}
		
		// about class values
		// 3. Number of user-defined classes
		logger.log("Number of user-defined classes: " + uCls.size());
		Set<String> clzzKeys =  uCls.keySet();
		for (String clzz : clzzKeys){
			if (clzz.indexOf("AMS") < 0 && clzz.indexOf("DF") < 0){     
				List<ClazzValue> l = possibleClsValues.get(clzz);
				logger.log("Class: " + clzz);
				logger.log("\t immediate values: " + l.size());
				logger.log("\t permutation values: " + count(uCls.get(clzz)));
				logger.log("\t valid values: " + countValid(uCls.get(clzz)));
			}
		}
		
		
		
	}
	
	private long count(Cls clzz){
		long ret = 1;
		Collection<Slot> subSlots = clzz.getTemplateSlots();
		for (Slot s : subSlots){
			
			if (isPrimitive(s)){
				ret = ret * possibleSlotValues.get(s).size();
				logger.log("\t\t" + s.getName() + " = " + possibleSlotValues.get(s).size());
			} else if (s.getValueType().equals(ValueType.INSTANCE)) {
				Collection<Cls> allowedCls = s.getAllowedClses();
				if (allowedCls != null){
					Iterator<Cls> allowedIter = allowedCls.iterator();
					while (allowedIter.hasNext()){
						Cls subCls = allowedIter.next(); 
						Collection<Instance> ins = protegeKb.getInstances(subCls);
						if (ins != null && ins.size() > 0){
							ret = ret * ins.size();
						//else {
						//	return ret * count(subCls);
							
							logger.log("\t\t" + s.getName() + " = " + ins.size());
						}
						
					}
				}
			}
		}
		return ret;
	}
	
	private long countValid(Cls clzz){
		long ret = 1;
		Collection<Slot> subSlots = clzz.getTemplateSlots();
		for (Slot s : subSlots){
			
			
			
			if (isPrimitive(s)){
				// Could valid value
				int c = 0;
				List<SlotValue> list = possibleSlotValues.get(s);
				for (SlotValue v : list){
					if (v.getType().equals(VALUE_VALID)){
						c += 1;
					}
				}
				logger.log("\t\t" + s.getName() + " = " + c);
				ret = ret * c;
			} else if (s.getValueType().equals(ValueType.INSTANCE)) {
				Collection<Cls> allowedCls = s.getAllowedClses();
				if (allowedCls != null){
					Iterator<Cls> allowedIter = allowedCls.iterator();
					while (allowedIter.hasNext()){
						Cls subCls = allowedIter.next(); 
						Collection<Instance> ins = protegeKb.getInstances(subCls);
						if (ins != null && ins.size() > 0){
							ret = ret * ins.size();
							
							logger.log("\t\t" + s.getName() + " = " + ins.size());

						//else {
						//	return ret * count(subCls);
						}
						
					}
				}
			}
		}
		return ret;
	}
	
	
	
	/**
	 * Test
	 * @param args
	 */
	public static void main(String[] args) {
		OntoBase project = new OntoBase();
		
		//String dbPath = "/hardmnt/idacox0/sra/cunduy/projects/Continuous Testing/BibFinderBDI/onto/BibFinder.pprj";
		//String workingPackage = "it.itc.sra.bibfinder.ontology";
		
		String dbPath = "/hardmnt/idacox0/sra/cunduy/workspace/jadex-booktrading/onto/booktrading-beans.pprj";
		String workingPackage = "jadex.examples.booktrading.ontology";
		
		try {
			
			IContentCodec codec = CodecFactory.createCodec(CodecType.NUGGETS_XML_CONTENT_CODEC, project.loader);
			project.setWorkingPackage(workingPackage);
			project.setCodec(codec);
			
			if (project.loadOntology(dbPath)){
//				List<String> contents = project.getValidContents("Player");
//				for (String s: contents){
//					System.out.println(s);
//				}
//				
//				contents = project.getValidContents("Card");
//				for (String s: contents){
//					System.out.println(s);
//				}
				
/*				String tmp = project.nextValidContent("Propose");
				System.out.println(tmp);
				
				tmp = project.nextValidContent("Propose");
				System.out.println(tmp);
				
				tmp = project.nextValidContent("Propose");
				System.out.println(tmp);

				tmp = project.nextValidContent("Propose");
				System.out.println(tmp);
*/
				
//				tmp = project.nextInvalidContent("Propose");
//				System.out.println(tmp);
//				
//				tmp = project.nextInvalidContent("Propose");
//				System.out.println(tmp);
				
				/*tmp = project.nextValidContent("Book");
				System.out.println(tmp);
				
				tmp = project.nextValidContent("Propose");
				System.out.println(tmp);*/

				// print statistic information
				project.printStatistic();
			}

		} catch (ECATExeption e) {
			e.printStackTrace();
		}
				
	}
}
