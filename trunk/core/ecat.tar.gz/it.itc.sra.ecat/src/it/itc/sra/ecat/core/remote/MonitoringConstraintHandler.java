package it.itc.sra.ecat.core.remote;

import it.itc.sra.ecat.monitordata.EventType;
import it.itc.sra.ecat.monitordata.KindType;
import it.itc.sra.ecat.util.CommonUtil;

import java.util.ArrayList;
import java.util.List;

import org.ocl4java.ConstraintFailedHandlerManager;
import org.ocl4java.ConstraintFailedHandlerManager.ConstraintFailedHandler;

public class MonitoringConstraintHandler implements ConstraintFailedHandler {

	private RemoteLogger logger;
	private String currentSessionID;

	public MonitoringConstraintHandler() {
		List<ConstraintFailedHandler> handlers = new ArrayList<ConstraintFailedHandler>();
		handlers.add(this);
		ConstraintFailedHandlerManager.setHandlers(handlers);
	}

	synchronized public void handleConstraintFailed(String ocl, String type, String method, Object... params) {

		if (logger != null) {
			EventType event = new EventType();
			event.setKind(KindType.CONSTRAINT_VIOLATED);
			
			event.setWhen(CommonUtil.getCurrentDateTime());
			event.setWhere(type + "." + method);
			event.setContent("Violation occurs at: " + type + "." + method + "!\n" + " OCL = " + ocl + " parameters = "
					+ params);
			logger.monitor(currentSessionID, event);
		} else {
			System.err.println("Violation occurs at: " + type + "." + method + "!\n" + " OCL = " + ocl + " parameters = "
					+ params);	
		}
	}

	public void setLogger(RemoteLogger logger) {
		this.logger = logger;
	}

	public void setCurrentSessionID(String currentSessionID) {
		this.currentSessionID = currentSessionID;
	}
	
}
