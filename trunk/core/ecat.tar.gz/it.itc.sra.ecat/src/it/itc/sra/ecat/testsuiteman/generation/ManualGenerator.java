/**
 * <copyright>
 *
 * eCAT - Tool for Continuous Testing Agent for the JADE/Eclipse Platform
 * Copyright (C) ITC-IRST, Trento, Italy
 * Authors: Duy Cu Nguyen
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 * The electronic copy of the license can be found here:
 * http://sra.itc.it/tools/taom/freesoftware/gpl.txt
 *
 * The contact information:
 * e-mail: cunduy@itc.it
 * site: http://sra.itc.it
 *
 * </copyright>
 */

package it.itc.sra.ecat.testsuiteman.generation;

import it.itc.sra.ecat.testsuiteman.*;
import it.itc.sra.ecat.core.ECATExeption;
import it.itc.sra.ecat.testsuiteman.protocollist.ProtocolList;
import it.itc.sra.ecat.testsuiteman.protocollist.ProtocolType;
import it.itc.sra.ecat.util.CommonUtil;
import it.itc.sra.ecat.util.GeneralLogger;
import it.itc.sra.ecat.util.GlobalConstants;
import it.itc.sra.ecat.util.JAXBUtil;
import it.itc.sra.ecat.testsuiteman.testsuite.*;

import java.util.GregorianCalendar;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import javax.xml.bind.JAXBElement;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;

public class ManualGenerator {

	Hashtable<String, TestScenarioType> scenarioList;

	Vector<String> scenarioNameList;

	private int tcID = 0;
	private int tsID = 0;

	private GeneralLogger logger = GeneralLogger.getInstance();

	public TestCaseType createTestCase(String scenarioName, String agentInCharge,
			String testerAgent) {
		TestSuiteProcessor processor = new TestSuiteProcessor();
		// 4. Create test case
		TestCaseType tc;
		tc = processor.createTestCaseType();
		tc.setActive(true);
		tcID += 1;
		tc.setID(agentInCharge + "TC" + String.valueOf(tcID));
		tc.setName("Test Case " + String.valueOf(tcID));
		tc.setPriority(0.1);
		tc.setDescription("For testing " + agentInCharge);

		if (scenarioNameList.contains(scenarioName)) {
			TestScenarioType tsce = scenarioList
					.get(scenarioName);
			tc.setScenario(tsce); // Add the scenario to the test case
			return tc;
		}
		;

		return null;
	}

	public TestSuite createTestSuite(String agentInCharge, String goal, String plan, String relationship) {
		TestSuiteProcessor processor = new TestSuiteProcessor();
		// 1. Create a test suite
		TestSuite ts = null;
		
		String tmp = CommonUtil.normalizeAgentName(agentInCharge);
		
		ts = processor.createTestSuite();
		tsID += 1;
		
		// 2. Create the general part
		ts.setCreatedBy("eCAT Generator");
		
		DatatypeFactory datatypeFactory;
		try {
			datatypeFactory = DatatypeFactory.newInstance();
			GregorianCalendar cal = new GregorianCalendar();
			ts.setCreatedDate(datatypeFactory.newXMLGregorianCalendar(cal));
		} catch (DatatypeConfigurationException e) {
			e.printStackTrace();
		}
		
		ts.setDescription("Test suite " + String.valueOf(tsID) + " for agent: " + agentInCharge);
		ts.setID("TS" + String.valueOf(tsID));
		ts.setName("Test suite " + String.valueOf(tsID));
		ts.setVersion("1");

		// 3. Create the functional part

		TargetType tf = processor.createTargetType();
		tf.setAgent(tmp);
		// ....

		// Create a goal-plan
		GoalPlanType gp = processor.createGoalPlanType();
		gp.setGoal(goal);
		gp.setPlan(plan);
		gp.setRelationship(relationship);

		// add gp to the functional part
		tf.getGoalPlan().add(gp);

		// add the general part to the test suite
		ts.getTarget().add(tf);

		return ts;
	}

	/**
	 * 
	 * @param agentInCharge
	 * @param testerAgent
	 * @param content
	 * @return
	 */
	public TestCaseType createPilotTestCase(String agentInCharge, String testerAgent, String content) {
		TestSuiteProcessor processor = new TestSuiteProcessor();
		// 4. Create test case
		TestCaseType tc;
		
		String tmp = CommonUtil.normalizeAgentName(agentInCharge);
		
		tc = processor.createTestCaseType();

		tc.setActive(true);
		tcID += 1;
		tc.setID(tmp + "TC" + String.valueOf(tcID));
		tc.setName("Test Case " + String.valueOf(tcID));
		tc.setPriority(0.1);
		tc.setDescription("For testing " + tmp);

		// 5. Create test scenario
		TestScenarioType tsce = processor.createTestScenarioType();
		tc.setScenario(tsce); // Add the scenario to the test case

		// 6. create test sequences
		TActionType act1 = processor.createTActionType();
		TActionType act2 = processor.createTActionType();
		TActionType act3 = processor.createTActionType();
		TActionType act4 = processor.createTActionType();
		
		// Add the sequence to the test scenario
		tsce.getTestAction().add(act1);
		tsce.getTestAction().add(act2);
		tsce.getTestAction().add(act4);
		tsce.getTestAction().add(act3);

		act1.setID("S1001");
		act1.setActType(AType.INITIAL);
		act1.setTimeout(5000);
		act1.setNextAction(act2);

		act2.setID("S1002");
		act2.setInitiator(testerAgent);
		act2.setResponder(tmp);
		act2.setActType(AType.COMMUNICATION);
		act2.setTimeout(5000);
		act2.setNextAction(act4);
		
		
		FipaMessageType aclMessage = new FipaMessageType();

		ContentType c = new ContentType();
		c.setValue(content);
		c.setClazz("String");
		aclMessage.setContent(c);
		
		aclMessage.setAct("REQUEST");
		aclMessage.setConversationId(CommonUtil.generateId("CID"));
		
		act2.setMessage(aclMessage);

		act4.setID("S1003");
		act4.setInitiator(tmp);
		act4.setResponder(testerAgent);
		act4.setActType(AType.COMMUNICATION);
		act4.setTimeout(5000);
		act4.setNextAction(act3);
		
		act3.setID("S1004");
		act3.setActType(AType.FINAL);
		act3.setTimeout(5000);
		
		return tc;
	}
	
	/**
	 * 
	 * @param agentInCharge
	 * @param testerAgent
	 * @param content
	 * @param scenarioPath
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public TestCaseType createTestCase(String agentInCharge, 
			String testerAgent, 
			String content,
			String scenarioPath) {
		
		TestSuiteProcessor processor = new TestSuiteProcessor();
		// 4. Create test case
		TestCaseType tc;
		
		String tmp = CommonUtil.normalizeAgentName(agentInCharge);
		
		tc = processor.createTestCaseType();

		tc.setActive(true);
		tcID += 1;
		tc.setID(tmp + "TC" + String.valueOf(tcID));
		tc.setName("Test Case " + String.valueOf(tcID));
		tc.setPriority(0.1);
		tc.setDescription("For testing " + tmp);

		// 5. Create test scenario
		TestScenarioType tsce = processor.createTestScenarioType();
		tc.setScenario(tsce); // Add the scenario to the test case
		
		try {
			
			JAXBElement<TestScenarioType> scenarioRoot = (JAXBElement<TestScenarioType>) JAXBUtil.loadJAXBFromFile( 
					GlobalConstants.TESTSUITE_PACKAGE_STUBS, scenarioPath);
			
			TestScenarioType scenario = scenarioRoot.getValue();

			// copy the prefered scenario
			List<TActionType> acts = scenario.getTestAction();
			Iterator<TActionType> iter = acts.iterator();
			int SeqID = -1;
			while (iter.hasNext()) {
				TActionType act = iter.next();
				// Change the sequence id
				SeqID += 1;
				act.setID("TC" + String.valueOf(tcID) + "SEQ" + String.valueOf(SeqID) + act.getID());
				
				if (act.getInitiator() != null && act.getInitiator().equalsIgnoreCase("TesterAgent")) {
					act.setInitiator(testerAgent);
					act.setResponder(tmp);

				} else if (act.getResponder() != null && act.getResponder().equalsIgnoreCase(
						"TesterAgent")) {
					act.setInitiator(tmp);
					act.setResponder(testerAgent);
				}
				
				FipaMessageType targetMsg = new FipaMessageType();
				
				if (act.getMessage() != null && act.getMessage() instanceof FipaMessageType) {
					FipaMessageType fipaMsg = act.getMessage();
					//targetMsg.setConversationId(CommonUtil.generateId("CID"));
					targetMsg.setAct(fipaMsg.getAct());
					
					targetMsg.setConversationId(CommonUtil.generateId("CID"));
					
					targetMsg.setLanguage("");
					targetMsg.setOntology("");

					ContentType c = new ContentType();
					c.setValue(content);
					c.setClazz("String");
					targetMsg.setContent(c);
					
					act.setMessage(targetMsg);
					
				//} else {
				//	sequence.setMessage(content);
				}
				
				tsce.getTestAction().add(act);
			}
			
			//tc.setScenario(scenario);
			
		} catch (ECATExeption e) {
			e.printStackTrace();
		}
		
		return tc;
	}

	/**
	 * Load data
	 * 
	 * @param protocolPath
	 * @param domainDataPath
	 */
	public void init(String protocolPath) {
		scenarioList = new Hashtable<String, TestScenarioType>();
		scenarioNameList = new Vector<String>();

		// Mashall xml file to object
		try {
			ProtocolList protocolList = (ProtocolList) JAXBUtil
					.loadJAXBFromFile(GlobalConstants.PROTOCOLLIST_PKG, protocolPath);
			// Fetch protocol list
			List<ProtocolType> l = protocolList.getProtocol();
			Iterator<ProtocolType> i = l.iterator();
			while (i.hasNext()) {
				ProtocolType proto = i.next();
				String protoName = proto.getName();
				String protoXMLFile = proto.getPath();

				// Marshall the test scenario
				TestScenarioType senario = (TestScenarioType) JAXBUtil
						.loadJAXBFromFile(GlobalConstants.TESTSUITE_PACKAGE_STUBS, protoXMLFile);
				scenarioList.put(protoName, senario);
				scenarioNameList.add(protoName);
			}

		} catch (ECATExeption e) {
			e.printStackTrace(logger.getOut());
		}
	}
	
	public void resetCounter(){
		tcID = 0;
		tsID = 0;		
	}


}
