/**
 * <copyright>
 *
 * eCAT - Tool for Continuous Testing Agent for the JADE/Eclipse Platform
 * Copyright (C) ITC-IRST, Trento, Italy
 * Authors: Duy Cu Nguyen
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 * The electronic copy of the license can be found here:
 * http://sra.itc.it/tools/taom/freesoftware/gpl.txt
 *
 * The contact information:
 * e-mail: cunduy@itc.it
 * site: http://sra.itc.it
 *
 * </copyright>
 */

package it.itc.sra.ecat;

import java.io.IOException;
import java.net.URL;

import it.itc.sra.ecat.core.MonitoringModel;
import it.itc.sra.ecat.core.TestResultsModel;
import it.itc.sra.ecat.core.executor.IExecutor;
import it.itc.sra.ecat.core.monitor.IMonitorAgent;
import it.itc.sra.ecat.core.tester.ITesterAgent;
import it.itc.sra.ecat.ecatplugin.preferences.PreferenceConstants;
import it.itc.sra.ecat.testsuiteman.testconfig.TestConfig;

import org.eclipse.core.runtime.FileLocator;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.Platform;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.resource.ImageRegistry;
import org.eclipse.swt.graphics.Image;
import org.eclipse.ui.plugin.AbstractUIPlugin;
import org.osgi.framework.BundleContext;

public class ECATPlugIn extends AbstractUIPlugin {

	private static ECATPlugIn instance;
	public static final String PLUGIN_ID = "it.itc.sra.ecat";
	
	private ITesterAgent testerAgent; // The reference to the TesterAgent
	private IMonitorAgent monitorAgent; // The reference to the Central Monitor
	private IExecutor executorAgent; // The reference to the Central Executor
	
	private MonitoringModel monitorModel;
	private TestResultsModel testResultModel;
	
	private TestConfig testConfig; // Current testing configuration
	
	private boolean testerReady = false;

	public static final String JADE_HOME = "jade.home.path";
	
	public static final String IMG_HORIZONTAL = "horizontal";
	public static final String IMG_VERTICAL = "vertical";
	public static final String IMG_FORM_BG = "formBg";
	public static final String IMG_WIZARD_BG = "wizardBg";
	
	public static final String IMG_TESTCASE = "testCase";
	public static final String IMG_TESTSUITE = "testSuite";
	public static final String IMG_NODE = "testNode";
	
	public static final String IMG_TEST_FAILED = "test_failed";
	public static final String IMG_TEST_OK = "test_ok";
	public static final String IMG_TEST_WAIT = "test_waiting";
	
	public static final String IMG_TEST_TS_DEFAULT = "test-tsdefault";
	
	public static final String IMG_CHECKED = "checked";
	public static final String IMG_UNCHECKED = "unchecked";
	

	public ECATPlugIn() {
		instance = this;
	}

	@Override
	public void start(BundleContext context) throws Exception {
		super.start(context);
		// Start the tester agent
		//
		monitorModel = MonitoringModel.getInstance();
		testResultModel = TestResultsModel.getInstance();
	}

	@Override
	public void stop(BundleContext context) throws Exception {
		instance = null;
		super.stop(context);
	}

	public static ECATPlugIn getDefault() {
		return instance;
	}

	public ITesterAgent getTesterAgent() {
		return testerAgent;
	}

	public void setTesterAgent(ITesterAgent testerAgent) {
		this.testerAgent = testerAgent;
	}


	public static String getHost() {
		String host = getDefault().getPluginPreferences().getString(
				PreferenceConstants.P_HOST);
		return host;
	}
	
	public static String getPort() {
		String port = getDefault().getPluginPreferences().getString(
				PreferenceConstants.P_PORT);
		return port;
	}
	
	public String getJADEParams() {
		String params = getDefault().getPluginPreferences().getString(
				PreferenceConstants.P_JADE_PARAM);
		return params;
	}

	public static String getLogPath() {
		String logPath = getDefault().getPluginPreferences().getString(
				PreferenceConstants.P_LOG);
		return logPath;
	}
	
	public boolean isShowGUI(){
		if (getDefault().getPluginPreferences().getBoolean(PreferenceConstants.P_SHOW_GUI))
			return true;
		
		return false;
	}
	
	public boolean isRunIndependently(){
		if (getDefault().getPluginPreferences().getBoolean(PreferenceConstants.P_RUN_SEPARATE_JADE))
			return true;
		
		return false;
	}

	public boolean isMonitoringEnable(){
		if (getDefault().getPluginPreferences().getBoolean(PreferenceConstants.P_ENABLE_MONITORING))
			return true;
		return false;
	}

	public boolean isTesterReady() {
		return testerReady;
	}

	public void setTesterReady(boolean testerReady) {
		this.testerReady = testerReady;
	}

	
	public IMonitorAgent getMonitorAgent() {
		return monitorAgent;
	}

	public void setMonitorAgent(IMonitorAgent monitorAgent) {
		this.monitorAgent = monitorAgent;
	}

	
	public TestConfig getTestConfig() {
		return testConfig;
	}

	public void setTestConfig(TestConfig testConfig) {
		this.testConfig = testConfig;
	}

	
	public Image getImage(String key) {
		return getImageRegistry().get(key);
	}
	
	public ImageDescriptor getImageDescriptor(String key) {
		return getImageRegistry().getDescriptor(key);
	}
	
	@Override
	protected void initializeImageRegistry(ImageRegistry registry) {
		registerImage(registry, IMG_HORIZONTAL, "th_horizontal.gif");
		registerImage(registry, IMG_VERTICAL, "th_vertical.gif");
		
		registerImage(registry, IMG_FORM_BG, "form_banner.gif");
		registerImage(registry, IMG_WIZARD_BG, "gents.jpg");
		
		registerImage(registry, IMG_TESTCASE, "tc.png");
		registerImage(registry, IMG_TESTSUITE, "ts.png");
		registerImage(registry, IMG_NODE, "node.png");
		
		registerImage(registry, IMG_TEST_FAILED, "fail.png");
		registerImage(registry, IMG_TEST_OK, "testok.png");
		registerImage(registry, IMG_TEST_WAIT, "wait.png");
		registerImage(registry, IMG_TEST_TS_DEFAULT, "ts-default.png");
		
		registerImage(registry, IMG_CHECKED, "checked.gif");
		registerImage(registry, IMG_UNCHECKED, "unchecked.gif");
		
	}
	
	private void registerImage(ImageRegistry registry, String key,
			String fileName) {
		try {
			IPath path = new Path("icons/" + fileName);
			URL url = find(path);
			if (url!=null) {
				ImageDescriptor desc = ImageDescriptor.createFromURL(url);
				registry.put(key, desc);
			}
		} catch (Exception e) {
		}
	}
	
	public IPath getPluginPath(){
		URL pluginPath = Platform.getBundle(ECATPlugIn.PLUGIN_ID).getEntry("/");
		try {
			if (pluginPath!= null){
				pluginPath = FileLocator.resolve(pluginPath);
				return new Path(pluginPath.getPath());
			}
		} catch (IOException e) {
			
		}
		URL url = FileLocator.find(Platform.getBundle(ECATPlugIn.PLUGIN_ID), new Path("/"), null);
		if (url!=null) {
			return new Path(url.getPath());
		}
		return new Path("/");
	}

	public String getHome(){
		return getPluginPath().toOSString();
	}
	
	public MonitoringModel getMonitorModel() {
		return monitorModel;
	}

	public IExecutor getExecutorAgent() {
		return executorAgent;
	}

	public void setExecutorAgent(IExecutor executorAgent) {
		this.executorAgent = executorAgent;
	}

	public TestResultsModel getTestResultModel() {
		return testResultModel;
	}

	public void setTestResultModel(TestResultsModel testResultModel) {
		this.testResultModel = testResultModel;
	}
	
}
