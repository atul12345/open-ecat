/**
 * <copyright>
 *
 * eCAT - Tool for Continuous Testing Agent for the JADE/Eclipse Platform
 * Copyright (C) ITC-IRST, Trento, Italy
 * Authors: Duy Cu Nguyen
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 * The electronic copy of the license can be found here:
 * http://sra.itc.it/tools/taom/freesoftware/gpl.txt
 *
 * The contact information:
 * e-mail: cunduy@itc.it
 * site: http://sra.itc.it
 *
 * </copyright>
 */

package it.itc.sra.ecat.testsuiteman;

import java.util.Iterator;
import java.util.List;

import it.itc.sra.ecat.core.ECATExeption;
import it.itc.sra.ecat.testsuiteman.testsuite.FipaMessageType;
import it.itc.sra.ecat.testsuiteman.testsuite.TActionType;
import it.itc.sra.ecat.testsuiteman.testsuite.TestCaseType;
import it.itc.sra.ecat.testsuiteman.testsuite.TestScenarioType;
import it.itc.sra.ecat.testsuiteman.testsuite.TestSuite;
import it.itc.sra.ecat.testsuiteman.testconfig.TestConfig;
import it.itc.sra.ecat.util.JAXBUtil;

/**
 * Represents a singleton.
 */

public class JADETestSuites {

	private static final String PACKAGE_STUBS = "it.itc.sra.ecat.testsuiteman.testsuite";
	private static JADETestSuites instance;

	private TestSuitesStorage suitesStorage = null;

	/**
	 * Load test suites from the list of test suite paths stored in the
	 * testconfig object
	 * 
	 * @param testConfig
	 * @throws ECATExeption
	 */
	public void loadTestSuites(TestConfig testConfig) throws ECATExeption {
		if (testConfig.getTestSuiteList() != null) {
			List<String> suiteList = testConfig.getTestSuiteList().getTestSuitePath();
			suitesStorage.removeAll();
			Iterator<String> iter = suiteList.iterator();
			while (iter.hasNext()) {
				String suitePath = iter.next();
				try {
					TestSuite suite = (TestSuite) JAXBUtil.loadJAXBFromFile(
							PACKAGE_STUBS, suitePath);
					suitesStorage.addSuite(suite.getID(), suite);
				} catch (ECATExeption e) {
					throw e;
				}
			}
		}
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		String testSuiteFile = "/hardmnt/idacox0/sra/cunduy/temp/CMS/Test/TS3-ProceedingsManager.suite";//"/hardmnt/idacox0/sra/cunduy/projects/Continuous Testing/BibFinder/Test/TS1-Search Bib.xml";

		try {
			TestSuite ts = (TestSuite) JAXBUtil.loadJAXBFromFile(PACKAGE_STUBS,
					testSuiteFile);

			// Try to extract information from this test suites
			pr(ts.getName());
			pr(ts.getTarget().get(0).getAgent());

			List testCases = ts.getTestCase();

			Iterator iterTestCase = testCases.iterator();
			while (iterTestCase.hasNext()) {
				TestCaseType tc = (TestCaseType) iterTestCase.next();
				pr("Test Case: " + tc.getName());
				pr(tc.getDescription());

				pr(tc.getSetup());

				TestScenarioType scenario = tc.getScenario();

				List actions = scenario.getTestAction();
				Iterator iterSequences = actions.iterator();
				while (iterSequences.hasNext()) {
					TActionType seq = (TActionType) iterSequences.next();
					pr(seq.getID());
					pr(seq.getInitiator() + " send to " + seq.getResponder());

					Object messageType = seq.getMessage();

					if (messageType instanceof FipaMessageType) {
						FipaMessageType fipaMsg = (FipaMessageType) messageType; // Cast
						// exception
						// here
						pr(fipaMsg.getAct());
						
						/*
						 * BibFinderActionType actionType =
						 * (BibFinderActionType) msgParam.getContent();
						 * 
						 * pr(actionType.getAction()); pr((String)
						 * actionType.getActionContent() .getContent().get(0));
						 */
					}

				}

			}

		} catch (ECATExeption e) {
			e.printStackTrace();
		}

	}

	public static void pr(Object str) {
		System.out.println(str);
	}

	/**
	 * prevents instantiation
	 */
	private JADETestSuites() {
		suitesStorage = new TestSuitesStorage();
	}

	/**
	 * Returns the singleton instance.
	 * 
	 * @return the singleton instance
	 */
	static public JADETestSuites getInstance() {
		if (instance == null) {
			instance = new JADETestSuites();
		}
		return instance;
	}

	public TestSuitesStorage getSuitesStorage() {
		return suitesStorage;
	}

}
