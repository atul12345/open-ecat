package it.itc.sra.ecat.util;

import it.itc.sra.ecat.testsuiteman.testconfig.NodeType;
import it.itc.sra.ecat.testsuiteman.testsuite.CheckType;
import it.itc.sra.ecat.testsuiteman.testsuite.ContentType;
import it.itc.sra.ecat.testsuiteman.testsuite.OperatorType;
import it.itc.sra.ecat.testsuiteman.testsuite.FipaMessageType;
import it.itc.sra.ecat.testsuiteman.testsuite.AType;
import it.itc.sra.ecat.testsuiteman.testsuite.ObjectFactory;
import it.itc.sra.ecat.testsuiteman.testsuite.OrderLink;
import it.itc.sra.ecat.testsuiteman.testsuite.OrderType;
import it.itc.sra.ecat.testsuiteman.testsuite.TActionType;
import it.itc.sra.ecat.testsuiteman.testsuite.TestCaseType;
import it.itc.sra.ecat.testsuiteman.testsuite.TestScenarioType;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class CommonUtil
{
    public static String getCurrentDateTime()
    {
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss:SSSS");
        return df.format(new Date());
    }
    
    public static String dateDiff(Date last, Date current) {
    	// Calculate different by mili second
    	
    	long miniSecond = current.getTime() - last.getTime();
    	Date diff = new Date(miniSecond);
    	SimpleDateFormat df = new SimpleDateFormat("hh:mm:ss:SSSS");
        return df.format(diff);
    }

    public static String generateId()
    {
        return Long.toString(System.currentTimeMillis());
    }

    public static String generateId(String prefix)
    {
        return prefix + Long.toString(System.currentTimeMillis());
    }

	/**
	 * Copy a test case
	 * 
	 * @param src
	 * @return
	 */
	public static TestCaseType copyTc(TestCaseType src) {
		
		Map<ContentType, ContentType> contentMap = new HashMap<ContentType, ContentType>();
		Map<TActionType, TActionType> actionMap = new HashMap<TActionType, TActionType>();
		// This two maps are used to copy references
		
		ObjectFactory testCaseFactory = new ObjectFactory();

		TestCaseType dest = testCaseFactory.createTestCaseType();

		dest.setActive(src.isActive());
		dest.setDescription(src.getDescription());

		String id = CommonUtil.generateId("TC");
		dest.setID(id);
		dest.setName("COF " + src.getName());
		dest.setDescription(src.getDescription());
		dest.setPriority(src.getPriority());
		dest.setType(src.getType());
		
		dest.setSetup(src.getSetup());
		dest.setTeardown(src.getTeardown());

		TestScenarioType targetScenario = testCaseFactory.createTestScenarioType();

		// Pick randomly a communication protocol
		TestScenarioType senario = (TestScenarioType) src.getScenario();

		// Fill test data into the scenario
		List<TActionType> acts = senario.getTestAction();
		Iterator<TActionType> iter = acts.iterator();
		while (iter.hasNext()) {
			TActionType action = (TActionType) iter.next();
			// Create new target sequence
			TActionType targetSequence = testCaseFactory.createTActionType();
			
			// Add a map
			actionMap.put(action, targetSequence);

			targetSequence.setID(action.getID());
			targetSequence.setTimeout(action.getTimeout());
			targetSequence.setActType(AType.fromValue(action.getActType().value()));

			targetSequence.setInitiator(action.getInitiator());
			targetSequence.setResponder(action.getResponder());

			if (action.getMessage() != null) {

				FipaMessageType srcMsg = (FipaMessageType) action.getMessage();

				FipaMessageType targetMsg = testCaseFactory.createFipaMessageType();
				
				targetMsg.setAct(srcMsg.getAct());
				targetMsg.setId(srcMsg.getId());

				targetMsg.setConversationId(CommonUtil.generateId("TA"));
				
				if (srcMsg.getLanguage() != null) {
					targetMsg.setLanguage(srcMsg.getLanguage());
				}

				if (srcMsg.getOntology() != null) {
					targetMsg.setOntology(srcMsg.getOntology());
				}
				
				if (srcMsg.getProtocol() != null) {
					targetMsg.setProtocol(srcMsg.getProtocol());
				}
				
				ContentType content = new ContentType();
				if (srcMsg.getContent() != null){
					content.setClazz(srcMsg.getContent().getClazz());
					content.setValue(srcMsg.getContent().getValue());
					content.setId(srcMsg.getContent().getId());
				}
				
				// Content reference will be relinked later
				// Put a map
				contentMap.put(srcMsg.getContent(), content);

				
				targetMsg.setContent(content);
				

				targetSequence.setMessage(targetMsg);
			}

			if (action.getVerdict() != null) {
				CheckType verdict = testCaseFactory.createCheckType();
				verdict.setCheckOperator(OperatorType.fromValue(action.getVerdict().getCheckOperator().value()));

				if (action.getVerdict().getExpectedValue() != null) {
					FipaMessageType srcMsg = (FipaMessageType) action.getVerdict().getExpectedValue();
					FipaMessageType targetMsg = testCaseFactory.createFipaMessageType();

					targetMsg.setAct(srcMsg.getAct());
					targetMsg.setId(srcMsg.getId());

					targetMsg.setConversationId(srcMsg.getConversationId());

					if (srcMsg.getLanguage() != null) {
						targetMsg.setLanguage(srcMsg.getLanguage());
					}

					if (srcMsg.getOntology() != null) {
						targetMsg.setOntology(srcMsg.getOntology());
					}
					
					if (srcMsg.getProtocol() != null) {
						targetMsg.setProtocol(srcMsg.getProtocol());
					}

					ContentType content = new ContentType();
					content.setClazz(srcMsg.getContent().getClazz());
					content.setValue(srcMsg.getContent().getValue());
					content.setId(srcMsg.getContent().getId());
					
					// Content reference will be relinked later
					targetMsg.setContent(content);
					// Put a map
					contentMap.put(srcMsg.getContent(), content);
					
					verdict.setExpectedValue(targetMsg);
				}
				// Set condition
				targetSequence.setVerdict(verdict);
			}

			// Add new sequence to the target scenario
			targetScenario.getTestAction().add(targetSequence);
		}
		
		// Relink references among sequences)
		
		Iterator<TActionType> iterOrigin = acts.iterator();
		while (iterOrigin.hasNext()){
			TActionType orgAct = (TActionType) iterOrigin.next();
			TActionType targetAct = actionMap.get(orgAct);
			Object obj;
			if ((obj = orgAct.getNextAction()) != null) {
				targetAct.setNextAction(actionMap.get(obj));
			}
			if ((obj = orgAct.getNextIfTrue()) != null) {
				targetAct.setNextIfTrue(actionMap.get(obj));
			}
			if ((obj = orgAct.getNextIfFalse()) != null) {
				targetAct.setNextIfFalse(actionMap.get(obj));
			}
			
			if (orgAct.getMessage() != null) {
				ContentType srcCnt = orgAct.getMessage().getContent();
				ContentType targetCnt = targetAct.getMessage().getContent();
				if (srcCnt.getValueref() != null){
					targetCnt.setValueref(contentMap.get(srcCnt.getValueref()));
				}
			}
			
			if (orgAct.getVerdict() != null){
				if (orgAct.getVerdict().getExpectedValue() != null) {
					ContentType srcCnt = orgAct.getVerdict().getExpectedValue().getContent();
					ContentType targetCnt = targetAct.getVerdict().getExpectedValue().getContent();
					if (srcCnt.getValueref() != null){
						targetCnt.setValueref(contentMap.get(srcCnt.getValueref()));
					}
				}
			}
			
		}
		
		
		// Add the scenario to the test case
		dest.setScenario(targetScenario);

		return dest;

	}
    
	/**
	 * Create links from specified protocol
	 * @param tc
	 */
	public static void createLinks(TestCaseType tc){
		List<TActionType> actions = tc.getScenario().getTestAction();
		for (TActionType act : actions){
			if (act.getNextAction() != null){
				TActionType nextAct = (TActionType) act.getNextAction();
				OrderLink link = new OrderLink();
				link.setOrderType(OrderType.SUBSEQUENCE);
				link.setSource("#" + act.getID());
				link.setTarget("#" + nextAct.getID());
				tc.getScenario().getLink().add(link);
			}
			
			if (act.getNextIfTrue() != null){
				TActionType nextAct = (TActionType) act.getNextIfTrue();
				OrderLink link = new OrderLink();
				link.setOrderType(OrderType.ONLY_IF_TRUE);
				link.setSource("#" + act.getID());
				link.setTarget("#" + nextAct.getID());
				tc.getScenario().getLink().add(link);
			}
			
			if (act.getNextIfFalse() != null){
				TActionType nextAct = (TActionType) act.getNextIfFalse();
				OrderLink link = new OrderLink();
				link.setOrderType(OrderType.ONLY_IF_FALSE);
				link.setSource("#" + act.getID());
				link.setTarget("#" + nextAct.getID());
				tc.getScenario().getLink().add(link);
			}
			
		}
	}
	
	
    public static String normalizeFileName(String fileName){
    	if (fileName == null)
			return "";
		return fileName.replaceAll("\r\n", "");
    }
    
    public static String normalizeAgentName(String name){
    	if (name == null)
			return "";
		return name.replaceAll("\r\n", "").replace(" ", "");
    }
    
    public static String normalizeXML(String input){
    	
    	if (input == null)
    		return "";
    	
    	//if (input.indexOf("<?xml") >= 0)
    	//{
	    	Pattern p = Pattern.compile("<");
	
	        Matcher matcher = p.matcher(input);
	        String tmp = matcher.replaceAll("&lt;");
	
	        p = Pattern.compile(">");
	        matcher = p.matcher(tmp);
	        tmp = matcher.replaceAll("&gt;");
	        
	        /*String expr = "\\\"";
	        p = Pattern.compile(expr);
	        matcher = p.matcher(tmp);
	        tmp = matcher.replaceAll("&quot;");*/
	        
	        return tmp;
    	//}
    	
    	//return input;
    }
    
    /**
     * Normalize remote monitoring agent GUID
     * @param node
     * @return
     */
    public static String getRemoteMonitoringAgentGUID(NodeType node){
    	String remoteAgentID = node.getRemoteMonitoringAgent();
		if (remoteAgentID.lastIndexOf("@") == -1){
			remoteAgentID = remoteAgentID + "@" + node.getNodeHap();
		}
		
		return remoteAgentID;
    }
    
    /**
     * normalize remote executor agent GUID
     * @param node
     * @return
     */
    public static String getRemoteExecutorAgentGUID(NodeType node){
    	String remoteAgentID = node.getRemoteExecutorAgent();
		if (remoteAgentID.lastIndexOf("@") == -1){
			remoteAgentID = remoteAgentID + "@" + node.getNodeHap();
		}
		
		return remoteAgentID;
    }
}
