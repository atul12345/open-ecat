/**
 * <copyright>
 *
 * eCAT - Tool for Continuous Testing Agent for the JADE/Eclipse Platform
 * Copyright (C) ITC-IRST, Trento, Italy
 * Authors: Duy Cu Nguyen
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 * The electronic copy of the license can be found here:
 * http://sra.itc.it/tools/taom/freesoftware/gpl.txt
 *
 * The contact information:
 * e-mail: cunduy@itc.it
 * site: http://sra.itc.it
 *
 * </copyright>
 */

package it.itc.sra.ecat.ecatplugin.generatewizards;

import it.itc.sra.ecat.ECATPlugIn;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.Path;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.viewers.ILabelProvider;
import org.eclipse.jface.viewers.ITreeContentProvider;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.DirectoryDialog;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.dialogs.ElementTreeSelectionDialog;
import org.eclipse.ui.model.BaseWorkbenchContentProvider;
import org.eclipse.ui.model.WorkbenchLabelProvider;


public class PathsPage extends WizardPage {
	private String troposModel = "";
	private String outputFolder = "";
	private String protocolFile = "";
	private boolean builtIn = true;

	protected PathsPage(String pageName, String title, ImageDescriptor titleImage) {
		super(pageName, title, titleImage);
	}
	
	
	public PathsPage(String pageName) {
		super(pageName);
		
	}


	public void createControl( Composite parent) {
		Composite composite = new Composite(parent, SWT.NONE);
		GridLayout layout = new GridLayout(3, false);
		composite.setLayout(layout);
		
		Label label = new Label(composite, SWT.NONE);
		label.setText("Tropos model:");
		final Text troposModelPath = new Text(composite, SWT.BORDER | SWT.SINGLE);
		troposModelPath.setText(troposModel);
		
		GridData layoutData = new GridData(GridData.FILL_HORIZONTAL);
		troposModelPath.setLayoutData(layoutData);
		
		Button troposBrowse = new Button(composite, SWT.NONE);
		layoutData = new GridData();
		layoutData.widthHint = 70;
		troposBrowse.setText("  Browse..  ");
		troposBrowse.setLayoutData(layoutData);
		
		troposBrowse.addMouseListener(new MouseListener(){

			public void mouseDoubleClick(MouseEvent e) {
			}

			public void mouseDown(MouseEvent e) {
				
				String tmp = getSelection("Tropos Model", "Select a Tropos model");
				if (!tmp.equals("")){ 
					troposModelPath.setText(tmp);
					troposModel = tmp;
				}
			}

			public void mouseUp(MouseEvent e) {
			}
			
		});
		
		createSpace(composite);
		// Second row, output folder
		
		label = new Label(composite, SWT.NONE);
		label.setText("Output folder:");
		final Text outputPath = new Text(composite, SWT.BORDER | SWT.SINGLE);
		outputPath.setText(outputFolder);
		
		layoutData = new GridData(GridData.FILL_HORIZONTAL);
		outputPath.setLayoutData(layoutData);
		
		Button outputBrowse = new Button(composite, SWT.NONE);
		layoutData = new GridData();
		layoutData.widthHint = 70;
		outputBrowse.setText("  Browse...  ");
		outputBrowse.setLayoutData(layoutData);
		
		outputBrowse.addMouseListener(new MouseListener(){

			public void mouseDoubleClick(MouseEvent e) {
			}

			public void mouseDown(MouseEvent e) {
				/*
				DirectoryDialog directoryDialog = new DirectoryDialog(getShell());
				String tmp = directoryDialog.open();
				if (tmp != null){
					outputPath.setText(tmp);
					outputFolder = tmp;
					
					if (!troposModel.equals("") && !outputFolder.equals("")){
						setPageComplete(true);
					}
				}
				*/
				
				String tmp = getSelection("Output Folder", "Select a folder for storing test suites");
				if (!tmp.equals("")){ 
					outputPath.setText(tmp);
					outputFolder = tmp;
					if (!troposModel.equals("") && !outputFolder.equals("")){
						setPageComplete(true);
					}
				}
			}

			public void mouseUp(MouseEvent e) {
			}
			
		});
		
		createSpace(composite);
		// Ask user to use built-in protocol templates 
		
		label = new Label(composite, SWT.NONE);
		label.setText("Use built-in scenario template");
		
		final Button useBuiltInScenarios = new Button(composite, SWT.CHECK);
		
		layoutData = new GridData(GridData.FILL_HORIZONTAL);
		layoutData.horizontalSpan = 2;
		useBuiltInScenarios.setText("Yes");
		useBuiltInScenarios.setLayoutData(layoutData);
		
		// Third row: Protocol
		
		label = new Label(composite, SWT.NONE);
		label.setText("Use user's scenario templates:");
		
		final Text protocolPath = new Text(composite, SWT.BORDER);
		protocolPath.setText(protocolFile);
		layoutData = new GridData(GridData.FILL_HORIZONTAL);
		protocolPath.setLayoutData(layoutData);
		
		final Button protocolBrowse = new Button(composite, SWT.NONE);
		layoutData = new GridData();
		layoutData.widthHint = 70;
		protocolBrowse.setText("  Browse...  ");
		protocolBrowse.setLayoutData(layoutData);
		
		protocolBrowse.setEnabled(false);
		protocolPath.setEnabled(false);
		useBuiltInScenarios.setSelection(true);
		
		useBuiltInScenarios.addMouseListener(new MouseListener(){
			
			public void mouseDoubleClick(MouseEvent e) {
			}

			public void mouseDown(MouseEvent e) {
				
				boolean selected = useBuiltInScenarios.getSelection();
				
				protocolBrowse.setEnabled(!protocolBrowse.getEnabled());
				protocolPath.setEnabled(!protocolPath.getEnabled());
				
				if (!selected){
					builtIn = true;
					IPath path  = ECATPlugIn.getDefault().getPluginPath();
					path =  path.append("data").append("protocol").append("ProtocolList.xml");
					String tmp = path.toOSString();
					//protocolFile = tmp;
					ScenariosPage nextPage = (ScenariosPage) getNextPage();
					nextPage.setPath(tmp);
					nextPage.update();
				} else if (protocolPath.getText() != null){
					builtIn = false;
					String tmp = protocolPath.getText();
					IPath path = new Path(tmp);
					if (path.isValidPath(tmp)){
						ScenariosPage nextPage = (ScenariosPage) getNextPage();
						nextPage.setPath(tmp);
						nextPage.update();
					}
				}
			}

			public void mouseUp(MouseEvent e) {
			}
			
		});
		
		protocolBrowse.addMouseListener(new MouseListener(){

			public void mouseDoubleClick(MouseEvent e) {
			}

			public void mouseDown(MouseEvent e) {
				
				//String tmp = getSelection("Scenario templates list", "Select the file that contains scenario templates");
				
				//DirectoryDialog directoryDialog = new DirectoryDialog(getShell());
				FileDialog fileDialog = new FileDialog(getShell());
				fileDialog.setFilterExtensions(new String[]{"*.xml"});
				fileDialog.setFileName(protocolPath.getText());
				String tmp = fileDialog.open();
				if (tmp != null){
					protocolPath.setText(tmp);
					protocolFile = tmp;
					ScenariosPage nextPage = (ScenariosPage) getNextPage();
					nextPage.setPath(tmp);
					nextPage.update();
				}
			}

			public void mouseUp(MouseEvent e) {
			}
			
		});
		
		
		setControl(composite);
		return;
	}
	
	private void createSpace(Composite composite){
		Label label = new Label(composite, SWT.NONE);
		GridData dg = new GridData();
		dg.horizontalSpan = 3;
		dg.heightHint = 3;
		label.setLayoutData(dg);
	}
	
	/**
	 * Ask user to select an element from the workspace
	 * @param title
	 * @param msg
	 * @return
	 */
	private String getSelection(String title, String msg){
		ILabelProvider lp= new WorkbenchLabelProvider();
		ITreeContentProvider cp= new BaseWorkbenchContentProvider(); 
		
		ElementTreeSelectionDialog dialog = new ElementTreeSelectionDialog(getShell(),lp, cp);
		dialog.setValidator(null);
		dialog.setAllowMultiple(false);
		dialog.setTitle(title); 
		dialog.setMessage(msg); 
		dialog.setInput(ResourcesPlugin.getWorkspace().getRoot());
		
		if (dialog.open() == ElementTreeSelectionDialog.OK) {
			Object[] elements= dialog.getResult();
			if (elements.length == 1) {
				String temp = ((IResource)elements[0]).getLocation().toOSString();
				return temp;
			}
		} 
		
		return "";
	}

	public String getOutputFolder() {
		return outputFolder;
	}

	public String getTroposModel() {
		return troposModel;
	}


	
	public String getProtocolFile() {
		return protocolFile;
	}


	public void setProtocolFile(String protocolFile) {
		this.protocolFile = protocolFile;
	}


	public void setOutputFolder(String outputFolder) {
		this.outputFolder = outputFolder;
	}


	public void setTroposModel(String troposModel) {
		this.troposModel = troposModel;
	}


	public boolean isBuiltIn() {
		return builtIn;
	}
	
	
}
