/**
 * <copyright>
 *
 * eCAT - Tool for Continuous Testing Agent for the JADE/Eclipse Platform
 * Copyright (C) ITC-IRST, Trento, Italy
 * Authors: Duy Cu Nguyen
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 * The electronic copy of the license can be found here:
 * http://sra.itc.it/tools/taom/freesoftware/gpl.txt
 *
 * The contact information:
 * e-mail: cunduy@itc.it
 * site: http://sra.itc.it
 *
 * </copyright>
 */

package it.itc.sra.ecat.ecatplugin.mutantwizards;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Group;

public class ClassSelectionPages extends WizardPage {

	private List<String> selectedClass;

	private String resultsPath;

	private org.eclipse.swt.widgets.List classlist;

	protected ClassSelectionPages(String pageName) {
		super(pageName);
		selectedClass = new ArrayList<String>();
	}

	public void createControl(Composite parent) {
		Composite comp = new Composite(parent, SWT.NONE);
		setControl(comp);

		GridLayout topLayout = new GridLayout();
		comp.setLayout(topLayout);

		createClasses(comp);

	}

	private void createClasses(Composite comp) {
		Group classes = new Group(comp, SWT.SHADOW_ETCHED_IN);
		classes.setText("Select classes to combine");

		GridLayout layout = new GridLayout();
		layout.marginLeft = 5;
		layout.marginRight = 5;
		layout.marginBottom = 5;
		classes.setLayout(layout);

		GridData gd = new GridData(GridData.FILL_BOTH
				| GridData.VERTICAL_ALIGN_BEGINNING);
		gd.horizontalSpan = 3;
		classes.setLayoutData(gd);

		classlist = new org.eclipse.swt.widgets.List(classes, SWT.V_SCROLL
				| SWT.MULTI | SWT.BORDER);
		prepareClassList();

		gd = new GridData(GridData.FILL_BOTH
				| GridData.VERTICAL_ALIGN_BEGINNING);
		classlist.setLayoutData(gd);

		classlist.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				String selected[] = classlist.getSelection();
				selectedClass.clear();
				for (int i = 0; i < selected.length; i++) {
					selectedClass.add(selected[i]);
				}
			}
		});
	}

	private void prepareClassList() {
		if (resultsPath == null || classlist == null) return;
		File file = new File(resultsPath);

		if (file.exists() && file.isDirectory()) {
			classlist.removeAll();

			File listFile[] = file.listFiles();
			for (File f : listFile) {
				if (f.isDirectory()) {
					classlist.add(f.getName());
				}
			}
		}
	}

	public List getSelectedClass() {
		return selectedClass;
	}

	public String getResultsPath() {
		return resultsPath;
	}

	public void setResultsPath(String resultsPath) {
		this.resultsPath = resultsPath;
		prepareClassList();
	}

}
