/**
 * <copyright>
 *
 * eCAT - Tool for Continuous Testing Agent for the JADE/Eclipse Platform
 * Copyright (C) ITC-IRST, Trento, Italy
 * Authors: Duy Cu Nguyen
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 * The electronic copy of the license can be found here:
 * http://sra.itc.it/tools/taom/freesoftware/gpl.txt
 *
 * The contact information:
 * e-mail: cunduy@itc.it
 * site: http://sra.itc.it
 *
 * </copyright>
 */

package it.itc.sra.ecat.core.tester;

import it.itc.sra.ecat.ECATPlugIn;
import it.itc.sra.ecat.core.Interaction;
import it.itc.sra.ecat.core.Synchronizer;
import it.itc.sra.ecat.core.TestResultsModel;
import it.itc.sra.ecat.core.monitor.IMonitorAgent;
import it.itc.sra.ecat.testsuiteman.JADETestSuites;
import it.itc.sra.ecat.testsuiteman.TestSuitesStorage;
import it.itc.sra.ecat.testsuiteman.generation.RandomGenerator;
import it.itc.sra.ecat.testsuiteman.testsuite.TestCaseType;
import it.itc.sra.ecat.testsuiteman.testsuite.TestSupportType;
import it.itc.sra.ecat.testsuiteman.testsuite.TestSuite;
import it.itc.sra.ecat.testsuiteman.testconfig.NodeType;
import it.itc.sra.ecat.testsuiteman.testconfig.PreferedStrategyType;
import it.itc.sra.ecat.testsuiteman.testconfig.TestConfig;
import it.itc.sra.ecat.util.CommonUtil;
import it.itc.sra.ecat.util.GeneralLogger;

import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.core.behaviours.ParallelBehaviour;
import jade.core.behaviours.SimpleBehaviour;
import jade.wrapper.AgentController;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * @author cunduy
 */
public class TesterAgent extends Agent implements ITesterAgent {

	//private static final String MY_NAME = "TesterAgent";
	private static final int MAX_NUM_TESTCASE = 10;

	private GeneralLogger logger = GeneralLogger.getInstance();
	/**
	 * 
	 */
	private static final long serialVersionUID = -878670846952378382L;

	private boolean stopTesting = true;
	
	private TestHelper helper; // TODO just copy, optimize later

	private TestResultsModel resultModel = TestResultsModel.getInstance();

	public TesterAgent() {
		super();
	}

	protected void setup() {
		super.setup();
		setEnabledO2ACommunication(true, 100); // Maximum 100 testConfigs can
		// be processed
		/**
		 * Initialize the communication between the plugin platform and the
		 * agent platform
		 * 
		 */

		// TODO, optimize it later
		helper = new TestHelper(this);
		
		this.addBehaviour(new PlugInListener(this));
		// this.addBehaviour(new ReceiveAnythingLeft(this));

		// Set the reference from the plugin to this agent
		ECATPlugIn.getDefault().setTesterAgent(this);

		// Notify the PlugIn that the agent is ready

		Object[] args = getArguments();
		Synchronizer synchronizer = (Synchronizer) (args[0]);
		synchronizer.Started();

		logger.log(GeneralLogger.LEVEL_INFO, "Tester Agent Started!");
	}

	protected void takeDown() {
		// Set the reference from the plugin to this agent
		ECATPlugIn.getDefault().setTesterReady(false);
		super.takeDown();
	}

	/**
	 * Listen to the request from the plugin
	 * 
	 * @author cunduy
	 * 
	 */
	private class PlugInListener extends CyclicBehaviour {

		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		public PlugInListener(Agent a) {
			super(a);

		}

		public void action() {
			Object interaction = getO2AObject();
			if (interaction != null) {
				if (stopTesting) {
					stopTesting = false;
				} else {
					return;
				}
				
				TestConfig testConfig = ((Interaction) interaction).getTestConfig();
				if (testConfig.getPreferedStrategy().equals(PreferedStrategyType.MANUAL)) {
					processTestSetup();
					myAgent.addBehaviour(new ManualTestExecutionBehaviour(myAgent, testConfig));
					//processTestTearDown();
				} else if (testConfig.getPreferedStrategy().equals(PreferedStrategyType.RANDOM)) {
					myAgent.addBehaviour(new RandomTestExecutionBehaviour(myAgent, testConfig));
				
				} else if (testConfig.getPreferedStrategy().equals(PreferedStrategyType.RANDOM_PLUS)) {
					RandomPlusTestExecutionBehaviour randomPTest = new RandomPlusTestExecutionBehaviour(myAgent, testConfig);
					myAgent.addBehaviour(randomPTest);
				
				} else if (testConfig.getPreferedStrategy().equals(PreferedStrategyType.MUTATION_PLUS)) {
					ArrayList<TestCaseType> list = prepareInitialPopulation(testConfig);
					MutationTestExecutionBehaviour mutationTest = new MutationTestExecutionBehaviour(myAgent,
							testConfig, list);
					myAgent.addBehaviour(mutationTest);
				
				} else if (testConfig.getPreferedStrategy().equals(PreferedStrategyType.MUTATION)) {
					ArrayList<TestCaseType> list = generateRandomInitialPopulation(testConfig);
					// Addd the generated test cases to the results views
					resultModel.addTestCase(list);
					
					MutationTestExecutionBehaviour mutationTest = new MutationTestExecutionBehaviour(myAgent,
							testConfig, list);
					myAgent.addBehaviour(mutationTest);
					
				} else if (testConfig.getPreferedStrategy().equals(PreferedStrategyType.ONTO_BASED)){
					OntoTestExecutionBehaviour ontoTest = new OntoTestExecutionBehaviour(myAgent, testConfig);
					myAgent.addBehaviour(ontoTest);
				}
			} else {
				block(); // block this behavior
			}

		}
	}

	/**
	 * Manual testing
	 * 
	 * @author cunduy
	 * 
	 */
	private class ManualTestExecutionBehaviour extends SimpleBehaviour {

		private static final long serialVersionUID = 663213861599983737L;
		private TestConfig testConfig;
		private int cycle = 0;

		private TestSuite[] suiteList;
		private TestCaseType[] testcases;
		private int currentSuite = -1;
		private int currentTC = 0;
		private IMonitorAgent monitorAgent = ECATPlugIn.getDefault().getMonitorAgent();
		private String currentSessionID = "";

		public ManualTestExecutionBehaviour(Agent a, TestConfig testConfig) {
			super(a);
			this.testConfig = testConfig;

			TestSuitesStorage storage = JADETestSuites.getInstance().getSuitesStorage();
			if (storage != null)
				suiteList = storage.getTestSuite();

			logger.log("Launch manual testing");
		}

		@Override
		public void action() {

			// Check the configuration file (Nodes configuration)

			if (testConfig.getDitributedNodeConfig() == null) {
				stopTesting = true;
				return;
			}

			if (stopTesting)
				return; // external force stop testing

			/*
			 * if (cycle > 0 && !parallelTestBehaviour.done()){
			 * //logger.log("Previous test has not done yet!"); block(1000);
			 * return; }
			 */
			if (currentSuite < suiteList.length) {

				if (currentSuite == -1) {
					// start or next test suite
					currentSuite = 0;
					testcases = prepareTestCaseTypes(suiteList[currentSuite]);
					currentTC = 0;
				}

				TestSuite suite = suiteList[currentSuite];
				TestCaseType tc = testcases[currentTC];

				List<NodeType> nodeList = testConfig.getDitributedNodeConfig().getNode();
				ParallelBehaviour parallelTestBehaviour = new ParallelBehaviour(ParallelBehaviour.WHEN_ALL);
				Iterator<NodeType> iter = nodeList.iterator();
				while (iter.hasNext()) {
					NodeType node = (NodeType) iter.next();
					ManualTestBehaviour testSession = new ManualTestBehaviour(myAgent, node);
					testSession.setTestCase(tc);
					parallelTestBehaviour.addSubBehaviour(testSession);
				}

				if (ECATPlugIn.getDefault().isMonitoringEnable()){
					
					// Synchronize previous trace
					
					if (monitorAgent != null && !currentSessionID.equals("")) {
						Synchronizer sync = new Synchronizer();
						monitorAgent.getRemoteTraces(sync);
						sync.waitOn();
					}
				

					//logger.log("Test suite:" + suite.getID());
					//logger.log("Test case: " + tc.getID());
					// New test session
					if (monitorAgent != null) {
						String taID = myAgent.getLocalName();
						String uid = myAgent.getAID().getHap() + "/";
						currentSessionID = CommonUtil.generateId(uid);
	
						Synchronizer sync = new Synchronizer();
						monitorAgent.startNewSession(currentSessionID, taID, suite.getID(), tc.getID(), sync);
						sync.waitOn();
					}
				}

				myAgent.addBehaviour(parallelTestBehaviour);
				currentTC += 1;
				
				if (currentTC == testcases.length){
					currentSuite += 1; // next suite
					if (currentSuite < suiteList.length)
						testcases = prepareTestCaseTypes(suiteList[currentSuite]);
					currentTC = 0;
				}
			}

			if (currentSuite == suiteList.length) {
				cycle = cycle + 1;

				// Display cycle
				resultModel.setTestCycle(cycle);
				logger.log("Finish manual testing cycle: " + String.valueOf(cycle));
				currentSuite = -1; // restart new cycle :-)
			}

			if (testConfig.getNumberCycle() != -1 && cycle >= testConfig.getNumberCycle()) {
				stopTesting = true;
				// Stop monitoring

				if (monitorAgent != null) {
					monitorAgent.delayedStopMonitoring();
				}
			} else {
				block(1000); // Stop between suite
			}
		}

		@Override
		public boolean done() {
			return stopTesting;
		}

	}

	/**
	 * Execute random testing
	 * 
	 * @author cunduy
	 */
	private class RandomTestExecutionBehaviour extends SimpleBehaviour {

		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		private TestConfig testConfig;
		private int cycle = 0;
		private IMonitorAgent monitorAgent = ECATPlugIn.getDefault().getMonitorAgent();
		private String currentSessionID = "";

		List<TestCaseType> tcList = null;
		Iterator<TestCaseType> tcIter;

		private boolean isNewCycle = true;
		private boolean isReady = false;

		RandomGenerator generator;

		public RandomTestExecutionBehaviour(Agent a, TestConfig testConfig) {
			super(a);
			this.testConfig = testConfig;
			generator = new RandomGenerator();

			String protocolPath = testConfig.getProtocolPath();
			String dataPath = testConfig.getDomainDataPath();
			if (protocolPath != null && dataPath != null) {
				isReady = generator.initData(protocolPath, dataPath);
			} else {
				logger.log("There are problems with protocolPath, dataPath\n"
						+ ". Please check random test configuration");
			}
		}

		public void action() {
			if (stopTesting)
				return; // external request
			
			if (!isReady){
				logger.log("Random test is not ready, you may have to check the test configuration file!");
				stopTesting = true;
				return;
			}
				
			
			if (isNewCycle){
				logger.log("START Generating test cases");
				Date startTime = new Date();
				
				String agentsUnderTest = testConfig.getAgentUnderTest();
				String agentsList[] = agentsUnderTest.split(";");
				
				String selectedAgent = agentsUnderTest;
				if (agentsList.length > 1){
					Random agentSelector = new Random();
					selectedAgent = agentsList[agentSelector.nextInt(agentsList.length)];
				}
				List<TestCaseType> tcList = generator.generate(testConfig.getMaxRandomTC(), selectedAgent);
				Date finishTime = new Date();
				logger.log("FINISH. Generation time: " + CommonUtil.dateDiff(startTime, finishTime));

				tcIter = tcList.iterator();
				
				isNewCycle = false;
			}
			
			logger.log("START Random Testing");
				
			if (tcIter != null && tcIter.hasNext()) {
				TestCaseType tc = tcIter.next();
				
				// add new generated test case to the view
				resultModel.addTestCase(tc);
				// Display cycle
				resultModel.setTestCycle(cycle);
				
				if (ECATPlugIn.getDefault().isMonitoringEnable()){
					
					// synchronize remote traces
					if (monitorAgent != null && !currentSessionID.equals("")){
						// Synchronize previous trace
						Synchronizer sync = new Synchronizer();
						monitorAgent.getRemoteTraces(sync);
						sync.waitOn();
						
					}
					
					// new test session
					if (monitorAgent != null){
						String taID = myAgent.getLocalName();
						String uid = myAgent.getAID().getHap() + "/";
						currentSessionID = CommonUtil.generateId(uid);
						
						Synchronizer sync = new Synchronizer();
						monitorAgent.startNewSession(currentSessionID, taID, "random-generated", tc.getID(), sync);
						sync.waitOn();
					}
				}
				
				List<NodeType> nodeList = testConfig.getDitributedNodeConfig().getNode();
				ParallelBehaviour parallelTestBehaviour = new ParallelBehaviour(ParallelBehaviour.WHEN_ALL);
				Iterator<NodeType> iter = nodeList.iterator();
				while (iter.hasNext()) {
					NodeType node = (NodeType) iter.next();
					RandomTestBehaviour testSession = new RandomTestBehaviour(myAgent, node);
					testSession.setTestCase(tc);
					parallelTestBehaviour.addSubBehaviour(testSession);
				}
				
				myAgent.addBehaviour(parallelTestBehaviour); // add and release program control
				
			} else {
				cycle = cycle + 1;
				isNewCycle = true;
			}
			
			if (cycle >= testConfig.getNumberCycle()){
				stopTesting = true;
				// Stop monitoring
				IMonitorAgent monitor =  ECATPlugIn.getDefault().getMonitorAgent();
				if (monitor != null){
					monitor.delayedStopMonitoring();
				}
			} else 
				block(1000); // Finish just one more cycle
		}

		public boolean done() {
			return stopTesting;
		}

	}

	
	/**
	 * Generate randomly an initial population for mutation testing
	 * @param testConfig
	 * @return
	 */
	private ArrayList<TestCaseType> generateRandomInitialPopulation(TestConfig testConfig) {
		
		RandomGenerator generator = new RandomGenerator();

		String protocolPath = testConfig.getProtocolPath();
		String dataPath = testConfig.getDomainDataPath();
		if (protocolPath != null && dataPath != null) {
			if (generator.initData(protocolPath, dataPath)){
				int numberOfCases = testConfig.getMaxRandomTC();
				if (numberOfCases < 1)
					numberOfCases = MAX_NUM_TESTCASE;
				
				String agentsUnderTest = testConfig.getAgentUnderTest();
				String agentsList[] = agentsUnderTest.split(";");
				
				String selectedAgent = agentsUnderTest;
				if (agentsList.length > 1){
					Random agentSelector = new Random();
					selectedAgent = agentsList[agentSelector.nextInt(agentsList.length)];
				}
				return (ArrayList<TestCaseType>)generator.generate(numberOfCases, selectedAgent);
			}
		}
		
		return null;
	}
	
	private ArrayList<TestCaseType> prepareInitialPopulation(TestConfig testConfig) {
		ArrayList<TestCaseType> ipopulation = new ArrayList<TestCaseType>();

		JADETestSuites jadeTestSuites = JADETestSuites.getInstance();
		TestSuitesStorage storage = jadeTestSuites.getSuitesStorage();

		Iterator<TestSuite> iterator = storage.iterator();

		while (iterator.hasNext()) {
			TestSuite suite = iterator.next();

			List<TestCaseType> tc = suite.getTestCase();
			Iterator<TestCaseType> iter = tc.iterator();
			while (iter.hasNext()) {
				ipopulation.add(iter.next());
			}
		}
		return ipopulation;
	}

	/**
	 * Get the list of test case from a test suite
	 * 
	 * @param testConfig
	 * @return
	 */
	private TestCaseType[] prepareTestCaseTypes(TestSuite suite) {
		TestCaseType testcases[] = (TestCaseType[]) suite.getTestCase().toArray(
				new TestCaseType[suite.getTestCase().size()]);
		// Sort testcases by their priority
		// TODO remove if needed, currently priority is not used
		// Arrays.sort(testcases, new TestCaseComparator());
		return testcases;
	}

	/**
	 * 
	 */
	public void performTest(Interaction interact) {
		try {

			putO2AObject(interact, AgentController.ASYNC);
			// interact.waitChangedResponse();

		} catch (InterruptedException e) {
			e.printStackTrace(logger.getOut());
		}
	}

	/**
	 * Checkpoint Behaviour
	 * 
	 * @author cunduy
	 */

	public void stopTesting() {
		// Stop all runing test
		stopTesting = true;
	}

	public boolean isRunningTest() {
		if (stopTesting)
			return false;
		else
			return true;
	}

	
	// TODO copy from the OntoTestExecution, optimize it later
	private void processTestSetup(){
		JADETestSuites storage = JADETestSuites.getInstance();
		Iterator<TestSuite> iterator = storage.getSuitesStorage().iterator();
		while (iterator.hasNext()) {
			TestSuite suite = iterator.next();
			TestSupportType setup = suite.getSetup(); 
			if (setup != null){
				helper.processTestSetupTeardown(setup);
			}
		}
	}
	
	/**
	 * Process tear down
	 */
	private void processTestTearDown(){
		JADETestSuites storage = JADETestSuites.getInstance();
		Iterator<TestSuite> iterator = storage.getSuitesStorage().iterator();
		while (iterator.hasNext()) {
			TestSuite suite = iterator.next();
			TestSupportType teardown = suite.getTeardown(); 
			if (teardown != null){
				helper.processTestSetupTeardown(teardown);
			}
		}
	}

}
