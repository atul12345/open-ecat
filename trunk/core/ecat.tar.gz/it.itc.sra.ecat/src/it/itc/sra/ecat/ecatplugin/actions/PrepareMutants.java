/**
 * <copyright>
 *
 * eCAT - Tool for Continuous Testing Agent for the JADE/Eclipse Platform
 * Copyright (C) ITC-IRST, Trento, Italy
 * Authors: Duy Cu Nguyen
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 * The electronic copy of the license can be found here:
 * http://sra.itc.it/tools/taom/freesoftware/gpl.txt
 *
 * The contact information:
 * e-mail: cunduy@itc.it
 * site: http://sra.itc.it
 *
 * </copyright>
 */

package it.itc.sra.ecat.ecatplugin.actions;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.StringTokenizer;
import java.util.Vector;

import it.itc.sra.ecat.ecatplugin.mutantwizards.MutantsPreparationWizard;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.wizard.WizardDialog;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.IWorkbenchWindowActionDelegate;

public class PrepareMutants implements IWorkbenchWindowActionDelegate {
	IWorkbenchWindow window;
	
	private String MUTANT_PREFIX = "mutant-";
	
	public void dispose() {
	}

	public void init(IWorkbenchWindow window) {
		this.window = window;
	}

	public void run(IAction action) {
		final MutantsPreparationWizard prepareMutantsWizard = new MutantsPreparationWizard();
		WizardDialog dialog = new WizardDialog(window.getShell(), prepareMutantsWizard);
		if (dialog.open() == WizardDialog.OK){
			
			final String resultPath = prepareMutantsWizard.getResultsPath();
			final String mutantsPath = prepareMutantsWizard.getMutantsPath();
			final List selectedClasses = prepareMutantsWizard.getSelectedClass();
			final int port = prepareMutantsWizard.getStartPort();
			final int mtpport = prepareMutantsWizard.getStartMtpPort();
			
			
			if (resultPath != null && mutantsPath != null){
				if (selectedClasses != null & selectedClasses.size() > 0){
					
					Job preparingJob = new Job("Preparing mutants"){
		
						@Override
						protected IStatus run(IProgressMonitor monitor) {
							IPath path = new Path(resultPath);
							
							Iterator iter = selectedClasses.iterator();
							HashMap<String, HashMap> hashMap = new HashMap<String, HashMap>();
							List possibleMutants = new ArrayList();
							
							//monitor.subTask("Analyzing...");
							
							while (iter.hasNext()){
								String nextClass = (String)iter.next();
								IPath subPath = path.append(nextClass);
								
								File dir = subPath.toFile();
								HashMap<String, File> h = new HashMap<String, File>();
								hashMap.put(nextClass, h);
								
								if (dir != null && dir.exists() && dir.isDirectory()){
									File subDirs[] = dir.listFiles();
									for (File f : subDirs){
										if (f.getName().equals("class_mutants")){
											File mutants[] = f.listFiles();
											for (File f1 : mutants){
												if (f1.isDirectory() && f1.listFiles() != null && f1.listFiles().length > 1){
													h.put(f1.getName(), f1);
													if (!possibleMutants.contains(f1.getName())){
														possibleMutants.add(f1.getName());
													}
												}
											}
										} else if (f.getName().equals("traditional_mutants")){
											File methodMutants[] = f.listFiles();	
											for (File f1 : methodMutants){
												if (f1.isDirectory() && f1.listFiles() != null && f1.listFiles().length > 1){
													
													File mutants[] = f1.listFiles();
													for (File f2 : mutants){
														if (f2.isDirectory() && f1.listFiles() != null && f1.listFiles().length > 1){
															h.put(f2.getName(), f2);
															if (!possibleMutants.contains(f2.getName())){
																possibleMutants.add(f2.getName());
															}
														}
													}
												}
											}
										}
									}
								} else {
									showMessage("Invalid MuJava result " + nextClass);
									selectedClasses.remove(nextClass);
								}
							}
							
							
							path = new Path(mutantsPath);
							File outDir = path.toFile();
							Random ranSelector = new Random();

							Path distPath = new Path(prepareMutantsWizard.getDistDir());
							File distDir = distPath.toFile();
							
							if (outDir != null && outDir.exists() && outDir.isDirectory()){
							
								monitor.beginTask("Combining mutants", possibleMutants.size());
								
								Iterator piter = possibleMutants.iterator();
								int mutantNum = 0;
								
								while (piter.hasNext()){
									String mutantName = (String)piter.next();
									// Create mutant folder
									mutantNum += 1;
									
									String folderName = "000" + String.valueOf(mutantNum);
									String subFix = "-p" + String.valueOf(port + mutantNum) 
													+ "-mtp"  + String.valueOf(mtpport + mutantNum);
									
									monitor.subTask(MUTANT_PREFIX + folderName.substring(folderName.length() - 3) + subFix);
									
									IPath mutantPath = path.append(MUTANT_PREFIX + folderName.substring(folderName.length() - 3) + subFix);
									File mutantDir = mutantPath.toFile();
									
									if (mutantDir.exists())
										mutantDir.delete(); // remove exisiting folder
							
									mutantDir.mkdir();
									
									IPath mutantPathClasses = mutantPath.append(mutantName);
									mutantDir = mutantPathClasses.toFile();
									mutantDir.mkdir();
									
									iter = selectedClasses.iterator();
									HashMap<String, File> h;
									while (iter.hasNext()){
										String nextClass = (String)iter.next();
										h = hashMap.get(nextClass);
										
										File classFile = h.get(mutantName);
										if (classFile == null){
											int index = ranSelector.nextInt(h.keySet().size());
											String ranSelectedMutant = (String) (h.keySet().toArray())[index];
											classFile = h.get(ranSelectedMutant);
										}
										
										IPath dest = prepareFolder(mutantPathClasses, nextClass);
										
										// Copy classes  
										
										try {
											copyFolder(classFile, dest.toFile());
											
										} catch (Exception e) {
											e.printStackTrace();
										}
									}

									// Copy the distribution folder to the mutant folder
									try {
										copyFolder(distDir, mutantPath.toFile());
									} catch (Exception e) {
										e.printStackTrace();
									}
									
									// Create a properties file
									IPath propertyPath = mutantPath.append("mutant.properties");
									createProperties(propertyPath, port + mutantNum, mtpport + mutantNum, mutantName);
									
									monitor.worked(1);
									
									
								} // Finish for all mutants
								
								monitor.done();
								
							} else {
								showMessage("Invalid output path");
								return new Status(IStatus.ERROR, "eCAT Plugin", 
										IStatus.ERROR, "Preparing mutants error!", null);
							}
							
							
							
							return new Status(IStatus.OK, "eCAT Plugin", 
									IStatus.OK, "Finish preparing mutants!", null);
						}
					};
					
					preparingJob.schedule();
				}
				
			} else {
				showMessage("Invalid paths or no classes are selected!");
			}

		}
	}
	
	/**
	 * Create a properties file for a mutant
	 * @param path
	 * @param port
	 * @param mtpPort
	 * @param classesFolder
	 */
	private void createProperties(IPath path, int port, int mtpPort, String classesFolder){
		File file = new File(path.toOSString());
    	if (!file.exists()) {
    		try {
				file.createNewFile();
				FileWriter out = new FileWriter(file);
				out.write("port=" + String.valueOf(port) + "\n");
				out.write("mtpport=" + String.valueOf(mtpPort) + "\n");
				out.write("classesFolder=" + classesFolder + "\n");
				out.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
    	}
    	
	}
	
	public void copyFolder(File fin, File fout) throws Exception {
		fout.mkdir();
		String[] children = fin.list();
		if (children == null) {
			// Either dir does not exist or is not a directory
		} else {
			for (int p = 0; p < children.length; p++) {
				File f = new File(fin + "/" + children[p]);
				File f1 = new File(fout + "/" + children[p]);
				if (f.isDirectory())
					copyFolder(f, f1);
				else
					copyFile(f, f1);
			}
		}
	}
	 
	 public void copyFile(File inputFile, File outputFile) {
		int bufferSize = 4 * 1024;
		try {
			FileReader in = new FileReader(inputFile);
			FileWriter out = new FileWriter(outputFile);
			int readSize;
			char buff[] = new char[bufferSize];
			while ((readSize = in.read(buff)) != -1)
				out.write(buff, 0, readSize);
			in.close();
			out.close();
		} catch (Exception e) {
		}
	}
	
	
	/**
	 * Create a hierarchy of folders
	 * 
	 * @param parent
	 * @param token
	 * @return
	 */
	private IPath prepareFolder(IPath parent, String token){
		IPath subPath = parent;
		File parentFolder = parent.toFile();
		if (parentFolder.exists()){
			StringTokenizer tokenizer = new StringTokenizer(token, ".");
			int numSegMent = tokenizer.countTokens();
			for (int i=0; i< numSegMent - 1; i++){
				subPath = subPath.append(tokenizer.nextToken());
				File f = subPath.toFile();
				if (!f.exists()){
					f.mkdir();
				}
			}
		}
		return subPath;
	}
	
	private void showMessage(String message){
		//MessageDialog.openInformation(window.getShell(), "Mutants preparation", message);
	}

	public void selectionChanged(IAction action, ISelection selection) {
	}

}
