/**
 * <copyright>
 *
 * eCAT - Tool for Continuous Testing Agent for the JADE/Eclipse Platform
 * Copyright (C) ITC-IRST, Trento, Italy
 * Authors: Duy Cu Nguyen
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 * The electronic copy of the license can be found here:
 * http://sra.itc.it/tools/taom/freesoftware/gpl.txt
 *
 * The contact information:
 * e-mail: cunduy@itc.it
 * site: http://sra.itc.it
 *
 * </copyright>
 */

package it.itc.sra.ecat.ecatplugin.mutantwizards;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.Path;
import org.eclipse.jface.viewers.ILabelProvider;
import org.eclipse.jface.viewers.ITreeContentProvider;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.DirectoryDialog;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.dialogs.ElementTreeSelectionDialog;
import org.eclipse.ui.model.BaseWorkbenchContentProvider;
import org.eclipse.ui.model.WorkbenchLabelProvider;

public class MutantsPathsPage extends WizardPage {

	private String resultsPath;
	private String mutantsPath;
	private String distDir;
	private int startPort;
	private int startMtpPort;
	
	protected MutantsPathsPage(String pageName) {
		super(pageName);
		
	}

	public void createControl(Composite parent) {
		Composite composite = new Composite(parent, SWT.NONE);
		GridLayout layout = new GridLayout(3, false);
		composite.setLayout(layout);
		
		setControl(composite);
		
		Label label = new Label(composite, SWT.NONE);
		label.setText("MuJava mutants result path:");
		final Text resultsPathDir = new Text(composite, SWT.BORDER | SWT.SINGLE);
		resultsPathDir.setText(resultsPath);
		resultsPathDir.addModifyListener(new ModifyListener(){

			public void modifyText(ModifyEvent e) {
				resultsPath = resultsPathDir.getText();
				validate();
			}
			
		});
		
		GridData layoutData = new GridData(GridData.FILL_HORIZONTAL);
		resultsPathDir.setLayoutData(layoutData);
		
		Button resultBrowse = new Button(composite, SWT.NONE);
		layoutData = new GridData();
		layoutData.widthHint = 70;
		resultBrowse.setText("  Browse..  ");
		resultBrowse.setLayoutData(layoutData);
		
		resultBrowse.addMouseListener(new MouseListener(){

			public void mouseDoubleClick(MouseEvent e) {
			}

			public void mouseDown(MouseEvent e) {
				
				String tmp = getSelection("MuJava mutants", "Select the MuJava results folder");
				if (!tmp.equals("")){ 
					resultsPathDir.setText(tmp);
					resultsPath = tmp;
				}
				
				if (!mutantsPath.equals("") && !resultsPath.equals("")){
					ClassSelectionPages nextPage =  (ClassSelectionPages)getNextPage();
					nextPage.setResultsPath(resultsPath);
					setPageComplete(true);
				}

			}

			public void mouseUp(MouseEvent e) {
			}
			
		});
		
		createSpace(composite);
		// Second row, output folder
		
		label = new Label(composite, SWT.NONE);
		label.setText("Output folder:");
		final Text outputPath = new Text(composite, SWT.BORDER | SWT.SINGLE);
		outputPath.setText(mutantsPath);
		outputPath.addModifyListener(new ModifyListener(){

			public void modifyText(ModifyEvent e) {
				mutantsPath = outputPath.getText();
				validate();
			}
			
		});
		
		layoutData = new GridData(GridData.FILL_HORIZONTAL);
		outputPath.setLayoutData(layoutData);
		
		Button outputBrowse = new Button(composite, SWT.NONE);
		layoutData = new GridData();
		layoutData.widthHint = 70;
		outputBrowse.setText("  Browse...  ");
		outputBrowse.setLayoutData(layoutData);
		
		outputBrowse.addMouseListener(new MouseListener(){

			public void mouseDoubleClick(MouseEvent e) {
			}

			public void mouseDown(MouseEvent e) {
				DirectoryDialog directoryDialog = new DirectoryDialog(getShell());
				String tmp = directoryDialog.open();
				if (tmp != null){
					outputPath.setText(tmp);
					mutantsPath = tmp;
					
					if (!mutantsPath.equals("") && !resultsPath.equals("")){
						setPageComplete(true);
						ClassSelectionPages nextPage =  (ClassSelectionPages)getNextPage();
						nextPage.setResultsPath(resultsPath);
					}
				}
			}

			public void mouseUp(MouseEvent e) {
			}
		});
		
		createSpace(composite);
		/// Dist dir
		
		label = new Label(composite, SWT.NONE);
		label.setText("Distribution lib and data (stubs):");
		final Text distPath = new Text(composite, SWT.BORDER | SWT.SINGLE);
		distPath.setText(distDir);
		distPath.addModifyListener(new ModifyListener(){

			public void modifyText(ModifyEvent e) {
				distDir = distPath.getText();
				validate();
			}
			
		});
		
		layoutData = new GridData(GridData.FILL_HORIZONTAL);
		distPath.setLayoutData(layoutData);
		
		Button distBrowse = new Button(composite, SWT.NONE);
		layoutData = new GridData();
		layoutData.widthHint = 70;
		distBrowse.setText("  Browse...  ");
		distBrowse.setLayoutData(layoutData);
		
		distBrowse.addMouseListener(new MouseListener(){
			public void mouseDoubleClick(MouseEvent e) {
			}
			public void mouseDown(MouseEvent e) {
				DirectoryDialog directoryDialog = new DirectoryDialog(getShell());
				String tmp = directoryDialog.open();
				if (tmp != null){
					distPath.setText(tmp);
					distDir = tmp;
					
				}
			}
			public void mouseUp(MouseEvent e) {
			}
		});
		
		/// Initial port
		createSpace(composite);
		label = new Label(composite, SWT.NONE);
		label.setText("JADE starting port:");
		
		final Text jadePort = new Text(composite, SWT.BORDER | SWT.SINGLE);
		jadePort.setText(String.valueOf(startPort));
		
		layoutData = new GridData(GridData.FILL_HORIZONTAL);
		layoutData.horizontalSpan = 2;
		jadePort.setLayoutData(layoutData);
		
		jadePort.addModifyListener(new ModifyListener(){

			public void modifyText(ModifyEvent e) {
				try{
					startPort =  Integer.parseInt(jadePort.getText());
				} catch (NumberFormatException e1){
					jadePort.setText("8080");
					startPort = 8080;
				}
			}
			
		});
		
		
		createSpace(composite);
		label = new Label(composite, SWT.NONE);
		label.setText("JADE MTP starting port:");
		
		final Text jadeMtpPort = new Text(composite, SWT.BORDER | SWT.SINGLE);
		jadeMtpPort.setText(String.valueOf(startMtpPort));
		
		layoutData = new GridData(GridData.FILL_HORIZONTAL);
		layoutData.horizontalSpan = 2;
		jadeMtpPort.setLayoutData(layoutData);
		
		jadeMtpPort.addModifyListener(new ModifyListener(){

			public void modifyText(ModifyEvent e) {
				try{
					startMtpPort =  Integer.parseInt(jadeMtpPort.getText());
				} catch (NumberFormatException e1){
					jadeMtpPort.setText("7779");
					startMtpPort = 7779;
				}
			}
			
		});
	}
	
	
	private void createSpace(Composite composite){
		Label label = new Label(composite, SWT.NONE);
		GridData dg = new GridData();
		dg.horizontalSpan = 3;
		dg.heightHint = 3;
		label.setLayoutData(dg);
	}
	
	/**
	 * Select a folder
	 * @param title
	 * @param msg
	 * @return
	 */
	private String getSelection(String title, String msg){
		ILabelProvider lp= new WorkbenchLabelProvider();
		ITreeContentProvider cp= new BaseWorkbenchContentProvider(); 
		
		ElementTreeSelectionDialog dialog = new ElementTreeSelectionDialog(getShell(),lp, cp);
		dialog.setValidator(null);
		dialog.setAllowMultiple(false);
		dialog.setTitle(title); 
		dialog.setMessage(msg); 
		dialog.setInput(ResourcesPlugin.getWorkspace().getRoot());
		
		if (dialog.open() == ElementTreeSelectionDialog.OK) {
			Object[] elements= dialog.getResult();
			if (elements.length == 1) {
				String temp = ((IResource)elements[0]).getLocation().toOSString();
				return temp;
			}
		} 
		
		return "";
	}


	public String getMutantsPath() {
		return mutantsPath;
	}

	public void setMutantsPath(String mutantsPath) {
		this.mutantsPath = mutantsPath;
	}

	public String getResultsPath() {
		return resultsPath;
	}

	public void setResultsPath(String resultsPath) {
		this.resultsPath = resultsPath;
	}

	public String getDistDir() {
		return distDir;
	}

	public void setDistDir(String distDir) {
		this.distDir = distDir;
	}

	
	public int getStartMtpPort() {
		return startMtpPort;
	}

	
	public void setStartMtpPort(int startMtpPort) {
		this.startMtpPort = startMtpPort;
	}

	
	public int getStartPort() {
		return startPort;
	}

	
	public void setStartPort(int startPort) {
		this.startPort = startPort;
	}

	private void validate(){
		IPath path = new Path(distDir);
		if (!path.isValidPath(distDir)){
			setErrorMessage("Path to the distribution dir is not valid");
		} 
		
		path = new Path(resultsPath);
		if (!path.isValidPath(resultsPath)){
			setErrorMessage("Path to the MuJava result is not valid");
		} 
		
		path = new Path(mutantsPath);
		if (!path.isValidPath(mutantsPath)){
			setErrorMessage("Output path is not valid");
		}
	}
	
}
