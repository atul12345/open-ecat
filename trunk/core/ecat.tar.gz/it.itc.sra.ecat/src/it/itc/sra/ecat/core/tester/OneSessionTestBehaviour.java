/**
 * <copyright>
 *
 * eCAT - Tool for Continuous Testing Agent for the JADE/Eclipse Platform
 * Copyright (C) ITC-IRST, Trento, Italy
 * Authors: Duy Cu Nguyen
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 * The electronic copy of the license can be found here:
 * http://sra.itc.it/tools/taom/freesoftware/gpl.txt
 *
 * The contact information:
 * e-mail: cunduy@itc.it
 * site: http://sra.itc.it
 *
 * </copyright>
 */

package it.itc.sra.ecat.core.tester;

import java.util.Date;
import java.util.Iterator;
import java.util.List;

import it.itc.sra.ecat.testsuiteman.testconfig.NodeType;
import it.itc.sra.ecat.testsuiteman.testsuite.ContentType;
import it.itc.sra.ecat.testsuiteman.testsuite.FipaMessageType;
import it.itc.sra.ecat.testsuiteman.testsuite.AType;
import it.itc.sra.ecat.testsuiteman.testsuite.TActionType;
import it.itc.sra.ecat.testsuiteman.testsuite.TestCaseType;
import it.itc.sra.ecat.testsuiteman.testsuite.TestScenarioType;
import it.itc.sra.ecat.util.CommonUtil;
import it.itc.sra.ecat.util.GeneralLogger;
import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.Behaviour;
import jade.core.behaviours.DataStore;
import jade.core.behaviours.FSMBehaviour;
import jade.core.behaviours.OneShotBehaviour;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import jade.proto.states.MsgReceiver;

/**
 * This behaviour supports one session (one node at a time)
 * 
 * @author cunduy
 *
 */
public class OneSessionTestBehaviour extends FSMBehaviour {
	/**
	 * 
	 */
	private static final long serialVersionUID = 5490549684777030435L;
	
	// Keys for the data storage
	protected final String LAST_PROCESSED_MESSAGE = "_last_processed_message" + hashCode();
	
	// FSM states name
	protected static final String STATE_INITIAL = "initial";
	protected static final String STATE_COMMUNICATION = "communication";
	protected static final String STATE_CHECKPOINT = "checkpoint";
	protected static final String STATE_BRANCH = "branch";
	protected static final String STATE_FINAL = "final";  		// Test success
	
	protected static final String STATE_WAIT = "wait";
	
	protected static final String STATE_COMMUNICATION_RECEIVE = "communication-receive";
	protected static final String STATE_COMMUNICATION_RECEIVE_NEXT = "communication-receive-next"; // used just to determine next state after receiving
	
	protected static final String STATE_DUM_FINAL = "dum-final"; // failure state
	
	// Events 
	protected static final int EVENT_INITIAL = 0;
	protected static final int EVENT_COMMUNICATION = 1;
	protected static final int EVENT_CHECKPOINT = 2;
	protected static final int EVENT_BRANCH = 3;
	protected static final int EVENT_FINAL = 4;
	
	protected static final int EVENT_COMMUNICATION_RECEIVE = 5;
	protected static final int EVENT_WAIT = 6;
	
	protected static final int EVENT_DUM_FINAL = -1;
	
	protected static final int DEFAULT_TIMEOUT = 2*1000; // 2 seconds 
	
	
	// The MessageTemplate used by the replyReceiver
	protected MessageTemplate replyTemplate = null;
	
	protected TestCaseType testCase = null;
	protected TestScenarioType testScenario = null;
	
	protected NodeType testNode = null;
	 
	protected TActionType currentAction = null;
	protected TestHelper testHelper = null;
	protected MsgReceiver myReceiver = null;
	private String conversionID;

	protected GeneralLogger logger = GeneralLogger.getInstance();
	
	public OneSessionTestBehaviour(Agent a, TestCaseType tc, NodeType testNode) {
		this.testCase = tc;
		this.testNode = testNode;
		testScenario = tc.getScenario();
		
		testHelper = new TestHelper(myAgent);
		initializeData();
		init(a, new DataStore());
	}
	
	public OneSessionTestBehaviour(Agent a, NodeType testNode){
		this.testNode = testNode;
		
		testHelper = new TestHelper(myAgent);
		initializeData();
		init(a, new DataStore());
	}
	

	public void setTestCase(TestCaseType testCase) {
		this.testCase = testCase;
		testScenario = testCase.getScenario();
	}

	
	////////////////////////////////////////////////////////////////////////////////////
	
	public void init(Agent a, DataStore ds){
		this.myAgent = a;
		setDataStore(ds);
		
		///////////////////////////////////////////////////////////////
		// Register states
		Behaviour b = null;
		
		// INITIAL
		b = new OneShotBehaviour(myAgent) {

			/**
			 * 
			 */
			private static final long serialVersionUID = 0L;
			int ret;

			@Override
			public void action() {
				currentAction = findInitialSequence();
				if (currentAction == null){
					ret = EVENT_DUM_FINAL;
				} else {
					
					conversionID = CommonUtil.generateId(testNode.getNodeName()); // new communication id
					
					postStateProcess(STATE_INITIAL, null);
				}
			}

			@Override
			public int onEnd() {
				if (ret != EVENT_DUM_FINAL){
					ret = determineNextState();
					currentAction = getNextSequence();
				}
				return ret;
			}
			
		};
		b.setDataStore(this.getDataStore());
		b.setBehaviourName(STATE_INITIAL);
		registerFirstState(b, STATE_INITIAL);
		
		// COMMUNICATION
		b = new OneShotBehaviour(myAgent){

			/**
			 * 
			 */
			private static final long serialVersionUID = 2558755755437905883L;
			int ret;
			
			@Override
			public void action() {
				
				if (currentAction == null) return;
				
				AType sequenceType = currentAction.getActType();
				
				if (sequenceType.equals(AType.COMMUNICATION)){
					String responder = normalizeAgentName(currentAction.getResponder());
					
					if (responder.equals(myAgent.getName())){
						// Receiving
						
						Integer tmp = currentAction.getTimeout();
						if (tmp == null)
							tmp = 0;
						
						int timeout = (tmp > 0) ? tmp : DEFAULT_TIMEOUT;
						Date d = new Date();
						myReceiver.setDeadline(d.getTime() + timeout);
						if (replyTemplate != null)
							myReceiver.setTemplate(replyTemplate);
						
						ret = EVENT_COMMUNICATION_RECEIVE;
						
					} else {
						// Sending
						
						Object definedMsg = currentAction.getMessage();
						if (definedMsg != null) {
							if (definedMsg instanceof FipaMessageType) {
								FipaMessageType fipaMsg = (FipaMessageType)definedMsg;
								ACLMessage msg = new ACLMessage(ACLMessage.getInteger(fipaMsg.getAct()));
								
								msg.setSender(myAgent.getAID());
								AID receiver =  new AID(currentAction.getResponder() + "@" + testNode.getNodeHap(), AID.ISGUID);
								receiver.addAddresses(testNode.getNodeAddress());
								
								msg.addReceiver(receiver);
								
								msg.setConversationId(conversionID);
								replyTemplate = MessageTemplate.MatchConversationId(conversionID);
								adjustReplyTemplate(msg);
								
								if (fipaMsg.getOntology() != null)
									msg.setOntology(fipaMsg.getOntology());
								if (fipaMsg.getLanguage() != null)
									msg.setLanguage(fipaMsg.getLanguage());
								if (fipaMsg.getProtocol() != null)
									msg.setProtocol(fipaMsg.getProtocol());
								
								if (fipaMsg.getContent().getValue() != null)
									msg.setContent(fipaMsg.getContent().getValue());
								else {
									// get content from reference
									Object obj = fipaMsg.getContent().getValueref();
									if (obj != null && obj instanceof ContentType){
										// Note that allow only one link
										msg.setContent(((ContentType)obj).getValue());
									}
								}
									
								
								// Ask the tester agent to schedule and send this msg
								myAgent.send(msg);
								getDataStore().put(LAST_PROCESSED_MESSAGE, msg);
								
								// launch post-state process
								//postStateProcess(STATE_COMMUNICATION, msg); // Send
								
							}
						}
						ret = determineNextState();
					}
				}
			}

			@Override
			public int onEnd() {
				if (ret != EVENT_COMMUNICATION_RECEIVE){
					
					currentAction = getNextSequence();
				}
				return ret;
			}
		};
		b.setDataStore(this.getDataStore());
		b.setBehaviourName(STATE_COMMUNICATION);
		registerState(b, STATE_COMMUNICATION);
		
		
		// COMMUNICATION RECEIVE
		myReceiver = new MsgReceiver(myAgent, null ,MsgReceiver.INFINITE, getDataStore(), LAST_PROCESSED_MESSAGE);
		myReceiver.setBehaviourName(STATE_COMMUNICATION_RECEIVE);
		registerState(myReceiver, STATE_COMMUNICATION_RECEIVE);		
		
		// COMMUNICATION RECEIVE NEXT, to determine which state to move next
		b = new OneShotBehaviour(myAgent){

			/**
			 * 
			 */
			private static final long serialVersionUID = 0L;

			int ret;
			
			@Override
			public void action() {

				// assign value of the content received to the message
				ACLMessage receivedMsg = (ACLMessage)getDataStore().get(LAST_PROCESSED_MESSAGE);
				
				if (receivedMsg != null && currentAction.getMessage() != null){
					FipaMessageType userMsg = currentAction.getMessage();
					if (userMsg != null){
						if (userMsg.getContent() != null){
							userMsg.getContent().setValue(receivedMsg.getContent());
						} else {
							ContentType receivedContent = new ContentType();
							receivedContent.setClazz("String"); // set to default
							receivedContent.setValue(receivedMsg.getContent());
						}
					}
				}
				
				ret = determineNextState();
				currentAction = getNextSequence();
				// launch post-state process
				postStateProcess(STATE_COMMUNICATION_RECEIVE, receivedMsg);

			}
			
			public int onEnd() {
				return ret;
			}
			
		};
		b.setDataStore(this.getDataStore());
		b.setBehaviourName(STATE_COMMUNICATION_RECEIVE_NEXT);
		registerState(b, STATE_COMMUNICATION_RECEIVE_NEXT);
		
		// BRANCH STATE
		b = new OneShotBehaviour(myAgent){

			private int ret;
			/**
			 * 
			 */
			private static final long serialVersionUID = 2482180231502142165L;

			@Override
			public void action() {
				
				if (currentAction == null) return;
				
				// Get one message from last processed ones. Assume that 
				// the content of the messages are identical
				
				ACLMessage lastMessage = (ACLMessage) getDataStore().get(LAST_PROCESSED_MESSAGE) ;
				
				boolean test = testHelper.checkCondition(lastMessage, currentAction.getVerdict());
				if (test && currentAction.getNextIfTrue() != null){
					currentAction = (TActionType)currentAction.getNextIfTrue();
					ret = determineNext();
				} else if (currentAction.getNextIfFalse() != null){
					currentAction = (TActionType)currentAction.getNextIfFalse();
					ret = determineNext();
				} else if (currentAction.getNextAction() != null){
					currentAction = (TActionType) currentAction.getNextAction(); // In case user don't specify either next true or false
					ret = determineNext();
				} else {
					ret = EVENT_DUM_FINAL;
				}
			}

			@Override
			public int onEnd() {
				return ret;
			}
			
			private int determineNext(){
				if (currentAction != null){
					AType nextSeqType = currentAction.getActType();
					if (nextSeqType.equals(AType.INITIAL)){
						return EVENT_INITIAL;
					} else if (nextSeqType.equals(AType.BRANCH)){
						return EVENT_BRANCH;
					} else if (nextSeqType.equals(AType.COMMUNICATION)){
						return EVENT_COMMUNICATION;
					} else if (nextSeqType.equals(AType.CHECKPOINT)){
						return EVENT_CHECKPOINT;
					} else if (nextSeqType.equals(AType.FINAL)){
						return EVENT_FINAL;
					}
				}
				return EVENT_DUM_FINAL;
			}
			
		};
		b.setDataStore(this.getDataStore());
		b.setBehaviourName(STATE_BRANCH);
		registerState(b, STATE_BRANCH);
		
		// CHECKPOINT STATE
		b = new OneShotBehaviour(myAgent){

			/**
			 * 
			 */
			private static final long serialVersionUID = 2482180231502142165L;
			int ret;

			@Override
			public void action() {
				// Check every sessions and update session state
				if (!checkPoints())
					ret = EVENT_DUM_FINAL;			
			}

			@Override
			public int onEnd() {
				if (ret != EVENT_DUM_FINAL) {
					ret = determineNextState();
					currentAction = getNextSequence();
				}
				
				return ret;
			}
			
			
		};
		b.setDataStore(this.getDataStore());
		b.setBehaviourName(STATE_CHECKPOINT);
		registerState(b, STATE_CHECKPOINT);
		
		// WAIT STATE
		b = new OneShotBehaviour(myAgent){

			/**
			 * 
			 */
			private static final long serialVersionUID = -3424460995623975117L;

			public void action() {
				if (currentAction == null) return;
				long timeout = currentAction.getTimeout() == null ? DEFAULT_TIMEOUT : currentAction.getTimeout();
				// force the tester agent to wait
				try {
					Thread.sleep(timeout);
				} catch (InterruptedException e) {
					//e.printStackTrace(); do nothing
				}
				
			}

			public int onEnd() {
				int ret = determineNextState();
				currentAction = getNextSequence();
				return ret;
			}
		};
		b.setBehaviourName(STATE_WAIT);
		b.setDataStore(this.getDataStore());
		registerState(b, STATE_WAIT);
		
		// FINAL STATE
		b = new OneShotBehaviour(myAgent){

			/**
			 * 
			 */
			private static final long serialVersionUID = 0L;

			@Override
			public void action() {
				// Test success
				logger.log("Test case " + testCase.getName() + " PASSED!");	
			}
			
		};
		b.setDataStore(this.getDataStore());
		b.setBehaviourName(STATE_FINAL);
		registerLastState(b, STATE_FINAL);
		
		
		// DUM FINAL STATE
		b = new OneShotBehaviour(myAgent){

			/**
			 * 
			 */
			private static final long serialVersionUID = 0L;

			@Override
			public void action() {
				// Test fail				
				logger.log("Test case " + testCase.getName() + " FAILED!");
			}
			
		};
		b.setDataStore(this.getDataStore());
		b.setBehaviourName(STATE_DUM_FINAL);
		registerLastState(b, STATE_DUM_FINAL);
			
		
		///////////////////////////////////////////////////////////////
		// Register transitions
		registerDefaultTransition(STATE_INITIAL, STATE_COMMUNICATION);
		
		registerTransition(STATE_COMMUNICATION, STATE_COMMUNICATION_RECEIVE, EVENT_COMMUNICATION_RECEIVE);
		registerDefaultTransition(STATE_COMMUNICATION_RECEIVE, STATE_COMMUNICATION_RECEIVE_NEXT);
				
		registerTransition(STATE_COMMUNICATION_RECEIVE, STATE_DUM_FINAL, MsgReceiver.INTERRUPTED);
		registerTransition(STATE_COMMUNICATION_RECEIVE, STATE_DUM_FINAL, MsgReceiver.TIMEOUT_EXPIRED);
		
		registerTransition(STATE_INITIAL, STATE_DUM_FINAL, EVENT_DUM_FINAL);
		registerTransition(STATE_COMMUNICATION, STATE_DUM_FINAL, EVENT_DUM_FINAL);
		registerTransition(STATE_CHECKPOINT, STATE_DUM_FINAL, EVENT_DUM_FINAL);
		registerTransition(STATE_BRANCH, STATE_DUM_FINAL, EVENT_DUM_FINAL);
		registerTransition(STATE_WAIT, STATE_DUM_FINAL, EVENT_DUM_FINAL);
		
		registerTransition(STATE_INITIAL, STATE_FINAL, EVENT_FINAL);
		registerTransition(STATE_COMMUNICATION, STATE_FINAL, EVENT_FINAL);
		registerTransition(STATE_CHECKPOINT, STATE_FINAL, EVENT_FINAL);
		registerTransition(STATE_BRANCH, STATE_FINAL, EVENT_FINAL);
		registerTransition(STATE_WAIT, STATE_FINAL, EVENT_FINAL);
				
		// move to wait state
		registerTransition(STATE_INITIAL, STATE_WAIT, EVENT_WAIT);
		registerTransition(STATE_COMMUNICATION, STATE_WAIT, EVENT_WAIT);
		registerTransition(STATE_CHECKPOINT, STATE_WAIT, EVENT_WAIT);
		registerTransition(STATE_BRANCH, STATE_WAIT, EVENT_WAIT);
		registerTransition(STATE_WAIT, STATE_WAIT, EVENT_WAIT);

		
		// Move to communication state
		registerTransition(STATE_COMMUNICATION, STATE_COMMUNICATION, EVENT_COMMUNICATION);
		registerTransition(STATE_CHECKPOINT, STATE_COMMUNICATION, EVENT_COMMUNICATION);
		registerTransition(STATE_BRANCH, STATE_COMMUNICATION, EVENT_COMMUNICATION);
		registerTransition(STATE_WAIT, STATE_COMMUNICATION, EVENT_COMMUNICATION);
		
		// Mote to checkpoint
		registerTransition(STATE_CHECKPOINT, STATE_CHECKPOINT, EVENT_CHECKPOINT);
		registerTransition(STATE_COMMUNICATION, STATE_CHECKPOINT, EVENT_CHECKPOINT);
		registerTransition(STATE_BRANCH, STATE_CHECKPOINT, EVENT_CHECKPOINT);
		registerTransition(STATE_WAIT, STATE_CHECKPOINT, EVENT_CHECKPOINT);
				
		// Mote to branch
		registerTransition(STATE_CHECKPOINT, STATE_BRANCH, EVENT_BRANCH);
		registerTransition(STATE_COMMUNICATION, STATE_BRANCH, EVENT_BRANCH);
		registerTransition(STATE_BRANCH, STATE_BRANCH, EVENT_BRANCH);
		registerTransition(STATE_WAIT, STATE_BRANCH, EVENT_BRANCH);

		registerTransition(STATE_COMMUNICATION_RECEIVE_NEXT, STATE_CHECKPOINT, EVENT_CHECKPOINT);
		registerTransition(STATE_COMMUNICATION_RECEIVE_NEXT, STATE_COMMUNICATION, EVENT_COMMUNICATION);
		registerTransition(STATE_COMMUNICATION_RECEIVE_NEXT, STATE_BRANCH, EVENT_BRANCH);
		registerTransition(STATE_COMMUNICATION_RECEIVE_NEXT, STATE_FINAL, EVENT_FINAL);
		registerTransition(STATE_COMMUNICATION_RECEIVE_NEXT, STATE_DUM_FINAL, EVENT_DUM_FINAL);
		registerTransition(STATE_COMMUNICATION_RECEIVE_NEXT, STATE_WAIT, EVENT_WAIT);
	}
	
	protected boolean checkPoints(){
		ACLMessage lastMessage = (ACLMessage) getDataStore().get(LAST_PROCESSED_MESSAGE) ;
		if (lastMessage != null){
			boolean checkResult = testHelper.checkCondition(lastMessage, currentAction.getVerdict());
			//if (!checkResult)
			return checkResult ; // Not satisfy the checkpoint
		} else {
			return false; // problem somewhere
		}
		//return true;
	}
	
	protected void initializeData(){
		
	}
	
	
	/**
	 * Find the initial sequence
	 * @return
	 */
	private TActionType findInitialSequence(){
		List<TActionType> seqs = testScenario.getTestAction();
		Iterator<TActionType> iter = seqs.iterator();
		TActionType initialSeq = null;
		while(iter.hasNext()) {
			TActionType nextSeq = (TActionType)iter.next();
			if (nextSeq.getActType().equals(AType.INITIAL)) {
				initialSeq = nextSeq;
				break;
			}
		}
		
		return initialSeq;
	}
	
	
	protected TActionType getNextSequence(){
		return (TActionType)currentAction.getNextAction();
	}
	
	protected int determineNextState(){
		TActionType next = (TActionType)currentAction.getNextAction();
		if (next != null){
			AType nextSeqType = next.getActType();
			if (nextSeqType.equals(AType.INITIAL)){
				return EVENT_INITIAL;
			} else if (nextSeqType.equals(AType.BRANCH)){
				return EVENT_BRANCH;
			} else if (nextSeqType.equals(AType.COMMUNICATION)){
				return EVENT_COMMUNICATION;
			} else if (nextSeqType.equals(AType.CHECKPOINT)){
				return EVENT_CHECKPOINT;
			} else if (nextSeqType.equals(AType.FINAL)){
				return EVENT_FINAL;
			} else if (nextSeqType.equals(AType.WAIT)){
				return EVENT_WAIT;
			}
		}
		return EVENT_DUM_FINAL;
	}

	private String normalizeAgentName(String name) {
		if (name != null && name.indexOf("@") > -1) {
			return name;
		} else if (name != null) {
			return name + "@" + myAgent.getHap();  
		} else return "";
	}

	/**
	 * Allow to overwrite final state behaviour
	 * @param b
	 */
	public void registerHandleFinal(Behaviour b) {
		registerLastState(b, STATE_FINAL);
		b.setDataStore(getDataStore());
	}
	
	/**
	 * Allow to overwrite dum final state behaviour
	 * @param b
	 */
	public void registerHandleDumFinal(Behaviour b) {
		registerLastState(b, STATE_DUM_FINAL);
		b.setDataStore(getDataStore());
	}
	
	protected void adjustReplyTemplate(ACLMessage msg) {
		// If myAgent is among the receivers (strange case, but can happen)
		// then modify the replyTemplate to avoid intercepting the initiation
		// message msg as if it was a reply
		AID r = (AID) msg.getAllReceiver().next();
		if (myAgent.getAID().equals(r)) {
			replyTemplate = MessageTemplate.and(
					replyTemplate,
					MessageTemplate.not(MessageTemplate.MatchCustom(msg, true)));
		}
	}

	public void reset(TestCaseType testCase) {
		
		DataStore ds = getDataStore();
		ds.remove(LAST_PROCESSED_MESSAGE);
		
		this.testCase = testCase;
		testScenario = testCase.getScenario();
		currentAction = null;
		
		myReceiver.reset(null, MsgReceiver.INFINITE, getDataStore(), LAST_PROCESSED_MESSAGE);
		
		super.reset();
	}

	////////////////////////////////////////////////////////////
	// Declare interface for child classes
	
	protected void postStateProcess(String state, Object msg){
		//logger.log(GeneralLogger.LEVEL_INFO, "Post process of the state: " + state);
	}
	
}
