package it.itc.sra.ecat.util;


import it.itc.sra.ecat.ECATPlugIn;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;

/**
 * Represents a singleton.
 */

public class GeneralLogger extends Logger {
    private String logFilePath = null;
    private PrintStream out = null;
    private int verbosity_level = Logger.LEVEL_INFO;

    
	/**
	 * Holds singleton instance
	 */
	private static GeneralLogger instance;

	public synchronized void log(String logMsg) {
		this.log(verbosity_level, logMsg);
	}

	public synchronized void log(int level, String log) {
		if (level <= verbosity_level)
        {
            String logStr = CommonUtil.getCurrentDateTime() + "\t\t" +  log;
            if (this.out != null)
            {
                out.println(logStr);
                out.flush();
            }
            else
                System.out.println(logStr);
        }
	}

	/**
	 * prevents instantiation
	 */
	private GeneralLogger() {
		try
        {
            verbosity_level = Logger.LEVEL_VERBOSE; 
            logFilePath = ECATPlugIn.getLogPath(); //ConfigMan.getInstance().getConfigObject().getLogPath(); 
            
            if (logFilePath != null)
            {
                try
                {
                	File file = new File(logFilePath);
                	if (!file.exists()) {
                		file.createNewFile();
                	}
                    out = new PrintStream(
                            new BufferedOutputStream(
                                    new FileOutputStream(file, true)));
                }
                catch (FileNotFoundException e)
                {
                    out = System.out;
                    e.printStackTrace();
                }
            }
            else
            {
                out = System.out;
            }
            
        }
        catch (Exception ne)
        {
            System.out.println("look up for verbosity level failed, setting level to \"verbose\"");
            verbosity_level = 3;
        }
	}

	
	/**
	 * @return  Returns the out.
	 * @uml.property  name="out"
	 */
	public PrintStream getOut() {
		return out;
	}

	/**
	 * Returns the singleton instance.
	 * @return  	the singleton instance
	 * @uml.property  name="instance"
	 */
	static public GeneralLogger getInstance() {
		if (instance == null) {
			synchronized (GeneralLogger.class){
                if (instance == null){
                	instance = new GeneralLogger();
                }
            }
		}
		return instance;
	}
}
