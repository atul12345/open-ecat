/**
 * <copyright>
 *
 * eCAT - Tool for Continuous Testing Agent for the JADE/Eclipse Platform
 * Copyright (C) ITC-IRST, Trento, Italy
 * Authors: Duy Cu Nguyen
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 * The electronic copy of the license can be found here:
 * http://sra.itc.it/tools/taom/freesoftware/gpl.txt
 *
 * The contact information:
 * e-mail: cunduy@itc.it
 * site: http://sra.itc.it
 *
 * </copyright>
 */

package it.itc.sra.ecat.ontobase;

import it.itc.sra.ecat.core.ECATExeption;
import it.itc.sra.ecat.testsuiteman.testconfig.CodecType;
import jade.content.lang.sl.SLCodec;
import jade.content.onto.Ontology;
import jadex.adapter.jade.JadeContentCodec;
import jadex.runtime.IContentCodec;
import jadex.runtime.JavaXMLContentCodec;
import jadex.runtime.NuggetsXMLContentCodec;

/**
 * Codec factory, used to create content codec as required
 * 
 * @author cunduy
 * 
 */
public class CodecFactory {

	public static IContentCodec createCodec(CodecType codec, Ontology ontology) throws ECATExeption {

		if (codec == null)
			throw new ECATExeption("Name of the codec can not be null!");

		if (codec.equals(CodecType.JADE_CONTENT_CODEC)) {
			if (ontology == null)
				throw new ECATExeption("Jade codec requires ontology!");
			return new JadeContentCodec(new SLCodec(0), ontology);
		} else if (codec.equals(CodecType.NUGGETS_XML_CONTENT_CODEC)) {
			return new NuggetsXMLContentCodec();
		} else if (codec.equals(CodecType.JAVA_XML_CONTENT_CODEC)) {
			return new JavaXMLContentCodec();
		}

		throw new ECATExeption("Codec is invalid or not supported!");
	}
	
	public static IContentCodec createCodec(CodecType codec, ClassLoader loader) throws ECATExeption {

		if (codec == null)
			throw new ECATExeption("Name of the codec can not be null!");

		if (codec.equals(CodecType.NUGGETS_XML_CONTENT_CODEC)) {
			try {
				Class<?> codecCls = loader.loadClass(NuggetsXMLContentCodec.class.getName());
				return (IContentCodec) codecCls.newInstance(); 
			} catch (ClassNotFoundException e) {
				throw new ECATExeption("Class NuggetsXMLContentCodec not found");
			} catch (Exception e){
				throw new ECATExeption("Exception while creating NuggetsXMLContentCodec");
			}
			//return new NuggetsXMLContentCodec();
		} else if (codec.equals(CodecType.JAVA_XML_CONTENT_CODEC)) {
			return new JavaXMLContentCodec();
		}

		throw new ECATExeption("Codec is invalid or not supported!");
	}

}
