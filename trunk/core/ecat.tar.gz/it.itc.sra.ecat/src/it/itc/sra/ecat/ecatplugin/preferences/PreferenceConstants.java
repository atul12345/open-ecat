package it.itc.sra.ecat.ecatplugin.preferences;

public class PreferenceConstants {

	public PreferenceConstants() {
	}

	// Fpublic static final String P_PATH = "pathPreference";
	public static final String P_PORT = "portPreference";
	public static final String P_HOST = "hostPreference";
	public static final String P_LOG = "logPreference";
	
	public static final String P_JADE_PARAM = "jadeParamPreference";
	public static final String P_SHOW_GUI = "rmaGUIPreference";
	public static final String P_RUN_SEPARATE_JADE = "runJADEPreference";
	
	public static final String P_TROPOS_MODEL = "troposModelPath";
	public static final String P_OUTPUT_FOLDER = "generateOutPutFolder";
	public static final String P_PROTOCOL_LIST = "protocolListFile";
	public static final String P_AGENT_UT = "agentUnderTest";

	public static final String P_MUTANTS_RESULT_PATH = "mutantResultPath";
	public static final String P_CREATED_MUTANTS_PATH = "createdMutantsPath";
	public static final String P_DIST_PATH = "distPath";
	public static final String P_JADE_STARTING_PORT = "jadeStaringPort";
	public static final String P_JADE_STARTING_MTP_PORT = "jadeStaringMtpPort";
	
	public static final String P_ENABLE_MONITORING = "enableMonitoring";
	public static final String P_MAX_MONITORING_LOG = "maxLengthMonitoringLog";

}
