/**
 * <copyright>
 *
 * eCAT - Tool for Continuous Testing Agent for the JADE/Eclipse Platform
 * Copyright (C) ITC-IRST, Trento, Italy
 * Authors: Duy Cu Nguyen
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 * The electronic copy of the license can be found here:
 * http://sra.itc.it/tools/taom/freesoftware/gpl.txt
 *
 * The contact information:
 * e-mail: cunduy@itc.it
 * site: http://sra.itc.it
 *
 * </copyright>
 */

package it.itc.sra.ecat.testsuiteman.generation;

import java.io.File;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Vector;

import javax.xml.bind.JAXBElement;
import org.eclipse.core.runtime.Path;

import it.itc.sra.ecat.core.ECATExeption;
import it.itc.sra.ecat.testsuiteman.TestSuitesStorage;
import it.itc.sra.ecat.testsuiteman.domaindata.DomainData;
import it.itc.sra.ecat.testsuiteman.domaindata.DomainData.DataElement;
import it.itc.sra.ecat.testsuiteman.protocollist.ProtocolList;
import it.itc.sra.ecat.testsuiteman.protocollist.ProtocolType;
import it.itc.sra.ecat.testsuiteman.testsuite.CheckType;
import it.itc.sra.ecat.testsuiteman.testsuite.ContentType;
import it.itc.sra.ecat.testsuiteman.testsuite.FipaMessageType;
import it.itc.sra.ecat.testsuiteman.testsuite.GoalReachType;
import it.itc.sra.ecat.testsuiteman.testsuite.ObjectFactory;
import it.itc.sra.ecat.testsuiteman.testsuite.TActionType;
import it.itc.sra.ecat.testsuiteman.testsuite.TestCaseType;
import it.itc.sra.ecat.testsuiteman.testsuite.TestScenarioType;
import it.itc.sra.ecat.util.CommonUtil;
import it.itc.sra.ecat.util.GeneralLogger;
import it.itc.sra.ecat.util.GlobalConstants;
import it.itc.sra.ecat.util.JAXBUtil;

public class RandomGenerator implements ISuitesGenerator {

	Random intRan = new Random();
	Random dataRan = new Random();
	Random dbRan = new Random();

	Hashtable<String, TestScenarioType> scenarioList;
	Vector<String> scenarioNameList;

	DomainData domainData;

	private GeneralLogger logger = GeneralLogger.getInstance();

	public RandomGenerator() {
		super();

	}

	public TestSuitesStorage generate() {
		return null;
	}

	public TestSuitesStorage generate(TestSuitesStorage currentSuites) {
		return null;
	}

	public List<TestCaseType> generate(int numberOfCases, String agentUnderTest) {
		ArrayList<TestCaseType> list = new ArrayList<TestCaseType>();
		ObjectFactory testCaseFactory = new ObjectFactory();
		
		for (int i = 0; i < numberOfCases; i++) {

			TestCaseType tc = testCaseFactory.createTestCaseType();
			tc.setActive(true);
			String id = "TC" + String.valueOf(i) + "-" + CommonUtil.generateId();
			tc.setID(id);
			tc.setName("Random" + id);
			tc.setDescription("Randomly-generated test case");
			tc.setPriority(dbRan.nextDouble());
			tc.setType(GoalReachType.UNSPECIFIED);

			TestScenarioType targetScenario = testCaseFactory.createTestScenarioType();

			// Pick randomly a communication protocol
			int luck = intRan.nextInt(scenarioNameList.size());
			String luckProtocolName = (String) scenarioNameList.get(luck);
			TestScenarioType senario = (TestScenarioType) scenarioList.get(luckProtocolName);

			// Fill test data into the scenario
			List<TActionType> acts = senario.getTestAction();
			Iterator<TActionType> iter = acts.iterator();
			while (iter.hasNext()) {
				TActionType act = (TActionType) iter.next();
				// Create new target sequence
				TActionType targetAct = testCaseFactory.createTActionType();

				targetAct.setID(act.getID());
				targetAct.setTimeout(act.getTimeout());
				targetAct.setActType(act.getActType());

				
				if (act.getInitiator() != null && act.getInitiator().equalsIgnoreCase(GlobalConstants.TESTER_AGENT_NAME)) {
					targetAct.setInitiator(GlobalConstants.TESTER_AGENT_NAME);
					targetAct.setResponder(agentUnderTest);

				} else if (act.getResponder() != null && act.getResponder().equalsIgnoreCase(
						GlobalConstants.TESTER_AGENT_NAME)) {
					targetAct.setResponder(GlobalConstants.TESTER_AGENT_NAME);
					targetAct.setInitiator(agentUnderTest);
				}

				Object obj;
				if ((obj = act.getMessage()) != null) {
					
					
					FipaMessageType targetMsg = new FipaMessageType();
					//targetMsg.setConversationId(CommonUtil.generateId("TA"));
					targetMsg.setConversationId(CommonUtil.generateId("TA"));
					if (obj instanceof FipaMessageType){
						FipaMessageType fipaMsg = (FipaMessageType)obj;
						targetMsg.setAct(fipaMsg.getAct());
						if (fipaMsg.getLanguage() != null) {
							targetMsg.setLanguage(fipaMsg.getLanguage());
						}
	
						if (fipaMsg.getOntology() != null) {
							targetMsg.setOntology(fipaMsg.getOntology());
						}
					}

					// Interesting part, pick randomly a data
					DataElement dataElement = (DataElement) domainData.getDataElement().get(
							dbRan.nextInt(domainData.getDataElement().size()));
					
					String content = (String) dataElement.getContent();
					ContentType c = new ContentType();
					c.setValue(content);
					c.setClazz("String");
					
					targetMsg.setContent(c);

					targetAct.setMessage(targetMsg);
				}

				if (act.getVerdict() != null) {
					CheckType targetVerdict = testCaseFactory.createCheckType();
					targetVerdict.setCheckOperator(act.getVerdict().getCheckOperator());

					if (act.getVerdict().getExpectedValue() != null) {
						
						obj = act.getVerdict().getExpectedValue();
						
						FipaMessageType targetMsg = testCaseFactory.createFipaMessageType();

						if (obj instanceof FipaMessageType){
							FipaMessageType fipaMsg = (FipaMessageType)obj;
							//targetMsg.setConversationId(fipaMsg.getConversationId());
							targetMsg.setAct(fipaMsg.getAct());
								
							targetMsg.setConversationId(fipaMsg.getConversationId());
							
							if (fipaMsg.getLanguage() != null) {
								targetMsg.setLanguage(fipaMsg.getLanguage());
							}
	
							if (fipaMsg.getOntology() != null) {
								targetMsg.setOntology(fipaMsg.getOntology());
							}
						
						}
						ContentType c = new ContentType();
						c.setValue("");
						c.setClazz("String");
						
						targetMsg.setContent(c);

						targetVerdict.setExpectedValue(targetMsg);
					}
					// Set condition
					targetAct.setVerdict(targetVerdict);
				}

				// Add new sequence to the target scenario
				targetScenario.getTestAction().add(targetAct);
			}

			// Relink the sequences (create references among sequences)
			Iterator<TActionType> iterOrigin = acts.iterator();
			Iterator<TActionType> iterTarget = targetScenario.getTestAction().iterator();

			while (iterOrigin.hasNext() && iterTarget.hasNext()) {
				TActionType sequence = (TActionType) iterOrigin.next();
				TActionType targetSequence = (TActionType) iterTarget.next();

				if (sequence.getNextAction() != null) {
					String nextSeqID = ((TActionType) sequence.getNextAction()).getID();
					Iterator<TActionType> iterTargetNext = targetScenario.getTestAction().iterator();
					while (iterTargetNext.hasNext()) {
						TActionType nextSequence = (TActionType) iterTargetNext.next();
						if (nextSequence.getID().equals(nextSeqID)) {
							targetSequence.setNextAction(nextSequence);
							break;
						}
					}
				}

				if (sequence.getNextIfFalse() != null) {
					String nextSeqID = ((TActionType) sequence.getNextIfFalse()).getID();
					Iterator<TActionType> iterTargetNext = targetScenario.getTestAction().iterator();
					while (iterTargetNext.hasNext()) {
						TActionType nextSequence = (TActionType) iterTargetNext.next();
						if (nextSequence.getID().equals(nextSeqID)) {
							targetSequence.setNextIfFalse(nextSequence);
							break;
						}
					}
				}
				if (sequence.getNextIfTrue() != null) {
					String nextSeqID = ((TActionType) sequence.getNextIfTrue()).getID();
					Iterator<TActionType> iterTargetNext = targetScenario.getTestAction().iterator();
					while (iterTargetNext.hasNext()) {
						TActionType nextSequence = (TActionType) iterTargetNext.next();
						if (nextSequence.getID().equals(nextSeqID)) {
							targetSequence.setNextIfTrue(nextSequence);
							break;
						}
					}
				}

			}

			// Add the scenario to the test case
			tc.setScenario(targetScenario);
			// Add the new generated test case to the test case list
			list.add(tc);

		}

		return list;
	}

	/**
	 * Fetch random test input data
	 *  
	 * @param tc
	 * require domainData != null
	 */
	public void fetchRandomData(TestCaseType tc){
		TestScenarioType sce = tc.getScenario();
		List<TActionType> seqs = sce.getTestAction();
		
		for (TActionType s: seqs){
			if (s.getInitiator() != null && s.getInitiator().equalsIgnoreCase(GlobalConstants.TESTER_AGENT_NAME)) {
				// The tester agent will send
				// Then change the message if possible
				Object obj = s.getMessage();
				if (obj != null && obj instanceof FipaMessageType){
					FipaMessageType msg = (FipaMessageType)obj;
					// Get new content value
					// Interesting part, pick randomly a data
					if (domainData == null || dbRan == null)
						return;
					
					DataElement dataElement = (DataElement) domainData.getDataElement().get(
							dbRan.nextInt(domainData.getDataElement().size()));
					
					String content = (String) dataElement.getContent();
					ContentType c = new ContentType();
					c.setValue(content);
					c.setClazz("String");
					msg.setContent(c);
				}
			}
		}
		
	}
	
	/**
	 * Load data
	 * 
	 * @param protocolPath
	 * @param domainDataPath
	 */
	public boolean initData(String protocolPath, String domainDataPath) {
		scenarioList = new Hashtable<String, TestScenarioType>();
		scenarioNameList = new Vector<String>();

		// Mashall xml file to object
		try {
			ProtocolList protocolList = (ProtocolList) JAXBUtil.loadJAXBFromFile(
					GlobalConstants.PROTOCOLLIST_PKG, protocolPath);
			// Fetch protocol list
			List<ProtocolType> l = protocolList.getProtocol();
			Iterator<ProtocolType> i = l.iterator();
			while (i.hasNext()) {
				ProtocolType proto = (ProtocolType) i.next();
				String protoName = proto.getName();
				
				String protoXMLFile = proto.getPath();
				String absolutePath = "";
				Path path = new Path(protocolPath);
				
				if (protoXMLFile.indexOf(File.separatorChar) >= 0 &&
						(protoXMLFile.indexOf(".") != 0)){
					// absolute
					absolutePath = protoXMLFile;
				} else if (protoXMLFile.indexOf(File.separatorChar) >= 0 &&
						protoXMLFile.indexOf(".") == 0){
					// relative
					absolutePath = path.removeLastSegments(1).append(protoXMLFile.substring(1)).toOSString();
				} else {
					// relative
					absolutePath = path.removeLastSegments(1).append(protoXMLFile).toOSString();
				}

				// Marshall the test scenario
				Object obj = JAXBUtil.loadJAXBFromFile(GlobalConstants.TESTSUITE_PACKAGE_STUBS, absolutePath);
				JAXBElement<TestScenarioType> senarioDoc = (JAXBElement<TestScenarioType>)obj;
				
				TestScenarioType senario =  senarioDoc.getValue();
				
				scenarioList.put(protoName, senario);
				scenarioNameList.add(protoName);
			}
			// Mashall domain data xml file
			domainData = (DomainData) JAXBUtil.loadJAXBFromFile(GlobalConstants.DOMAINDATA_PKG,
					domainDataPath);

			
		} catch (ECATExeption e) {
			e.printStackTrace(logger.getOut());
			return false;
		}
		
		return true;
	}
	
	/**
	 * Init domain data
	 * @param domainDataPath
	 * @return
	 */
	public boolean initData(String domainDataPath) {

		// Mashall domain data file
		try {
			domainData = (DomainData) JAXBUtil.loadJAXBFromFile(GlobalConstants.DOMAINDATA_PKG,
					domainDataPath);
			return true;
		} catch (ECATExeption e) {
			e.printStackTrace(logger.getOut());
			return false;
		}
	}

	/**
	 * Test the class
	 * @param args
	 */
	public static void main(String[] args) {
		RandomGenerator generator = new RandomGenerator();
		generator.initData(
				"/Users/cuduynguyen/projects/it.itc.sra.ecat/data/protocol/ProtocolList.xml",
				"/Users/cuduynguyen/projects/Continuous Testing/BibFinder/Test/DomainData.xml");

		List testCases = generator.generate(2, "BibFinder");
		Iterator iter = testCases.iterator();
		while (iter.hasNext()) {
			
			ObjectFactory factory = new ObjectFactory();
			JAXBElement<TestCaseType> tc = factory.createTestCase((TestCaseType) iter.next());
			
			try {
				String xmlOut = JAXBUtil.transformJAXBToString(
						GlobalConstants.TESTSUITE_PACKAGE_STUBS, tc);
				System.out.println(xmlOut);
				System.out.println("--------------------------------------");
			} catch (ECATExeption e) {
				e.printStackTrace();
			}
		}
	}
}
