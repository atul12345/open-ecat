/**
 * <copyright>
 *
 * eCAT - Tool for Continuous Testing Agent for the JADE/Eclipse Platform
 * Copyright (C) ITC-IRST, Trento, Italy
 * Authors: Duy Cu Nguyen
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 * The electronic copy of the license can be found here:
 * http://sra.itc.it/tools/taom/freesoftware/gpl.txt
 *
 * The contact information:
 * e-mail: cunduy@itc.it
 * site: http://sra.itc.it
 *
 * </copyright>
 */

package it.itc.sra.ecat.ecatplugin.generatewizards;

import java.io.File;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import it.itc.sra.ecat.ECATPlugIn;
import it.itc.sra.ecat.core.ECATExeption;
import it.itc.sra.ecat.ecatplugin.preferences.PreferenceConstants;
import it.itc.sra.ecat.t2ttransform.TransformException;
import it.itc.sra.ecat.t2ttransform.TroposNavigator;
import it.itc.sra.ecat.testsuiteman.generation.ManualGenerator;
import it.itc.sra.ecat.testsuiteman.protocollist.ProtocolType;
import it.itc.sra.ecat.testsuiteman.testsuite.TestCaseType;
import it.itc.sra.ecat.testsuiteman.testsuite.TestSuite;
import it.itc.sra.ecat.util.CommonUtil;
import it.itc.sra.ecat.util.GlobalConstants;
import it.itc.sra.ecat.util.JAXBUtil;
import it.itc.sra.taom4e.model.core.informalcore.Actor;
import it.itc.sra.taom4e.model.core.informalcore.Goal;
import it.itc.sra.taom4e.model.core.informalcore.Plan;

import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.ui.INewWizard;
import org.eclipse.ui.IWorkbench;

public class TestGenerateWizard extends Wizard implements INewWizard {
	

	private PathsPage pathPage;
	private ScenariosPage scenarioPage;
	
	public String getOutputFolder() {
		return pathPage.getOutputFolder();
	}

	public String getTroposModel() {
		return pathPage.getTroposModel();
	}
	
	public String getProtocolListFile(){
		if (!pathPage.isBuiltIn()){
			return pathPage.getProtocolFile();
		} else {
			IPath path  = ECATPlugIn.getDefault().getPluginPath();
			path =  path.append("data").append("protocol").append("ProtocolList.xml");
			return path.toOSString();
		}
		 
	}
	
	public Map<ProtocolType, Boolean> getSelectedScenarios() {
		return scenarioPage.getSelectedScenarios();
	}

	
	@Override
	public boolean performFinish() {
		
		if (pathPage == null) return false;
		
		final String troposModel = pathPage.getTroposModel();
		final String outputFolder = pathPage.getOutputFolder();
		final String protocolList = pathPage.getProtocolFile();
		
		ECATPlugIn.getDefault().getPreferenceStore().setValue(PreferenceConstants.P_TROPOS_MODEL, troposModel);
		ECATPlugIn.getDefault().getPreferenceStore().setValue(PreferenceConstants.P_OUTPUT_FOLDER, outputFolder);
		ECATPlugIn.getDefault().getPreferenceStore().setValue(PreferenceConstants.P_PROTOCOL_LIST, protocolList);
		
		if (troposModel.equals("") || outputFolder.equals("")){
			MessageDialog.openInformation(null, "Select model and output folder",
				" You have to specify a Tropos model and an output folder!");
			return false;
		}
		
		Job generateJob = new Job("Generate Test Suite from Tropos analysis"){

			@Override
			protected IStatus run(IProgressMonitor monitor) {
				
				//monitor.beginTask(Generate, totalWork)
				
				
				try {
					TroposNavigator tn = new TroposNavigator(troposModel);
				
					IPath scenarioTemplatesPath = new Path(getProtocolListFile());
					
					Map<ProtocolType, Boolean> selectedScenarios = getSelectedScenarios();
					
								
					ManualGenerator generator = new ManualGenerator();
					generator.resetCounter();
					
					List<Actor> actors = tn.getActors();
					monitor.beginTask("Generating test suites", actors.size());
					
					
					for (Actor a : actors) {
						monitor.worked(1);
						monitor.setTaskName("Generate test suites for " + a.getName());
						
						HashMap<Goal, Plan> meansEndList = tn.getAllMeansEnd(a);
						Iterator<Goal> iter = meansEndList.keySet().iterator();
						while (iter.hasNext()){
							Goal goal = iter.next();
							Plan plan = meansEndList.get(goal);
							TestSuite ts = generator.createTestSuite(a.getName(), encodeContent(goal.getName()), encodeContent(plan.getName()), "Means-End");
							
							boolean selected = false;
							
							
							if (selectedScenarios.size() > 0){
								for (ProtocolType proto : selectedScenarios.keySet()){
									if (selectedScenarios.get(proto).booleanValue()){
										String scenarioPath = proto.getPath();
										String absolutePath = "";
										// Auto detect if the path is relative or absolute
										if (scenarioPath.indexOf(File.separatorChar) >= 0 &&
												(scenarioPath.indexOf(".") != 0)){
											// absolute
											absolutePath = scenarioPath;
										} else if (scenarioPath.indexOf(File.separatorChar) >= 0 &&
												scenarioPath.indexOf(".") == 0){
											// relative
											absolutePath = scenarioTemplatesPath.removeLastSegments(1).append(scenarioPath.substring(1)).toOSString();
										} else {
											// relative
											absolutePath = scenarioTemplatesPath.removeLastSegments(1).append(scenarioPath).toOSString();
										}
											
										TestCaseType tc = generator.createTestCase(a.getName(), "TesterAgent", encodeContent(goal.getName()) + " To-be-replaced", absolutePath);
										CommonUtil.createLinks(tc);
										ts.getTestCase().add(tc);
										selected = true;
									}
								}
							} 
							
							if (selectedScenarios.size() == 0 || !selected)
							{
								// Default scenario
								TestCaseType tc = generator.createPilotTestCase(a.getName(), "TesterAgent", encodeContent(goal.getName()) + " To-be-replaced");
								CommonUtil.createLinks(tc);
								ts.getTestCase().add(tc);
							}
							
							// Save test suite
							
							String tsFile = outputFolder + "/" + ts.getID() + "-" + a.getName() + ".suite";
							
							
							try {
								JAXBUtil.saveJAXBToFile(GlobalConstants.TESTSUITE_PACKAGE_STUBS, ts, CommonUtil.normalizeFileName(tsFile));
							} catch (ECATExeption e) {
								e.printStackTrace();
							}
						}
						
					}
					
				} catch (TransformException e) {
					MessageDialog.openInformation(null, "Problem with Tropos model",
							"Error reading the Tropos model! Please ensure that it is a Taom4e 0.5 compatible model!");
					e.printStackTrace();
				}
				
				return new Status(IStatus.OK, "eCAT Plugin", 
						IStatus.OK, "Finish Generating Test Suites!", null);
			}
		
		};
		
		generateJob.schedule();
		
		return true;
	}
	
	private String encodeContent(String in){
		if (in == null)
			return "";
		return in.replaceAll("\r\n|\r|\n", "_").replace(" ", "_");
    }

	@Override
	public void addPages() {
		ImageDescriptor imgDes = ECATPlugIn.getDefault().getImageDescriptor(ECATPlugIn.IMG_WIZARD_BG);
		pathPage = new PathsPage("pathPage");
		pathPage.setTitle("Generate test from Tropos model");
		pathPage.setDescription("Select Tropos model and output folder for test suites");
		
		String troposModel = ECATPlugIn.getDefault().getPreferenceStore().getString(PreferenceConstants.P_TROPOS_MODEL);
		String outputFolder = ECATPlugIn.getDefault().getPreferenceStore().getString(PreferenceConstants.P_OUTPUT_FOLDER);
		String protocolList = ECATPlugIn.getDefault().getPreferenceStore().getString(PreferenceConstants.P_PROTOCOL_LIST);
		
		pathPage.setTroposModel(troposModel);
		pathPage.setOutputFolder(outputFolder);
		pathPage.setProtocolFile(protocolList);
		
		scenarioPage =  new ScenariosPage("scenarioPage");
		scenarioPage.setTitle("Select Scenario Templates");
		
		IPath path  = ECATPlugIn.getDefault().getPluginPath();
		path =  path.append("data").append("protocol").append("ProtocolList.xml");
		String tmp = path.toOSString();
		// Default built-in
		scenarioPage.setPath(tmp);
		
		addPage(pathPage);
		addPage(scenarioPage);
	}

	
	
	public TestGenerateWizard() {
		setWindowTitle("Generate Test Suites");
		ImageDescriptor imgDes = ECATPlugIn.getDefault().getImageDescriptor(ECATPlugIn.IMG_WIZARD_BG);
		setDefaultPageImageDescriptor(imgDes);
		//setNeedsProgressMonitor(true);
		
	}

	public void init(IWorkbench workbench, IStructuredSelection selection) {
		setWindowTitle("Generate Test Suites");
		ImageDescriptor imgDes = ECATPlugIn.getDefault().getImageDescriptor(ECATPlugIn.IMG_WIZARD_BG);
		setDefaultPageImageDescriptor(imgDes);
	}

}
