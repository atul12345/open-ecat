/**
 * <copyright>
 *
 * eCAT - Tool for Continuous Testing Agent for the JADE/Eclipse Platform
 * Copyright (C) ITC-IRST, Trento, Italy
 * Authors: Duy Cu Nguyen
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 * The electronic copy of the license can be found here:
 * http://sra.itc.it/tools/taom/freesoftware/gpl.txt
 *
 * The contact information:
 * e-mail: cunduy@itc.it
 * site: http://sra.itc.it
 *
 * </copyright>
 */
package it.itc.sra.ecat.core.tester;

import it.itc.sra.ecat.ECATPlugIn;
import it.itc.sra.ecat.core.MonitoringModel;
import it.itc.sra.ecat.core.Synchronizer;
import it.itc.sra.ecat.core.TestResultsModel;
import it.itc.sra.ecat.core.executor.IExecutor;
import it.itc.sra.ecat.core.monitor.IMonitorAgent;
import it.itc.sra.ecat.core.monitor.RemoteMonitoringLogs;
import it.itc.sra.ecat.monitordata.EventType;
import it.itc.sra.ecat.monitordata.SessionType;
import it.itc.sra.ecat.testsuiteman.testconfig.NodeType;
import it.itc.sra.ecat.testsuiteman.testconfig.TestConfig;
import it.itc.sra.ecat.testsuiteman.testsuite.FipaMessageType;
import it.itc.sra.ecat.testsuiteman.testsuite.AType;
import it.itc.sra.ecat.testsuiteman.testsuite.TActionType;
import it.itc.sra.ecat.testsuiteman.testsuite.TestCaseType;
import it.itc.sra.ecat.testsuiteman.testsuite.TestScenarioType;
import it.itc.sra.ecat.util.CommonUtil;
import it.itc.sra.ecat.util.GeneralLogger;
import it.itc.sra.ecat.util.GlobalConstants;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

import jade.core.Agent;
import jade.core.behaviours.Behaviour;
import jade.core.behaviours.DataStore;
import jade.core.behaviours.FSMBehaviour;
import jade.core.behaviours.OneShotBehaviour;
import jade.core.behaviours.ParallelBehaviour;

public class MutationTestExecutionBehaviour extends FSMBehaviour {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1370489922937429350L;
	// FSM states name
	protected static final String STATE_INITIAL = "initial";
	protected static final String STATE_CONTROL = "control";
	protected static final String STATE_TESTRUN = "testrun";
	protected static final String STATE_CALCULATEFITNESS = "calculate-fitness";
	protected static final String STATE_EVALUATION = "evaluation";
	protected static final String STATE_EVOLUTION = "evolution";
	protected static final String STATE_FINAL = "final"; 
	protected static final String STATE_RESET_REMOTES = "reset-remotes";
	protected static final String STATE_GET_REMOTE_TRACES = "get-remote-traces";

	// FSM EVENT
	protected static final int EVENT_INITIAL_FAILURE = -1;
	protected static final int EVENT_INITIAL_OK = 0;
	protected static final int EVENT_TEST_EXECUTION = 1;
	protected static final int EVENT_CONTROL = 2;
	protected static final int EVENT_CALCULATE_FITNESS = 3;
	protected static final int EVENT_EVALUATION = 4;
	protected static final int EVENT_EVOLUTION = 5;
	protected static final int EVENT_GET_LOGS = 6;
	protected static final int EVENT_ABOUT = 7;

	protected static final int EVENT_FINISH = 99;
	protected static final int EVENT_FINISH_FAILED = -99;

	ParallelBehaviour parallelTestExecutor;

	// //////////////////////////////////////////
	// GA variables

	public static final int MAX_NUMBER_GEN = 5; // Maximum number of generation
	public static final int MAX_POPULATION_SIZE = 20; // Maximum number of
														// generation

	private ArrayList<Individual> population;
	
	private boolean execNewCasesOnly = false; // by default, execute all test cases at all cycle
	
	private MsgStorage msgStorage;
	private ArrayList<NodeType> mutantNodes;

	private TestConfig testConfig;

	private boolean configOK = false;

	private MonitoringModel monitoringModel = MonitoringModel.getInstance();

	private IMonitorAgent monitorAgent;
	private TestResultsModel resultModel = TestResultsModel.getInstance();

	private double mutationProb = 0.1;
	private int maxGen = MAX_NUMBER_GEN;
	private int maxPSize = MAX_POPULATION_SIZE;

	private GeneralLogger logger = GeneralLogger.getInstance();

	private int numbOfMutants; // Total number of mutants killed

	private Individual currentIndividual; // Current individual
	private int currentIndIndex;		  // Current index of the current individual	
	private int currentGen; // Current generation

	private String currentSessionID = "";
	private String currentTcID = "";
	private String currentTsTD = "na";

	/**
	 * Individual of the population
	 * @author cunduy
	 *
	 */
	private class Individual{
		private TestCaseType tc;
		private double fitness;
		private int tcLength; 		// length of the tc
		private boolean executed;	// to track if tc has been executed
		
		private Individual(TestCaseType tc) {
			this.tc = tc;
			tcLength = length(tc);
			executed = false;
			fitness = 0;
		}

		public TestCaseType getTc() {
			return tc;
		}

		public void setTc(TestCaseType tc) {
			this.tc = tc;
		}

		public double getFitness() {
			return fitness;
		}

		public void setFitness(double fitness) {
			this.fitness = fitness;
		}

		public int getTcLength() {
			return tcLength;
		}

		public void setTcLength(int tcLength) {
			this.tcLength = tcLength;
		}

		public boolean isExecuted() {
			return executed;
		}

		public void setExecuted(boolean executed) {
			this.executed = executed;
		}

		
		@Override
		public boolean equals(Object obj) {
			
			if (obj == null) return false;
			
			if (obj instanceof Individual){
				Individual tmp = (Individual)obj;
				if (tmp.getTc() != null &&
						(tmp.getTc().getID().equals(tc.getID()))){
					return true;
				}
				
			}
			
			return false;
		}
		
		
		
	}
	
	// ///////////////////////////////////////////////////
	// Constructors

	public MutationTestExecutionBehaviour(Agent a, TestConfig testConfig, ArrayList<TestCaseType> initialTestCases) {
		super(a);

		this.testConfig = testConfig;

		if (testConfig.getMaxMutationGen() > 0) {
			maxGen = testConfig.getMaxMutationGen();
		}

		if (testConfig.getMaxMutationPsize() > 0) {
			maxPSize = testConfig.getMaxMutationPsize();
		}

		if (testConfig.getMutationProb() > 0) {
			mutationProb = testConfig.getMutationProb();
		}
		
		if (testConfig.isMutationExeNewCasesOnly()){
			execNewCasesOnly = true;
		}

		population = new ArrayList<Individual>();
		
		// copy from initialTestCases
		int size = (initialTestCases.size() < maxPSize) ? initialTestCases.size() : maxPSize;

		Iterator<TestCaseType> iter = initialTestCases.iterator();
		int i = 0;
		while (iter.hasNext() && (i < size)) {
			Individual ind = new Individual((TestCaseType) iter.next());
			population.add(ind);
		}

		mutantNodes = new ArrayList<NodeType>();
		msgStorage = new MsgStorage();

		monitorAgent = ECATPlugIn.getDefault().getMonitorAgent();
		if (monitorAgent == null) {
			configOK = false;
		} else {
			configOK = initMutants() && initMsg();
		}

		init(a, new DataStore());
	}

	/**
	 * Initiate behaviour
	 * 
	 * @param a
	 * @param ds
	 */

	private void init(Agent a, DataStore ds) {
		this.myAgent = a;
		setDataStore(ds);

		// /////////////////////////////////////////////////////////////
		// Register states
		Behaviour b = null;

		// INITIAL
		b = new OneShotBehaviour(myAgent) {

			/**
			 * 
			 */
			private static final long serialVersionUID = 0L;
			int ret = EVENT_INITIAL_OK;

			@Override
			public void action() {
				if (!configOK) {
					ret = EVENT_INITIAL_FAILURE;
					logger.log(GeneralLogger.LEVEL_INFO, "Mutation testing: configuration contains errors");
				}

				// Initiate value
				currentGen = 0;
			}

			@Override
			public int onEnd() {
				return ret;
			}

		};
		b.setDataStore(this.getDataStore());
		b.setBehaviourName(STATE_INITIAL);
		registerFirstState(b, STATE_INITIAL);

		// RESET REMOTE MONIROTING AGENTS
		b = new OneShotBehaviour(myAgent) {

			/**
			 * 
			 */
			private static final long serialVersionUID = 0L;

			public void action() {
				Synchronizer sync = new Synchronizer();
				monitorAgent.resetRemotes(sync);
				sync.waitOn();

			}

			public int onEnd() {
				return EVENT_CONTROL;
			}

		};
		b.setBehaviourName(STATE_RESET_REMOTES);
		registerState(b, STATE_RESET_REMOTES);

		// CONTROL
		b = new OneShotBehaviour(myAgent) {

			/**
			 * 
			 */
			private static final long serialVersionUID = 1216627535851615221L;

			int ret;

			@Override
			public void action() {

				if (!ECATPlugIn.getDefault().getTesterAgent().isRunningTest()) {
					ret = EVENT_ABOUT; // external force stop
					return;
				}

				Behaviour pre = getPrevious();
				if (pre.getBehaviourName().equals(STATE_RESET_REMOTES)
						|| pre.getBehaviourName().equals(STATE_EVOLUTION)) {
					// New generation
					currentIndividual = null;
					currentIndIndex = -1;
					currentGen += 1;
					
					// Display current generation
					if (currentGen <= maxGen) {
						//resultModel.setNumTestCase(population.size());
						resultModel.setTestCycle(currentGen);
					}

					logger.log(GeneralLogger.LEVEL_INFO, "Mutation testing: generation " + String.valueOf(currentGen));

				} else if (pre.getBehaviourName().equals(STATE_TESTRUN)) {
					// getRemoteLogs.reset(reportRequest);
					ret = EVENT_GET_LOGS;
					return;
				}

				if (currentGen > maxGen) {
					ret = EVENT_EVALUATION;
					return;
				}

				// Take next individual
				if (execNewCasesOnly){
					// find the next index
					currentIndIndex = -1;
					for (int i = 0; i< population.size(); i++){
						if (!population.get(i).isExecuted()){
							currentIndIndex = i;
							break;
						}
					}
					
					if (currentIndIndex == -1){
						// all are executed
						currentIndIndex = population.size();
					}
				} else
					currentIndIndex += 1; // increase by one
				
				if (currentIndIndex < population.size()) {

					// Reset the remote monitoring trace
					// prepareRemoteMonitoring();
					
					currentIndividual = population.get(currentIndIndex); 

					TestCaseType tc = currentIndividual.getTc();

					String taID = myAgent.getLocalName();
					String uid = myAgent.getAID().getHap() + "/";
					currentSessionID = CommonUtil.generateId(uid);
					currentTcID = tc.getID();

					Synchronizer sync = new Synchronizer();
					monitorAgent.startNewSession(currentSessionID, taID, currentTsTD, currentTcID, sync);
					sync.waitOn();

					if ((currentIndIndex == 0) && (currentGen == 1)) {
						// initialize sub behaviour
						Iterator<NodeType> iter = mutantNodes.iterator();
						while (iter.hasNext()) {
							NodeType node = (NodeType) iter.next();
							// OneSessionTestBehaviour testSession = new
							// OneSessionTestBehaviour(myAgent, node);
							MutationTestBehaviour testSession = new MutationTestBehaviour(myAgent, node, msgStorage);
							testSession.setTestCase(tc);
							parallelTestExecutor.addSubBehaviour(testSession);
						}
					} else {

						resetRemoteMutants(); // Reset remote mutants

						/* Does not work with JADE 3.5
						parallelTestExecutor.reset();
						Iterator behaviour = parallelTestExecutor.getChildren().iterator();
						while (behaviour.hasNext()) {
							// OneSessionTestBehaviour b =
							// (OneSessionTestBehaviour) behaviour.next();
							MutationTestBehaviour b = (MutationTestBehaviour) behaviour.next();

							// Put all message received to the message storage
							msgStorage.add(b.getReceivedMsg());
							parallelTestExecutor.removeSubBehaviour(b);

						}
						*/

						Iterator<NodeType> iter = mutantNodes.iterator();
						while (iter.hasNext()) {
							NodeType node = (NodeType) iter.next();
							// OneSessionTestBehaviour testSession = new
							// OneSessionTestBehaviour(myAgent, node);
							MutationTestBehaviour testSession = new MutationTestBehaviour(myAgent, node, msgStorage);
							testSession.setTestCase(tc);
							parallelTestExecutor.addSubBehaviour(testSession);
						}
					}

					ret = EVENT_TEST_EXECUTION; // Go to test execution
				} else {
					ret = EVENT_EVALUATION; // Go to evaluation step
				}
			}

			@Override
			public int onEnd() {
				return ret;
			}

		};
		b.setDataStore(this.getDataStore());
		b.setBehaviourName(STATE_CONTROL);
		registerState(b, STATE_CONTROL);

		// TEST EXECUTION
		parallelTestExecutor = new ParallelBehaviour(myAgent, ParallelBehaviour.WHEN_ALL);
		parallelTestExecutor.setBehaviourName(STATE_TESTRUN);
		parallelTestExecutor.setDataStore(this.getDataStore());
		registerState(parallelTestExecutor, STATE_TESTRUN);

		// GET REMOTE MONITORING TRACE
		b = new OneShotBehaviour(myAgent) {

			/**
			 * 
			 */
			private static final long serialVersionUID = 0L;

			public void action() {
				Synchronizer sync = new Synchronizer();
				monitorAgent.getRemoteTraces(sync);
				sync.waitOn();
			}

			public int onEnd() {
				return EVENT_CALCULATE_FITNESS;
			}
		};
		b.setBehaviourName(STATE_GET_REMOTE_TRACES);
		registerState(b, STATE_GET_REMOTE_TRACES);

		// FITNESS CALCULATION
		b = new OneShotBehaviour(myAgent) {

			/**
			 * 
			 */
			private static final long serialVersionUID = 8613983438658481937L;

			@Override
			public void action() {
				if (currentIndividual == null) return;
				
				currentIndividual.setExecuted(true); // set executed
				calculateFitness(currentIndividual);
			}

		};
		b.setDataStore(this.getDataStore());
		b.setBehaviourName(STATE_CALCULATEFITNESS);
		registerState(b, STATE_CALCULATEFITNESS);

		// EVALUATION STATE
		b = new OneShotBehaviour(myAgent) {

			/**
			 * 
			 */
			private static final long serialVersionUID = 4428583988709047475L;

			boolean optimalFound = false;

			@Override
			public void action() {
				if (currentGen < maxGen) {
					// Error with exec only new cases option
					/* 
					numbOfMutants = 0;
					for (Individual i : population) {
						numbOfMutants += i.getFitness();
					}
					
					if (numbOfMutants > 0){
						for (Individual i : population) {
							i.setFitness(i.getFitness() / (double)numbOfMutants);
						}
					} else {
						logger.log("Number of mutants kill by all test case zero");
					}
					*/
				}
			}

			@Override
			public int onEnd() {
				if (optimalFound || (currentGen >= maxGen)) {
					return EVENT_FINISH;
				} else {
					return EVENT_EVOLUTION;
				}
			}
		};
		b.setDataStore(this.getDataStore());
		b.setBehaviourName(STATE_EVALUATION);
		registerState(b, STATE_EVALUATION);

		// EVOLUATION STATE
		b = new OneShotBehaviour(myAgent) {

			/**
			 * 
			 */
			private static final long serialVersionUID = -645671384973266611L;

			@Override
			public void action() {
				logger.log(GeneralLogger.LEVEL_INFO, "Mutation testing: Evolution");
				evoluation();
			}

		};
		b.setDataStore(this.getDataStore());
		b.setBehaviourName(STATE_EVOLUTION);
		registerState(b, STATE_EVOLUTION);

		// FINAL STATE
		b = new OneShotBehaviour(myAgent) {

			/**
			 * 
			 */
			private static final long serialVersionUID = 1216627535851615221L;

			@Override
			public void action() {
				ITesterAgent tester = ECATPlugIn.getDefault().getTesterAgent();
				if (tester != null) {
					((TesterAgent) tester).stopTesting();
				}

				IMonitorAgent monitor = ECATPlugIn.getDefault().getMonitorAgent();
				if (monitor != null) {
					monitor.delayedStopMonitoring();
				}

				logger.log(GeneralLogger.LEVEL_INFO, "Mutation testing: Done");
				logger.log(GeneralLogger.LEVEL_INFO, "Mutation testing: Number of generation: "
						+ String.valueOf(currentGen));
				logger.log(GeneralLogger.LEVEL_INFO, "Mutation testing: Population size: "
						+ String.valueOf(population.size()));

			}

		};
		b.setDataStore(this.getDataStore());
		registerLastState(b, STATE_FINAL);

		// Transitions registration
		registerTransition(STATE_INITIAL, STATE_RESET_REMOTES, EVENT_INITIAL_OK);
		registerTransition(STATE_INITIAL, STATE_FINAL, EVENT_INITIAL_FAILURE);

		registerDefaultTransition(STATE_TESTRUN, STATE_CONTROL);
		registerDefaultTransition(STATE_CALCULATEFITNESS, STATE_CONTROL);
		registerTransition(STATE_CONTROL, STATE_TESTRUN, EVENT_TEST_EXECUTION);

		// registerTransition(STATE_CONTROL, STATE_CALCULATEFITNESS,
		// EVENT_CALCULATE_FITNESS);
		registerTransition(STATE_CONTROL, STATE_GET_REMOTE_TRACES, EVENT_GET_LOGS);
		registerTransition(STATE_CONTROL, STATE_EVALUATION, EVENT_EVALUATION);

		registerTransition(STATE_CONTROL, STATE_FINAL, EVENT_ABOUT);

		registerTransition(STATE_EVALUATION, STATE_FINAL, EVENT_FINISH);
		registerTransition(STATE_EVALUATION, STATE_EVOLUTION, EVENT_EVOLUTION);
		// registerDefaultTransition(STATE_EVALUATION, STATE_EVOLUTION);

		registerDefaultTransition(STATE_EVOLUTION, STATE_CONTROL);

		registerTransition(STATE_RESET_REMOTES, STATE_CONTROL, EVENT_CONTROL);
		registerTransition(STATE_RESET_REMOTES, STATE_FINAL, EVENT_FINISH_FAILED);

		registerTransition(STATE_GET_REMOTE_TRACES, STATE_CALCULATEFITNESS, EVENT_CALCULATE_FITNESS);
		registerTransition(STATE_GET_REMOTE_TRACES, STATE_FINAL, EVENT_FINISH_FAILED);
	}

	// //////////////////////////////////////////////////
	// 

	/**
	 * Init mutants references from test configuration. This method also checks
	 * the testConfig object
	 * 
	 * @return
	 */
	private boolean initMutants() {
		// Initialize local references to remote mutants

		if (this.testConfig == null)
			return false;
		else if (this.testConfig.getDitributedNodeConfig() == null)
			return false;
		else {
			List<NodeType> l = this.testConfig.getDitributedNodeConfig().getNode();
			Iterator<NodeType> iter = l.iterator();
			while (iter.hasNext()) {
				mutantNodes.add((NodeType) iter.next());
			}
			
		}
		return true;
	}

	/**
	 * Init GA
	 * 
	 * @return
	 */
	private boolean initMsg() {
		// Init the storage of all outgoing messages from the
		// initial population

		if (testConfig != null) {
			String dbPath = testConfig.getDomainDataPath();
			if (dbPath != null) {
				msgStorage.init(dbPath);
			}
		}

		Iterator<Individual> iter = population.iterator();
		int i = 0;
		while (iter.hasNext()) {
			TestCaseType tc = iter.next().getTc();
			TestScenarioType ts = tc.getScenario();
			List<TActionType> seqList = ts.getTestAction();
			Iterator<TActionType> seqIter = seqList.iterator();

			while (seqIter.hasNext()) {
				TActionType seq = (TActionType) seqIter.next();
				if (seq.getActType().equals(AType.COMMUNICATION)) {
					if (seq.getInitiator().equals(GlobalConstants.TESTER_AGENT_NAME)) {
						Object obj = seq.getMessage();
						if (obj != null && (obj instanceof FipaMessageType)) {
							msgStorage.add((FipaMessageType) obj); // The
							// fipamessage
						}
					}
				}
			}
			i = i + 1;
		}

		return true;
	}
	
	/**
	 * Calculate length of a test case
	 * @param tc
	 * @return
	 */
	private int length(TestCaseType tc){
		int ret = 0;
		if (tc == null) return 0;
		
		TestScenarioType ts = tc.getScenario();
		List<TActionType> seqList = ts.getTestAction();
		Iterator<TActionType> seqIter = seqList.iterator();
		
		while (seqIter.hasNext()) {
			TActionType seq = (TActionType) seqIter.next();
			if (seq.getActType().equals(AType.COMMUNICATION)) {
				if (seq.getInitiator().equals(GlobalConstants.TESTER_AGENT_NAME)) {
					Object obj = seq.getMessage();
					if (obj != null && (obj instanceof FipaMessageType)) {
						ret += 1;
					}
				}
			}
		}
		
		return ret;
	}
	

	/**
	 * Perform crossover to produce a couple of children
	 * 
	 * @param father
	 * @param mother
	 * @return
	 */
	private ArrayList<TestCaseType> xover(TestCaseType father, TestCaseType mother, int maxCutPos) {
		ArrayList<TestCaseType> offsprings = new ArrayList<TestCaseType>();

		TestCaseType child1 = null;
		child1 = CommonUtil.copyTc(father);
		offsprings.add(child1);

		TestCaseType child2 = null;
		child2 = CommonUtil.copyTc(mother);
		offsprings.add(child2);

		Random posSelector = new Random();
		int cutpos = posSelector.nextInt(maxCutPos);

		if (cutpos == 0)
			cutpos = maxCutPos; // 

		// exchange outgoing messages
		TestScenarioType ts = child1.getScenario();
		List<TActionType> actList = ts.getTestAction();
		List<TActionType> actList2 = child2.getScenario().getTestAction();

		int i = 0;
		int j = 0;
		int count = 0;

		while (i < actList.size() && count < cutpos) {
			TActionType seq = (TActionType) actList.get(i);

			if (seq.getActType().equals(AType.COMMUNICATION)) {
				if (seq.getInitiator().equals(GlobalConstants.TESTER_AGENT_NAME)) {
					Object obj = seq.getMessage();
					if (obj != null && (obj instanceof FipaMessageType)) {
						while (j < actList2.size()) {
							TActionType seq2 = (TActionType) actList2.get(j);

							if (seq2.getActType().equals(AType.COMMUNICATION)) {
								if (seq2.getInitiator().equals(GlobalConstants.TESTER_AGENT_NAME)) {
									Object obj2 = seq2.getMessage();
									if (obj2 != null && (obj2 instanceof FipaMessageType)) {
										seq.setMessage((FipaMessageType) obj2);
										seq2.setMessage((FipaMessageType) obj);

										count += 1;
									}
									j += 1;
									break;
								}
							}
							j += 1;
						}
					}
				}
			}
			i += 1;
		}

		return offsprings;
	}

	/**
	 * Perform mutation at the position <b>pos</b>
	 * 
	 * @param tc
	 * @param pos
	 * @return
	 */
	private TestCaseType mutateTestCase(TestCaseType tc, int pos) {

		TestCaseType ret = CommonUtil.copyTc(tc);
		
		TestScenarioType ts = ret.getScenario();
		List<TActionType> actList = ts.getTestAction();
		Iterator<TActionType> seqIter = actList.iterator();

		Random msgSelector = new Random();
		int count = 0;

		while (seqIter.hasNext()) {
			TActionType seq = (TActionType) seqIter.next();
			if (seq.getActType().equals(AType.COMMUNICATION)) {
				if (seq.getInitiator().equals(GlobalConstants.TESTER_AGENT_NAME)) {
					Object obj = seq.getMessage();
					if (obj != null && (obj instanceof FipaMessageType)) {
						count = count + 1;
						if (count == pos) {
							FipaMessageType msg = msgStorage.get(msgSelector.nextInt(msgStorage.size() - 1));
							seq.setMessage(msg);
							break;
						}
					}
				}
			}
		}

		return ret;
	}

	/**
	 * Select the best individual, except the individual that could be selected
	 * before.
	 * 
	 * except = -1 to select among all.
	 * 
	 * @param individual
	 * @param selector
	 * @return
	 */
	private Individual elitistSelection(Individual exceptInd) {
		// Select the best individual
		double max = 0.0;
		Individual max_index = null;

		for (Individual ind : population) {
			
			if (ind.getFitness() > max && !ind.equals(exceptInd)) {
				max = ind.getFitness();
				max_index = ind;
			}
		}

		if (max_index == null) {
			Random nextSelector = new Random();
			int tmp = nextSelector.nextInt(population.size());
			max_index = population.get(tmp);
		}

		return max_index;
	}

	/**
	 * Selection based on roulette-wheel algorithm cumulative distribution
	 * method
	 * 
	 * @return
	 */
	private Individual rouletteWheelSelection() {
		Random selector = new Random();
		double r = selector.nextDouble();
		
		// First, have to standardize the fitness values
		numbOfMutants = 0;
		for (Individual ind : population) {
			numbOfMutants += ind.getFitness();
		}
		
		if (numbOfMutants > 0){
			double fit[] = new double[population.size()];
			
			if (numbOfMutants > 0){
				for (int j=0; j <population.size(); j++) {
					fit[j] = population.get(j).getFitness() / (double)numbOfMutants;
				}
			} 
			
			int i = 0;
			double l = 0.0;
			
			while (i < population.size()) {
				if (l <= r && r < l + fit[i]) {
					return population.get(i);
				} else {
					l = l + fit[i];
				}
				i += 1;
			}
		}
		
		// return a random individual
		Random nextSelector = new Random();
		int tmp = nextSelector.nextInt(population.size());
		return population.get(tmp);
	}

	/**
	 * Remove the worse individual of the population in case when the population
	 * size exceeds the maximum number of individual
	 * 
	 * @return
	 */
	private boolean removeWorseIndividual() {
		double min = MAX_POPULATION_SIZE; //asume max
		int min_index = 0;

		for (int i = 0; i < population.size(); i++) {
			if (population.get(i).getFitness() <= min) {
				min = population.get(i).getFitness();
				min_index = i;
			}
		}

		Individual ind = population.get(min_index);
		resultModel.removeTestCase(ind.getTc());
		population.remove(min_index);

		return true;
	}

	/**
	 * Prepare or reset remote mutants
	 * 
	 */
	protected void resetRemoteMutants() {
		IExecutor centerExecutor = ECATPlugIn.getDefault().getExecutorAgent();
		if (centerExecutor != null) {
			Synchronizer syn = new Synchronizer();
			centerExecutor.resetRemoteAgents(testConfig, syn);
			syn.waitOn(); // Wait for reseting agents
		}
	}

	/*
	 * Prepare for logging trace
	 */
	protected void prepareRemoteMonitoring() {
		monitoringModel.resetRemoteTrace(); // Create logs on the central
											// monitoring agent
		// monitorAgent.resetRemotes(); // Request all remote monitoring agents
		// to reset their logs
	}

	/**
	 * Identify number of mutant killed by previous test case Here we have to
	 * options, either by looking at the test result or monitoring trace
	 * 
	 * @param tcIndex
	 * @return
	 */
	private int calculateFitness(Individual ind) {
		int killMutants = 0;

		if (mutantNodes == null || mutantNodes.size() == 0)
			return 0;

		// Compare monitoring trace of all mutants to the first one,
		// assume that the first one is the one of the original program
		NodeType firstNode = mutantNodes.get(0);

		String remoteAgentID = CommonUtil.getRemoteMonitoringAgentGUID(firstNode);
		RemoteMonitoringLogs originalTrace = monitoringModel.getRemoteLogger(remoteAgentID);

		SessionType originalST = originalTrace.getSessionType(currentSessionID);

		// logger.log(GeneralLogger.LEVEL_INFO, "Original Trace: " +
		// originalTrace);

		for (int i = 1; i < mutantNodes.size(); i++) {
			NodeType node = mutantNodes.get(i);

			String key = CommonUtil.getRemoteMonitoringAgentGUID(node);
			RemoteMonitoringLogs trace = monitoringModel.getRemoteLogger(key);
			SessionType st = trace.getSessionType(currentSessionID);

			if (!isEqual(originalST, st)) {
				// Mutant killed
				killMutants += 1;
			}
		}

		ind.setFitness((double) killMutants);

		return killMutants;

	}

	private boolean isEqual(SessionType s1, SessionType s2) {
		if (s1 == null || s2 == null)
			return false;
		else {
			// TODO implement the comparison between to SessionType, currently it is too simple
			List<EventType> l1 = s1.getEvent();
			List<EventType> l2 = s2.getEvent();
			if (l1.size() != l2.size())
				return false;
		}
		return true;
	}

	/**
	 * GA evoluation
	 * 
	 */
	protected void evoluation() {
		// Choose evolution method
		Random methodSelector = new Random();
		Random posSelector = new Random();
		if (methodSelector.nextDouble() <= mutationProb) { // Mutation

			Individual selectedInd = elitistSelection(null); // The best

			// Change randomly one gen
			if (selectedInd.getTcLength() > 0) {
				int posToBeReplaced = posSelector.nextInt(selectedInd.getTcLength());

				if (posToBeReplaced == 0 && selectedInd.getTcLength() > 0)
					posToBeReplaced = 1; // first place

				TestCaseType newTestCase = mutateTestCase(selectedInd.getTc(), posToBeReplaced);
				Individual newInd = new Individual(newTestCase);
				if (population.size() < maxPSize) {
					population.add(newInd);

				} else {
					if (removeWorseIndividual()) { // Remove the worse
						// individual
						population.add(newInd);
					}
				}

				// Add test case to the results view
				resultModel.addTestCase(newTestCase);
			}
		} else { // Xover

			Individual selectedFather = rouletteWheelSelection();
			Individual selectedMother = rouletteWheelSelection();

			TestCaseType father = selectedFather.getTc();
			TestCaseType mother = selectedMother.getTc();

			int maxCutPost = selectedFather.getTcLength() > selectedMother.getTcLength() ? selectedMother.getTcLength()
					: selectedFather.getTcLength();

			ArrayList<TestCaseType> offsprings = xover(father, mother, maxCutPost);

			TestCaseType son = offsprings.get(0);
			Individual newInd = new Individual(son);

			if (population.size() < maxPSize) {
				population.add(newInd);
			} else {
				if (removeWorseIndividual()) { // Remove the worse
					// individual
					population.add(newInd);
				}
			}

			// Add test case to the results view
			resultModel.addTestCase(son);

			TestCaseType daughter = offsprings.get(1);
			newInd = new Individual(daughter);
			if (population.size() < maxPSize) {
				population.add(newInd);
			} else {
				if (removeWorseIndividual()) { // Remove the worse
					// individual
					population.add(newInd);
				}
			}

			// Add test case to the results view
			resultModel.addTestCase(daughter);
		}
	}
}
