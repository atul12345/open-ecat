/**
 * <copyright>
 *
 * eCAT - Tool for Continuous Testing Agent for the JADE/Eclipse Platform
 * Copyright (C) ITC-IRST, Trento, Italy
 * Authors: Duy Cu Nguyen
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 * The electronic copy of the license can be found here:
 * http://sra.itc.it/tools/taom/freesoftware/gpl.txt
 *
 * The contact information:
 * e-mail: cunduy@itc.it
 * site: http://sra.itc.it
 *
 * </copyright>
 * 
 * NOTE: This class shares the inspiration of Sniffer class of JADE. It also 
 * reuses some code from Sniffer
 * 
 */

package it.itc.sra.ecat.core.remote;

import it.itc.sra.ecat.core.monitor.onto.MonitoringOntology;
import it.itc.sra.ecat.core.monitor.onto.RequestLogs;
import it.itc.sra.ecat.core.monitor.onto.RequestMonitorTrace;
import it.itc.sra.ecat.core.monitor.onto.Reset;
import it.itc.sra.ecat.core.monitor.onto.Setup;
import it.itc.sra.ecat.core.monitor.onto.StartSession;
import it.itc.sra.ecat.core.monitor.onto.Stop;
import it.itc.sra.ecat.core.monitor.onto.UpdateLogs;
import it.itc.sra.ecat.core.monitor.onto.UpdateMonitorTrace;
import it.itc.sra.ecat.monitordata.EventType;
import it.itc.sra.ecat.monitordata.KindType;
import it.itc.sra.ecat.util.CommonUtil;
import jade.content.Concept;
import jade.content.ContentManager;
import jade.content.lang.Codec;
import jade.content.lang.Codec.CodecException;
import jade.content.lang.sl.SLCodec;
import jade.content.onto.Ontology;
import jade.content.onto.OntologyException;
import jade.content.onto.UngroundedException;
import jade.content.onto.basic.Action;
import jade.content.onto.basic.Done;
import jade.core.AID;
import jade.core.ContainerID;
import jade.core.behaviours.CyclicBehaviour;
import jade.core.behaviours.SenderBehaviour;
import jade.core.behaviours.SequentialBehaviour;
import jade.domain.FIPANames;
import jade.domain.FIPAAgentManagement.Envelope;
import jade.domain.JADEAgentManagement.JADEManagementOntology;
import jade.domain.JADEAgentManagement.SniffOff;
import jade.domain.JADEAgentManagement.SniffOn;
import jade.domain.introspection.BornAgent;
import jade.domain.introspection.DeadAgent;
import jade.domain.introspection.Event;
import jade.domain.introspection.EventRecord;
import jade.domain.introspection.IntrospectionVocabulary;
import jade.domain.introspection.MovedAgent;
import jade.domain.introspection.Occurred;
import jade.domain.introspection.PostedMessage;
import jade.domain.introspection.SentMessage;
import jade.lang.acl.ACLCodec;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import jade.lang.acl.StringACLCodec;
import jade.proto.AchieveREResponder;
import jade.proto.SimpleAchieveREInitiator;
import jade.tools.ToolAgent;
import jade.tools.sniffer.Agent;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

public class RemoteMonitorAgent extends ToolAgent {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6737534307694370237L;

	private static final boolean SNIFF_ON = true;
	private static final boolean SNIFF_OFF = false;

	private ArrayList<String> monitoredAgents = null;
	private ArrayList<Agent> agentsUnderSniff = null;

	private ContentManager manager = (ContentManager) getContentManager();
	// This agent speaks the SL language
	private Codec codec = new SLCodec();
	private Ontology ontology = MonitoringOntology.getInstance();

	private String currentSessionID = null;

	private RemoteLogger logger = new RemoteLogger();
	private MonitoringConstraintHandler constraintHandler;

	// /////////////////////////////////////////////////////////////////////
	/**
	 * This behavior is used to communicate with the central monitoring agent
	 * 
	 * @author cunduy
	 * 
	 */
	private class CentralRequestListener extends AchieveREResponder {

		/**
		 * 
		 */
		private static final long serialVersionUID = 7756681376882887643L;

		public CentralRequestListener() {
			super(RemoteMonitorAgent.this, MessageTemplate.and(MessageTemplate
					.MatchPerformative(ACLMessage.REQUEST), MessageTemplate
					.MatchProtocol(FIPANames.InteractionProtocol.FIPA_REQUEST)));
		}

		@Override
		protected ACLMessage prepareResponse(ACLMessage request) {
			// query = request.getContent();
			ACLMessage response = request.createReply();

			try {
				Action action = (Action) manager.extractContent(request);
				Concept c = action.getAction();
				if (c instanceof Setup || c instanceof Reset
						|| c instanceof Stop || c instanceof RequestLogs
						|| c instanceof RequestMonitorTrace
						|| c instanceof StartSession) {
					response.setPerformative(ACLMessage.AGREE);
					response.setContent("Correct request, pls hold-on for reply!");
				} else {
					response.setPerformative(ACLMessage.REFUSE);
					response.setContent("I dont understand your query!");
				}

			} catch (UngroundedException e) {
				response.setPerformative(ACLMessage.REFUSE);
				response.setContent("Error occured: " + e.getMessage());
				e.printStackTrace();
			} catch (CodecException e) {
				response.setPerformative(ACLMessage.REFUSE);
				response.setContent("Error occured: " + e.getMessage());
				e.printStackTrace();
			} catch (OntologyException e) {
				response.setPerformative(ACLMessage.REFUSE);
				response.setContent("Error occured: " + e.getMessage());
				e.printStackTrace();
			}
			return response;
		}

		@Override
		protected ACLMessage prepareResultNotification(ACLMessage request,
				ACLMessage response) {
			// Send back the notification
			ACLMessage result = request.createReply();
			result.setPerformative(ACLMessage.INFORM);
			result.setLanguage(codec.getName());
			result.setOntology(ontology.getName());

			Action action;
			try {
				action = (Action) manager.extractContent(request);
				Concept c = action.getAction();
				if (c instanceof Setup) {
					String agentList = ((Setup) c).getParam();
					setMonitoredAgents(agentList); // Reset the list of agents
													// being monitored

					Done done = new Done(action);
					manager.fillContent(result, done);

				} else if (c instanceof Reset) {
					logger.resetLog(); // clear the log
					logger.resetMonitor();
					Done done = new Done(action);

					manager.fillContent(result, done);

				} else if (c instanceof StartSession) {
					StartSession newSess = (StartSession) c;
					String sessID = newSess.getSessionID();
					String testerID = newSess.getAid();
					String suiteID = newSess.getTestSuite();
					String caseID = newSess.getTestCase();

					// Create a new monitoring session
					logger.startSession(sessID, testerID, suiteID, caseID);
					currentSessionID = sessID;
					constraintHandler.setCurrentSessionID(currentSessionID);

					Done done = new Done(action);
					manager.fillContent(result, done);

				} else if (c instanceof RequestLogs) {
					Action a = new Action();
					UpdateLogs log = new UpdateLogs();
					a.setActor(getAID());
					a.setAction(log);
					log.setLogs(logger.getLogs());
					logger.resetLog();
					manager.fillContent(result, a);

				} else if (c instanceof RequestMonitorTrace) {
					Action a = new Action();
					a.setActor(getAID());

					String sessionID = ((RequestMonitorTrace) c).getSessionID();
					UpdateMonitorTrace report = new UpdateMonitorTrace();
					report.setSessionID(sessionID);
					report.setSessionTrace(logger.getSessionTrace(sessionID));

					a.setAction(report);
					manager.fillContent(result, a);
				}

			} catch (UngroundedException e) {
				e.printStackTrace();
			} catch (CodecException e) {
				e.printStackTrace();
			} catch (OntologyException e) {
				e.printStackTrace();
			}

			return result;
		}

	}

	// //////////////////////////////////////////////////////////////////////
	/**
	 * This behavior is used to listen to events happened in the platform
	 * 
	 * We handle only two events: BORNAGENT, DEADAGENT
	 * 
	 * @author cunduy
	 * 
	 */
	private class AMSEventListener extends AMSListenerBehaviour {

		/**
		 * 
		 */
		private static final long serialVersionUID = -4242277399424514726L;

		@Override
		protected void installHandlers(Map handlersTable) {
			handlersTable.put(IntrospectionVocabulary.BORNAGENT,
					new EventHandler() {
						public void handle(Event ev) {
							BornAgent ba = (BornAgent) ev;
							ContainerID cid = ba.getWhere();
							String container = cid.getName();
							AID agent = ba.getAgent();

							// Here we check to see if the agent is one that we
							// automatically will
							// start sniffing. If so, we invoke
							// DoSnifferAction's doSniff and start
							// the sniffing process.

							if (monitoredAgents.size() == 0 
									|| monitoredListContains(agent.getLocalName())) {
								// logger.monitor("born(" + agent.getLocalName()
								// + ");");

								EventType event = new EventType();
								event.setKind(KindType.AGENTBORN);
								event.setContent(agent.getName());
								event.setWhen(CommonUtil.getCurrentDateTime());
								event.setWhere(container);

								logger.monitor(currentSessionID, event);
								
								if (!isSystemAgent(agent.getName())){
									List agents = new ArrayList();
									agents.add(new Agent(agent));
									sniffMsg(agents, SNIFF_ON);
								}
							}

						}
					});

			handlersTable.put(IntrospectionVocabulary.DEADAGENT,
					new EventHandler() {
						public void handle(Event ev) {
							DeadAgent da = (DeadAgent) ev;
							ContainerID cid = da.getWhere();
							String container = cid.getName();
							AID agent = da.getAgent();

							// the agent has been killed
							if (monitoredAgents.size() == 0 
									|| monitoredListContains(agent.getLocalName())) {
								// logger.monitor("killed(" +
								// agent.getLocalName() + ");");
								EventType event = new EventType();
								event.setKind(KindType.AGENTDEAD);
								event.setContent(agent.getName());
								event.setWhen(CommonUtil.getCurrentDateTime());
								event.setWhere(container);

								logger.monitor(currentSessionID, event);
								
								if (monitoredListContains(agent.getLocalName())){
									List agents = new ArrayList();
									agents.add(new Agent(agent));
									sniffMsg(agents, SNIFF_OFF);
								} else {
									Agent a = new Agent(agent);
									if (agentsUnderSniff.contains(a)) {
										agentsUnderSniff.remove(a);
									}
								}
							}

						}
					});
			handlersTable.put(IntrospectionVocabulary.MOVEDAGENT,
					new EventHandler() {
						public void handle(Event ev) {
							MovedAgent ma = (MovedAgent) ev;
							String where = ma.getFrom().getName();
							String toWhere = ma.getTo().getName();
							AID agent = ma.getAgent();

							if (monitoredAgents.size() == 0 || monitoredListContains(agent.getLocalName())) {
								EventType event = new EventType();
								event.setKind(KindType.AGENTMOVE);
								event.setContent(agent.getName());
								event.setWhen(CommonUtil.getCurrentDateTime());
								event.setWhere(where);
								event.setTowhere(toWhere);

								logger.monitor(currentSessionID, event);
							}
						}

					});
		}

	}

	// //////////////////////////////////////////////////////////////////////

	// //////////////////////////////////////////////////////////////////////
	/**
	 * This class is responsible to send request to AMS, asking for starting or
	 * stopping monitoring an agent
	 * 
	 */
	private class AMSMonitoringInitiator extends SimpleAchieveREInitiator {

		/**
		 * 
		 */
		private static final long serialVersionUID = 3761591523810723495L;

		public AMSMonitoringInitiator(String action, ACLMessage arg1) {
			super(RemoteMonitorAgent.this, arg1);
		}

		@Override
		protected void handleAgree(ACLMessage arg0) {

		}

		@Override
		protected void handleFailure(ACLMessage arg0) {
			System.err.print(arg0);
		}

		@Override
		protected void handleInform(ACLMessage arg0) {

		}

		@Override
		protected void handleNotUnderstood(ACLMessage arg0) {
			System.err.print(arg0);
		}

		@Override
		protected void handleRefuse(ACLMessage arg0) {
			System.err.print(arg0);
		}

	}

	// //////////////////////////////////////////////////////////////////////

	// //////////////////////////////////////////////////////////////////////
	/**
	 * Monitoring agent communication
	 * 
	 */
	private class CommunicationMonitoring extends CyclicBehaviour {

		/**
		 * 
		 */
		private static final long serialVersionUID = -8471251362602173973L;
		private MessageTemplate listenSniffTemplate;

		CommunicationMonitoring() {
			listenSniffTemplate = MessageTemplate.MatchConversationId(getName()
					+ "-event");
		}

		public void action() {

			ACLMessage current = receive(listenSniffTemplate);
			if (current != null) {

				try {
					Occurred o = (Occurred) getContentManager().extractContent(
							current);
					EventRecord er = o.getWhat();
					Event ev = er.getWhat();
					String content = null;
					Envelope env = null;
					AID unicastReceiver = null;
					if (ev instanceof SentMessage) {
						content = ((SentMessage) ev).getMessage().getPayload();
						env = ((SentMessage) ev).getMessage().getEnvelope();
						unicastReceiver = ((SentMessage) ev).getReceiver();
					} else if (ev instanceof PostedMessage) {
						content = ((PostedMessage) ev).getMessage()
								.getPayload();
						env = ((PostedMessage) ev).getMessage().getEnvelope();
						unicastReceiver = ((PostedMessage) ev).getReceiver();
					} else
						return;

					ACLCodec codec = new StringACLCodec();
					String charset = null;
					if ((env == null)
							|| ((charset = env.getPayloadEncoding()) == null)) {
						charset = ACLCodec.DEFAULT_CHARSET;
					}
					ACLMessage tmp = codec.decode(content.getBytes(charset),
							charset);
					tmp.setEnvelope(env);

					// If this is a 'posted-message' event and the sender is
					// currently under sniff, then the message was already
					// displayed when the 'sent-message' event occurred. In that
					// case, we simply skip this message.
					if (ev instanceof PostedMessage) {
						Agent a = new Agent(tmp.getSender());
						if (agentsUnderSniff.contains(a))
							return;
					}

					String senderName = tmp.getSender().getLocalName();

					Iterator iter = tmp.getAllReceiver();
					while (iter.hasNext()) {
						AID receiver = (AID) iter.next();

						if (monitoredAgents.size() == 0 || monitoredListContains(senderName)
								|| monitoredListContains(receiver
										.getLocalName())) {
							// Log only those agents under monitored
							// logger.monitor("communicate(" + senderName + ","
							// + receiver.getLocalName() + "," +
							// ACLMessage.getPerformative(tmp.getPerformative())
							// + ");");
							EventType event = new EventType();
							event.setKind(KindType.COMMUNICATION);
							event.setContent(tmp.toString());
							event.setWhen(CommonUtil.getCurrentDateTime());
							event.setSender(tmp.getSender().getName());
							event.setReceiver(receiver.getName());

							logger.monitor(currentSessionID, event);

							// logger.log("communicate(" + senderName + "-->" +
							// receiver.getName() + ");");
							// logger.log(tmp.toString());
						}
					}

				} catch (Throwable e) {
					// logger.log(e.getMessage());
					e.printStackTrace();
				}
			} else
				block();
		}
	}

	// ///////////////////////////////////////////////////////////////////////

	// //////////////////////////////////////////////////////////////////////
	@Override
	protected void toolSetup() {

		manager.registerLanguage(codec, FIPANames.ContentLanguage.FIPA_SL);
		manager.registerOntology(ontology);

		monitoredAgents = new ArrayList<String>();
		agentsUnderSniff = new ArrayList<Agent>();

		Object[] args = getArguments();
		
		if (args != null && args.length > 0) {
			String monitoredList = (String) args[0];
			setMonitoredAgents(monitoredList);
		}
		
		// Initilize constrants handler
		constraintHandler = new MonitoringConstraintHandler();
		constraintHandler.setLogger(logger);
		
		SequentialBehaviour subscribe2AMS = new SequentialBehaviour();
		// Send 'subscribe' message to the AMS
		subscribe2AMS.addSubBehaviour(new SenderBehaviour(this, getSubscribe()));

		// Handle incoming messages from the AMS
		subscribe2AMS.addSubBehaviour(new AMSEventListener());

		// Schedule Behaviours for execution
		addBehaviour(subscribe2AMS);
		addBehaviour(new CommunicationMonitoring());

		// Handle request from the central monitoring agent
		addBehaviour(new CentralRequestListener());

		logger.log("Remote Monitoring Agent: " + getName() + " started");

	}

	private void setMonitoredAgents(String agentList) {

		// 

		// System.out.println("AgentList:" + agentList);

		monitoredAgents.clear();
		// Stop sniffing previous agents, if any

		// if (agentsUnderSniff.size() > 0){
		// ArrayList<Agent> agentOffs =
		// (ArrayList<Agent>)agentsUnderSniff.clone();
		// sniffMsg(agentOffs, SNIFF_OFF);
		// }
		// agentsUnderSniff.clear();

		//ArrayList<Agent> newSniffredList = new ArrayList<Agent>();

		StringTokenizer parser = new StringTokenizer(agentList, ";");
		while (parser.hasMoreElements()) {
			String agentID = parser.nextToken();
			int atPos = agentID.lastIndexOf('@');
			if (atPos == -1) {
				agentID = agentID + "@" + getHap();
			}
			monitoredAgents.add(agentID);
//
//			AID agent = new AID();
//			agent.setName(agentID);
//			newSniffredList.add(new Agent(agent));
		}

		// Sniff new agent set
		//sniffMsg(newSniffredList, SNIFF_ON);
	}

	@Override
	protected void toolTakeDown() {
		/*
		 * List l = (List) (agentsUnderSniff.clone()); ACLMessage request =
		 * getSniffMsg(l, SNIFF_OFF);
		 *  // Start a FIPARequestProtocol to sniffOff all the agents since //
		 * the sniffer is shutting down try { if (request != null)
		 * FIPAService.doFipaRequestClient(this, request); } catch
		 * (jade.domain.FIPAException e) { // When the AMS replies the tool
		 * notifier is no longer registered. // But we don't care as we are
		 * exiting e.printStackTrace(); }
		 */

		// Now we unsubscribe from the rma list
		send(getCancel());
	}

	// //////////////////////////////////////////////////////////////////////
	/**
	 * Code copied from Sniffer agent of JADE platform.
	 * 
	 */

	private void sniffMsg(List agents, boolean onFlag) {
		ACLMessage request = getSniffMsg(agents, onFlag);
		if (request != null)
			addBehaviour(new AMSMonitoringInitiator((onFlag ? "SniffAgentOn"
					: "SniffAgentOff"), request));

	}

	private ACLMessage getSniffMsg(List agents, boolean onFlag) {

		Iterator it = agents.iterator();

		if (onFlag) {
			SniffOn so = new SniffOn();
			so.setSniffer(getAID());
			boolean empty = true;
			while (it.hasNext()) {
				Agent a = (Agent) it.next();
				AID agentID = new AID();
				agentID.setName(a.agentName + '@' + getHap());
				if (!agentsUnderSniff.contains(a)) {
					agentsUnderSniff.add(a);
					so.addSniffedAgents(agentID);
					empty = false;
				}
			}
			if (!empty) {
				try {
					Action a = new Action();
					a.setActor(getAMS());
					a.setAction(so);

					ACLMessage requestMsg = getRequest();
					requestMsg.setOntology(JADEManagementOntology.NAME);
					getContentManager().fillContent(requestMsg, a);
					return requestMsg;
				} catch (Exception fe) {
					// fe.printStackTrace();
					logger.log(fe.getMessage());
				}
			}
		}

		else {
			SniffOff so = new SniffOff();
			so.setSniffer(getAID());
			boolean empty = true;
			while (it.hasNext()) {
				Agent a = (Agent) it.next();
				AID agentID = new AID();
				agentID.setName(a.agentName + '@' + getHap());
				if (agentsUnderSniff.contains(a)) {
					agentsUnderSniff.remove(a);
					so.addSniffedAgents(agentID);
					empty = false;
				}
			}
			if (!empty) {
				try {
					Action a = new Action();
					a.setActor(getAMS());
					a.setAction(so);

					ACLMessage requestMsg = getRequest();
					requestMsg.setOntology(JADEManagementOntology.NAME);
					getContentManager().fillContent(requestMsg, a);
					requestMsg.setReplyWith(getName() + (new Date().getTime()));
					return requestMsg;
				} catch (Exception fe) {
					// fe.printStackTrace();
					logger.log(fe.getMessage());
				}
			}
		}
		return null;
	}

	/**
	 * Check if an agent is in the monitored list or not
	 * 
	 * @param agentLocalName
	 * @return
	 */
	private boolean monitoredListContains(String agentLocalName) {

		String agentID = agentLocalName;
		int atPos = agentLocalName.lastIndexOf('@');
		if (atPos == -1) {
			agentID = agentLocalName + "@" + getHap();
		}

		return monitoredAgents.contains(agentID);
	}
	
	private boolean isSystemAgent(String agentName){
		if (agentName == null) return false;
		
		if (agentName.startsWith("ams")
			|| agentName.startsWith("df")
			|| agentName.startsWith("rma")
			|| agentName.startsWith("RemoteMonitorAgent")
			|| agentName.startsWith("RemoteExecutorAgent"))
			return true;
		
		return false;
	}

}
