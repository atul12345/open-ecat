/**
 * <copyright>
 *
 * eCAT - Tool for Continuous Testing Agent for the JADE/Eclipse Platform
 * Copyright (C) ITC-IRST, Trento, Italy
 * Authors: Duy Cu Nguyen
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 * The electronic copy of the license can be found here:
 * http://sra.itc.it/tools/taom/freesoftware/gpl.txt
 *
 * The contact information:
 * e-mail: cunduy@itc.it
 * site: http://sra.itc.it
 *
 * </copyright>
 */

package it.itc.sra.ecat.ecatplugin.generatewizards;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import it.itc.sra.ecat.ECATPlugIn;
import it.itc.sra.ecat.core.ECATExeption;
import it.itc.sra.ecat.testsuiteman.protocollist.ProtocolList;
import it.itc.sra.ecat.testsuiteman.protocollist.ProtocolType;
import it.itc.sra.ecat.util.GlobalConstants;
import it.itc.sra.ecat.util.JAXBUtil;

import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.viewers.CellEditor;
import org.eclipse.jface.viewers.CheckboxCellEditor;
import org.eclipse.jface.viewers.ICellModifier;
import org.eclipse.jface.viewers.IStructuredContentProvider;
import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TextCellEditor;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;

public class ScenariosPage extends WizardPage{

	private String scenarioTemplatesPath;
	private List<ProtocolType> scenarios;
	private Map<ProtocolType, Boolean>selectedScenarios;
	
	private TableViewer viewer;
	private String columnNames[] = {"Selected","Name","Path"};
	
	protected ScenariosPage(String pageName) {
		super(pageName);
		
		selectedScenarios = new HashMap<ProtocolType, Boolean>();
	}
	
	
	public ScenariosPage(String pageName, String title, ImageDescriptor titleImage) {
		super(pageName, title, titleImage);
		selectedScenarios = new HashMap<ProtocolType, Boolean>();
	}


	public void createControl(Composite parent) {
		Composite composite = new Composite(parent, SWT.NONE);
		GridLayout layout = new GridLayout(1, true);
		composite.setLayout(layout);
		
		//Label label = new Label(composite, SWT.NONE);
		//label.setText("Select test scenarios:");
		
		GridData layoutData = new GridData(GridData.FILL_BOTH);
		layoutData.heightHint = 200;
		//layoutData.horizontalSpan = 3;
		
		//label.setLayoutData(layoutData);
		
		
		// Table that lists all the possible scenarios
		
		Table scenarioTable = new Table(composite, SWT.BORDER);
		scenarioTable.setLayoutData(layoutData);
		
		TableColumn column = new TableColumn(scenarioTable, SWT.LEFT);
		column.setText("Selected");
		column.setWidth(100);
		
		column = new TableColumn(scenarioTable, SWT.LEFT);
		column.setText("Scenario Name");
		column.setWidth(200);
		
		column = new TableColumn(scenarioTable, SWT.LEFT);
		column.setText("Path");
		column.setWidth(100);
		
		viewer = new TableViewer(scenarioTable);
		viewer.setUseHashlookup(true);
		viewer.setColumnProperties(columnNames);
		
		CellEditor editors[] = new CellEditor[columnNames.length];
		editors[0] = new CheckboxCellEditor(scenarioTable);
		
		TextCellEditor textEditor = new TextCellEditor(scenarioTable);
		((Text) textEditor.getControl()).setTextLimit(60);
		editors[1] = textEditor;

		textEditor = new TextCellEditor(scenarioTable);
		((Text) textEditor.getControl()).setTextLimit(200);
		editors[2] = textEditor;
		
		viewer.setCellEditors(editors);
		viewer.setCellModifier(new TableCellModifier());
		
		viewer.getTable().setHeaderVisible(true);
		viewer.setContentProvider(new TableContentProvider());
		viewer.setLabelProvider(new TableLabelProvider());
		
		update();
		
		setControl(composite);
	}
	
	/**
	 * Refresh the wizard page
	 *
	 */
	public void update(){
		if (scenarioTemplatesPath != null){
			init(scenarioTemplatesPath);
			viewer.setInput(scenarios);
			viewer.refresh();
		}
	}
	
	/**
	 * Table content
	 * @author cunduy
	 *
	 */
	public class TableContentProvider implements IStructuredContentProvider {

		public Object[] getElements(Object inputElement) {
			if (scenarios != null)
				return scenarios.toArray();
			return new Object[0];
		}

		public void dispose() {
		}

		public void inputChanged(Viewer viewer, Object oldInput, Object newInput) {
		}
		
	}
	
	
	/**
	 * Display 
	 * @author cunduy
	 *
	 */
	public class TableLabelProvider extends LabelProvider implements ITableLabelProvider {

		
		public Image getColumnImage(Object element, int columnIndex) {
			if (columnIndex == 0){
				if (selectedScenarios.get(element).booleanValue())
					return ECATPlugIn.getDefault().getImage(
						ECATPlugIn.IMG_CHECKED);
				else 
					return ECATPlugIn.getDefault().getImage(
							ECATPlugIn.IMG_UNCHECKED);
			}
			return null;
		}

		public String getColumnText(Object element, int columnIndex) {
			if (columnIndex == 1 && element instanceof ProtocolType) {
				return ((ProtocolType)element).getName();
			} else if (columnIndex == 2 && element instanceof ProtocolType){
				return ((ProtocolType)element).getPath();
			}
			return "";
		}
	}
	
	/**
	 * Modify cell
	 * @author cunduy
	 *
	 */
	public class TableCellModifier implements ICellModifier{

		public boolean canModify(Object element, String property) {
			if (property.equals("Selected"))
				return true;
			return false;
		}

		public Object getValue(Object element, String property) {
			
			if (property.equals("Selected")){
				return selectedScenarios.get(element).booleanValue();
			} else if (property.equals("Name")){
				return ((ProtocolType)element).getName(); 
			} else {
				return ((ProtocolType)element).getPath();
			}
		}

		public void modify(Object element, String property, Object value) {
			if (property.equals("Selected")){
				TableItem item = (TableItem) element;
				ProtocolType proto = (ProtocolType)item.getData();
				selectedScenarios.put(proto, (Boolean) value);
				viewer.refresh();
			}
		}
	}

	/**
	 * Init the scenario list
	 * @param protocolPath
	 */
	public void init(String protocolPath) {
		scenarios = new ArrayList<ProtocolType>();
		
		// Mashall xml file to object
		try {
			ProtocolList protocolList = (ProtocolList) JAXBUtil
					.loadJAXBFromFile(GlobalConstants.PROTOCOLLIST_PKG, protocolPath);
			// Fetch protocol list
			List l = protocolList.getProtocol();
			Iterator i = l.iterator();
			while (i.hasNext()) {
				ProtocolType proto = (ProtocolType) i.next();
				scenarios.add(proto);
				selectedScenarios.put(proto, false);
			}
			setMessage(null);
		} catch (ECATExeption e) {
			//e.printStackTrace(logger.getOut());
			setMessage("Wrong protocol list file, please go back and reselect", WizardPage.ERROR);
		}
	}


	public void setPath(String path) {
		this.scenarioTemplatesPath = path;
	}

	public Map<ProtocolType, Boolean> getSelectedScenarios() {
		return selectedScenarios;
	}
	
}
