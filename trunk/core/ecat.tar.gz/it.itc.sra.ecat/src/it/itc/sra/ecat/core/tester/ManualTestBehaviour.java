/**
 * <copyright>
 *
 * eCAT - Tool for Continuous Testing Agent for the JADE/Eclipse Platform
 * Copyright (C) ITC-IRST, Trento, Italy
 * Authors: Duy Cu Nguyen
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 * The electronic copy of the license can be found here:
 * http://sra.itc.it/tools/taom/freesoftware/gpl.txt
 *
 * The contact information:
 * e-mail: cunduy@itc.it
 * site: http://sra.itc.it
 *
 * </copyright>
 */

package it.itc.sra.ecat.core.tester;

import it.itc.sra.ecat.core.TestResultsModel;
import it.itc.sra.ecat.ecatplugin.views.ITestModelListener;
import it.itc.sra.ecat.testsuiteman.testconfig.NodeType;
import jade.core.Agent;
import jade.core.behaviours.Behaviour;
import jade.core.behaviours.OneShotBehaviour;
import jade.lang.acl.ACLMessage;

public class ManualTestBehaviour extends OneSessionTestBehaviour {
	
	TestResultsModel model = TestResultsModel.getInstance();
	
	public ManualTestBehaviour(Agent a, NodeType testNode) {
		super(a, testNode);
		init();
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 3005397922123871670L;

	
	public void init(){
		
		// Reimplement final state
		Behaviour b = new OneShotBehaviour(){
			
			/**
			 * 
			 */
			private static final long serialVersionUID = 0L;

			@Override
			public void action() {
				ACLMessage lastMessage = (ACLMessage) getDataStore().get(LAST_PROCESSED_MESSAGE) ;
				Object msg = null;
				if (lastMessage != null)
					msg = lastMessage.clone(); 

				model.updateStatus(testCase, testNode, ITestModelListener.STATE_FINAL , msg);
			}
			
		};
		registerHandleFinal(b);

		// Reimplement dum final state
		b = new OneShotBehaviour(){

			/**
			 * 
			 */
			private static final long serialVersionUID = 0L;

			@Override
			public void action() {
				ACLMessage lastMessage = (ACLMessage) getDataStore().get(LAST_PROCESSED_MESSAGE) ;
				Object msg = null;
				if (lastMessage != null)
					msg = lastMessage.clone(); 

				//logger.log(GeneralLogger.LEVEL_INFO, "test failed at state: " + getPrevious().getBehaviourName());
				if (currentAction != null){
					//logger.log(GeneralLogger.LEVEL_INFO, "at sequence: " + currentSequence.getID());
					model.updateStatus(testCase, testNode, ITestModelListener.STATE_DUM_FINAL , 
							msg, getPrevious().getBehaviourName(), currentAction.getID());
				} else {
					model.updateStatus(testCase, testNode, ITestModelListener.STATE_DUM_FINAL , msg);
				}
				//if (msg !=null){
				//	logger.log(GeneralLogger.LEVEL_INFO, "last proceeded message: " + msg.toString());
				//}
			}
			
		};
		registerHandleDumFinal(b);
		
	}
}
