/**
 * <copyright>
 *
 * eCAT - Tool for Continuous Testing Agent for the JADE/Eclipse Platform
 * Copyright (C) ITC-IRST, Trento, Italy
 * Authors: Duy Cu Nguyen
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 * The electronic copy of the license can be found here:
 * http://sra.itc.it/tools/taom/freesoftware/gpl.txt
 *
 * The contact information:
 * e-mail: cunduy@itc.it
 * site: http://sra.itc.it
 *
 * </copyright>
 */

package it.itc.sra.ecat.util;

import it.itc.sra.ecat.testsuiteman.testconfig.OntologyType;
import it.itc.sra.ecat.testsuiteman.testconfig.PreferedStrategyType;
import it.itc.sra.ecat.testsuiteman.testconfig.TestConfig;

public class Validator {
	public static String errorMessage;
	
	/**
	 * Validate test configuration
	 * @param tconfig
	 * @return
	 */
	public static boolean validate(TestConfig tconfig){
		
		// No node configuration
		if (tconfig.getDitributedNodeConfig() == null){
			errorMessage = "No testing node is specified!";
			return false;
		}
		
		if (tconfig.getDitributedNodeConfig().getNode() == null 
				|| tconfig.getDitributedNodeConfig().getNode().size() == 0){
			errorMessage = "No testing node is specified!";
			return false;
		}
			
		
		// no number of cycle specified 
		if (tconfig.getNumberCycle() <= 0){
			errorMessage = "Number of test cycle must be specified";
			return false;
		}
		
		// check specific data according to testing strategy
		if (tconfig.getPreferedStrategy() == null){
			errorMessage = "Testing method/strategy must be specified";
			return false;
		}
		
		PreferedStrategyType testMethod = tconfig.getPreferedStrategy();
		
		if (testMethod.equals(PreferedStrategyType.AUTO) ||
				testMethod.equals(PreferedStrategyType.WHITE_BOX)){
			errorMessage = "Test method Auto and White-box are currently not supported!";
			return false;
		}
		
		if (testMethod.equals(PreferedStrategyType.RANDOM)
				|| testMethod.equals(PreferedStrategyType.MUTATION)){
			if (tconfig.getDomainDataPath() == null ||
					tconfig.getAgentUnderTest() == null ||
					tconfig.getProtocolPath() == null){
				errorMessage = "Domain data, agent under test, or protocol path are missing!";
				return false;
			}
			
			if (tconfig.getMaxRandomTC() == null ||
					(tconfig.getMaxRandomTC() != null && tconfig.getMaxRandomTC() <= 0)){
				errorMessage = "Number of random test cases per cycle (MaxRandomTC) must be specified!";
				return false;
			}
			
		} else {
			if (tconfig.getTestSuiteList() == null ||
					(tconfig.getTestSuiteList() != null &&
							(tconfig.getTestSuiteList().getTestSuitePath() == null ||
									tconfig.getTestSuiteList().getTestSuitePath().size() == 0))){
				errorMessage = "List of initial test suites must be specified method!";
				return false;
			}
		}

		if (testMethod.equals(PreferedStrategyType.MUTATION) ||
				testMethod.equals(PreferedStrategyType.MUTATION_PLUS)){
			if (tconfig.getMaxMutationGen() == null || tconfig.getMaxMutationGen() <= 0){
				errorMessage = "Number of generation must be not null and greater than 0!";
				return false;
			}
			
			if (tconfig.getMaxMutationPsize() == null || tconfig.getMaxMutationPsize() <= 0){
				errorMessage = "The size of the polulation must be not null and greater than 0!";
				return false;
			}
			
			if (tconfig.getMutationProb() == null 
					|| tconfig.getMutationProb() <= 0 
					|| tconfig.getMutationProb() > 1){
				errorMessage = "The mutation probability must be not null and in between 0 and 1!";
				return false;
			}
		}
		
		if (testMethod.equals(PreferedStrategyType.ONTO_BASED)){
			// check ontology settings
			if (tconfig.getOntologySetting() == null){
				errorMessage = "Ontology setting must be specified!";
				return false;
			} else {
				OntologyType onto = tconfig.getOntologySetting();
				if (onto.getClasspath() == null
					 || onto.getCodec() == null 
					 || onto.getInputType() == null
					 || onto.getLanguage() == null
					 || onto.getOntologyName() == null
					 || onto.getOntologyPackage() == null
					 || onto.getProtegeOntologyPath() == null) {
					
					errorMessage = "Ontotogy setting is incomplete!";
					return false;
				}
					
			}
		} 
		
		return true;
	}
}
