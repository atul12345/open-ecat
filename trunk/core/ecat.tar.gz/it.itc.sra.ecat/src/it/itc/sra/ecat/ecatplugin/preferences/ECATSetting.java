package it.itc.sra.ecat.ecatplugin.preferences;

import it.itc.sra.ecat.ECATPlugIn;
import org.eclipse.jface.preference.*;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPreferencePage;

public class ECATSetting extends FieldEditorPreferencePage
    implements IWorkbenchPreferencePage
{

    public ECATSetting()
    {
        super(1);
        setPreferenceStore(ECATPlugIn.getDefault().getPreferenceStore());
        setDescription("eCAT Preferences");
    }

    public void createFieldEditors()
    {
        //addField(new DirectoryFieldEditor(PreferenceConstants.P_PATH, "&JADE Home Directory:", getFieldEditorParent()));
    	
    	addField(new BooleanFieldEditor(PreferenceConstants.P_RUN_SEPARATE_JADE, "Run eCAT in an independent JADE", getFieldEditorParent()));
        addField(new StringFieldEditor(PreferenceConstants.P_PORT, "JADE Runtime Port:", getFieldEditorParent()));
        addField(new StringFieldEditor(PreferenceConstants.P_HOST, "JADE Host:", getFieldEditorParent()));
        addField(new StringFieldEditor(PreferenceConstants.P_JADE_PARAM, "JADE custom parameters (if any):", getFieldEditorParent()));
        addField(new BooleanFieldEditor(PreferenceConstants.P_SHOW_GUI, "Show RMA GUI", getFieldEditorParent()));
        
        addField(new FileFieldEditor(PreferenceConstants.P_LOG, "Log path:", getFieldEditorParent()));
        
        addField(new BooleanFieldEditor(PreferenceConstants.P_ENABLE_MONITORING, 
        		"Enable monitoring (not applicable for Mutation method -- always anable)",
        		getFieldEditorParent()));
        
        addField(new IntegerFieldEditor(PreferenceConstants.P_MAX_MONITORING_LOG, "Length of monitoring trace to be displayed:", getFieldEditorParent()));
    }

    public void init(IWorkbench iworkbench)
    {
    }
}
