/**
 * <copyright>
 *
 * eCAT - Tool for Continuous Testing Agent for the JADE/Eclipse Platform
 * Copyright (C) ITC-IRST, Trento, Italy
 * Authors: Duy Cu Nguyen
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 * The electronic copy of the license can be found here:
 * http://sra.itc.it/tools/taom/freesoftware/gpl.txt
 *
 * The contact information:
 * e-mail: cunduy@itc.it
 * site: http://sra.itc.it
 *
 * </copyright>
 */

package it.itc.sra.ecat.core.remote;

import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.StringTokenizer;

import jade.content.onto.basic.Action;
import jade.core.AID;
import jade.core.AgentContainer;
import jade.core.ContainerID;
import jade.core.ServiceException;
import jade.core.behaviours.SenderBehaviour;
import jade.core.behaviours.SequentialBehaviour;
import jade.domain.FIPANames;
import jade.domain.FIPAAgentManagement.FailureException;
import jade.domain.FIPAAgentManagement.NotUnderstoodException;
import jade.domain.FIPAAgentManagement.RefuseException;
import jade.domain.JADEAgentManagement.CreateAgent;
import jade.domain.JADEAgentManagement.JADEManagementOntology;
import jade.domain.JADEAgentManagement.KillAgent;
import jade.domain.introspection.BornAgent;
import jade.domain.introspection.DeadAgent;
import jade.domain.introspection.Event;
import jade.domain.introspection.IntrospectionVocabulary;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import jade.proto.AchieveREResponder;
import jade.proto.SimpleAchieveREInitiator;
import jade.tools.ToolAgent;



public class RemoteExecutorAgent extends ToolAgent {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1131658735614569355L;

	private String preloadAgents; //= "BibExchangerAgent:it.itc.sra.bibfinder.core.BibExchangerAgent;BibExtractorAgent:it.itc.sra.bibfinder.core.BibExtractorAgent;BibFinderAgent:it.itc.sra.bibfinder.core.BibFinderAgent";
	
	private static final String COMMAND_RESETS = "RESETS";
	
	private Hashtable<String , String> agentList;
	private Hashtable<String, String> deadList;
	
	private class CentralRequestListener extends AchieveREResponder{
		private String command; 
		
		public CentralRequestListener() {
			super(RemoteExecutorAgent.this, MessageTemplate.and(MessageTemplate.MatchPerformative(ACLMessage.REQUEST)
					,MessageTemplate.MatchProtocol(FIPANames.InteractionProtocol.FIPA_REQUEST)));
		}

		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		@Override
		protected ACLMessage handleRequest(ACLMessage request) throws NotUnderstoodException, RefuseException {
			
			command = request.getContent();
			ACLMessage response = request.createReply();
			
			if (command != null && command.equals(COMMAND_RESETS)){
				response.setPerformative(ACLMessage.AGREE);
				response.setContent("Remote executor agrees");
			} else {
				response.setPerformative(ACLMessage.REFUSE);
				response.setContent("Invalid command");
			}
			
//			Action action;
//			try {
//				action = (Action)manager.extractContent(request);
//				Concept c = action.getAction();
//				if (c instanceof Reset){
//					response.setPerformative(ACLMessage.AGREE);
//					response.setContent("Correct request, pls hold-on for reply!");
//				} else {
//					response.setPerformative(ACLMessage.REFUSE);
//					response.setContent("I dont understand your query!");
//				}
//			} catch (UngroundedException e) {
//				response.setPerformative(ACLMessage.REFUSE);
//				response.setContent("Error occured: " + e.getMessage());
//				e.printStackTrace();
//			} catch (CodecException e) {
//				response.setPerformative(ACLMessage.REFUSE);
//				response.setContent("Error occured: " + e.getMessage());
//				e.printStackTrace();
//			} catch (OntologyException e) {
//				response.setPerformative(ACLMessage.REFUSE);
//				response.setContent("Error occured: " + e.getMessage());
//				e.printStackTrace();
//			}
			return response;			
		}

		@Override
		protected ACLMessage prepareResultNotification(ACLMessage request, ACLMessage response) throws FailureException {
			
			// Perform stop and start all the mutants
			
			/*
			Iterator iter = agentList.keySet().iterator();
			while (iter.hasNext()){
				String name = (String)iter.next();
				// Kill agent
				killAgent(new AID(name + "@" + getHap(), AID.ISLOCALNAME));
			}
			*/

			Iterator<String> iter = deadList.keySet().iterator();
			String resetList = "Agent(s) reset: ";
			while (iter.hasNext()){
				String name = (String)iter.next();
				String agentClass = agentList.get(name);
				String containerName = deadList.get(name);
				
				//System.out.println("Reset agent: " + name);
				resetList += name + ",";
				// Create agent
				createAgent(name, agentClass, containerName, "");
				
			}
			
			ACLMessage result = request.createReply();
			result.setPerformative(ACLMessage.INFORM);
			result.setContent("Reset Done!\n" + resetList);
			
			return result;
		}
		
		
		
	}
	
	/**
	 * Subscription behaviour
	 * @author cunduy
	 *
	 */
	private class AMSEventListener extends AMSListenerBehaviour {

		/**
		 * 
		 */
		private static final long serialVersionUID = 5244496442332177569L;

		@Override
		protected void installHandlers(Map handlersTable) {
			handlersTable.put(IntrospectionVocabulary.BORNAGENT,
					new EventHandler() {
						public void handle(final Event ev) {
							final BornAgent ba = (BornAgent) ev;
							final ContainerID cid = ba.getWhere();
							final String container = cid.getName();
							final AID agent = ba.getAgent();
							
							if (agentList.containsKey(agent.getLocalName())){
								if (deadList.containsKey(agent.getLocalName()))
									deadList.remove(agent.getLocalName());
							}
							
						}
					});

			handlersTable.put(IntrospectionVocabulary.DEADAGENT,
					new EventHandler() {
						public void handle(Event ev) {
							DeadAgent da = (DeadAgent) ev;
							ContainerID cid = da.getWhere();
							String container = cid.getName();
							AID agent = da.getAgent();

							System.out.println("Agent: " + agent.getLocalName() + " died");
							
							if (agentList.containsKey(agent.getLocalName())){
								//System.out.println("Add dead agent: " + agent.getLocalName() + " to the list");
								deadList.put(agent.getLocalName(), container);
							}
						}
					});
		}

	}
	
	/**
	 * Send request to local ams
	 * @author cunduy
	 *
	 */
	private class AMSActionInitiator extends SimpleAchieveREInitiator{

		/**
		 * 
		 */
		private static final long serialVersionUID = 6196292560519282021L;
		public AMSActionInitiator(String action, ACLMessage arg1) {
			super(RemoteExecutorAgent.this, arg1);
		}

		@Override
		protected void handleAgree(ACLMessage arg0) {
			//System.out.println(arg0.toString());
		}

		@Override
		protected void handleFailure(ACLMessage arg0) {
			System.out.println(arg0.toString());
		}

		@Override
		protected void handleInform(ACLMessage arg0) {
			//System.out.println(arg0.toString());
		}

		@Override
		protected void handleNotUnderstood(ACLMessage arg0) {
			System.out.println(arg0.toString());
		}

		@Override
		protected void handleRefuse(ACLMessage arg0) {
			System.out.println(arg0.toString());
		}
		
	}

	@Override
	protected void toolSetup() {
		
		agentList = new Hashtable<String, String>();
		deadList = new Hashtable<String, String>();
		
		Object[] args = getArguments();
		if (args != null){
			preloadAgents = (String)args[0];
			parsePreloadDescription();
		}
		
		
		SequentialBehaviour subscribe2AMS = new SequentialBehaviour();
		// Send 'subscribe' message to the AMS
		subscribe2AMS.addSubBehaviour(new SenderBehaviour(this, getSubscribe()));
		
		// Handle incoming messages from the AMS
		subscribe2AMS.addSubBehaviour(new AMSEventListener());
		
		//	Schedule Behaviours for execution
		addBehaviour(subscribe2AMS);
		
		addBehaviour(new CentralRequestListener());
	}

	@Override
	protected void toolTakeDown() {
		super.toolTakeDown();
	}
	
	private void createAgent(String agentName, String agentClass, String containerName, String ownerName){
		
		CreateAgent ca = new CreateAgent();
		
		if(containerName == null || containerName.equals(""))
			containerName = AgentContainer.MAIN_CONTAINER_NAME;
		
		// fill the create action with the intended agent owner
		jade.security.JADEPrincipal intendedOwner = null;
		jade.security.Credentials initialCredentials = null;
		
		try {
			jade.security.JADEPrincipal rmaOwner = null;
			jade.security.Credentials rmaCredentials = null;
			jade.security.CredentialsHelper ch = (jade.security.CredentialsHelper) getHelper("jade.core.security.Security");
			// get RMA's owner
			if (ch!=null) {  rmaCredentials = ch.getCredentials();    }
			if (rmaCredentials!=null) {  rmaOwner = rmaCredentials.getOwner();    }
			intendedOwner = rmaOwner;
		}
		catch (ServiceException se) { // Security service not present. Owner is null. 
			intendedOwner=null;
			initialCredentials=null;
		}
		
		
		ca.setOwner( intendedOwner );
		ca.setInitialCredentials( initialCredentials );
		
		ca.setAgentName(agentName);
		ca.setClassName(agentClass);
		ca.setContainer(new ContainerID(containerName, null));
		
		try {
			Action a = new Action();
			a.setActor(getAMS());
			a.setAction(ca);
			
			ACLMessage requestMsg = getRequest();
			requestMsg.setOntology(JADEManagementOntology.NAME);
			getContentManager().fillContent(requestMsg, a);
			addBehaviour(new AMSActionInitiator("CreateAgent", requestMsg));
		}
		catch(Exception fe) {
			fe.printStackTrace();
		}
	}
	
	public void killAgent(AID name) {
		
		KillAgent ka = new KillAgent();
		
		ka.setAgent(name);
		
		try {
			Action a = new Action();
			a.setActor(getAMS());
			a.setAction(ka);
			
			ACLMessage requestMsg = getRequest();
			requestMsg.setOntology(JADEManagementOntology.NAME);
			getContentManager().fillContent(requestMsg, a);
			addBehaviour(new AMSActionInitiator("KillAgent", requestMsg));
		}
		catch(Exception fe) {
			fe.printStackTrace();
		}
		
	}
	
	private void parsePreloadDescription() {
		
		StringTokenizer parser = new StringTokenizer(preloadAgents, ";");
		while (parser.hasMoreElements()) {
			String agentInfo = parser.nextToken();
			StringTokenizer st = new StringTokenizer(agentInfo, ":");
			String name = st.nextToken();
			String agentClass = st.nextToken();
			
			agentList.put(name, agentClass);
		}
	}
	
	/*
	private Boolean preloadContains(String agentLocalName) {
		
		StringTokenizer parser = new StringTokenizer(PRELOAD_AGENTS, ";");
		while (parser.hasMoreElements()) {
			String agentID = parser.nextToken();
			int atPos = agentID.lastIndexOf('@');
			if (atPos == -1) {
				if (agentID.equals(agentLocalName))
					return true;
			} else {
				if (agentID.substring(0, atPos).equals(agentLocalName)) // trip the hap
					return true;
			}
		}
		return false;
	}*/
	
}
