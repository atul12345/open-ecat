/**
 * <copyright>
 *
 * eCAT - Tool for Continuous Testing Agent for the JADE/Eclipse Platform
 * Copyright (C) ITC-IRST, Trento, Italy
 * Authors: Duy Cu Nguyen
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 * The electronic copy of the license can be found here:
 * http://sra.itc.it/tools/taom/freesoftware/gpl.txt
 *
 * The contact information:
 * e-mail: cunduy@itc.it
 * site: http://sra.itc.it
 *
 * </copyright>
 */

package it.itc.sra.ecat.core.monitor;

import it.itc.sra.ecat.ECATPlugIn;
import it.itc.sra.ecat.core.ECATExeption;
import it.itc.sra.ecat.core.MonitoringModel;
import it.itc.sra.ecat.core.Synchronizer;
import it.itc.sra.ecat.core.monitor.onto.MonitoringOntology;
import it.itc.sra.ecat.core.monitor.onto.RequestLogs;
import it.itc.sra.ecat.core.monitor.onto.RequestMonitorTrace;
import it.itc.sra.ecat.core.monitor.onto.Reset;
import it.itc.sra.ecat.core.monitor.onto.StartSession;
import it.itc.sra.ecat.core.monitor.onto.UpdateLogs;
import it.itc.sra.ecat.core.monitor.onto.UpdateMonitorTrace;
import it.itc.sra.ecat.monitordata.SessionType;
import it.itc.sra.ecat.testsuiteman.testconfig.NodeType;
import it.itc.sra.ecat.testsuiteman.testconfig.TestConfig;
import it.itc.sra.ecat.util.CommonUtil;
import it.itc.sra.ecat.util.GlobalConstants;
import it.itc.sra.ecat.util.JAXBUtil;
import it.itc.sra.ecat.util.MonitorLogger;

import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import javax.xml.bind.JAXBElement;

import jade.content.ContentElement;
import jade.content.ContentManager;
import jade.content.lang.Codec;
import jade.content.lang.Codec.CodecException;
import jade.content.lang.sl.SLCodec;
import jade.content.onto.Ontology;
import jade.content.onto.OntologyException;
import jade.content.onto.UngroundedException;
import jade.content.onto.basic.Action;
import jade.content.onto.basic.Done;
import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.TickerBehaviour;
import jade.domain.FIPANames;
import jade.lang.acl.ACLMessage;
import jade.proto.AchieveREInitiator;

public class CentralMonitorAgent extends Agent implements IMonitorAgent {

	private MonitorLogger logger = MonitorLogger.getInstance();
	private static final long REFRESH_INTERVAL = 5 * 1000; // 2 seconds

	private static final String RESET_CONTENT = "RESET";

	// We handle contents
	private ContentManager manager = (ContentManager) getContentManager();
	// This agent speaks the SL language
	private Codec codec = new SLCodec();
	private Ontology ontology = MonitoringOntology.getInstance();

	private static final int STATUS_STOP = 0;
	private static final int STATUS_RESTART = 1;
	private static final int STATUS_READY = 2;
	private static final int STATUS_STOPPING = 3;

	private ControlRemoteMonitoringAgent controlRemoteAgentLogBehavior = null;
	
	// private ControlRemoteMonitoringAgent controlRemoteAgentStartupBehavior =
	// null;

	private ACLMessage logsRequest;
	private ACLMessage reportRequest;
	private ACLMessage startSessionRequest;

	private TestConfig testConfig;
	private int agentStatus = STATUS_STOP;

	private MonitoringModel model = MonitoringModel.getInstance();
	private String currentSessionID = ""; 
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void setup() {

		manager.registerLanguage(codec, FIPANames.ContentLanguage.FIPA_SL);
		manager.registerOntology(ontology);

		logsRequest = new ACLMessage(ACLMessage.REQUEST);
		logsRequest.setProtocol(FIPANames.InteractionProtocol.FIPA_REQUEST);
		logsRequest.setSender(getAID());
		logsRequest.setLanguage(codec.getName());
		logsRequest.setOntology(ontology.getName());

		reportRequest = new ACLMessage(ACLMessage.REQUEST);
		reportRequest.setProtocol(FIPANames.InteractionProtocol.FIPA_REQUEST);
		reportRequest.setSender(getAID());
		reportRequest.setLanguage(codec.getName());
		reportRequest.setOntology(ontology.getName());
		
		startSessionRequest = new ACLMessage(ACLMessage.REQUEST);
		startSessionRequest.setProtocol(FIPANames.InteractionProtocol.FIPA_REQUEST);
		startSessionRequest.setSender(getAID());
		startSessionRequest.setLanguage(codec.getName());
		startSessionRequest.setOntology(ontology.getName());

		addBehaviour(new MonitoringBehavior());
		// Set the reference from the plugin to this agent
		ECATPlugIn.getDefault().setMonitorAgent(this);
	}

	@Override
	protected void takeDown() {
		super.takeDown();
	}

	/**
	 * Fetch receivers each time user launches a test
	 */
	private void prepareReceiver() {
		// Set receivers of the message, taken from the test configuration
		if (fetchReceivers(logsRequest, true) 
				&& fetchReceivers(reportRequest, true)
				&& fetchReceivers(startSessionRequest, true)) {
			agentStatus = STATUS_READY;
			// logger.log("Central monitoring agent READY!");
		}
	}

	/**
	 * Get remote log regularly 
	 * @author cunduy
	 *
	 */
	private class MonitoringBehavior extends TickerBehaviour {

		public MonitoringBehavior() {
			super(CentralMonitorAgent.this, REFRESH_INTERVAL);
		}

		/**
		 * 
		 */
		private static final long serialVersionUID = 2405948836121947703L;

		@Override
		protected void onTick() {

			if (agentStatus == STATUS_STOP) {
				return; // Do nothing
			}

			// Get Logs from remote monitoring agent
			logsRequest.setConversationId(CommonUtil.generateId("LOGS"));

			RequestLogs requestLog = new RequestLogs();
			requestLog.setSessionID("");

			Action action = new Action(getAID(), requestLog);
			try {
				manager.fillContent(logsRequest, action);
			} catch (CodecException e) {
				e.printStackTrace(logger.getOut());
			} catch (OntologyException e) {
				e.printStackTrace(logger.getOut());
			}

			if (controlRemoteAgentLogBehavior == null) {
				// logger.log("Create new logs behavior");
				controlRemoteAgentLogBehavior = new ControlRemoteMonitoringAgent(logsRequest, null);
				addBehaviour(controlRemoteAgentLogBehavior);
			} else if (controlRemoteAgentLogBehavior.isDone()) {
				// logger.log("Reset logs behavior");
				controlRemoteAgentLogBehavior.reset(logsRequest);
				addBehaviour(controlRemoteAgentLogBehavior);
			}

			if (agentStatus == STATUS_STOPPING) {
				// If external call this agent to stop, it performs the last
				// tick and then stop
				agentStatus = STATUS_STOP;
			}
		}
	}

	/**
	 * Protocol used to communicate with remote monitoring agent
	 * 
	 * @author cunduy
	 * 
	 */
	private class ControlRemoteMonitoringAgent extends AchieveREInitiator {

		private boolean done = false;
		private Synchronizer threadSyn;
		
		ACLMessage request;
		/**
		 * 
		 */
		private static final long serialVersionUID = 1625788541600157419L;

		public ControlRemoteMonitoringAgent(ACLMessage request, Synchronizer sync) {
			super(CentralMonitorAgent.this, request);
			this.request = request;
			this.threadSyn = sync;
		}

		@Override
		protected void handleAgree(ACLMessage agree) {
			// the remotemonitoringagent agrees
			// logger.log(agree.toString());
		}

		@Override
		protected void handleAllResultNotifications(Vector resultNotifications) {
			// Handle all results notifications from all remote monitoring
			// agents
			if (resultNotifications != null) {
				Iterator iter = resultNotifications.iterator();
				while (iter.hasNext()) {
					ACLMessage inform = (ACLMessage) iter.next();

					try {
						ContentElement cl = manager.extractContent(inform);
						RemoteMonitoringLogs remoteLog = model.getRemoteLogger(inform.getSender().getName());

						if (remoteLog == null)
							logger.log(inform.toString());
						else {
							if (cl instanceof Action) {
								Action a = (Action) cl;
								if (a.getAction() instanceof UpdateLogs) {
									// Log
									UpdateLogs remoteLogs = (UpdateLogs) a.getAction();
									if (remoteLogs.getLogs() != null && !remoteLogs.getLogs().equals(""))
										remoteLog.log(remoteLogs.getLogs());
								} else if (a.getAction() instanceof UpdateMonitorTrace) {
									// Monitoring report
									UpdateMonitorTrace informMonitor = (UpdateMonitorTrace) a.getAction();
									if (informMonitor.getSessionTrace() != null){
										String xmlTrace = informMonitor.getSessionTrace();
										SessionType sessionTrace;
										try {
											JAXBElement<SessionType> tmp = (JAXBElement<SessionType>) JAXBUtil.loadJAXBFromString(GlobalConstants.MONITORDATA_PKG, xmlTrace); 
											sessionTrace = tmp.getValue(); 
											remoteLog.monitor(sessionTrace);
										} catch (ECATExeption e) {
											//e.printStackTrace(logger.getOut());
											logger.log(inform.getContent());
										}
										
									}
								}
							}
						}

						if (cl instanceof Done) {
							Done d = (Done) cl;
							Action a = (Action) d.getAction();
							if (a.getAction() instanceof Reset) {
								logger.log("Remote agent: " + inform.getSender().getName() + " reset!");
							} else if (a.getAction() instanceof StartSession) {
								//logger.log("Remote agent: " + inform.getSender().getName()
								//				+ " New session is created successfully!");
							} else 
								logger.log("Remote agent: " + inform.getSender().getName()
										+ " initiated successfully!");
						}
					} catch (UngroundedException e) {
						e.printStackTrace(logger.getOut());
					} catch (CodecException e) {
						e.printStackTrace(logger.getOut());
					} catch (OntologyException e) {
						e.printStackTrace(logger.getOut());
					}

				}
			}
			// Notify threads that is waiting
			if (threadSyn != null){
				threadSyn.Started();
			}
			done = true;
		}

		@Override
		protected void handleInform(ACLMessage inform) {
			// the remotemonitoringagent informs the results
			// if (inform.getContent() != null &&
			// !inform.getContent().equals("")){
			// logger.log(inform.toString());
			// }
		}

		@Override
		protected void handleRefuse(ACLMessage refuse) {
			// the remotemonitoringagent refuses
			logger.log(refuse.toString());
			done = false;
		}

		@Override
		protected void handleFailure(ACLMessage failure) {
			super.handleFailure(failure);
			logger.log("Unknown failure");
			done = false;
		}

		@Override
		public int onEnd() {
			// logger.log("Removing the ControlRemoteMonitoringAgent behavior");
			done = true;
			// Notify threads that is waiting
			if (threadSyn != null){
				threadSyn.Started();
			}
			return super.onEnd();
		}

		public boolean isDone() {
			return done;
		}

		@Override
		public void reset(ACLMessage msg) {
			done = false;
			super.reset(msg);
		}

	}

	/**
	 * Fetch receivers from test configuration to a message
	 * 
	 * @param msg
	 */
	protected boolean fetchReceivers(ACLMessage msg, boolean isMonitorAgent) {
		if (testConfig != null) {
			if (testConfig.getDitributedNodeConfig() != null) {
				List<NodeType> nodes = testConfig.getDitributedNodeConfig().getNode();
				Iterator<NodeType> iter = nodes.iterator();
				while (iter.hasNext()) {
					NodeType node = (NodeType) iter.next();

					if (isMonitorAgent) {
						String remoteAgentID = CommonUtil.getRemoteMonitoringAgentGUID(node);
						AID receiver = new AID(remoteAgentID, AID.ISGUID);
						receiver.addAddresses(node.getNodeAddress());
						msg.addReceiver(receiver);
					} else {
						String remoteAgentID = CommonUtil.getRemoteExecutorAgentGUID(node);
						AID receiver = new AID(remoteAgentID, AID.ISGUID);
						receiver.addAddresses(node.getNodeAddress());
						msg.addReceiver(receiver);
					}
				}
			}
			return true;
		} else {
			return false;
		}
	}

	// //////////////////////////////////////////////////////////////////////////
	// Plugin interaction implementation

	
	public void startNewSession(String sessionID, String taID, String tsID, String tcID, Synchronizer syn){
		// Update local variable
		currentSessionID = sessionID;
		
		startSessionRequest.setConversationId(CommonUtil.generateId("NEWSEX"));
		
		StartSession startAction = new StartSession();
		startAction.setAid(taID);
		startAction.setSessionID(sessionID);
		startAction.setTestCase(tcID);
		startAction.setTestSuite(tsID);
		
		Action a = new Action();
		a.setAction(startAction);
		a.setActor(getAID());

		try {
			manager.fillContent(startSessionRequest, a);
		} catch (CodecException e) {
			e.printStackTrace(logger.getOut());
		} catch (OntologyException e) {
			e.printStackTrace(logger.getOut());
		}
		
		ControlRemoteMonitoringAgent newSexBehaviour 
				= new ControlRemoteMonitoringAgent(startSessionRequest, syn);
		addBehaviour(newSexBehaviour);
		
	}
	
	/**
	 * Get monitoring traces from remote moniroting agents
	 */
	public void getRemoteTraces(Synchronizer syn){
		reportRequest.setConversationId(CommonUtil.generateId("MOR"));
		
		RequestMonitorTrace request = new RequestMonitorTrace();
		request.setSessionID(currentSessionID);

		Action action = new Action();
		action.setAction(request);
		action.setActor(getAID());

		try {
			manager.fillContent(reportRequest, action);
		} catch (CodecException e) {
			e.printStackTrace(logger.getOut());
		} catch (OntologyException e) {
			e.printStackTrace(logger.getOut());
		}
		
		ControlRemoteMonitoringAgent controlRemoteAgentReportBehavior = new ControlRemoteMonitoringAgent(reportRequest, syn);
		addBehaviour(controlRemoteAgentReportBehavior);
	}
	
	
	/**
	 * Communicate with remote monitoring agents and ask them to reset the
	 * monitoring trace
	 * 
	 */
	public void resetRemotes(Synchronizer syn) {
		ACLMessage request = new ACLMessage(ACLMessage.REQUEST);
		request.setProtocol(FIPANames.InteractionProtocol.FIPA_REQUEST);
		request.setLanguage(codec.getName());
		request.setOntology(ontology.getName());
		request.setSender(getAID());
		request.setConversationId(CommonUtil.generateId("RESET"));

		if (fetchReceivers(request, true)) {

			Reset reset = new Reset();
			reset.setParam(RESET_CONTENT);

			Action a = new Action(getAID(), reset);
			try {
				manager.fillContent(request, a);
			} catch (CodecException e) {
				e.printStackTrace(logger.getOut());
			} catch (OntologyException e) {
				e.printStackTrace(logger.getOut());
			}

			request.setReplyWith(RESET_CONTENT);
			ControlRemoteMonitoringAgent controlRemoteAgentResetBehavior = new ControlRemoteMonitoringAgent(request, syn);
			addBehaviour(controlRemoteAgentResetBehavior);
		}
	}

	public void restartMonitoring(TestConfig tconfig) {
		this.testConfig = tconfig;
		agentStatus = STATUS_RESTART;

		prepareReceiver();
	}

	public void startMonitoring(TestConfig tconfig) {
		if (agentStatus == STATUS_STOP || agentStatus == STATUS_RESTART) {
			this.testConfig = tconfig;

			/*
			 * No need ACLMessage request = new ACLMessage(ACLMessage.REQUEST);
			 * request.setProtocol(FIPANames.InteractionProtocol.FIPA_REQUEST);
			 * request.setLanguage(codec.getName());
			 * request.setOntology(ontology.getName());
			 * request.setSender(getAID());
			 * request.setConversationId(CommonUtil.generateId("SETUP")); //
			 * Fetch receiver fetchReceivers(request);
			 * 
			 * Setup setup = new Setup(); if (tconfig.getDitributedNodeConfig() !=
			 * null) { // REMARK: use the configuration of the first node for
			 * all NodeType firstNode = (NodeType) tconfig
			 * .getDitributedNodeConfig().getNode().get(0);
			 * setup.setParam(firstNode.getMonitoredAgentList());
			 * 
			 * Action a = new Action(getAID(), setup); try {
			 * manager.fillContent(request, a); } catch (CodecException e) {
			 * e.printStackTrace(logger.getOut()); } catch (OntologyException e) {
			 * e.printStackTrace(logger.getOut()); }
			 * 
			 * if (controlRemoteAgentStartupBehavior == null) {
			 * controlRemoteAgentStartupBehavior = new
			 * ControlRemoteMonitoringAgent( request);
			 * addBehaviour(controlRemoteAgentStartupBehavior); } else if
			 * (controlRemoteAgentStartupBehavior.isDone()) {
			 * controlRemoteAgentStartupBehavior.reset(request);
			 * addBehaviour(controlRemoteAgentStartupBehavior); } }
			 */
			// agentStatus = STATUS_READY;
		}
	}

	public void stopMonitoring() {
		agentStatus = STATUS_STOP;
	}

	public void delayedStopMonitoring() {
		agentStatus = STATUS_STOPPING;
	}

}
