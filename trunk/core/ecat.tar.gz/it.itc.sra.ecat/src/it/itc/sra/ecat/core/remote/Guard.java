/**
 * <copyright>
 *
 * eCAT - Tool for Continuous Testing Agent for the JADE/Eclipse Platform
 * Copyright (C) ITC-IRST, Trento, Italy
 * Authors: Duy Cu Nguyen
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 * The electronic copy of the license can be found here:
 * http://sra.itc.it/tools/taom/freesoftware/gpl.txt
 *
 * The contact information:
 * e-mail: cunduy@itc.it
 * site: http://sra.itc.it
 *
 * </copyright>
 */

package it.itc.sra.ecat.core.remote;

import it.itc.sra.ecat.monitordata.EventType;
import it.itc.sra.ecat.monitordata.KindType;
import it.itc.sra.ecat.util.CommonUtil;

public class Guard {
	private RemoteLogger logger;
	private String currentSessionID;
	
	synchronized public void guard(Boolean expr){
		if (!expr){
			report("unspecified at " + expr.hashCode());
		}
	}
	
	synchronized public void guard(boolean expr){
		if (!expr){
			report("unspecified");
		}
	}

	synchronized public void guard(Boolean expr, String expressios){
		if (!expr){
			report(expressios);
		}
	}
	
	synchronized public void guard(boolean expr, String expression){
		if (!expr){
			report(expression);
		}
	}
	
	public void report(String expr){
		if (logger != null) {
			EventType event = new EventType();
			event.setKind(KindType.GUARD_VIOLATED);
			
			event.setWhen(CommonUtil.getCurrentDateTime());
			event.setWhere(expr);
			event.setContent("Guard violation occurs at: " + expr);
			logger.monitor(currentSessionID, event);
		} else {
			System.err.println("Guard violation occurs at: " + expr);	
		}
	}

	public void setLogger(RemoteLogger logger) {
		this.logger = logger;
	}

	public void setCurrentSessionID(String currentSessionID) {
		this.currentSessionID = currentSessionID;
	}

	
}
