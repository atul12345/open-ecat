/**
 * <copyright>
 *
 * eCAT - Tool for Continuous Testing Agent for the JADE/Eclipse Platform
 * Copyright (C) ITC-IRST, Trento, Italy
 * Authors: Duy Cu Nguyen
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 * The electronic copy of the license can be found here:
 * http://sra.itc.it/tools/taom/freesoftware/gpl.txt
 *
 * The contact information:
 * e-mail: cunduy@itc.it
 * site: http://sra.itc.it
 *
 * </copyright>
 */

package it.itc.sra.ecat.core.remote;


import it.itc.sra.ecat.core.ECATExeption;
import it.itc.sra.ecat.monitordata.EventType;
import it.itc.sra.ecat.monitordata.MonitoringTrace;
import it.itc.sra.ecat.monitordata.ObjectFactory;
import it.itc.sra.ecat.monitordata.SessionType;
import it.itc.sra.ecat.util.CommonUtil;
import it.itc.sra.ecat.util.GlobalConstants;
import it.itc.sra.ecat.util.JAXBUtil;

import java.io.StringWriter;
import java.util.List;
import javax.xml.bind.JAXBElement;

public class RemoteLogger {
	
    private StringWriter out = null;
    private MonitoringTrace monitorTrace = null;
    private SessionType currentSession = null;
    
	public RemoteLogger() {
		out = new StringWriter();
		monitorTrace = new MonitoringTrace();
	}

	/*
	static public RemoteLogger getInstance() {
		if (instance == null) {
			synchronized (RemoteLogger.class){
                if (instance == null){
                	instance = new RemoteLogger();
                }
            }
		}
		return instance;
	}*/
	
	public synchronized void log(String logMsg) {
		 String logStr = CommonUtil.getCurrentDateTime() + "\t\t" +  logMsg + "\n";
         if (this.out != null)
         {
             out.write(logStr);
             //out.flush();
         }
         else
             System.out.println(logStr);
	}
	
	
	public String getLogs(){
		return out.toString();
	}
	
	public void resetLog(){
		out.getBuffer().setLength(0);
	}
	
	public synchronized void startSession(String id, String testerID, String tsID, String tcID) {
		currentSession = new SessionType();
		currentSession.setId(id);
		currentSession.setTesterAID(testerID);
		currentSession.setTestSuiteID(tsID);
		currentSession.setTestCaseID(tcID);
		
		monitorTrace.getSession().add(currentSession);
	}
	
	public synchronized void monitor(String sessionID, EventType event) {
		if (currentSession != null && currentSession.getId().equals(sessionID))
			currentSession.getEvent().add(event);
		else {
			SessionType s = findSession(sessionID);
			if (s != null)
				s.getEvent().add(event);
		}
	}
	
	public String getSessionTrace(String sessionID){

		try {
			SessionType s = null;
			if (currentSession != null && currentSession.getId().equals(sessionID)){
				s = currentSession;
			} else {
				s = findSession(sessionID);
			}
			
			if (s != null) {
				ObjectFactory factory = new ObjectFactory();
				JAXBElement<SessionType> element = factory.createSession(s);
				String trace = JAXBUtil.transformJAXBToString(GlobalConstants.MONITORDATA_PKG
						, element);
				return trace;
			} else {
				System.out.println("Error with current session, can not find!");
			}
		} catch (ECATExeption e) {
			e.printStackTrace();
		}
		
		return "Remote monitoring agent experiences exception or not ready!";
	}
	
	/**
	 * 
	 * @param sessionID
	 */
	private void removeSession(String sessionID){
		List<SessionType> list = monitorTrace.getSession();
		int index = -1;
		for (SessionType s : list) {
			index += 1;
			if (s.getId().equals(sessionID)){
				break;
			}
		}
		
		if (index > -1 && index < list.size()){
			list.remove(index);
		}
	}

	
	public void resetMonitor(){
		monitorTrace.getSession().clear();
	}
	
	private SessionType findSession(String sessionID){
		List<SessionType> list = monitorTrace.getSession();
		for (SessionType s : list){
			if (s.getId().equals(sessionID))
				return s;
		}
		return null;
	}
}
