package it.itc.sra.ecat.core;

/**
 * Proxy Synchronizer
 * 
 * Object synchronizing the starting of the Plugin and the Tester Agent
 * 
 * @author <A HREF="mailto:Fabien.Gandon@cs.cmu.edu">Fabien GANDON</A>, <A
 *         href="http://www-2.cs.cmu.edu/~sadeh/Mobile%20Commerce%20Lab.htm">Mobile
 *         Lab.</A>, <A href="http://www.cmu.edu/">CMU</A>, 11th June 2003
 * @version 1.0
 * @since JDK1.4
 */

/**
 * Modified by D.C. Nguyen
 * ITC-irst
 */

public class Synchronizer
{
    private boolean Started = false;
    private static final long TIMEOUT = 2000; 

    /**
     * Wait for synchronization signal
     */
    public synchronized void waitOn()
    {
        try
        {
            while (!Started)
                wait(); //TIMEOUT
        }
        catch (InterruptedException l_InterruptedException)
        {
            l_InterruptedException.printStackTrace();
        }
    }

    /**
     * Send synchronization signal
     */
    public synchronized void Started()
    {
        Started = true;
        notifyAll();
    }

} // End of Synchronizer class
