package it.itc.sra.ecat.ecatplugin.actions;


import it.itc.sra.ecat.jadeplatform.JadePlatform;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.IWorkbenchWindowActionDelegate;

public class Shutdown implements IWorkbenchWindowActionDelegate {

	public void dispose() {

	}

	public void init(IWorkbenchWindow window) {

	}

	public void run(IAction action) {
		Job runeCAT = new Job("Shutting down eCAT"){

			@Override
			protected IStatus run(IProgressMonitor monitor) {
				ClassLoader cl = Thread.currentThread().getContextClassLoader();
				try {
					Thread.currentThread().setContextClassLoader(
							getClass().getClassLoader());
					// start JADE & eCAT
					JadePlatform jadePlatform = JadePlatform.getInstance(); 
					jadePlatform.shutdown();
				} catch (Exception e) {
					return new Status(IStatus.ERROR, "eCAT Plugin", 
							IStatus.ERROR, "eCAT started!", null);

				} finally {
					Thread.currentThread().setContextClassLoader(cl);
				}
				
				return new Status(IStatus.OK, "eCAT Plugin", 
						IStatus.OK, "eCAT started!", null);
			}
			
		};
		runeCAT.schedule();
		
		
	}

	public void selectionChanged(IAction action, ISelection selection) {
	}

}
