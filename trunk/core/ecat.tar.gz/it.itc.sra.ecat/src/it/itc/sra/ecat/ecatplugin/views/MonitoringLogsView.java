/**
 * <copyright>
 *
 * eCAT - Tool for Continuous Testing Agent for the JADE/Eclipse Platform
 * Copyright (C) ITC-IRST, Trento, Italy
 * Authors: Duy Cu Nguyen
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 * The electronic copy of the license can be found here:
 * http://sra.itc.it/tools/taom/freesoftware/gpl.txt
 *
 * The contact information:
 * e-mail: cunduy@itc.it
 * site: http://sra.itc.it
 *
 * </copyright>
 */

package it.itc.sra.ecat.ecatplugin.views;

import it.itc.sra.ecat.ECATPlugIn;

import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Layout;
import org.eclipse.ui.forms.ManagedForm;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.forms.widgets.ScrolledForm;
import org.eclipse.ui.part.ViewPart;


public class MonitoringLogsView extends ViewPart{

	MonitoringLogsBlock block;
	Composite parent;
	
	public MonitoringLogsView() {
		block = new MonitoringLogsBlock(this);
	}

	@Override
	public void createPartControl(Composite parent) {
		this.parent = parent;
		
		ManagedForm managedForm = new ManagedForm(parent); 
		final ScrolledForm form = managedForm.getForm();
		form.setText("ECAT Monitoring Logs");
		form.setBackgroundImage(ECATPlugIn.getDefault().getImage(ECATPlugIn.IMG_FORM_BG));
		
		if (ECATPlugIn.getDefault().isTesterReady())
			block.createContent(managedForm);
		else {
			// Show a message to inform user
			
			FormToolkit toolkit = managedForm.getToolkit();
			form.getBody().setLayout(new GridLayout());
			form.getBody().setLayoutData(new GridData(GridData.FILL_BOTH));
			toolkit.createLabel(form.getBody(), "Not yet started or is disable!");
		}
	}

	@Override
	public void setFocus() {
		
	}
}
