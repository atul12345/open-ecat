package it.itc.sra.ecat.testsuiteman.generation;

import java.util.List;

import it.itc.sra.ecat.testsuiteman.TestSuitesStorage;

public interface ISuitesGenerator {
	/**
	 * Generate test suites
	 * @return
	 */
	TestSuitesStorage generate();
	
	/**
	 * Generate test suites based on a previous test suites
	 * @param currentSuites
	 * @return
	 */
	TestSuitesStorage generate(TestSuitesStorage currentSuites);
	
	/**
	 * Generate a number of test case for a specific agent
	 * @param numberOfCases
	 * @param agentUnderTest
	 * @return
	 */
	List generate(int numberOfCases, String agentUnderTest); 
}