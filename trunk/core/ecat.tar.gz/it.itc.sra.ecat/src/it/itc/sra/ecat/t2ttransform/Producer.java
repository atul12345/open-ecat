/**
 * @author Mirko Morandini
 * Project JadexWork, file created on 12-giu-2006
 * ITC-irst, Universita' di Trento, 2006.
 */
package it.itc.sra.ecat.t2ttransform;

import it.itc.sra.taom4e.model.core.informalcore.*;


import java.util.List;

public class Producer {

	private static TroposNavigator tn;

	/**
	 * This tool produces a BDI-based implementation in Jadex from a Tropos Actor diagram modelled in TAOM.
	 * Run it in Eclipse in a configuration with the following arguments: "${resource_loc}" ${string_prompt}
	 * Select the Tropos Model, Run the configuration, input the actor name in the prompt. 
	 * @param args
	 */
	public static void main(String args[]) {
		String filename = "Tropos/BibFinderDesign.tropos";// take from args in final version
		String actorname = null;
		if (args==null || args.length==0) {
			System.out.println("No input arguments found. \n" +
					"Call me with [ModelFilename.tropos] [Actor_Name]\n" +
			"Now I take the default model and the first actor.");
		}else {
			if (args.length>0) {
				filename=args[0];
			}
			if (args.length>1) {
				actorname=args[1];
				actorname=NameUtility.adjustName(actorname);
			}
		}
		
		// load a TAOM-generated TROPOS Model from an XML file
		try {
			tn = new TroposNavigator(filename);
		} catch (TransformException e) {
			e.printStackTrace();
		}
		print("TROPOS file " + filename + " loaded.");

		List<Actor> actors = tn.getActors();
		tn.printContents("Available actors: ", actors);

		for (Actor a : actors) {
			print("-------------------------------------");
			tn.printContents("All hard goals for " + a.getName(), tn.getHardGoals(a));
			tn.printContents("Root     goals for " + a.getName(), tn.getRootGoals(a));
			tn.printContents("All soft goals for " + a.getName(), tn.getSoftGoals(a));
			tn.printContents("All   plans for " + a.getName(), tn.getPlans(a));
			tn.printContents("Means plans for " + a.getName(), tn.getAllMeansEndPlans(a));
		}
		print("**************************************************************");

		// for (Actor a : actors){
		
		Actor a=null;
		
		if (actorname!=null) {
			print("I try to take Actor " + actorname);
			a=tn.getActor(actorname);
		}
		if (a==null) {
			a = actors.get(0);
			print("I take Actor " + a.getName());
		}
		/*
		AgentDefinition ad = new AgentDefinition(a);
		// analyse all root goals
		for (HardGoal rootgoal : tn.getRootGoals(a)) {
			print("Now I analyse root goal: " + rootgoal.getName());

			Const type, request;
			if (tn.isDelegated(rootgoal)) {
				type = Const.ACHIEVE;
				request=Const.REQUEST;
			} else {
				// type=Const.MAINTAIN;
				type = Const.ACHIEVE;// For now only achieve is implemented, this has to be a
				request=Const.NONE;
				// maintain-goal!
			}
			GoalContainer gc = ad.createGoal(rootgoal, type);
			gc.setRequest(request);
			
			ad.addRootGoal(gc);
			addGoal(rootgoal, gc, ad);
		}
		// write the agent (xml+java plan bodies) to the output directory
		ad.writeAgent();
		*/
	}
//
//	private static void addGoal(Goal g, GoalContainer gc, AgentDefinition ad) {
//
//		addContributions(g, gc, ad);
//		
//		// uncomment if needed!
//		//if (tn.isDelegated(g))
//		//for testing purposes we allow requests for all goals
//			gc.setRequest(Const.REQUEST);
//		
//		if (tn.isBooleanDecAND(g)) {
//			List<Goal> declist = tn.getBooleanDec(g);
//			tn.printContents("All AND Decompositions for " + g.getName(), declist);
//			// sets decomposition flag and creates the AND-Plan (call only one time!)
//			gc.createDecomposition(Const.AND);
//			for (Goal dec : declist) {
//				boolean newgoal=!ad.containsGoal(dec);	
//				// addDecomp adds the new goal to container and goalbase and, if needed (OR, M-E)
//				// organizes dispatch goals
//				GoalContainer deccont = ad.createGoal(dec, Const.ACHIEVE);
//				gc.addDecomp(deccont);
//				if (newgoal)
//					addGoal(dec, deccont, ad);
//			}
//
//		} else if (tn.isBooleanDecOR(g)) {
//			List<Goal> declist = tn.getBooleanDec(g);
//			tn.printContents("All OR Decompositions for " + g.getName(), declist);
//			// sets decomposition flag and creates the Metagoal+plan (call only one time!)
//			gc.createDecomposition(Const.OR);
//			for (Goal dec : declist) {
//				boolean newgoal=!ad.containsGoal(dec);	
//				// addDecomp adds the new goal and, if needed (OR, M-E) organizes dispatch goals
//				GoalContainer deccont = ad.createGoal(dec, Const.ACHIEVE);
//				gc.addDecomp(deccont);
//				if (newgoal)
//					addGoal(dec, deccont, ad);
//			}
//			
//		}
//		if (tn.isMeansEndDec(g)) {
//			List<Plan> melist = tn.getMeansEndMeanPlans(g);
//			tn.printContents("All Means for End " + g.getName(), melist);
//			// sets decomposition flag and creates the Metagoal+plan,
//			// shall be the same than with OR! They could also be mixed in this implementation!
//			gc.createDecomposition(Const.ME);
//			for (Plan p : melist) {
//				boolean newplan=!ad.containsPlan(p);	
//				PlanContainer pc = ad.createPlan(p);
//				gc.addMERealPlan(pc);
//				if (newplan)
//					addPlan(p, pc, ad);
//			}
//		}
//		if (tn.isGoalWhyDependency(g)) {
//			for (Dependency dep : tn.getGoalDependencies(g)) {
//				String goal = NameUtility.adjustName(tn.getDependumGoalFromDependency(dep).getName());
//				String actor = NameUtility.adjustName(tn.getActorFromDependency(dep).getName());
//				gc.addDependency(goal, actor);
//			}
//		}
//	}
//
//	/**
//	 * @param g
//	 * @param gc
//	 * @param ad
//	 */
//	private static void addContributions(TroposModelElement m, ElementContainer ec, AgentDefinition ad) {
//
//		if (tn.hasContributions(m)) {
//			System.out.println("All Contributions of " + m.getName() + ": ");
//			for (FContribution c : tn.getContributions(m)) {
//				System.out.println(c.getSource().getName() + "----|" + c.getMetric() + "|--->"
//						+ c.getTarget().getName());
//				if (c.getTarget() instanceof FSoftGoal) {
//					FSoftGoal sg = (FSoftGoal) c.getTarget();
//					SoftgoalContainer sgcont = ad.createSoftgoal(sg);
//					ec.addContribution(sgcont, c.getMetric());
//				}
//
//			}
//		}
//	}
//
//	private static void addPlan(Plan p, PlanContainer pc, AgentDefinition ad) {
//		addContributions(p, pc, ad);
//		// RESOURCES (USE/PRODUCE) TO BE IMPLEMENTED, HERE AND IN THE NAVIGATOR!!
//	}

	/**
	 * The main output, can be changed to everything
	 * @param s
	 */
	public static void print(String s) {
		System.out.println(s);
	}

}