/**
 * <copyright>
 *
 * eCAT - Tool for Continuous Testing Agent for the JADE/Eclipse Platform
 * Copyright (C) ITC-IRST, Trento, Italy
 * Authors: Duy Cu Nguyen
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 * The electronic copy of the license can be found here:
 * http://sra.itc.it/tools/taom/freesoftware/gpl.txt
 *
 * The contact information:
 * e-mail: cunduy@itc.it
 * site: http://sra.itc.it
 *
 * </copyright>
 */

package it.itc.sra.ecat.core.executor;

import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import it.itc.sra.ecat.ECATPlugIn;
import it.itc.sra.ecat.core.Synchronizer;
import it.itc.sra.ecat.testsuiteman.testconfig.NodeType;
import it.itc.sra.ecat.testsuiteman.testconfig.TestConfig;
import it.itc.sra.ecat.util.CommonUtil;
import it.itc.sra.ecat.util.GeneralLogger;
import jade.core.AID;
import jade.core.Agent;
import jade.domain.FIPANames;
import jade.lang.acl.ACLMessage;
import jade.proto.AchieveREInitiator;

public class CentralExecutorAgent extends Agent implements IExecutor{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8175560049793974119L;
	GeneralLogger logger = GeneralLogger.getInstance();
	private static final String COMMAND_RESETS = "RESETS";
	private Synchronizer syn;
	
	private ControlRemoteExecutorAgent controlRemoteExecutorAgentBehavior = null;
	
	
	@Override
	protected void setup() {
		ECATPlugIn.getDefault().setExecutorAgent(this);
	}

	@Override
	protected void takeDown() {
		super.takeDown();
	}
	
	private class ControlRemoteExecutorAgent extends AchieveREInitiator{

		private boolean done =false;
		/**
		 * 
		*/
		private static final long serialVersionUID = 1625788541600157419L;
		
		public ControlRemoteExecutorAgent(ACLMessage request) {
			super(CentralExecutorAgent.this, request);
		}

		@Override
		protected void handleAgree(ACLMessage agree) {
			//logger.log(agree.toString());
		}

		@Override
		protected void handleAllResultNotifications(Vector resultNotifications) {
			// Handle all results notifications from all remote monitoring agents 
//			if (resultNotifications != null){
//				Iterator iter = resultNotifications.iterator();
//				while (iter.hasNext()){
//					ACLMessage inform = (ACLMessage)iter.next();
//					logger.log(inform.toString());
//				}
//			}
			done =true;
			
		}

		@Override
		protected void handleInform(ACLMessage inform) {
//			if (inform.getContent() != null && !inform.getContent().equals("")){
//				logger.log(inform.toString());
//			}
		}

		@Override
		protected void handleRefuse(ACLMessage refuse) {
			logger.log(refuse.toString());
		}

		
		
		@Override
		public int onEnd() {
			done =true;
			syn.Started();
			
			return super.onEnd();
		}

		public boolean isDone() {
			return done;
		}

		@Override
		public void reset(ACLMessage msg) {
			done = false;
			super.reset(msg);
		}
		
	}

	
	public void resetRemoteAgents(TestConfig testConfig, Synchronizer syn){
		this.syn = syn;
		
		ACLMessage request = new ACLMessage(ACLMessage.REQUEST);
		request.setProtocol(FIPANames.InteractionProtocol.FIPA_REQUEST);
		request.setSender(getAID());
		request.setContent(COMMAND_RESETS);
		
		
		// Set receivers of the message, taken from the test configuration
		if (testConfig != null){
			if (testConfig.getDitributedNodeConfig() != null){
				List<NodeType> nodes = testConfig.getDitributedNodeConfig().getNode();
				Iterator<NodeType> iter = nodes.iterator();
				request.clearAllReceiver();
				while (iter.hasNext()){
					NodeType node = (NodeType)iter.next();
					String remoteAID = CommonUtil.getRemoteExecutorAgentGUID(node);
					AID receiver = new AID(remoteAID, AID.ISGUID);
					receiver.addAddresses(node.getNodeAddress());
					request.addReceiver(receiver);
					
				}
			}
		}
		
		if (controlRemoteExecutorAgentBehavior == null){
			controlRemoteExecutorAgentBehavior = new ControlRemoteExecutorAgent(request);
			addBehaviour(controlRemoteExecutorAgentBehavior);
		} else if (controlRemoteExecutorAgentBehavior.isDone()){
			controlRemoteExecutorAgentBehavior.reset(request);
			addBehaviour(controlRemoteExecutorAgentBehavior);
		}
		
		
	}
}
