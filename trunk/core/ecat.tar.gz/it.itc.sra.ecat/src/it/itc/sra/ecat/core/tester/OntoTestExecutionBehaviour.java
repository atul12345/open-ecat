/**
 * <copyright>
 *
 * eCAT - Tool for Continuous Testing Agent for the JADE/Eclipse Platform
 * Copyright (C) ITC-IRST, Trento, Italy
 * Authors: Duy Cu Nguyen
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 * The electronic copy of the license can be found here:
 * http://sra.itc.it/tools/taom/freesoftware/gpl.txt
 *
 * The contact information:
 * e-mail: cunduy@itc.it
 * site: http://sra.itc.it
 *
 * </copyright>
 */

package it.itc.sra.ecat.core.tester;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import it.itc.sra.ecat.ECATPlugIn;
import it.itc.sra.ecat.core.Synchronizer;
import it.itc.sra.ecat.core.TestResultsModel;
import it.itc.sra.ecat.core.monitor.IMonitorAgent;
import it.itc.sra.ecat.ontobase.OntoBase;
import it.itc.sra.ecat.testsuiteman.JADETestSuites;
import it.itc.sra.ecat.testsuiteman.testconfig.NodeType;
import it.itc.sra.ecat.testsuiteman.testconfig.TestConfig;
import it.itc.sra.ecat.testsuiteman.testsuite.TestCaseType;
import it.itc.sra.ecat.testsuiteman.testsuite.TestSupportType;
import it.itc.sra.ecat.testsuiteman.testsuite.TestSuite;
import it.itc.sra.ecat.util.CommonUtil;
import it.itc.sra.ecat.util.GeneralLogger;
import jade.core.Agent;
import jade.core.behaviours.Behaviour;
import jade.core.behaviours.DataStore;
import jade.core.behaviours.FSMBehaviour;
import jade.core.behaviours.OneShotBehaviour;
import jade.core.behaviours.ParallelBehaviour;


public class OntoTestExecutionBehaviour  extends FSMBehaviour{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5275474680794446140L;
	
	private GeneralLogger logger = GeneralLogger.getInstance();
	
	protected static final String STATE_INITIAL = "initial";
	
	protected static final String STATE_RESET_REMOTES = "reset-remotes";
	
	protected static final String STATE_GENERATE_INPUT = "generate-inputs";
	protected static final String STATE_START_TEST_SESSION = "start-new-test-session";
	protected static final String STATE_RUNTEST = "test-execution";
	protected static final String STATE_GET_REMOTE_TRACES = "get-remote-traces";

	protected static final String STATE_FINAL = "final";  				
	
	
	protected static final int EVENT_INITIAL_FAILURE = -1;
	protected static final int EVENT_INITIAL_OK = 0;
	protected static final int EVENT_ABOUT = 2;
	protected static final int EVENT_FINISH = 99;
	protected static final int EVENT_CONTINUE = 100;
	
	
	private IMonitorAgent monitorAgent;
	private TestResultsModel resultModel = TestResultsModel.getInstance();
	
	private TestConfig testConfig;
	private List<NodeType> nodeList;
	
	private boolean configOK = false;
	
	private int cycle;
	private int currentTc;
	
	private String currentSessionID = "";
	private String testSuiteID = "onto-generated";
	private TestCaseType tc;
	private TestCaseType[] tcList;
	
	private OntoBase ontologySupporter;
	private TestHelper helper;
	
	ParallelBehaviour parallelTestExecutor;
	
	public OntoTestExecutionBehaviour(Agent a, TestConfig testConfig) {
		super(a);
		this.testConfig = testConfig;
		
		this.myAgent = a;
		setDataStore(new DataStore());
		nodeList = new ArrayList<NodeType>();
		ontologySupporter = new OntoBase();
		helper = new TestHelper(a);
		
		monitorAgent = ECATPlugIn.getDefault().getMonitorAgent();
		if (monitorAgent == null) {
			configOK = false;
		} else 
			configOK = initNodes() & initData();
		
		init(); // initiate the behavior
		logger.log("Launch ontology-based testing");
	}
	
	/**
	 * Initiate the list of test cases
	 * @return
	 */
	private boolean initData(){
		// Get all the specified test cases
		JADETestSuites storage = JADETestSuites.getInstance();
		Iterator<TestSuite> iterator = storage.getSuitesStorage().iterator();
		List<TestCaseType> list = new ArrayList<TestCaseType>();
		while (iterator.hasNext()) {
			TestSuite suite = iterator.next();

			List<TestCaseType> tc = suite.getTestCase();
			Iterator<TestCaseType> iter = tc.iterator();
			while (iter.hasNext()) {
				list.add(iter.next());
			}
		}
		if (list.size() > 0){
			tcList = list.toArray(new TestCaseType[list.size()]);

			// Initiate the ontology supporter
			return  ontologySupporter.init(testConfig);

		}
		// Initiate the ontology supporter
		return false;
	}
	
	/**
	 * Process test setup
	 */
	private void processTestSetup(){
		// TODO: here process all test setup together
		JADETestSuites storage = JADETestSuites.getInstance();
		Iterator<TestSuite> iterator = storage.getSuitesStorage().iterator();
		while (iterator.hasNext()) {
			TestSuite suite = iterator.next();
			TestSupportType setup = suite.getSetup(); 
			if (setup != null){
				helper.processTestSetupTeardown(setup);
			}
		}
	}
	
	/**
	 * Process tear down
	 */
	private void processTestTearDown(){
		// TODO: here process all test teardown together
		JADETestSuites storage = JADETestSuites.getInstance();
		Iterator<TestSuite> iterator = storage.getSuitesStorage().iterator();
		while (iterator.hasNext()) {
			TestSuite suite = iterator.next();
			TestSupportType teardown = suite.getTeardown(); 
			if (teardown != null){
				helper.processTestSetupTeardown(teardown);
			}
		}
	}
	
	/**
	 * Initiate node list
	 * @return
	 */
	private boolean initNodes() {
		if (this.testConfig == null)
			return false;
		else if (this.testConfig.getDitributedNodeConfig() == null)
			return false;
		else {
			List<NodeType> l = this.testConfig.getDitributedNodeConfig().getNode();
			Iterator<NodeType> iter = l.iterator();
			while (iter.hasNext()) {
				nodeList.add((NodeType) iter.next());
			}
		}
		return true;
	}
	
	
	private void init(){
		///////////////////////////////////////////////////////////////
		// Register states
		
		Behaviour b = null;
		
		// INITIAL
		b = new OneShotBehaviour(myAgent) {
			/**
			 * 
			 */
			private static final long serialVersionUID = -302868421899352103L;
			int ret = EVENT_INITIAL_OK;
			
			public void action() {
				if (!configOK) {
					ret = EVENT_INITIAL_FAILURE;
					logger.log("Onto-based testing: configuration contains errors");
				}
				
				// Process test setup of all testsuite
				processTestSetup();
				
				cycle = 0;
				currentTc = 0;
			}
			
			@Override
			public int onEnd() {
				return ret;
			}
		};
		b.setDataStore(this.getDataStore());
		b.setBehaviourName(STATE_INITIAL);
		registerFirstState(b, STATE_INITIAL);
		
		// RESET REMOTE TRACES
		b = new OneShotBehaviour(myAgent){

			/**
			 * 
			 */
			private static final long serialVersionUID = 6685387078648954792L;
			int ret;
			public void action() {
				
				if (isAbout()){
					ret = EVENT_ABOUT;
					return;
				}
				if (ECATPlugIn.getDefault().isMonitoringEnable()){
					Synchronizer sync = new Synchronizer();
					monitorAgent.resetRemotes(sync);
					sync.waitOn();
				}
			}
			
			public int onEnd() {
				if (ret == EVENT_ABOUT)
					return ret;
				return super.onEnd();
			}
		};
		b.setDataStore(this.getDataStore());
		b.setBehaviourName(STATE_RESET_REMOTES);
		registerState(b, STATE_RESET_REMOTES);
		
		// GENERATE NEW TESTCASE
		b = new OneShotBehaviour(myAgent){

			/**
			 * 
			 */
			private static final long serialVersionUID = -430028880724567221L;
			int ret;
			public void action() {
				if (isAbout()){
					ret = EVENT_ABOUT;
					return;
				}

				// Generate a new test case based on ontology
				if (tcList.length == 0 || currentTc > tcList.length - 1){
					ret = EVENT_ABOUT;
					logger.log("Test cases are not initialized, or currentTc > tcList.length - 1");
					return;
				}
				
				//tc = tcList[currentTc];
				TestCaseType template = tcList[currentTc];
				tc = CommonUtil.copyTc(template);
				currentTc = currentTc + 1;
				ontologySupporter.fetchContents(tc);
				resultModel.addTestCase(tc);
				
				// initiate parallel test executor
				if (cycle != 0 && parallelTestExecutor!= null){
					Iterator behaviour = parallelTestExecutor.getChildren().iterator();
					while (behaviour.hasNext()) {
						OntoTestBehaviour b = (OntoTestBehaviour) behaviour.next();
						parallelTestExecutor.removeSubBehaviour(b);
					}
				}
				
				Iterator<NodeType> iter = nodeList.iterator();
				while (iter.hasNext()) {
					NodeType node = (NodeType) iter.next();
					OntoTestBehaviour testSession = new OntoTestBehaviour(myAgent, node, ontologySupporter);
					testSession.setTestCase(tc);
					parallelTestExecutor.addSubBehaviour(testSession);
				}
			}

			public int onEnd() {
				if (ret == EVENT_ABOUT)
					return ret;
				return super.onEnd();
			}
		};
		b.setDataStore(this.getDataStore());
		b.setBehaviourName(STATE_GENERATE_INPUT);
		registerState(b, STATE_GENERATE_INPUT);
		
		
		// START NEW TEST SESSION
		b = new OneShotBehaviour(myAgent){

			/**
			 * 
			 */
			private static final long serialVersionUID = -430028880724567221L;
			private int ret;
			
			public void action() {
				if (isAbout()){
					ret = EVENT_ABOUT;
					return;
				}
				
				String taID = myAgent.getLocalName();
				String uid = myAgent.getAID().getHap() + "/";
				currentSessionID = CommonUtil.generateId(uid);
				String currentTcID = "undefined";
				if (tc != null)
					currentTcID = tc.getID();
				
				if (ECATPlugIn.getDefault().isMonitoringEnable()){
					Synchronizer sync = new Synchronizer();
					monitorAgent.startNewSession(currentSessionID, taID
								, testSuiteID, currentTcID, sync);
					sync.waitOn();
				}
			}
			
			public int onEnd() {
				if (ret == EVENT_ABOUT)
					return ret;
				return super.onEnd();
			}
		};
		b.setBehaviourName(STATE_START_TEST_SESSION);
		b.setDataStore(this.getDataStore());
		registerState(b, STATE_START_TEST_SESSION);
		
		// TEST EXECUTION
		parallelTestExecutor = new ParallelBehaviour(myAgent, ParallelBehaviour.WHEN_ALL);
		parallelTestExecutor.setBehaviourName(STATE_RUNTEST);
		parallelTestExecutor.setDataStore(this.getDataStore());
		registerState(parallelTestExecutor, STATE_RUNTEST);
		
		// GET REMOTE TRACES AND DECIDE WHAT NEXT
		b = new OneShotBehaviour(myAgent){
			/**
			 * 
			 */
			private static final long serialVersionUID = 6865608526948326758L;
			
			private int ret;

			public void action() {
				if (isAbout()){
					ret = EVENT_ABOUT;
					return;
				}
				
				// Get remote traces
				if (ECATPlugIn.getDefault().isMonitoringEnable()){
					Synchronizer sync = new Synchronizer();
					monitorAgent.getRemoteTraces(sync);
					sync.waitOn();
				}
				
				ret = EVENT_CONTINUE;
				if (cycle == testConfig.getNumberCycle() - 1){
					ret = EVENT_FINISH;
				} else if (currentTc == tcList.length) {
					cycle += 1;
					currentTc = 0; // next cycle
					resultModel.setTestCycle(cycle);
				}
			}
			public int onEnd() {
				return ret;
			}
		};
		
		b.setBehaviourName(STATE_GET_REMOTE_TRACES);
		b.setDataStore(this.getDataStore());
		registerState(b, STATE_GET_REMOTE_TRACES);
		
		// FINAL
		b = new OneShotBehaviour(myAgent){

			/**
			 * 
			 */
			private static final long serialVersionUID = 6685387078648954792L;

			public void action() {
				// Stop monitoring
				if (monitorAgent != null){
					monitorAgent.delayedStopMonitoring();
				}
				
				// Process test teardown
				processTestTearDown();
				
				// Done
				if (ECATPlugIn.getDefault().getTesterAgent() != null)
					ECATPlugIn.getDefault().getTesterAgent().stopTesting(); //
				
				int last_event = getLastExitValue();
				if (last_event == EVENT_ABOUT)
					logger.log("Ontology-based testing: ABOUT");
				else
					logger.log("Ontology-based testing: DONE");

				// print statistic information
				ontologySupporter.printStatistic();
			}
		};
		b.setDataStore(this.getDataStore());
		b.setBehaviourName(STATE_FINAL);
		registerLastState(b, STATE_FINAL);
		
		
		// Transitions registration
		registerTransition(STATE_INITIAL, STATE_RESET_REMOTES, EVENT_INITIAL_OK);
		registerTransition(STATE_INITIAL, STATE_FINAL, EVENT_INITIAL_FAILURE);
		
		registerDefaultTransition(STATE_RESET_REMOTES, STATE_GENERATE_INPUT);
		registerDefaultTransition(STATE_GENERATE_INPUT, STATE_START_TEST_SESSION);
		registerDefaultTransition(STATE_START_TEST_SESSION, STATE_RUNTEST);
		registerDefaultTransition(STATE_RUNTEST, STATE_GET_REMOTE_TRACES);
		
		registerTransition(STATE_GET_REMOTE_TRACES, STATE_GENERATE_INPUT, EVENT_CONTINUE);
		registerTransition(STATE_GET_REMOTE_TRACES, STATE_FINAL, EVENT_FINISH);
		
		// About
		registerTransition(STATE_RESET_REMOTES, STATE_FINAL, EVENT_ABOUT);
		registerTransition(STATE_GENERATE_INPUT, STATE_FINAL, EVENT_ABOUT);
		registerTransition(STATE_START_TEST_SESSION, STATE_FINAL, EVENT_ABOUT);
		registerTransition(STATE_RUNTEST, STATE_FINAL, EVENT_ABOUT);
		registerTransition(STATE_GET_REMOTE_TRACES, STATE_FINAL, EVENT_ABOUT);
		
	}
	
	/**
	 * Check if user forces to stop testing
	 * @return
	 */
	private boolean isAbout(){
		if (ECATPlugIn.getDefault().getTesterAgent() != null &&
				ECATPlugIn.getDefault().getTesterAgent().isRunningTest())
			return false;
		
		return true;
	}
}
