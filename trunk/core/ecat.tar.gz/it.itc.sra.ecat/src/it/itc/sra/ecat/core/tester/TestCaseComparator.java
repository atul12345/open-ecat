/**
 * <copyright>
 *
 * eCAT - Tool for Continuous Testing Agent for the JADE/Eclipse Platform
 * Copyright (C) ITC-IRST, Trento, Italy
 * Authors: Duy Cu Nguyen
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 * The electronic copy of the license can be found here:
 * http://sra.itc.it/tools/taom/freesoftware/gpl.txt
 *
 * The contact information:
 * e-mail: cunduy@itc.it
 * site: http://sra.itc.it
 *
 * </copyright>
 */

package it.itc.sra.ecat.core.tester;

import it.itc.sra.ecat.testsuiteman.testsuite.TestCaseType;

import java.util.Comparator;

/**
 * Compare priority of 2 test cases
 * @author cunduy
 *
 */

public class TestCaseComparator implements Comparator<TestCaseType> {

	
	public int compare(TestCaseType tc0, TestCaseType tc1) {
		
		if (tc0.getPriority() > tc1.getPriority()) {
			return -1;
		} else if (tc0.getPriority() == tc1.getPriority()) {
			return 0;
		} else {
			return 1;
		}
	}

}
