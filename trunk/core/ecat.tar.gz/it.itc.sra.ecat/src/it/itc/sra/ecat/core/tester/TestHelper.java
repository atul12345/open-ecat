/**
 * <copyright>
 *
 * eCAT - Tool for Continuous Testing Agent for the JADE/Eclipse Platform
 * Copyright (C) ITC-IRST, Trento, Italy
 * Authors: Duy Cu Nguyen
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 * The electronic copy of the license can be found here:
 * http://sra.itc.it/tools/taom/freesoftware/gpl.txt
 *
 * The contact information:
 * e-mail: cunduy@itc.it
 * site: http://sra.itc.it
 *
 * </copyright>
 */

package it.itc.sra.ecat.core.tester;


import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import it.itc.sra.ecat.testsuiteman.testconfig.NodeType;
import it.itc.sra.ecat.testsuiteman.testconfig.TestConfig;
import it.itc.sra.ecat.testsuiteman.testsuite.CheckType;
import it.itc.sra.ecat.testsuiteman.testsuite.FipaMessageType;
import it.itc.sra.ecat.testsuiteman.testsuite.AType;
import it.itc.sra.ecat.testsuiteman.testsuite.OperatorType;
import it.itc.sra.ecat.testsuiteman.testsuite.ParamType;
import it.itc.sra.ecat.testsuiteman.testsuite.TActionType;
import it.itc.sra.ecat.testsuiteman.testsuite.TaskType;
import it.itc.sra.ecat.testsuiteman.testsuite.TestCaseType;
import it.itc.sra.ecat.testsuiteman.testsuite.TestSupportType;
import it.itc.sra.ecat.testsuiteman.testsuite.TestScenarioType;
import it.itc.sra.ecat.testsuiteman.testsuite.TestSupportType.Task;
import it.itc.sra.ecat.util.GeneralLogger;
import it.itc.sra.ecat.util.Logger;
import jade.core.AID;
import jade.core.Agent;
import jade.domain.DFService;
import jade.domain.FIPAException;
import jade.domain.FIPAAgentManagement.DFAgentDescription;
import jade.domain.FIPAAgentManagement.ServiceDescription;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;

/**
 * This class helps executing test cases 
 *
 * @author cunduy
 *
 */
public class TestHelper {

	private static final int TIMEOUT = 5000;
	
	private final String LAST_PROCESS_MSG = "__last_process_message" + hashCode();
	private HashMap<String, ACLMessage> dataStore;
	
	
	private Agent myAgent;
	private GeneralLogger logger = GeneralLogger.getInstance();
	private TestConfig testConfig;

	public TestHelper(Agent myAgent) {
		this.myAgent = myAgent;
		dataStore = new HashMap<String, ACLMessage>();
	}
	
	
		
	public void setTestConfig(TestConfig testConfig) {
		this.testConfig = testConfig;
	}
	
	/**
	 * Process setup or teardown
	 * @param expression
	 */
	public void processTestSetupTeardown(TestSupportType expression){
		
		List<Task> tasks = expression.getTask();
		
		for (Task t : tasks){
			List<ParamType> params = t.getParam();
			if (t.getType().equals(TaskType.REGISTER_AGENT)){
				String sName = null; String sType = null; String ontology = null;
				for (ParamType p : params){
					if (p.getName().equals("serviceName")){
						sName = p.getValue();
					} else if (p.getName().equals("serviceType")){
						sType = p.getValue();
					} else if (p.getName().equals("serviceOntology")){
						ontology = p.getValue();
					}
				}
				
				// Register
				dfRegister(sName, sType, ontology);
				
			} else if (t.getType().equals(TaskType.DEREGISTER_AGENT)){
				String sName = null; String sType = null; String ontology = null;
				for (ParamType p : params){
					if (p.getName().equals("serviceName")){
						sName = p.getValue();
					} else if (p.getName().equals("serviceType")){
						sType = p.getValue();
					} else if (p.getName().equals("serviceOntology")){
						ontology = p.getValue();
					}
				}
				
				// DeRegister
				dfDeRegister(sName, sType, ontology);
			} else {
				logger.log("Task: " + t.getName() + " type: " + t.getType().toString() + " has not implemented yet!");
			}
		}
	}
	
	/**
	 * Deregister the service
	 * @param serviceName
	 * @param serviceType
	 * @param ontology
	 */
	private void dfDeRegister(String serviceName, String serviceType, String ontology){
		DFAgentDescription dfd = new DFAgentDescription();
        dfd.setName(myAgent.getAID());
        
        ServiceDescription sd = new ServiceDescription();
        
        if (serviceName != null)
        	sd.setName(serviceName);
        
        if (serviceType != null)
        	sd.setType(serviceType);
        if (ontology != null)
        	sd.addOntologies(ontology);
        
        dfd.addServices(sd);
        try
        {
            DFService.deregister(myAgent, dfd);
        }
        catch (FIPAException e)
        {
            e.printStackTrace(logger.getOut());
        }
	}
	
	/**
	 * Register with the DF
	 * @param serviceName
	 * @param serviceType
	 * @param ontology
	 */
	private boolean dfRegister(String serviceName, String serviceType, String ontology){
		DFAgentDescription dfd = new DFAgentDescription();
        dfd.setName(myAgent.getAID());
        
        ServiceDescription sd = new ServiceDescription();
        
        if (serviceName != null)
        	sd.setName(serviceName);
        else 
        	return false; //service name must be not null 
        
        if (serviceType != null)
        	sd.setType(serviceType);
        if (ontology != null)
        	sd.addOntologies(ontology);
        
        dfd.addServices(sd);
        try
        {
            DFService.register(myAgent, dfd);
            return true;
        }
        catch (FIPAException e)
        {
            e.printStackTrace(logger.getOut());
            return false;
        }
	}

	/**
	 * Process each test case, set test config before calling this operation
	 * @param tc
	 * @return
	 */
	public boolean processTestCase(TestCaseType tc) {
		
		if (testConfig == null) return false;
		
		boolean ret = false;
		
		// Log
		logger.log(Logger.LEVEL_INFO, "Process test case: " + tc.getName());
		
		// 1. Process the setup condition
/*		Object setup = tc.getSetup();
		if (setup != null) {
			if (setup instanceof TestScenarioType) {
				processSenario((TestScenarioType)setup);
			}
		}
*/		
		// 2. Process the test scenario
		ret = processSenario(tc.getScenario());
		
		// 3. Process the teardown
/*		Object tear = tc.getTeardown();
		if (tear != null) {
			if (tear instanceof TestScenarioType) {
				processSenario((TestScenarioType)tear);
			}
		}
*/		
		return ret;
	}
	
	
	
	/**
	 * Process each scenario
	 * 
	 * @param testScenario
	 * @return
	 */
	private boolean processSenario(TestScenarioType testScenario) {

		logger.log(Logger.LEVEL_INFO, "Process scenario ");
		
		// Start from the initial sequence
		List<TActionType> acts = testScenario.getTestAction();
		Iterator<TActionType> iter = acts.iterator();
		TActionType initialSeq = null;
		while(iter.hasNext()) {
			TActionType nextSeq = (TActionType)iter.next();
			if (nextSeq.getActType().equals(AType.INITIAL)) {
				initialSeq = nextSeq;
				break;
			}
		}
		
		if (initialSeq != null)
			return	processSequence(initialSeq, testScenario); // call recursive method
		else 
			return true;
	}
	
	/**
	 * Identify the next sequence to be executed
	 * @param currentSequence
	 * @param testScenario
	 * @return
	 */
	private TActionType getNextSequence(TActionType currentSequence, TestScenarioType testScenario) {
		return  (TActionType)currentSequence.getNextAction();
	}
	
	public MessageTemplate buildTemplate(FipaMessageType fipaMsg) {
		MessageTemplate template = null;
		if (fipaMsg.getAct() != null && fipaMsg.getConversationId() != null) {
			template = MessageTemplate.and(MessageTemplate.MatchConversationId(fipaMsg.getConversationId()),
					MessageTemplate.MatchPerformative(ACLMessage.getInteger(fipaMsg.getAct())));
		} else if (fipaMsg.getAct() != null && fipaMsg.getOntology() != null) {
			template = MessageTemplate.and(MessageTemplate.MatchOntology(fipaMsg.getOntology()),
					MessageTemplate.MatchPerformative(ACLMessage.getInteger(fipaMsg.getAct())));
		} else if (fipaMsg.getAct() != null 
				&& fipaMsg.getOntology() != null
				&& fipaMsg.getLanguage() != null) {
			template = MessageTemplate.and(MessageTemplate.or(MessageTemplate.MatchOntology(fipaMsg.getOntology()),
					MessageTemplate.MatchLanguage(fipaMsg.getLanguage())), MessageTemplate.MatchPerformative(ACLMessage.getInteger(fipaMsg.getAct())));
		} else if (fipaMsg.getAct() != null && fipaMsg.getLanguage() != null) {
			template = MessageTemplate.and(MessageTemplate.MatchLanguage(fipaMsg.getLanguage()),
					MessageTemplate.MatchPerformative(ACLMessage.getInteger(fipaMsg.getAct())));
		} else if (fipaMsg.getAct() != null) {
			template = MessageTemplate.MatchPerformative(ACLMessage.getInteger(fipaMsg.getAct()));
		}
		return template;
	}

	
	private boolean processSequence(TActionType action, TestScenarioType testScenario) {
		boolean ret = true;
		
		if (action == null)
			return true; // In case the sequence contains error that could not be parsed
		
		
		// Get and check sequence type
		AType actType = action.getActType();
		String initiator = normalizeAgentName(action.getInitiator());
		String responder = normalizeAgentName(action.getResponder());
		
		logger.log("Processing sequence " + action.getActType() + "; seqID = " + action.getID());
		
		if (actType.equals(AType.INITIAL)){
			return true;
		}
		
		if (!actType.equals(AType.BRANCH)){
		
			if (actType.equals(AType.INITIAL)){
				// Simply skip
			
			} else if (actType.equals(AType.COMMUNICATION)){
				if (responder.equalsIgnoreCase(myAgent.getName())) {
					//////////////////////////////////////////////////////////////
					// Get the message from the agent under tested
					MessageTemplate template = null;
					// 1. Get the predefined message template
					Object definedMsg = action.getMessage();
					
					int timeOut = action.getTimeout(); 
					if (timeOut < 0)
						timeOut = TIMEOUT;
					
					if (definedMsg != null) {
						if (definedMsg instanceof FipaMessageType) {
							FipaMessageType fipaMsg = (FipaMessageType)definedMsg;
							template = buildTemplate(fipaMsg);
						}
					}
					
					ACLMessage msg = myAgent.blockingReceive(template, timeOut);
					// Put message to the message store
					dataStore.put(LAST_PROCESS_MSG, msg);
					
					
				} else if (initiator.equalsIgnoreCase(myAgent.getName())) {
					// The tester is the initiator (sender)
					// Create a message and send to the receiver
					Object definedMsg = action.getMessage();
					if (definedMsg != null) {
						if (definedMsg instanceof FipaMessageType) {
							FipaMessageType fipaMsg = (FipaMessageType)definedMsg;
							ACLMessage msg = new ACLMessage(ACLMessage.getInteger(fipaMsg.getAct()));
							msg.setSender(myAgent.getAID());
							
							
							List<NodeType> nodes = testConfig.getDitributedNodeConfig().getNode();
							Iterator<NodeType> iter = nodes.iterator(); // Only the first node is taken into account
							if (iter.hasNext()){
								NodeType node = (NodeType)iter.next();
							
								AID receiver = new AID(action.getResponder(), AID.ISGUID);
								receiver.addAddresses(node.getNodeAddress());
								msg.addReceiver(receiver);
								
								msg.setConversationId(fipaMsg.getConversationId());
								if (fipaMsg.getOntology() != null)
									msg.setOntology(fipaMsg.getOntology());
								if (fipaMsg.getLanguage() != null)
									msg.setLanguage(fipaMsg.getLanguage());
								
							
								msg.setContent(fipaMsg.getContent().getValue());
								
								// Ask the tester agent to schedule and send this msg
								myAgent.send(msg);
								dataStore.put(LAST_PROCESS_MSG, msg);
							}
						}
					}
				}
				
				ret = true;
			
			} else if (actType.equals("checkpoint")) {
	
				ACLMessage msg = dataStore.get(LAST_PROCESS_MSG);
				
				if (msg == null) {
					logger.log(Logger.LEVEL_ERROR, "ERROR: No message received, normally because of timeout error in the previous sequence of: " + action.getID());
					return false;
				} else {
					// Check condition
					// Compare the message with the specified condition
					if (!checkCondition(msg, action.getVerdict())){
						logger.log(Logger.LEVEL_ERROR, "ERROR: Error \"output is not expected\" found in the sequence, : " + action.getID());
						logger.log(Logger.LEVEL_ERROR, msg.toString());
						return false;
					}
				}
			}
			
			//	Process next sequence
			TActionType nextSeq = getNextSequence(action, testScenario);
			if (nextSeq == null)
				return ret;
			else
				return processSequence(nextSeq, testScenario);
			
			
		} else if (actType.equals("branch")) {
			
			ACLMessage msg = dataStore.get(LAST_PROCESS_MSG);
			
			if (msg == null) {
				logger.log(Logger.LEVEL_ERROR, "ERROR: Timeout error in the sequence: " + action.getID());
				return false;
			} else {
				// Check condition and decide next sequence
				// Compare the message with the specified condition
				logger.log(Logger.LEVEL_INFO, msg.toString());
				
				if (checkCondition(msg, action.getVerdict())){
					if (action.getNextIfTrue() != null) {
						return processSequence((TActionType)action.getNextIfTrue(), testScenario);
					} else {
						return true;
					}
				} else {
					if (action.getNextIfFalse() != null) {
						return processSequence((TActionType)action.getNextIfFalse(), testScenario);
					} else {
						return true;
					}
				}
			}
		}
		
		return ret;
		
	}
	
	
	/**
	 * Compare the msg to the specified data 
	 * @param msg
	 * @param condition
	 * @return
	 */
	public boolean checkCondition(ACLMessage msg, CheckType condition) {
		
		OperatorType opt = condition.getCheckOperator();
		Object expectedOutput = condition.getExpectedValue();
		FipaMessageType expectedMsg = null;
		if (expectedOutput == null) {
			return true;
		} else if (!(expectedOutput instanceof FipaMessageType)) {
			logger.log(Logger.LEVEL_ERROR, "Can not inteprete the condition data ");
			return false; // Can not inteprete the condition data
		} else {
			expectedMsg = (FipaMessageType)expectedOutput;
		}
		
		if (opt.equals(OperatorType.EQUAL)) {

			//logger.log(Logger.LEVEL_INFO, "Check condition EQUAL");
			//logger.log(Logger.LEVEL_INFO, "Compare " + msg.getContent());
			//logger.log(Logger.LEVEL_INFO, "To " + expectedMsg.getContent());
			
			if (msg.getContent() == null || expectedMsg.getContent() == null)
				return false;

			return msg.getContent().equalsIgnoreCase(expectedMsg.getContent().getValue());
						
		} else if (opt.equals(OperatorType.NOT_EQUAL)) {
			if (msg.getContent().equalsIgnoreCase(expectedMsg.getContent().getValue()))
				return false; 
			else 
				return true;
		} else if (opt.equals(OperatorType.GREATER_OR_EQUAL)) {
			// FIXME Implement checkpoint
			return true;
		} else if (opt.equals(OperatorType.LESS_OR_EQUAL)) {
			// FIXME Implement checkpoint
			return true;
		} else if (opt.equals(OperatorType.GREATER)) {
			// FIXME Implement checkpoint
			return true;
		} else if (opt.equals(OperatorType.LESS)) {
			// FIXME Implement checkpoint
			return true;
		} else if (opt.equals(OperatorType.CONTAINS)) {
			
			if (msg.getContent() == null || expectedMsg.getContent() == null)
				return false;
			
			return (msg.getContent().indexOf(expectedMsg.getContent().getValue()) > -1 );
			
		} else if (opt.equals(OperatorType.NOT_CONTAINS)) {
			if (msg.getContent() == null || expectedMsg.getContent() == null)
				return false;
			return (msg.getContent().indexOf(expectedMsg.getContent().getValue()) < 0);
			
		} else if (opt.equals(OperatorType.IS_NULL)) {
			return (msg.getContent() == null || msg.getContent() == "");
		} else if (opt.equals(OperatorType.NOT_NULL)) {
			return (msg.getContent() != null); 
		}
			
		
		return false; // Unknown error
	}
	
	/**
	 * 
	 * @param name
	 * @return
	 */
	private String normalizeAgentName(String name) {
		if (name != null && name.indexOf("@") > -1) {
			return name;
		} else if (name != null) {
			return name + "@" + myAgent.getHap();  
		} else return "";
	}
}
