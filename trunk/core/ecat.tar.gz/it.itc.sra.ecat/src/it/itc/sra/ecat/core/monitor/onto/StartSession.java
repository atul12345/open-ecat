package it.itc.sra.ecat.core.monitor.onto;


import jade.content.*;
import jade.util.leap.*;
import jade.core.*;

/**
* Protege name: StartSession
* @author ontology bean generator
* @version 2007/10/12, 20:00:38
*/
public class StartSession implements AgentAction {

   /**
* Protege name: aid
   */
   private String aid;
   public void setAid(String value) { 
    this.aid=value;
   }
   public String getAid() {
     return this.aid;
   }

   /**
* Protege name: sessionID
   */
   private String sessionID;
   public void setSessionID(String value) { 
    this.sessionID=value;
   }
   public String getSessionID() {
     return this.sessionID;
   }

   /**
* Protege name: testCase
   */
   private String testCase;
   public void setTestCase(String value) { 
    this.testCase=value;
   }
   public String getTestCase() {
     return this.testCase;
   }

   /**
* Protege name: testSuite
   */
   private String testSuite;
   public void setTestSuite(String value) { 
    this.testSuite=value;
   }
   public String getTestSuite() {
     return this.testSuite;
   }

}
