package it.itc.sra.ecat.core.monitor.onto;


import jade.content.*;
import jade.util.leap.*;
import jade.core.*;

/**
* Protege name: RequestMonitorTrace
* @author ontology bean generator
* @version 2007/10/12, 20:00:38
*/
public class RequestMonitorTrace implements AgentAction {

   /**
* Protege name: sessionID
   */
   private String sessionID;
   public void setSessionID(String value) { 
    this.sessionID=value;
   }
   public String getSessionID() {
     return this.sessionID;
   }

}
