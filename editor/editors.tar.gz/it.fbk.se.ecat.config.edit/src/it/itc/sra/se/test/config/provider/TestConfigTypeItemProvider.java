/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package it.itc.sra.se.test.config.provider;


import it.itc.sra.se.test.config.ConfigFactory;
import it.itc.sra.se.test.config.ConfigPackage;
import it.itc.sra.se.test.config.PlatformType;
import it.itc.sra.se.test.config.TestConfigType;

import java.util.Collection;
import java.util.List;

import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.ResourceLocator;

import org.eclipse.emf.ecore.EStructuralFeature;

import org.eclipse.emf.edit.provider.ComposeableAdapterFactory;
import org.eclipse.emf.edit.provider.IEditingDomainItemProvider;
import org.eclipse.emf.edit.provider.IItemLabelProvider;
import org.eclipse.emf.edit.provider.IItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.IItemPropertySource;
import org.eclipse.emf.edit.provider.IStructuredItemContentProvider;
import org.eclipse.emf.edit.provider.ITreeItemContentProvider;
import org.eclipse.emf.edit.provider.ItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.ItemProviderAdapter;
import org.eclipse.emf.edit.provider.ViewerNotification;

/**
 * This is the item provider adapter for a {@link it.itc.sra.se.test.config.TestConfigType} object.
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class TestConfigTypeItemProvider
	extends ItemProviderAdapter
	implements
		IEditingDomainItemProvider,
		IStructuredItemContentProvider,
		ITreeItemContentProvider,
		IItemLabelProvider,
		IItemPropertySource {
	/**
	 * This constructs an instance from a factory and a notifier.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TestConfigTypeItemProvider(AdapterFactory adapterFactory) {
		super(adapterFactory);
	}

	/**
	 * This returns the property descriptors for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public List<IItemPropertyDescriptor> getPropertyDescriptors(Object object) {
		if (itemPropertyDescriptors == null) {
			super.getPropertyDescriptors(object);

			addPlatformPropertyDescriptor(object);
			addPreferedStrategyPropertyDescriptor(object);
			addProtocolPathPropertyDescriptor(object);
			addDomainDataPathPropertyDescriptor(object);
			addMaxRandomTCPropertyDescriptor(object);
			addNumberCyclePropertyDescriptor(object);
			addAgentUnderTestPropertyDescriptor(object);
			addMaxMutationGenPropertyDescriptor(object);
			addMaxMutationPsizePropertyDescriptor(object);
			addMutationProbPropertyDescriptor(object);
		}
		return itemPropertyDescriptors;
	}

	/**
	 * This adds a property descriptor for the Platform feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addPlatformPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_TestConfigType_platform_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_TestConfigType_platform_feature", "_UI_TestConfigType_type"),
				 ConfigPackage.Literals.TEST_CONFIG_TYPE__PLATFORM,
				 true,
				 false,
				 false,
				 ItemPropertyDescriptor.GENERIC_VALUE_IMAGE,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the Prefered Strategy feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addPreferedStrategyPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_TestConfigType_preferedStrategy_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_TestConfigType_preferedStrategy_feature", "_UI_TestConfigType_type"),
				 ConfigPackage.Literals.TEST_CONFIG_TYPE__PREFERED_STRATEGY,
				 true,
				 false,
				 false,
				 ItemPropertyDescriptor.GENERIC_VALUE_IMAGE,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the Protocol Path feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addProtocolPathPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_TestConfigType_protocolPath_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_TestConfigType_protocolPath_feature", "_UI_TestConfigType_type"),
				 ConfigPackage.Literals.TEST_CONFIG_TYPE__PROTOCOL_PATH,
				 true,
				 false,
				 false,
				 ItemPropertyDescriptor.GENERIC_VALUE_IMAGE,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the Domain Data Path feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addDomainDataPathPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_TestConfigType_domainDataPath_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_TestConfigType_domainDataPath_feature", "_UI_TestConfigType_type"),
				 ConfigPackage.Literals.TEST_CONFIG_TYPE__DOMAIN_DATA_PATH,
				 true,
				 false,
				 false,
				 ItemPropertyDescriptor.GENERIC_VALUE_IMAGE,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the Max Random TC feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addMaxRandomTCPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_TestConfigType_maxRandomTC_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_TestConfigType_maxRandomTC_feature", "_UI_TestConfigType_type"),
				 ConfigPackage.Literals.TEST_CONFIG_TYPE__MAX_RANDOM_TC,
				 true,
				 false,
				 false,
				 ItemPropertyDescriptor.INTEGRAL_VALUE_IMAGE,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the Number Cycle feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addNumberCyclePropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_TestConfigType_numberCycle_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_TestConfigType_numberCycle_feature", "_UI_TestConfigType_type"),
				 ConfigPackage.Literals.TEST_CONFIG_TYPE__NUMBER_CYCLE,
				 true,
				 false,
				 false,
				 ItemPropertyDescriptor.INTEGRAL_VALUE_IMAGE,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the Agent Under Test feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addAgentUnderTestPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_TestConfigType_agentUnderTest_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_TestConfigType_agentUnderTest_feature", "_UI_TestConfigType_type"),
				 ConfigPackage.Literals.TEST_CONFIG_TYPE__AGENT_UNDER_TEST,
				 true,
				 false,
				 false,
				 ItemPropertyDescriptor.GENERIC_VALUE_IMAGE,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the Max Mutation Gen feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addMaxMutationGenPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_TestConfigType_maxMutationGen_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_TestConfigType_maxMutationGen_feature", "_UI_TestConfigType_type"),
				 ConfigPackage.Literals.TEST_CONFIG_TYPE__MAX_MUTATION_GEN,
				 true,
				 false,
				 false,
				 ItemPropertyDescriptor.INTEGRAL_VALUE_IMAGE,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the Max Mutation Psize feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addMaxMutationPsizePropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_TestConfigType_maxMutationPsize_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_TestConfigType_maxMutationPsize_feature", "_UI_TestConfigType_type"),
				 ConfigPackage.Literals.TEST_CONFIG_TYPE__MAX_MUTATION_PSIZE,
				 true,
				 false,
				 false,
				 ItemPropertyDescriptor.INTEGRAL_VALUE_IMAGE,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the Mutation Prob feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addMutationProbPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_TestConfigType_mutationProb_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_TestConfigType_mutationProb_feature", "_UI_TestConfigType_type"),
				 ConfigPackage.Literals.TEST_CONFIG_TYPE__MUTATION_PROB,
				 true,
				 false,
				 false,
				 ItemPropertyDescriptor.REAL_VALUE_IMAGE,
				 null,
				 null));
	}

	/**
	 * This specifies how to implement {@link #getChildren} and is used to deduce an appropriate feature for an
	 * {@link org.eclipse.emf.edit.command.AddCommand}, {@link org.eclipse.emf.edit.command.RemoveCommand} or
	 * {@link org.eclipse.emf.edit.command.MoveCommand} in {@link #createCommand}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Collection<? extends EStructuralFeature> getChildrenFeatures(Object object) {
		if (childrenFeatures == null) {
			super.getChildrenFeatures(object);
			childrenFeatures.add(ConfigPackage.Literals.TEST_CONFIG_TYPE__TEST_SUITE_LIST);
			childrenFeatures.add(ConfigPackage.Literals.TEST_CONFIG_TYPE__ONTOLOGY_SETTING);
			childrenFeatures.add(ConfigPackage.Literals.TEST_CONFIG_TYPE__DITRIBUTED_NODE_CONFIG);
		}
		return childrenFeatures;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EStructuralFeature getChildFeature(Object object, Object child) {
		// Check the type of the specified child object and return the proper feature to use for
		// adding (see {@link AddCommand}) it as a child.

		return super.getChildFeature(object, child);
	}

	/**
	 * This returns TestConfigType.gif.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object getImage(Object object) {
		return overlayImage(object, getResourceLocator().getImage("full/obj16/TestConfigType"));
	}

	/**
	 * This returns the label text for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getText(Object object) {
		PlatformType labelValue = ((TestConfigType)object).getPlatform();
		String label = labelValue == null ? null : labelValue.toString();
		return label == null || label.length() == 0 ?
			getString("_UI_TestConfigType_type") :
			getString("_UI_TestConfigType_type") + " " + label;
	}

	/**
	 * This handles model notifications by calling {@link #updateChildren} to update any cached
	 * children and by creating a viewer notification, which it passes to {@link #fireNotifyChanged}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void notifyChanged(Notification notification) {
		updateChildren(notification);

		switch (notification.getFeatureID(TestConfigType.class)) {
			case ConfigPackage.TEST_CONFIG_TYPE__PLATFORM:
			case ConfigPackage.TEST_CONFIG_TYPE__PREFERED_STRATEGY:
			case ConfigPackage.TEST_CONFIG_TYPE__PROTOCOL_PATH:
			case ConfigPackage.TEST_CONFIG_TYPE__DOMAIN_DATA_PATH:
			case ConfigPackage.TEST_CONFIG_TYPE__MAX_RANDOM_TC:
			case ConfigPackage.TEST_CONFIG_TYPE__NUMBER_CYCLE:
			case ConfigPackage.TEST_CONFIG_TYPE__AGENT_UNDER_TEST:
			case ConfigPackage.TEST_CONFIG_TYPE__MAX_MUTATION_GEN:
			case ConfigPackage.TEST_CONFIG_TYPE__MAX_MUTATION_PSIZE:
			case ConfigPackage.TEST_CONFIG_TYPE__MUTATION_PROB:
				fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), false, true));
				return;
			case ConfigPackage.TEST_CONFIG_TYPE__TEST_SUITE_LIST:
			case ConfigPackage.TEST_CONFIG_TYPE__ONTOLOGY_SETTING:
			case ConfigPackage.TEST_CONFIG_TYPE__DITRIBUTED_NODE_CONFIG:
				fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), true, false));
				return;
		}
		super.notifyChanged(notification);
	}

	/**
	 * This adds {@link org.eclipse.emf.edit.command.CommandParameter}s describing the children
	 * that can be created under this object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected void collectNewChildDescriptors(Collection<Object> newChildDescriptors, Object object) {
		super.collectNewChildDescriptors(newChildDescriptors, object);

		newChildDescriptors.add
			(createChildParameter
				(ConfigPackage.Literals.TEST_CONFIG_TYPE__TEST_SUITE_LIST,
				 ConfigFactory.eINSTANCE.createTestSuiteListType()));

		newChildDescriptors.add
			(createChildParameter
				(ConfigPackage.Literals.TEST_CONFIG_TYPE__ONTOLOGY_SETTING,
				 ConfigFactory.eINSTANCE.createOntologyType()));

		newChildDescriptors.add
			(createChildParameter
				(ConfigPackage.Literals.TEST_CONFIG_TYPE__DITRIBUTED_NODE_CONFIG,
				 ConfigFactory.eINSTANCE.createDitributedNodeConfigType()));
	}

	/**
	 * Return the resource locator for this item provider's resources.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ResourceLocator getResourceLocator() {
		return TestConfigEditPlugin.INSTANCE;
	}

}
