/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package schema;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Addresses Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link schema.AddressesType#getUrl <em>Url</em>}</li>
 * </ul>
 * </p>
 *
 * @see schema.SchemaPackage#getAddressesType()
 * @model extendedMetaData="name='AddressesType' kind='elementOnly'"
 * @generated
 */
public interface AddressesType extends EObject {
	/**
	 * Returns the value of the '<em><b>Url</b></em>' containment reference list.
	 * The list contents are of type {@link schema.UrlType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Url</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Url</em>' containment reference list.
	 * @see schema.SchemaPackage#getAddressesType_Url()
	 * @model containment="true" required="true"
	 *        extendedMetaData="kind='element' name='url' namespace='##targetNamespace'"
	 * @generated
	 */
	EList<UrlType> getUrl();

} // AddressesType
