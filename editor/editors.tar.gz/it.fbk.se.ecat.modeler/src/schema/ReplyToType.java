/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package schema;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Reply To Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link schema.ReplyToType#getAgentIdentifier <em>Agent Identifier</em>}</li>
 * </ul>
 * </p>
 *
 * @see schema.SchemaPackage#getReplyToType()
 * @model extendedMetaData="name='Reply-toType' kind='elementOnly'"
 * @generated
 */
public interface ReplyToType extends EObject {
	/**
	 * Returns the value of the '<em><b>Agent Identifier</b></em>' containment reference list.
	 * The list contents are of type {@link schema.AgentIdentifierType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Agent Identifier</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Agent Identifier</em>' containment reference list.
	 * @see schema.SchemaPackage#getReplyToType_AgentIdentifier()
	 * @model containment="true" required="true"
	 *        extendedMetaData="kind='element' name='agent-identifier' namespace='##targetNamespace'"
	 * @generated
	 */
	EList<AgentIdentifierType> getAgentIdentifier();

} // ReplyToType
