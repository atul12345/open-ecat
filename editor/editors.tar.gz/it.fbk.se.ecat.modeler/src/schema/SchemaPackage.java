/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package schema;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see schema.SchemaFactory
 * @model kind="package"
 * @generated
 */
public interface SchemaPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "schema";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.fipa.org/ACLSchema";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "schema";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	SchemaPackage eINSTANCE = schema.impl.SchemaPackageImpl.init();

	/**
	 * The meta object id for the '{@link schema.impl.AddressesTypeImpl <em>Addresses Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see schema.impl.AddressesTypeImpl
	 * @see schema.impl.SchemaPackageImpl#getAddressesType()
	 * @generated
	 */
	int ADDRESSES_TYPE = 0;

	/**
	 * The feature id for the '<em><b>Url</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADDRESSES_TYPE__URL = 0;

	/**
	 * The number of structural features of the '<em>Addresses Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADDRESSES_TYPE_FEATURE_COUNT = 1;

	/**
	 * The meta object id for the '{@link schema.impl.AgentIdentifierTypeImpl <em>Agent Identifier Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see schema.impl.AgentIdentifierTypeImpl
	 * @see schema.impl.SchemaPackageImpl#getAgentIdentifierType()
	 * @generated
	 */
	int AGENT_IDENTIFIER_TYPE = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGENT_IDENTIFIER_TYPE__NAME = 0;

	/**
	 * The feature id for the '<em><b>Addresses</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGENT_IDENTIFIER_TYPE__ADDRESSES = 1;

	/**
	 * The feature id for the '<em><b>Resolvers</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGENT_IDENTIFIER_TYPE__RESOLVERS = 2;

	/**
	 * The feature id for the '<em><b>User Defined</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGENT_IDENTIFIER_TYPE__USER_DEFINED = 3;

	/**
	 * The number of structural features of the '<em>Agent Identifier Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGENT_IDENTIFIER_TYPE_FEATURE_COUNT = 4;

	/**
	 * The meta object id for the '{@link schema.impl.ContentTypeImpl <em>Content Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see schema.impl.ContentTypeImpl
	 * @see schema.impl.SchemaPackageImpl#getContentType()
	 * @generated
	 */
	int CONTENT_TYPE = 2;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTENT_TYPE__VALUE = 0;

	/**
	 * The feature id for the '<em><b>Valueref</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTENT_TYPE__VALUEREF = 1;

	/**
	 * The feature id for the '<em><b>Class</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTENT_TYPE__CLASS = 2;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTENT_TYPE__ID = 3;

	/**
	 * The number of structural features of the '<em>Content Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTENT_TYPE_FEATURE_COUNT = 4;

	/**
	 * The meta object id for the '{@link schema.impl.DocumentRootImpl <em>Document Root</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see schema.impl.DocumentRootImpl
	 * @see schema.impl.SchemaPackageImpl#getDocumentRoot()
	 * @generated
	 */
	int DOCUMENT_ROOT = 3;

	/**
	 * The feature id for the '<em><b>Mixed</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT_ROOT__MIXED = 0;

	/**
	 * The feature id for the '<em><b>XMLNS Prefix Map</b></em>' map.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT_ROOT__XMLNS_PREFIX_MAP = 1;

	/**
	 * The feature id for the '<em><b>XSI Schema Location</b></em>' map.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT_ROOT__XSI_SCHEMA_LOCATION = 2;

	/**
	 * The feature id for the '<em><b>Fipa Message</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT_ROOT__FIPA_MESSAGE = 3;

	/**
	 * The number of structural features of the '<em>Document Root</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT_ROOT_FEATURE_COUNT = 4;

	/**
	 * The meta object id for the '{@link schema.impl.FipaMessageTypeImpl <em>Fipa Message Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see schema.impl.FipaMessageTypeImpl
	 * @see schema.impl.SchemaPackageImpl#getFipaMessageType()
	 * @generated
	 */
	int FIPA_MESSAGE_TYPE = 4;

	/**
	 * The feature id for the '<em><b>Sender</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIPA_MESSAGE_TYPE__SENDER = 0;

	/**
	 * The feature id for the '<em><b>Receiver</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIPA_MESSAGE_TYPE__RECEIVER = 1;

	/**
	 * The feature id for the '<em><b>Content</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIPA_MESSAGE_TYPE__CONTENT = 2;

	/**
	 * The feature id for the '<em><b>Language</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIPA_MESSAGE_TYPE__LANGUAGE = 3;

	/**
	 * The feature id for the '<em><b>Encoding</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIPA_MESSAGE_TYPE__ENCODING = 4;

	/**
	 * The feature id for the '<em><b>Ontology</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIPA_MESSAGE_TYPE__ONTOLOGY = 5;

	/**
	 * The feature id for the '<em><b>Protocol</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIPA_MESSAGE_TYPE__PROTOCOL = 6;

	/**
	 * The feature id for the '<em><b>Reply With</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIPA_MESSAGE_TYPE__REPLY_WITH = 7;

	/**
	 * The feature id for the '<em><b>In Reply To</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIPA_MESSAGE_TYPE__IN_REPLY_TO = 8;

	/**
	 * The feature id for the '<em><b>Reply By</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIPA_MESSAGE_TYPE__REPLY_BY = 9;

	/**
	 * The feature id for the '<em><b>Reply To</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIPA_MESSAGE_TYPE__REPLY_TO = 10;

	/**
	 * The feature id for the '<em><b>Conversation Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIPA_MESSAGE_TYPE__CONVERSATION_ID = 11;

	/**
	 * The feature id for the '<em><b>User Defined</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIPA_MESSAGE_TYPE__USER_DEFINED = 12;

	/**
	 * The feature id for the '<em><b>Act</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIPA_MESSAGE_TYPE__ACT = 13;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIPA_MESSAGE_TYPE__ID = 14;

	/**
	 * The number of structural features of the '<em>Fipa Message Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIPA_MESSAGE_TYPE_FEATURE_COUNT = 15;

	/**
	 * The meta object id for the '{@link schema.impl.ReceiverTypeImpl <em>Receiver Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see schema.impl.ReceiverTypeImpl
	 * @see schema.impl.SchemaPackageImpl#getReceiverType()
	 * @generated
	 */
	int RECEIVER_TYPE = 5;

	/**
	 * The feature id for the '<em><b>Agent Identifier</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RECEIVER_TYPE__AGENT_IDENTIFIER = 0;

	/**
	 * The number of structural features of the '<em>Receiver Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RECEIVER_TYPE_FEATURE_COUNT = 1;

	/**
	 * The meta object id for the '{@link schema.impl.ReplyByTypeImpl <em>Reply By Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see schema.impl.ReplyByTypeImpl
	 * @see schema.impl.SchemaPackageImpl#getReplyByType()
	 * @generated
	 */
	int REPLY_BY_TYPE = 6;

	/**
	 * The feature id for the '<em><b>Href</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REPLY_BY_TYPE__HREF = 0;

	/**
	 * The feature id for the '<em><b>Time</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REPLY_BY_TYPE__TIME = 1;

	/**
	 * The number of structural features of the '<em>Reply By Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REPLY_BY_TYPE_FEATURE_COUNT = 2;

	/**
	 * The meta object id for the '{@link schema.impl.ReplyToTypeImpl <em>Reply To Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see schema.impl.ReplyToTypeImpl
	 * @see schema.impl.SchemaPackageImpl#getReplyToType()
	 * @generated
	 */
	int REPLY_TO_TYPE = 7;

	/**
	 * The feature id for the '<em><b>Agent Identifier</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REPLY_TO_TYPE__AGENT_IDENTIFIER = 0;

	/**
	 * The number of structural features of the '<em>Reply To Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REPLY_TO_TYPE_FEATURE_COUNT = 1;

	/**
	 * The meta object id for the '{@link schema.impl.ResolversTypeImpl <em>Resolvers Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see schema.impl.ResolversTypeImpl
	 * @see schema.impl.SchemaPackageImpl#getResolversType()
	 * @generated
	 */
	int RESOLVERS_TYPE = 8;

	/**
	 * The feature id for the '<em><b>Agent Identifier</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RESOLVERS_TYPE__AGENT_IDENTIFIER = 0;

	/**
	 * The number of structural features of the '<em>Resolvers Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RESOLVERS_TYPE_FEATURE_COUNT = 1;

	/**
	 * The meta object id for the '{@link schema.impl.SenderTypeImpl <em>Sender Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see schema.impl.SenderTypeImpl
	 * @see schema.impl.SchemaPackageImpl#getSenderType()
	 * @generated
	 */
	int SENDER_TYPE = 9;

	/**
	 * The feature id for the '<em><b>Agent Identifier</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENDER_TYPE__AGENT_IDENTIFIER = 0;

	/**
	 * The number of structural features of the '<em>Sender Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENDER_TYPE_FEATURE_COUNT = 1;

	/**
	 * The meta object id for the '{@link schema.impl.UrlTypeImpl <em>Url Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see schema.impl.UrlTypeImpl
	 * @see schema.impl.SchemaPackageImpl#getUrlType()
	 * @generated
	 */
	int URL_TYPE = 10;

	/**
	 * The feature id for the '<em><b>Href</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int URL_TYPE__HREF = 0;

	/**
	 * The number of structural features of the '<em>Url Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int URL_TYPE_FEATURE_COUNT = 1;

	/**
	 * The meta object id for the '{@link schema.impl.UserDefinedTypeImpl <em>User Defined Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see schema.impl.UserDefinedTypeImpl
	 * @see schema.impl.SchemaPackageImpl#getUserDefinedType()
	 * @generated
	 */
	int USER_DEFINED_TYPE = 11;

	/**
	 * The feature id for the '<em><b>Mixed</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USER_DEFINED_TYPE__MIXED = 0;

	/**
	 * The feature id for the '<em><b>Href</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USER_DEFINED_TYPE__HREF = 1;

	/**
	 * The number of structural features of the '<em>User Defined Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USER_DEFINED_TYPE_FEATURE_COUNT = 2;

	/**
	 * The meta object id for the '{@link schema.ActType <em>Act Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see schema.ActType
	 * @see schema.impl.SchemaPackageImpl#getActType()
	 * @generated
	 */
	int ACT_TYPE = 12;

	/**
	 * The meta object id for the '<em>Act Type Object</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see schema.ActType
	 * @see schema.impl.SchemaPackageImpl#getActTypeObject()
	 * @generated
	 */
	int ACT_TYPE_OBJECT = 13;


	/**
	 * Returns the meta object for class '{@link schema.AddressesType <em>Addresses Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Addresses Type</em>'.
	 * @see schema.AddressesType
	 * @generated
	 */
	EClass getAddressesType();

	/**
	 * Returns the meta object for the containment reference list '{@link schema.AddressesType#getUrl <em>Url</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Url</em>'.
	 * @see schema.AddressesType#getUrl()
	 * @see #getAddressesType()
	 * @generated
	 */
	EReference getAddressesType_Url();

	/**
	 * Returns the meta object for class '{@link schema.AgentIdentifierType <em>Agent Identifier Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Agent Identifier Type</em>'.
	 * @see schema.AgentIdentifierType
	 * @generated
	 */
	EClass getAgentIdentifierType();

	/**
	 * Returns the meta object for the attribute '{@link schema.AgentIdentifierType#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see schema.AgentIdentifierType#getName()
	 * @see #getAgentIdentifierType()
	 * @generated
	 */
	EAttribute getAgentIdentifierType_Name();

	/**
	 * Returns the meta object for the containment reference '{@link schema.AgentIdentifierType#getAddresses <em>Addresses</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Addresses</em>'.
	 * @see schema.AgentIdentifierType#getAddresses()
	 * @see #getAgentIdentifierType()
	 * @generated
	 */
	EReference getAgentIdentifierType_Addresses();

	/**
	 * Returns the meta object for the containment reference '{@link schema.AgentIdentifierType#getResolvers <em>Resolvers</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Resolvers</em>'.
	 * @see schema.AgentIdentifierType#getResolvers()
	 * @see #getAgentIdentifierType()
	 * @generated
	 */
	EReference getAgentIdentifierType_Resolvers();

	/**
	 * Returns the meta object for the containment reference list '{@link schema.AgentIdentifierType#getUserDefined <em>User Defined</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>User Defined</em>'.
	 * @see schema.AgentIdentifierType#getUserDefined()
	 * @see #getAgentIdentifierType()
	 * @generated
	 */
	EReference getAgentIdentifierType_UserDefined();

	/**
	 * Returns the meta object for class '{@link schema.ContentType <em>Content Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Content Type</em>'.
	 * @see schema.ContentType
	 * @generated
	 */
	EClass getContentType();

	/**
	 * Returns the meta object for the attribute '{@link schema.ContentType#getValue <em>Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Value</em>'.
	 * @see schema.ContentType#getValue()
	 * @see #getContentType()
	 * @generated
	 */
	EAttribute getContentType_Value();

	/**
	 * Returns the meta object for the attribute '{@link schema.ContentType#getValueref <em>Valueref</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Valueref</em>'.
	 * @see schema.ContentType#getValueref()
	 * @see #getContentType()
	 * @generated
	 */
	EAttribute getContentType_Valueref();

	/**
	 * Returns the meta object for the attribute '{@link schema.ContentType#getClass_ <em>Class</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Class</em>'.
	 * @see schema.ContentType#getClass_()
	 * @see #getContentType()
	 * @generated
	 */
	EAttribute getContentType_Class();

	/**
	 * Returns the meta object for the attribute '{@link schema.ContentType#getId <em>Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Id</em>'.
	 * @see schema.ContentType#getId()
	 * @see #getContentType()
	 * @generated
	 */
	EAttribute getContentType_Id();

	/**
	 * Returns the meta object for class '{@link schema.DocumentRoot <em>Document Root</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Document Root</em>'.
	 * @see schema.DocumentRoot
	 * @generated
	 */
	EClass getDocumentRoot();

	/**
	 * Returns the meta object for the attribute list '{@link schema.DocumentRoot#getMixed <em>Mixed</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute list '<em>Mixed</em>'.
	 * @see schema.DocumentRoot#getMixed()
	 * @see #getDocumentRoot()
	 * @generated
	 */
	EAttribute getDocumentRoot_Mixed();

	/**
	 * Returns the meta object for the map '{@link schema.DocumentRoot#getXMLNSPrefixMap <em>XMLNS Prefix Map</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the map '<em>XMLNS Prefix Map</em>'.
	 * @see schema.DocumentRoot#getXMLNSPrefixMap()
	 * @see #getDocumentRoot()
	 * @generated
	 */
	EReference getDocumentRoot_XMLNSPrefixMap();

	/**
	 * Returns the meta object for the map '{@link schema.DocumentRoot#getXSISchemaLocation <em>XSI Schema Location</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the map '<em>XSI Schema Location</em>'.
	 * @see schema.DocumentRoot#getXSISchemaLocation()
	 * @see #getDocumentRoot()
	 * @generated
	 */
	EReference getDocumentRoot_XSISchemaLocation();

	/**
	 * Returns the meta object for the containment reference '{@link schema.DocumentRoot#getFipaMessage <em>Fipa Message</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Fipa Message</em>'.
	 * @see schema.DocumentRoot#getFipaMessage()
	 * @see #getDocumentRoot()
	 * @generated
	 */
	EReference getDocumentRoot_FipaMessage();

	/**
	 * Returns the meta object for class '{@link schema.FipaMessageType <em>Fipa Message Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Fipa Message Type</em>'.
	 * @see schema.FipaMessageType
	 * @generated
	 */
	EClass getFipaMessageType();

	/**
	 * Returns the meta object for the containment reference '{@link schema.FipaMessageType#getSender <em>Sender</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Sender</em>'.
	 * @see schema.FipaMessageType#getSender()
	 * @see #getFipaMessageType()
	 * @generated
	 */
	EReference getFipaMessageType_Sender();

	/**
	 * Returns the meta object for the containment reference '{@link schema.FipaMessageType#getReceiver <em>Receiver</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Receiver</em>'.
	 * @see schema.FipaMessageType#getReceiver()
	 * @see #getFipaMessageType()
	 * @generated
	 */
	EReference getFipaMessageType_Receiver();

	/**
	 * Returns the meta object for the containment reference '{@link schema.FipaMessageType#getContent <em>Content</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Content</em>'.
	 * @see schema.FipaMessageType#getContent()
	 * @see #getFipaMessageType()
	 * @generated
	 */
	EReference getFipaMessageType_Content();

	/**
	 * Returns the meta object for the attribute '{@link schema.FipaMessageType#getLanguage <em>Language</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Language</em>'.
	 * @see schema.FipaMessageType#getLanguage()
	 * @see #getFipaMessageType()
	 * @generated
	 */
	EAttribute getFipaMessageType_Language();

	/**
	 * Returns the meta object for the attribute '{@link schema.FipaMessageType#getEncoding <em>Encoding</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Encoding</em>'.
	 * @see schema.FipaMessageType#getEncoding()
	 * @see #getFipaMessageType()
	 * @generated
	 */
	EAttribute getFipaMessageType_Encoding();

	/**
	 * Returns the meta object for the attribute '{@link schema.FipaMessageType#getOntology <em>Ontology</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Ontology</em>'.
	 * @see schema.FipaMessageType#getOntology()
	 * @see #getFipaMessageType()
	 * @generated
	 */
	EAttribute getFipaMessageType_Ontology();

	/**
	 * Returns the meta object for the attribute '{@link schema.FipaMessageType#getProtocol <em>Protocol</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Protocol</em>'.
	 * @see schema.FipaMessageType#getProtocol()
	 * @see #getFipaMessageType()
	 * @generated
	 */
	EAttribute getFipaMessageType_Protocol();

	/**
	 * Returns the meta object for the attribute '{@link schema.FipaMessageType#getReplyWith <em>Reply With</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Reply With</em>'.
	 * @see schema.FipaMessageType#getReplyWith()
	 * @see #getFipaMessageType()
	 * @generated
	 */
	EAttribute getFipaMessageType_ReplyWith();

	/**
	 * Returns the meta object for the attribute '{@link schema.FipaMessageType#getInReplyTo <em>In Reply To</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>In Reply To</em>'.
	 * @see schema.FipaMessageType#getInReplyTo()
	 * @see #getFipaMessageType()
	 * @generated
	 */
	EAttribute getFipaMessageType_InReplyTo();

	/**
	 * Returns the meta object for the containment reference '{@link schema.FipaMessageType#getReplyBy <em>Reply By</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Reply By</em>'.
	 * @see schema.FipaMessageType#getReplyBy()
	 * @see #getFipaMessageType()
	 * @generated
	 */
	EReference getFipaMessageType_ReplyBy();

	/**
	 * Returns the meta object for the containment reference '{@link schema.FipaMessageType#getReplyTo <em>Reply To</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Reply To</em>'.
	 * @see schema.FipaMessageType#getReplyTo()
	 * @see #getFipaMessageType()
	 * @generated
	 */
	EReference getFipaMessageType_ReplyTo();

	/**
	 * Returns the meta object for the attribute '{@link schema.FipaMessageType#getConversationId <em>Conversation Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Conversation Id</em>'.
	 * @see schema.FipaMessageType#getConversationId()
	 * @see #getFipaMessageType()
	 * @generated
	 */
	EAttribute getFipaMessageType_ConversationId();

	/**
	 * Returns the meta object for the containment reference '{@link schema.FipaMessageType#getUserDefined <em>User Defined</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>User Defined</em>'.
	 * @see schema.FipaMessageType#getUserDefined()
	 * @see #getFipaMessageType()
	 * @generated
	 */
	EReference getFipaMessageType_UserDefined();

	/**
	 * Returns the meta object for the attribute '{@link schema.FipaMessageType#getAct <em>Act</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Act</em>'.
	 * @see schema.FipaMessageType#getAct()
	 * @see #getFipaMessageType()
	 * @generated
	 */
	EAttribute getFipaMessageType_Act();

	/**
	 * Returns the meta object for the attribute '{@link schema.FipaMessageType#getId <em>Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Id</em>'.
	 * @see schema.FipaMessageType#getId()
	 * @see #getFipaMessageType()
	 * @generated
	 */
	EAttribute getFipaMessageType_Id();

	/**
	 * Returns the meta object for class '{@link schema.ReceiverType <em>Receiver Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Receiver Type</em>'.
	 * @see schema.ReceiverType
	 * @generated
	 */
	EClass getReceiverType();

	/**
	 * Returns the meta object for the containment reference list '{@link schema.ReceiverType#getAgentIdentifier <em>Agent Identifier</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Agent Identifier</em>'.
	 * @see schema.ReceiverType#getAgentIdentifier()
	 * @see #getReceiverType()
	 * @generated
	 */
	EReference getReceiverType_AgentIdentifier();

	/**
	 * Returns the meta object for class '{@link schema.ReplyByType <em>Reply By Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Reply By Type</em>'.
	 * @see schema.ReplyByType
	 * @generated
	 */
	EClass getReplyByType();

	/**
	 * Returns the meta object for the attribute '{@link schema.ReplyByType#getHref <em>Href</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Href</em>'.
	 * @see schema.ReplyByType#getHref()
	 * @see #getReplyByType()
	 * @generated
	 */
	EAttribute getReplyByType_Href();

	/**
	 * Returns the meta object for the attribute '{@link schema.ReplyByType#getTime <em>Time</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Time</em>'.
	 * @see schema.ReplyByType#getTime()
	 * @see #getReplyByType()
	 * @generated
	 */
	EAttribute getReplyByType_Time();

	/**
	 * Returns the meta object for class '{@link schema.ReplyToType <em>Reply To Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Reply To Type</em>'.
	 * @see schema.ReplyToType
	 * @generated
	 */
	EClass getReplyToType();

	/**
	 * Returns the meta object for the containment reference list '{@link schema.ReplyToType#getAgentIdentifier <em>Agent Identifier</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Agent Identifier</em>'.
	 * @see schema.ReplyToType#getAgentIdentifier()
	 * @see #getReplyToType()
	 * @generated
	 */
	EReference getReplyToType_AgentIdentifier();

	/**
	 * Returns the meta object for class '{@link schema.ResolversType <em>Resolvers Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Resolvers Type</em>'.
	 * @see schema.ResolversType
	 * @generated
	 */
	EClass getResolversType();

	/**
	 * Returns the meta object for the containment reference list '{@link schema.ResolversType#getAgentIdentifier <em>Agent Identifier</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Agent Identifier</em>'.
	 * @see schema.ResolversType#getAgentIdentifier()
	 * @see #getResolversType()
	 * @generated
	 */
	EReference getResolversType_AgentIdentifier();

	/**
	 * Returns the meta object for class '{@link schema.SenderType <em>Sender Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Sender Type</em>'.
	 * @see schema.SenderType
	 * @generated
	 */
	EClass getSenderType();

	/**
	 * Returns the meta object for the containment reference '{@link schema.SenderType#getAgentIdentifier <em>Agent Identifier</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Agent Identifier</em>'.
	 * @see schema.SenderType#getAgentIdentifier()
	 * @see #getSenderType()
	 * @generated
	 */
	EReference getSenderType_AgentIdentifier();

	/**
	 * Returns the meta object for class '{@link schema.UrlType <em>Url Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Url Type</em>'.
	 * @see schema.UrlType
	 * @generated
	 */
	EClass getUrlType();

	/**
	 * Returns the meta object for the attribute '{@link schema.UrlType#getHref <em>Href</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Href</em>'.
	 * @see schema.UrlType#getHref()
	 * @see #getUrlType()
	 * @generated
	 */
	EAttribute getUrlType_Href();

	/**
	 * Returns the meta object for class '{@link schema.UserDefinedType <em>User Defined Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>User Defined Type</em>'.
	 * @see schema.UserDefinedType
	 * @generated
	 */
	EClass getUserDefinedType();

	/**
	 * Returns the meta object for the attribute list '{@link schema.UserDefinedType#getMixed <em>Mixed</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute list '<em>Mixed</em>'.
	 * @see schema.UserDefinedType#getMixed()
	 * @see #getUserDefinedType()
	 * @generated
	 */
	EAttribute getUserDefinedType_Mixed();

	/**
	 * Returns the meta object for the attribute '{@link schema.UserDefinedType#getHref <em>Href</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Href</em>'.
	 * @see schema.UserDefinedType#getHref()
	 * @see #getUserDefinedType()
	 * @generated
	 */
	EAttribute getUserDefinedType_Href();

	/**
	 * Returns the meta object for enum '{@link schema.ActType <em>Act Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Act Type</em>'.
	 * @see schema.ActType
	 * @generated
	 */
	EEnum getActType();

	/**
	 * Returns the meta object for data type '{@link schema.ActType <em>Act Type Object</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Act Type Object</em>'.
	 * @see schema.ActType
	 * @model instanceClass="schema.ActType"
	 *        extendedMetaData="name='act_._type:Object' baseType='act_._type'"
	 * @generated
	 */
	EDataType getActTypeObject();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	SchemaFactory getSchemaFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link schema.impl.AddressesTypeImpl <em>Addresses Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see schema.impl.AddressesTypeImpl
		 * @see schema.impl.SchemaPackageImpl#getAddressesType()
		 * @generated
		 */
		EClass ADDRESSES_TYPE = eINSTANCE.getAddressesType();

		/**
		 * The meta object literal for the '<em><b>Url</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ADDRESSES_TYPE__URL = eINSTANCE.getAddressesType_Url();

		/**
		 * The meta object literal for the '{@link schema.impl.AgentIdentifierTypeImpl <em>Agent Identifier Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see schema.impl.AgentIdentifierTypeImpl
		 * @see schema.impl.SchemaPackageImpl#getAgentIdentifierType()
		 * @generated
		 */
		EClass AGENT_IDENTIFIER_TYPE = eINSTANCE.getAgentIdentifierType();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute AGENT_IDENTIFIER_TYPE__NAME = eINSTANCE.getAgentIdentifierType_Name();

		/**
		 * The meta object literal for the '<em><b>Addresses</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference AGENT_IDENTIFIER_TYPE__ADDRESSES = eINSTANCE.getAgentIdentifierType_Addresses();

		/**
		 * The meta object literal for the '<em><b>Resolvers</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference AGENT_IDENTIFIER_TYPE__RESOLVERS = eINSTANCE.getAgentIdentifierType_Resolvers();

		/**
		 * The meta object literal for the '<em><b>User Defined</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference AGENT_IDENTIFIER_TYPE__USER_DEFINED = eINSTANCE.getAgentIdentifierType_UserDefined();

		/**
		 * The meta object literal for the '{@link schema.impl.ContentTypeImpl <em>Content Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see schema.impl.ContentTypeImpl
		 * @see schema.impl.SchemaPackageImpl#getContentType()
		 * @generated
		 */
		EClass CONTENT_TYPE = eINSTANCE.getContentType();

		/**
		 * The meta object literal for the '<em><b>Value</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONTENT_TYPE__VALUE = eINSTANCE.getContentType_Value();

		/**
		 * The meta object literal for the '<em><b>Valueref</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONTENT_TYPE__VALUEREF = eINSTANCE.getContentType_Valueref();

		/**
		 * The meta object literal for the '<em><b>Class</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONTENT_TYPE__CLASS = eINSTANCE.getContentType_Class();

		/**
		 * The meta object literal for the '<em><b>Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONTENT_TYPE__ID = eINSTANCE.getContentType_Id();

		/**
		 * The meta object literal for the '{@link schema.impl.DocumentRootImpl <em>Document Root</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see schema.impl.DocumentRootImpl
		 * @see schema.impl.SchemaPackageImpl#getDocumentRoot()
		 * @generated
		 */
		EClass DOCUMENT_ROOT = eINSTANCE.getDocumentRoot();

		/**
		 * The meta object literal for the '<em><b>Mixed</b></em>' attribute list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DOCUMENT_ROOT__MIXED = eINSTANCE.getDocumentRoot_Mixed();

		/**
		 * The meta object literal for the '<em><b>XMLNS Prefix Map</b></em>' map feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOCUMENT_ROOT__XMLNS_PREFIX_MAP = eINSTANCE.getDocumentRoot_XMLNSPrefixMap();

		/**
		 * The meta object literal for the '<em><b>XSI Schema Location</b></em>' map feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOCUMENT_ROOT__XSI_SCHEMA_LOCATION = eINSTANCE.getDocumentRoot_XSISchemaLocation();

		/**
		 * The meta object literal for the '<em><b>Fipa Message</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOCUMENT_ROOT__FIPA_MESSAGE = eINSTANCE.getDocumentRoot_FipaMessage();

		/**
		 * The meta object literal for the '{@link schema.impl.FipaMessageTypeImpl <em>Fipa Message Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see schema.impl.FipaMessageTypeImpl
		 * @see schema.impl.SchemaPackageImpl#getFipaMessageType()
		 * @generated
		 */
		EClass FIPA_MESSAGE_TYPE = eINSTANCE.getFipaMessageType();

		/**
		 * The meta object literal for the '<em><b>Sender</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FIPA_MESSAGE_TYPE__SENDER = eINSTANCE.getFipaMessageType_Sender();

		/**
		 * The meta object literal for the '<em><b>Receiver</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FIPA_MESSAGE_TYPE__RECEIVER = eINSTANCE.getFipaMessageType_Receiver();

		/**
		 * The meta object literal for the '<em><b>Content</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FIPA_MESSAGE_TYPE__CONTENT = eINSTANCE.getFipaMessageType_Content();

		/**
		 * The meta object literal for the '<em><b>Language</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FIPA_MESSAGE_TYPE__LANGUAGE = eINSTANCE.getFipaMessageType_Language();

		/**
		 * The meta object literal for the '<em><b>Encoding</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FIPA_MESSAGE_TYPE__ENCODING = eINSTANCE.getFipaMessageType_Encoding();

		/**
		 * The meta object literal for the '<em><b>Ontology</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FIPA_MESSAGE_TYPE__ONTOLOGY = eINSTANCE.getFipaMessageType_Ontology();

		/**
		 * The meta object literal for the '<em><b>Protocol</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FIPA_MESSAGE_TYPE__PROTOCOL = eINSTANCE.getFipaMessageType_Protocol();

		/**
		 * The meta object literal for the '<em><b>Reply With</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FIPA_MESSAGE_TYPE__REPLY_WITH = eINSTANCE.getFipaMessageType_ReplyWith();

		/**
		 * The meta object literal for the '<em><b>In Reply To</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FIPA_MESSAGE_TYPE__IN_REPLY_TO = eINSTANCE.getFipaMessageType_InReplyTo();

		/**
		 * The meta object literal for the '<em><b>Reply By</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FIPA_MESSAGE_TYPE__REPLY_BY = eINSTANCE.getFipaMessageType_ReplyBy();

		/**
		 * The meta object literal for the '<em><b>Reply To</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FIPA_MESSAGE_TYPE__REPLY_TO = eINSTANCE.getFipaMessageType_ReplyTo();

		/**
		 * The meta object literal for the '<em><b>Conversation Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FIPA_MESSAGE_TYPE__CONVERSATION_ID = eINSTANCE.getFipaMessageType_ConversationId();

		/**
		 * The meta object literal for the '<em><b>User Defined</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FIPA_MESSAGE_TYPE__USER_DEFINED = eINSTANCE.getFipaMessageType_UserDefined();

		/**
		 * The meta object literal for the '<em><b>Act</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FIPA_MESSAGE_TYPE__ACT = eINSTANCE.getFipaMessageType_Act();

		/**
		 * The meta object literal for the '<em><b>Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FIPA_MESSAGE_TYPE__ID = eINSTANCE.getFipaMessageType_Id();

		/**
		 * The meta object literal for the '{@link schema.impl.ReceiverTypeImpl <em>Receiver Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see schema.impl.ReceiverTypeImpl
		 * @see schema.impl.SchemaPackageImpl#getReceiverType()
		 * @generated
		 */
		EClass RECEIVER_TYPE = eINSTANCE.getReceiverType();

		/**
		 * The meta object literal for the '<em><b>Agent Identifier</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference RECEIVER_TYPE__AGENT_IDENTIFIER = eINSTANCE.getReceiverType_AgentIdentifier();

		/**
		 * The meta object literal for the '{@link schema.impl.ReplyByTypeImpl <em>Reply By Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see schema.impl.ReplyByTypeImpl
		 * @see schema.impl.SchemaPackageImpl#getReplyByType()
		 * @generated
		 */
		EClass REPLY_BY_TYPE = eINSTANCE.getReplyByType();

		/**
		 * The meta object literal for the '<em><b>Href</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute REPLY_BY_TYPE__HREF = eINSTANCE.getReplyByType_Href();

		/**
		 * The meta object literal for the '<em><b>Time</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute REPLY_BY_TYPE__TIME = eINSTANCE.getReplyByType_Time();

		/**
		 * The meta object literal for the '{@link schema.impl.ReplyToTypeImpl <em>Reply To Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see schema.impl.ReplyToTypeImpl
		 * @see schema.impl.SchemaPackageImpl#getReplyToType()
		 * @generated
		 */
		EClass REPLY_TO_TYPE = eINSTANCE.getReplyToType();

		/**
		 * The meta object literal for the '<em><b>Agent Identifier</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference REPLY_TO_TYPE__AGENT_IDENTIFIER = eINSTANCE.getReplyToType_AgentIdentifier();

		/**
		 * The meta object literal for the '{@link schema.impl.ResolversTypeImpl <em>Resolvers Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see schema.impl.ResolversTypeImpl
		 * @see schema.impl.SchemaPackageImpl#getResolversType()
		 * @generated
		 */
		EClass RESOLVERS_TYPE = eINSTANCE.getResolversType();

		/**
		 * The meta object literal for the '<em><b>Agent Identifier</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference RESOLVERS_TYPE__AGENT_IDENTIFIER = eINSTANCE.getResolversType_AgentIdentifier();

		/**
		 * The meta object literal for the '{@link schema.impl.SenderTypeImpl <em>Sender Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see schema.impl.SenderTypeImpl
		 * @see schema.impl.SchemaPackageImpl#getSenderType()
		 * @generated
		 */
		EClass SENDER_TYPE = eINSTANCE.getSenderType();

		/**
		 * The meta object literal for the '<em><b>Agent Identifier</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SENDER_TYPE__AGENT_IDENTIFIER = eINSTANCE.getSenderType_AgentIdentifier();

		/**
		 * The meta object literal for the '{@link schema.impl.UrlTypeImpl <em>Url Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see schema.impl.UrlTypeImpl
		 * @see schema.impl.SchemaPackageImpl#getUrlType()
		 * @generated
		 */
		EClass URL_TYPE = eINSTANCE.getUrlType();

		/**
		 * The meta object literal for the '<em><b>Href</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute URL_TYPE__HREF = eINSTANCE.getUrlType_Href();

		/**
		 * The meta object literal for the '{@link schema.impl.UserDefinedTypeImpl <em>User Defined Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see schema.impl.UserDefinedTypeImpl
		 * @see schema.impl.SchemaPackageImpl#getUserDefinedType()
		 * @generated
		 */
		EClass USER_DEFINED_TYPE = eINSTANCE.getUserDefinedType();

		/**
		 * The meta object literal for the '<em><b>Mixed</b></em>' attribute list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute USER_DEFINED_TYPE__MIXED = eINSTANCE.getUserDefinedType_Mixed();

		/**
		 * The meta object literal for the '<em><b>Href</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute USER_DEFINED_TYPE__HREF = eINSTANCE.getUserDefinedType_Href();

		/**
		 * The meta object literal for the '{@link schema.ActType <em>Act Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see schema.ActType
		 * @see schema.impl.SchemaPackageImpl#getActType()
		 * @generated
		 */
		EEnum ACT_TYPE = eINSTANCE.getActType();

		/**
		 * The meta object literal for the '<em>Act Type Object</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see schema.ActType
		 * @see schema.impl.SchemaPackageImpl#getActTypeObject()
		 * @generated
		 */
		EDataType ACT_TYPE_OBJECT = eINSTANCE.getActTypeObject();

	}

} //SchemaPackage
