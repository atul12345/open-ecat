/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package schema;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Fipa Message Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link schema.FipaMessageType#getSender <em>Sender</em>}</li>
 *   <li>{@link schema.FipaMessageType#getReceiver <em>Receiver</em>}</li>
 *   <li>{@link schema.FipaMessageType#getContent <em>Content</em>}</li>
 *   <li>{@link schema.FipaMessageType#getLanguage <em>Language</em>}</li>
 *   <li>{@link schema.FipaMessageType#getEncoding <em>Encoding</em>}</li>
 *   <li>{@link schema.FipaMessageType#getOntology <em>Ontology</em>}</li>
 *   <li>{@link schema.FipaMessageType#getProtocol <em>Protocol</em>}</li>
 *   <li>{@link schema.FipaMessageType#getReplyWith <em>Reply With</em>}</li>
 *   <li>{@link schema.FipaMessageType#getInReplyTo <em>In Reply To</em>}</li>
 *   <li>{@link schema.FipaMessageType#getReplyBy <em>Reply By</em>}</li>
 *   <li>{@link schema.FipaMessageType#getReplyTo <em>Reply To</em>}</li>
 *   <li>{@link schema.FipaMessageType#getConversationId <em>Conversation Id</em>}</li>
 *   <li>{@link schema.FipaMessageType#getUserDefined <em>User Defined</em>}</li>
 *   <li>{@link schema.FipaMessageType#getAct <em>Act</em>}</li>
 *   <li>{@link schema.FipaMessageType#getId <em>Id</em>}</li>
 * </ul>
 * </p>
 *
 * @see schema.SchemaPackage#getFipaMessageType()
 * @model extendedMetaData="name='fipa-messageType' kind='elementOnly'"
 * @generated
 */
public interface FipaMessageType extends EObject {
	/**
	 * Returns the value of the '<em><b>Sender</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Sender</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sender</em>' containment reference.
	 * @see #setSender(SenderType)
	 * @see schema.SchemaPackage#getFipaMessageType_Sender()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='sender' namespace='##targetNamespace'"
	 * @generated
	 */
	SenderType getSender();

	/**
	 * Sets the value of the '{@link schema.FipaMessageType#getSender <em>Sender</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Sender</em>' containment reference.
	 * @see #getSender()
	 * @generated
	 */
	void setSender(SenderType value);

	/**
	 * Returns the value of the '<em><b>Receiver</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Receiver</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Receiver</em>' containment reference.
	 * @see #setReceiver(ReceiverType)
	 * @see schema.SchemaPackage#getFipaMessageType_Receiver()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='receiver' namespace='##targetNamespace'"
	 * @generated
	 */
	ReceiverType getReceiver();

	/**
	 * Sets the value of the '{@link schema.FipaMessageType#getReceiver <em>Receiver</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Receiver</em>' containment reference.
	 * @see #getReceiver()
	 * @generated
	 */
	void setReceiver(ReceiverType value);

	/**
	 * Returns the value of the '<em><b>Content</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Content</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Content</em>' containment reference.
	 * @see #setContent(ContentType)
	 * @see schema.SchemaPackage#getFipaMessageType_Content()
	 * @model containment="true" required="true"
	 *        extendedMetaData="kind='element' name='content' namespace='##targetNamespace'"
	 * @generated
	 */
	ContentType getContent();

	/**
	 * Sets the value of the '{@link schema.FipaMessageType#getContent <em>Content</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Content</em>' containment reference.
	 * @see #getContent()
	 * @generated
	 */
	void setContent(ContentType value);

	/**
	 * Returns the value of the '<em><b>Language</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Language</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Language</em>' attribute.
	 * @see #setLanguage(String)
	 * @see schema.SchemaPackage#getFipaMessageType_Language()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.String"
	 *        extendedMetaData="kind='element' name='language' namespace='##targetNamespace'"
	 * @generated
	 */
	String getLanguage();

	/**
	 * Sets the value of the '{@link schema.FipaMessageType#getLanguage <em>Language</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Language</em>' attribute.
	 * @see #getLanguage()
	 * @generated
	 */
	void setLanguage(String value);

	/**
	 * Returns the value of the '<em><b>Encoding</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Encoding</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Encoding</em>' attribute.
	 * @see #setEncoding(String)
	 * @see schema.SchemaPackage#getFipaMessageType_Encoding()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.String"
	 *        extendedMetaData="kind='element' name='encoding' namespace='##targetNamespace'"
	 * @generated
	 */
	String getEncoding();

	/**
	 * Sets the value of the '{@link schema.FipaMessageType#getEncoding <em>Encoding</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Encoding</em>' attribute.
	 * @see #getEncoding()
	 * @generated
	 */
	void setEncoding(String value);

	/**
	 * Returns the value of the '<em><b>Ontology</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Ontology</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ontology</em>' attribute.
	 * @see #setOntology(String)
	 * @see schema.SchemaPackage#getFipaMessageType_Ontology()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.String"
	 *        extendedMetaData="kind='element' name='ontology' namespace='##targetNamespace'"
	 * @generated
	 */
	String getOntology();

	/**
	 * Sets the value of the '{@link schema.FipaMessageType#getOntology <em>Ontology</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Ontology</em>' attribute.
	 * @see #getOntology()
	 * @generated
	 */
	void setOntology(String value);

	/**
	 * Returns the value of the '<em><b>Protocol</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Protocol</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Protocol</em>' attribute.
	 * @see #setProtocol(String)
	 * @see schema.SchemaPackage#getFipaMessageType_Protocol()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.String"
	 *        extendedMetaData="kind='element' name='protocol' namespace='##targetNamespace'"
	 * @generated
	 */
	String getProtocol();

	/**
	 * Sets the value of the '{@link schema.FipaMessageType#getProtocol <em>Protocol</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Protocol</em>' attribute.
	 * @see #getProtocol()
	 * @generated
	 */
	void setProtocol(String value);

	/**
	 * Returns the value of the '<em><b>Reply With</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Reply With</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Reply With</em>' attribute.
	 * @see #setReplyWith(String)
	 * @see schema.SchemaPackage#getFipaMessageType_ReplyWith()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.String"
	 *        extendedMetaData="kind='element' name='reply-with' namespace='##targetNamespace'"
	 * @generated
	 */
	String getReplyWith();

	/**
	 * Sets the value of the '{@link schema.FipaMessageType#getReplyWith <em>Reply With</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Reply With</em>' attribute.
	 * @see #getReplyWith()
	 * @generated
	 */
	void setReplyWith(String value);

	/**
	 * Returns the value of the '<em><b>In Reply To</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>In Reply To</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>In Reply To</em>' attribute.
	 * @see #setInReplyTo(String)
	 * @see schema.SchemaPackage#getFipaMessageType_InReplyTo()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.String"
	 *        extendedMetaData="kind='element' name='in-reply-to' namespace='##targetNamespace'"
	 * @generated
	 */
	String getInReplyTo();

	/**
	 * Sets the value of the '{@link schema.FipaMessageType#getInReplyTo <em>In Reply To</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>In Reply To</em>' attribute.
	 * @see #getInReplyTo()
	 * @generated
	 */
	void setInReplyTo(String value);

	/**
	 * Returns the value of the '<em><b>Reply By</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Reply By</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Reply By</em>' containment reference.
	 * @see #setReplyBy(ReplyByType)
	 * @see schema.SchemaPackage#getFipaMessageType_ReplyBy()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='reply-by' namespace='##targetNamespace'"
	 * @generated
	 */
	ReplyByType getReplyBy();

	/**
	 * Sets the value of the '{@link schema.FipaMessageType#getReplyBy <em>Reply By</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Reply By</em>' containment reference.
	 * @see #getReplyBy()
	 * @generated
	 */
	void setReplyBy(ReplyByType value);

	/**
	 * Returns the value of the '<em><b>Reply To</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Reply To</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Reply To</em>' containment reference.
	 * @see #setReplyTo(ReplyToType)
	 * @see schema.SchemaPackage#getFipaMessageType_ReplyTo()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='reply-to' namespace='##targetNamespace'"
	 * @generated
	 */
	ReplyToType getReplyTo();

	/**
	 * Sets the value of the '{@link schema.FipaMessageType#getReplyTo <em>Reply To</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Reply To</em>' containment reference.
	 * @see #getReplyTo()
	 * @generated
	 */
	void setReplyTo(ReplyToType value);

	/**
	 * Returns the value of the '<em><b>Conversation Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Conversation Id</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Conversation Id</em>' attribute.
	 * @see #setConversationId(String)
	 * @see schema.SchemaPackage#getFipaMessageType_ConversationId()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.String"
	 *        extendedMetaData="kind='element' name='conversation-id' namespace='##targetNamespace'"
	 * @generated
	 */
	String getConversationId();

	/**
	 * Sets the value of the '{@link schema.FipaMessageType#getConversationId <em>Conversation Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Conversation Id</em>' attribute.
	 * @see #getConversationId()
	 * @generated
	 */
	void setConversationId(String value);

	/**
	 * Returns the value of the '<em><b>User Defined</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>User Defined</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>User Defined</em>' containment reference.
	 * @see #setUserDefined(UserDefinedType)
	 * @see schema.SchemaPackage#getFipaMessageType_UserDefined()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='user-defined' namespace='##targetNamespace'"
	 * @generated
	 */
	UserDefinedType getUserDefined();

	/**
	 * Sets the value of the '{@link schema.FipaMessageType#getUserDefined <em>User Defined</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>User Defined</em>' containment reference.
	 * @see #getUserDefined()
	 * @generated
	 */
	void setUserDefined(UserDefinedType value);

	/**
	 * Returns the value of the '<em><b>Act</b></em>' attribute.
	 * The default value is <code>"ACCEPT-PROPOSAL"</code>.
	 * The literals are from the enumeration {@link schema.ActType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Act</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Act</em>' attribute.
	 * @see schema.ActType
	 * @see #isSetAct()
	 * @see #unsetAct()
	 * @see #setAct(ActType)
	 * @see schema.SchemaPackage#getFipaMessageType_Act()
	 * @model default="ACCEPT-PROPOSAL" unsettable="true" required="true"
	 *        extendedMetaData="kind='attribute' name='act'"
	 * @generated
	 */
	ActType getAct();

	/**
	 * Sets the value of the '{@link schema.FipaMessageType#getAct <em>Act</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Act</em>' attribute.
	 * @see schema.ActType
	 * @see #isSetAct()
	 * @see #unsetAct()
	 * @see #getAct()
	 * @generated
	 */
	void setAct(ActType value);

	/**
	 * Unsets the value of the '{@link schema.FipaMessageType#getAct <em>Act</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetAct()
	 * @see #getAct()
	 * @see #setAct(ActType)
	 * @generated
	 */
	void unsetAct();

	/**
	 * Returns whether the value of the '{@link schema.FipaMessageType#getAct <em>Act</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Act</em>' attribute is set.
	 * @see #unsetAct()
	 * @see #getAct()
	 * @see #setAct(ActType)
	 * @generated
	 */
	boolean isSetAct();

	/**
	 * Returns the value of the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Id</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Id</em>' attribute.
	 * @see #setId(String)
	 * @see schema.SchemaPackage#getFipaMessageType_Id()
	 * @model id="true" dataType="org.eclipse.emf.ecore.xml.type.ID"
	 *        extendedMetaData="kind='attribute' name='id'"
	 * @generated
	 */
	String getId();

	/**
	 * Sets the value of the '{@link schema.FipaMessageType#getId <em>Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Id</em>' attribute.
	 * @see #getId()
	 * @generated
	 */
	void setId(String value);

} // FipaMessageType
