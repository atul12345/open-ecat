/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package schema;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.Enumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>Act Type</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see schema.SchemaPackage#getActType()
 * @model extendedMetaData="name='act_._type'"
 * @generated
 */
public enum ActType implements Enumerator {
	/**
	 * The '<em><b>ACCEPTPROPOSAL</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #ACCEPTPROPOSAL_VALUE
	 * @generated
	 * @ordered
	 */
	ACCEPTPROPOSAL(0, "ACCEPTPROPOSAL", "ACCEPT-PROPOSAL"),

	/**
	 * The '<em><b>AGREE</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #AGREE_VALUE
	 * @generated
	 * @ordered
	 */
	AGREE(1, "AGREE", "AGREE"),

	/**
	 * The '<em><b>CANCEL</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #CANCEL_VALUE
	 * @generated
	 * @ordered
	 */
	CANCEL(2, "CANCEL", "CANCEL"),

	/**
	 * The '<em><b>CFP</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #CFP_VALUE
	 * @generated
	 * @ordered
	 */
	CFP(3, "CFP", "CFP"),

	/**
	 * The '<em><b>CONFIRM</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #CONFIRM_VALUE
	 * @generated
	 * @ordered
	 */
	CONFIRM(4, "CONFIRM", "CONFIRM"),

	/**
	 * The '<em><b>DISCONFIRM</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #DISCONFIRM_VALUE
	 * @generated
	 * @ordered
	 */
	DISCONFIRM(5, "DISCONFIRM", "DISCONFIRM"),

	/**
	 * The '<em><b>FAILURE</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #FAILURE_VALUE
	 * @generated
	 * @ordered
	 */
	FAILURE(6, "FAILURE", "FAILURE"),

	/**
	 * The '<em><b>INFORM</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #INFORM_VALUE
	 * @generated
	 * @ordered
	 */
	INFORM(7, "INFORM", "INFORM"),

	/**
	 * The '<em><b>NOTUNDERSTOOD</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #NOTUNDERSTOOD_VALUE
	 * @generated
	 * @ordered
	 */
	NOTUNDERSTOOD(8, "NOTUNDERSTOOD", "NOT-UNDERSTOOD"),

	/**
	 * The '<em><b>PROPOSE</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #PROPOSE_VALUE
	 * @generated
	 * @ordered
	 */
	PROPOSE(9, "PROPOSE", "PROPOSE"),

	/**
	 * The '<em><b>QUERYIF</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #QUERYIF_VALUE
	 * @generated
	 * @ordered
	 */
	QUERYIF(10, "QUERYIF", "QUERY-IF"),

	/**
	 * The '<em><b>QUERYREF</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #QUERYREF_VALUE
	 * @generated
	 * @ordered
	 */
	QUERYREF(11, "QUERYREF", "QUERY-REF"),

	/**
	 * The '<em><b>REFUSE</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #REFUSE_VALUE
	 * @generated
	 * @ordered
	 */
	REFUSE(12, "REFUSE", "REFUSE"),

	/**
	 * The '<em><b>REJECTPROPOSAL</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #REJECTPROPOSAL_VALUE
	 * @generated
	 * @ordered
	 */
	REJECTPROPOSAL(13, "REJECTPROPOSAL", "REJECT-PROPOSAL"),

	/**
	 * The '<em><b>REQUEST</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #REQUEST_VALUE
	 * @generated
	 * @ordered
	 */
	REQUEST(14, "REQUEST", "REQUEST"),

	/**
	 * The '<em><b>REQUESTWHEN</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #REQUESTWHEN_VALUE
	 * @generated
	 * @ordered
	 */
	REQUESTWHEN(15, "REQUESTWHEN", "REQUEST-WHEN"),

	/**
	 * The '<em><b>REQUESTWHENEVER</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #REQUESTWHENEVER_VALUE
	 * @generated
	 * @ordered
	 */
	REQUESTWHENEVER(16, "REQUESTWHENEVER", "REQUEST-WHENEVER"),

	/**
	 * The '<em><b>SUBSCRIBE</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #SUBSCRIBE_VALUE
	 * @generated
	 * @ordered
	 */
	SUBSCRIBE(17, "SUBSCRIBE", "SUBSCRIBE"),

	/**
	 * The '<em><b>INFORMIF</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #INFORMIF_VALUE
	 * @generated
	 * @ordered
	 */
	INFORMIF(18, "INFORMIF", "INFORM-IF"),

	/**
	 * The '<em><b>INFORMREF</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #INFORMREF_VALUE
	 * @generated
	 * @ordered
	 */
	INFORMREF(19, "INFORMREF", "INFORM-REF"),

	/**
	 * The '<em><b>PROXY</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #PROXY_VALUE
	 * @generated
	 * @ordered
	 */
	PROXY(20, "PROXY", "PROXY"),

	/**
	 * The '<em><b>PROPAGATE</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #PROPAGATE_VALUE
	 * @generated
	 * @ordered
	 */
	PROPAGATE(21, "PROPAGATE", "PROPAGATE");

	/**
	 * The '<em><b>ACCEPTPROPOSAL</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>ACCEPTPROPOSAL</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #ACCEPTPROPOSAL
	 * @model literal="ACCEPT-PROPOSAL"
	 * @generated
	 * @ordered
	 */
	public static final int ACCEPTPROPOSAL_VALUE = 0;

	/**
	 * The '<em><b>AGREE</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>AGREE</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #AGREE
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int AGREE_VALUE = 1;

	/**
	 * The '<em><b>CANCEL</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>CANCEL</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #CANCEL
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int CANCEL_VALUE = 2;

	/**
	 * The '<em><b>CFP</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>CFP</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #CFP
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int CFP_VALUE = 3;

	/**
	 * The '<em><b>CONFIRM</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>CONFIRM</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #CONFIRM
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int CONFIRM_VALUE = 4;

	/**
	 * The '<em><b>DISCONFIRM</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>DISCONFIRM</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #DISCONFIRM
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int DISCONFIRM_VALUE = 5;

	/**
	 * The '<em><b>FAILURE</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>FAILURE</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #FAILURE
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int FAILURE_VALUE = 6;

	/**
	 * The '<em><b>INFORM</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>INFORM</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #INFORM
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int INFORM_VALUE = 7;

	/**
	 * The '<em><b>NOTUNDERSTOOD</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>NOTUNDERSTOOD</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #NOTUNDERSTOOD
	 * @model literal="NOT-UNDERSTOOD"
	 * @generated
	 * @ordered
	 */
	public static final int NOTUNDERSTOOD_VALUE = 8;

	/**
	 * The '<em><b>PROPOSE</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>PROPOSE</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #PROPOSE
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int PROPOSE_VALUE = 9;

	/**
	 * The '<em><b>QUERYIF</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>QUERYIF</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #QUERYIF
	 * @model literal="QUERY-IF"
	 * @generated
	 * @ordered
	 */
	public static final int QUERYIF_VALUE = 10;

	/**
	 * The '<em><b>QUERYREF</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>QUERYREF</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #QUERYREF
	 * @model literal="QUERY-REF"
	 * @generated
	 * @ordered
	 */
	public static final int QUERYREF_VALUE = 11;

	/**
	 * The '<em><b>REFUSE</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>REFUSE</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #REFUSE
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int REFUSE_VALUE = 12;

	/**
	 * The '<em><b>REJECTPROPOSAL</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>REJECTPROPOSAL</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #REJECTPROPOSAL
	 * @model literal="REJECT-PROPOSAL"
	 * @generated
	 * @ordered
	 */
	public static final int REJECTPROPOSAL_VALUE = 13;

	/**
	 * The '<em><b>REQUEST</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>REQUEST</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #REQUEST
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int REQUEST_VALUE = 14;

	/**
	 * The '<em><b>REQUESTWHEN</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>REQUESTWHEN</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #REQUESTWHEN
	 * @model literal="REQUEST-WHEN"
	 * @generated
	 * @ordered
	 */
	public static final int REQUESTWHEN_VALUE = 15;

	/**
	 * The '<em><b>REQUESTWHENEVER</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>REQUESTWHENEVER</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #REQUESTWHENEVER
	 * @model literal="REQUEST-WHENEVER"
	 * @generated
	 * @ordered
	 */
	public static final int REQUESTWHENEVER_VALUE = 16;

	/**
	 * The '<em><b>SUBSCRIBE</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>SUBSCRIBE</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #SUBSCRIBE
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int SUBSCRIBE_VALUE = 17;

	/**
	 * The '<em><b>INFORMIF</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>INFORMIF</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #INFORMIF
	 * @model literal="INFORM-IF"
	 * @generated
	 * @ordered
	 */
	public static final int INFORMIF_VALUE = 18;

	/**
	 * The '<em><b>INFORMREF</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>INFORMREF</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #INFORMREF
	 * @model literal="INFORM-REF"
	 * @generated
	 * @ordered
	 */
	public static final int INFORMREF_VALUE = 19;

	/**
	 * The '<em><b>PROXY</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>PROXY</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #PROXY
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int PROXY_VALUE = 20;

	/**
	 * The '<em><b>PROPAGATE</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>PROPAGATE</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #PROPAGATE
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int PROPAGATE_VALUE = 21;

	/**
	 * An array of all the '<em><b>Act Type</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final ActType[] VALUES_ARRAY =
		new ActType[] {
			ACCEPTPROPOSAL,
			AGREE,
			CANCEL,
			CFP,
			CONFIRM,
			DISCONFIRM,
			FAILURE,
			INFORM,
			NOTUNDERSTOOD,
			PROPOSE,
			QUERYIF,
			QUERYREF,
			REFUSE,
			REJECTPROPOSAL,
			REQUEST,
			REQUESTWHEN,
			REQUESTWHENEVER,
			SUBSCRIBE,
			INFORMIF,
			INFORMREF,
			PROXY,
			PROPAGATE,
		};

	/**
	 * A public read-only list of all the '<em><b>Act Type</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final List<ActType> VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>Act Type</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static ActType get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			ActType result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Act Type</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static ActType getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			ActType result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Act Type</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static ActType get(int value) {
		switch (value) {
			case ACCEPTPROPOSAL_VALUE: return ACCEPTPROPOSAL;
			case AGREE_VALUE: return AGREE;
			case CANCEL_VALUE: return CANCEL;
			case CFP_VALUE: return CFP;
			case CONFIRM_VALUE: return CONFIRM;
			case DISCONFIRM_VALUE: return DISCONFIRM;
			case FAILURE_VALUE: return FAILURE;
			case INFORM_VALUE: return INFORM;
			case NOTUNDERSTOOD_VALUE: return NOTUNDERSTOOD;
			case PROPOSE_VALUE: return PROPOSE;
			case QUERYIF_VALUE: return QUERYIF;
			case QUERYREF_VALUE: return QUERYREF;
			case REFUSE_VALUE: return REFUSE;
			case REJECTPROPOSAL_VALUE: return REJECTPROPOSAL;
			case REQUEST_VALUE: return REQUEST;
			case REQUESTWHEN_VALUE: return REQUESTWHEN;
			case REQUESTWHENEVER_VALUE: return REQUESTWHENEVER;
			case SUBSCRIBE_VALUE: return SUBSCRIBE;
			case INFORMIF_VALUE: return INFORMIF;
			case INFORMREF_VALUE: return INFORMREF;
			case PROXY_VALUE: return PROXY;
			case PROPAGATE_VALUE: return PROPAGATE;
		}
		return null;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final int value;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String name;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String literal;

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private ActType(int value, String name, String literal) {
		this.value = value;
		this.name = name;
		this.literal = literal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getValue() {
	  return value;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
	  return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLiteral() {
	  return literal;
	}

	/**
	 * Returns the literal value of the enumerator, which is its string representation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		return literal;
	}
	
} //ActType
