/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package schema;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see schema.SchemaPackage
 * @generated
 */
public interface SchemaFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	SchemaFactory eINSTANCE = schema.impl.SchemaFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>Addresses Type</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Addresses Type</em>'.
	 * @generated
	 */
	AddressesType createAddressesType();

	/**
	 * Returns a new object of class '<em>Agent Identifier Type</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Agent Identifier Type</em>'.
	 * @generated
	 */
	AgentIdentifierType createAgentIdentifierType();

	/**
	 * Returns a new object of class '<em>Content Type</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Content Type</em>'.
	 * @generated
	 */
	ContentType createContentType();

	/**
	 * Returns a new object of class '<em>Document Root</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Document Root</em>'.
	 * @generated
	 */
	DocumentRoot createDocumentRoot();

	/**
	 * Returns a new object of class '<em>Fipa Message Type</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Fipa Message Type</em>'.
	 * @generated
	 */
	FipaMessageType createFipaMessageType();

	/**
	 * Returns a new object of class '<em>Receiver Type</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Receiver Type</em>'.
	 * @generated
	 */
	ReceiverType createReceiverType();

	/**
	 * Returns a new object of class '<em>Reply By Type</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Reply By Type</em>'.
	 * @generated
	 */
	ReplyByType createReplyByType();

	/**
	 * Returns a new object of class '<em>Reply To Type</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Reply To Type</em>'.
	 * @generated
	 */
	ReplyToType createReplyToType();

	/**
	 * Returns a new object of class '<em>Resolvers Type</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Resolvers Type</em>'.
	 * @generated
	 */
	ResolversType createResolversType();

	/**
	 * Returns a new object of class '<em>Sender Type</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Sender Type</em>'.
	 * @generated
	 */
	SenderType createSenderType();

	/**
	 * Returns a new object of class '<em>Url Type</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Url Type</em>'.
	 * @generated
	 */
	UrlType createUrlType();

	/**
	 * Returns a new object of class '<em>User Defined Type</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>User Defined Type</em>'.
	 * @generated
	 */
	UserDefinedType createUserDefinedType();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	SchemaPackage getSchemaPackage();

} //SchemaFactory
