/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package schema;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sender Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link schema.SenderType#getAgentIdentifier <em>Agent Identifier</em>}</li>
 * </ul>
 * </p>
 *
 * @see schema.SchemaPackage#getSenderType()
 * @model extendedMetaData="name='SenderType' kind='elementOnly'"
 * @generated
 */
public interface SenderType extends EObject {
	/**
	 * Returns the value of the '<em><b>Agent Identifier</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Agent Identifier</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Agent Identifier</em>' containment reference.
	 * @see #setAgentIdentifier(AgentIdentifierType)
	 * @see schema.SchemaPackage#getSenderType_AgentIdentifier()
	 * @model containment="true" required="true"
	 *        extendedMetaData="kind='element' name='agent-identifier' namespace='##targetNamespace'"
	 * @generated
	 */
	AgentIdentifierType getAgentIdentifier();

	/**
	 * Sets the value of the '{@link schema.SenderType#getAgentIdentifier <em>Agent Identifier</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Agent Identifier</em>' containment reference.
	 * @see #getAgentIdentifier()
	 * @generated
	 */
	void setAgentIdentifier(AgentIdentifierType value);

} // SenderType
