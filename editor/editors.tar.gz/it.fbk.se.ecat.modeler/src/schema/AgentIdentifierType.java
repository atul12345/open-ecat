/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package schema;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Agent Identifier Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link schema.AgentIdentifierType#getName <em>Name</em>}</li>
 *   <li>{@link schema.AgentIdentifierType#getAddresses <em>Addresses</em>}</li>
 *   <li>{@link schema.AgentIdentifierType#getResolvers <em>Resolvers</em>}</li>
 *   <li>{@link schema.AgentIdentifierType#getUserDefined <em>User Defined</em>}</li>
 * </ul>
 * </p>
 *
 * @see schema.SchemaPackage#getAgentIdentifierType()
 * @model extendedMetaData="name='Agent-identifierType' kind='elementOnly'"
 * @generated
 */
public interface AgentIdentifierType extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see schema.SchemaPackage#getAgentIdentifierType_Name()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.String" required="true"
	 *        extendedMetaData="kind='element' name='name' namespace='##targetNamespace'"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link schema.AgentIdentifierType#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Addresses</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Addresses</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Addresses</em>' containment reference.
	 * @see #setAddresses(AddressesType)
	 * @see schema.SchemaPackage#getAgentIdentifierType_Addresses()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='addresses' namespace='##targetNamespace'"
	 * @generated
	 */
	AddressesType getAddresses();

	/**
	 * Sets the value of the '{@link schema.AgentIdentifierType#getAddresses <em>Addresses</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Addresses</em>' containment reference.
	 * @see #getAddresses()
	 * @generated
	 */
	void setAddresses(AddressesType value);

	/**
	 * Returns the value of the '<em><b>Resolvers</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Resolvers</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Resolvers</em>' containment reference.
	 * @see #setResolvers(EObject)
	 * @see schema.SchemaPackage#getAgentIdentifierType_Resolvers()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='resolvers' namespace='##targetNamespace'"
	 * @generated
	 */
	EObject getResolvers();

	/**
	 * Sets the value of the '{@link schema.AgentIdentifierType#getResolvers <em>Resolvers</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Resolvers</em>' containment reference.
	 * @see #getResolvers()
	 * @generated
	 */
	void setResolvers(EObject value);

	/**
	 * Returns the value of the '<em><b>User Defined</b></em>' containment reference list.
	 * The list contents are of type {@link schema.UserDefinedType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>User Defined</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>User Defined</em>' containment reference list.
	 * @see schema.SchemaPackage#getAgentIdentifierType_UserDefined()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='user-defined' namespace='##targetNamespace'"
	 * @generated
	 */
	EList<UserDefinedType> getUserDefined();

} // AgentIdentifierType
