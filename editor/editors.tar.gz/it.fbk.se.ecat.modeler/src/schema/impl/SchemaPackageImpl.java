/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package schema.impl;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

import org.eclipse.emf.ecore.xml.type.XMLTypePackage;

import schema.ActType;
import schema.AddressesType;
import schema.AgentIdentifierType;
import schema.ContentType;
import schema.DocumentRoot;
import schema.FipaMessageType;
import schema.ReceiverType;
import schema.ReplyByType;
import schema.ReplyToType;
import schema.ResolversType;
import schema.SchemaFactory;
import schema.SchemaPackage;
import schema.SenderType;
import schema.UrlType;
import schema.UserDefinedType;

import suite.SuitePackage;

import suite.impl.SuitePackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class SchemaPackageImpl extends EPackageImpl implements SchemaPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass addressesTypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass agentIdentifierTypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass contentTypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass documentRootEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass fipaMessageTypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass receiverTypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass replyByTypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass replyToTypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass resolversTypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass senderTypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass urlTypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass userDefinedTypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum actTypeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType actTypeObjectEDataType = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see schema.SchemaPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private SchemaPackageImpl() {
		super(eNS_URI, SchemaFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this
	 * model, and for any others upon which it depends.  Simple
	 * dependencies are satisfied by calling this method on all
	 * dependent packages before doing anything else.  This method drives
	 * initialization for interdependent packages directly, in parallel
	 * with this package, itself.
	 * <p>Of this package and its interdependencies, all packages which
	 * have not yet been registered by their URI values are first created
	 * and registered.  The packages are then initialized in two steps:
	 * meta-model objects for all of the packages are created before any
	 * are initialized, since one package's meta-model objects may refer to
	 * those of another.
	 * <p>Invocation of this method will not affect any packages that have
	 * already been initialized.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static SchemaPackage init() {
		if (isInited) return (SchemaPackage)EPackage.Registry.INSTANCE.getEPackage(SchemaPackage.eNS_URI);

		// Obtain or create and register package
		SchemaPackageImpl theSchemaPackage = (SchemaPackageImpl)(EPackage.Registry.INSTANCE.getEPackage(eNS_URI) instanceof SchemaPackageImpl ? EPackage.Registry.INSTANCE.getEPackage(eNS_URI) : new SchemaPackageImpl());

		isInited = true;

		// Initialize simple dependencies
		XMLTypePackage.eINSTANCE.eClass();

		// Obtain or create and register interdependencies
		SuitePackageImpl theSuitePackage = (SuitePackageImpl)(EPackage.Registry.INSTANCE.getEPackage(SuitePackage.eNS_URI) instanceof SuitePackageImpl ? EPackage.Registry.INSTANCE.getEPackage(SuitePackage.eNS_URI) : SuitePackage.eINSTANCE);

		// Create package meta-data objects
		theSchemaPackage.createPackageContents();
		theSuitePackage.createPackageContents();

		// Initialize created meta-data
		theSchemaPackage.initializePackageContents();
		theSuitePackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theSchemaPackage.freeze();

		return theSchemaPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAddressesType() {
		return addressesTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAddressesType_Url() {
		return (EReference)addressesTypeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAgentIdentifierType() {
		return agentIdentifierTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAgentIdentifierType_Name() {
		return (EAttribute)agentIdentifierTypeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAgentIdentifierType_Addresses() {
		return (EReference)agentIdentifierTypeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAgentIdentifierType_Resolvers() {
		return (EReference)agentIdentifierTypeEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAgentIdentifierType_UserDefined() {
		return (EReference)agentIdentifierTypeEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getContentType() {
		return contentTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getContentType_Value() {
		return (EAttribute)contentTypeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getContentType_Valueref() {
		return (EAttribute)contentTypeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getContentType_Class() {
		return (EAttribute)contentTypeEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getContentType_Id() {
		return (EAttribute)contentTypeEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDocumentRoot() {
		return documentRootEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDocumentRoot_Mixed() {
		return (EAttribute)documentRootEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDocumentRoot_XMLNSPrefixMap() {
		return (EReference)documentRootEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDocumentRoot_XSISchemaLocation() {
		return (EReference)documentRootEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDocumentRoot_FipaMessage() {
		return (EReference)documentRootEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getFipaMessageType() {
		return fipaMessageTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getFipaMessageType_Sender() {
		return (EReference)fipaMessageTypeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getFipaMessageType_Receiver() {
		return (EReference)fipaMessageTypeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getFipaMessageType_Content() {
		return (EReference)fipaMessageTypeEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getFipaMessageType_Language() {
		return (EAttribute)fipaMessageTypeEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getFipaMessageType_Encoding() {
		return (EAttribute)fipaMessageTypeEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getFipaMessageType_Ontology() {
		return (EAttribute)fipaMessageTypeEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getFipaMessageType_Protocol() {
		return (EAttribute)fipaMessageTypeEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getFipaMessageType_ReplyWith() {
		return (EAttribute)fipaMessageTypeEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getFipaMessageType_InReplyTo() {
		return (EAttribute)fipaMessageTypeEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getFipaMessageType_ReplyBy() {
		return (EReference)fipaMessageTypeEClass.getEStructuralFeatures().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getFipaMessageType_ReplyTo() {
		return (EReference)fipaMessageTypeEClass.getEStructuralFeatures().get(10);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getFipaMessageType_ConversationId() {
		return (EAttribute)fipaMessageTypeEClass.getEStructuralFeatures().get(11);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getFipaMessageType_UserDefined() {
		return (EReference)fipaMessageTypeEClass.getEStructuralFeatures().get(12);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getFipaMessageType_Act() {
		return (EAttribute)fipaMessageTypeEClass.getEStructuralFeatures().get(13);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getFipaMessageType_Id() {
		return (EAttribute)fipaMessageTypeEClass.getEStructuralFeatures().get(14);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getReceiverType() {
		return receiverTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getReceiverType_AgentIdentifier() {
		return (EReference)receiverTypeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getReplyByType() {
		return replyByTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getReplyByType_Href() {
		return (EAttribute)replyByTypeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getReplyByType_Time() {
		return (EAttribute)replyByTypeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getReplyToType() {
		return replyToTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getReplyToType_AgentIdentifier() {
		return (EReference)replyToTypeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getResolversType() {
		return resolversTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getResolversType_AgentIdentifier() {
		return (EReference)resolversTypeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSenderType() {
		return senderTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getSenderType_AgentIdentifier() {
		return (EReference)senderTypeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getUrlType() {
		return urlTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getUrlType_Href() {
		return (EAttribute)urlTypeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getUserDefinedType() {
		return userDefinedTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getUserDefinedType_Mixed() {
		return (EAttribute)userDefinedTypeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getUserDefinedType_Href() {
		return (EAttribute)userDefinedTypeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getActType() {
		return actTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getActTypeObject() {
		return actTypeObjectEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SchemaFactory getSchemaFactory() {
		return (SchemaFactory)getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated) return;
		isCreated = true;

		// Create classes and their features
		addressesTypeEClass = createEClass(ADDRESSES_TYPE);
		createEReference(addressesTypeEClass, ADDRESSES_TYPE__URL);

		agentIdentifierTypeEClass = createEClass(AGENT_IDENTIFIER_TYPE);
		createEAttribute(agentIdentifierTypeEClass, AGENT_IDENTIFIER_TYPE__NAME);
		createEReference(agentIdentifierTypeEClass, AGENT_IDENTIFIER_TYPE__ADDRESSES);
		createEReference(agentIdentifierTypeEClass, AGENT_IDENTIFIER_TYPE__RESOLVERS);
		createEReference(agentIdentifierTypeEClass, AGENT_IDENTIFIER_TYPE__USER_DEFINED);

		contentTypeEClass = createEClass(CONTENT_TYPE);
		createEAttribute(contentTypeEClass, CONTENT_TYPE__VALUE);
		createEAttribute(contentTypeEClass, CONTENT_TYPE__VALUEREF);
		createEAttribute(contentTypeEClass, CONTENT_TYPE__CLASS);
		createEAttribute(contentTypeEClass, CONTENT_TYPE__ID);

		documentRootEClass = createEClass(DOCUMENT_ROOT);
		createEAttribute(documentRootEClass, DOCUMENT_ROOT__MIXED);
		createEReference(documentRootEClass, DOCUMENT_ROOT__XMLNS_PREFIX_MAP);
		createEReference(documentRootEClass, DOCUMENT_ROOT__XSI_SCHEMA_LOCATION);
		createEReference(documentRootEClass, DOCUMENT_ROOT__FIPA_MESSAGE);

		fipaMessageTypeEClass = createEClass(FIPA_MESSAGE_TYPE);
		createEReference(fipaMessageTypeEClass, FIPA_MESSAGE_TYPE__SENDER);
		createEReference(fipaMessageTypeEClass, FIPA_MESSAGE_TYPE__RECEIVER);
		createEReference(fipaMessageTypeEClass, FIPA_MESSAGE_TYPE__CONTENT);
		createEAttribute(fipaMessageTypeEClass, FIPA_MESSAGE_TYPE__LANGUAGE);
		createEAttribute(fipaMessageTypeEClass, FIPA_MESSAGE_TYPE__ENCODING);
		createEAttribute(fipaMessageTypeEClass, FIPA_MESSAGE_TYPE__ONTOLOGY);
		createEAttribute(fipaMessageTypeEClass, FIPA_MESSAGE_TYPE__PROTOCOL);
		createEAttribute(fipaMessageTypeEClass, FIPA_MESSAGE_TYPE__REPLY_WITH);
		createEAttribute(fipaMessageTypeEClass, FIPA_MESSAGE_TYPE__IN_REPLY_TO);
		createEReference(fipaMessageTypeEClass, FIPA_MESSAGE_TYPE__REPLY_BY);
		createEReference(fipaMessageTypeEClass, FIPA_MESSAGE_TYPE__REPLY_TO);
		createEAttribute(fipaMessageTypeEClass, FIPA_MESSAGE_TYPE__CONVERSATION_ID);
		createEReference(fipaMessageTypeEClass, FIPA_MESSAGE_TYPE__USER_DEFINED);
		createEAttribute(fipaMessageTypeEClass, FIPA_MESSAGE_TYPE__ACT);
		createEAttribute(fipaMessageTypeEClass, FIPA_MESSAGE_TYPE__ID);

		receiverTypeEClass = createEClass(RECEIVER_TYPE);
		createEReference(receiverTypeEClass, RECEIVER_TYPE__AGENT_IDENTIFIER);

		replyByTypeEClass = createEClass(REPLY_BY_TYPE);
		createEAttribute(replyByTypeEClass, REPLY_BY_TYPE__HREF);
		createEAttribute(replyByTypeEClass, REPLY_BY_TYPE__TIME);

		replyToTypeEClass = createEClass(REPLY_TO_TYPE);
		createEReference(replyToTypeEClass, REPLY_TO_TYPE__AGENT_IDENTIFIER);

		resolversTypeEClass = createEClass(RESOLVERS_TYPE);
		createEReference(resolversTypeEClass, RESOLVERS_TYPE__AGENT_IDENTIFIER);

		senderTypeEClass = createEClass(SENDER_TYPE);
		createEReference(senderTypeEClass, SENDER_TYPE__AGENT_IDENTIFIER);

		urlTypeEClass = createEClass(URL_TYPE);
		createEAttribute(urlTypeEClass, URL_TYPE__HREF);

		userDefinedTypeEClass = createEClass(USER_DEFINED_TYPE);
		createEAttribute(userDefinedTypeEClass, USER_DEFINED_TYPE__MIXED);
		createEAttribute(userDefinedTypeEClass, USER_DEFINED_TYPE__HREF);

		// Create enums
		actTypeEEnum = createEEnum(ACT_TYPE);

		// Create data types
		actTypeObjectEDataType = createEDataType(ACT_TYPE_OBJECT);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized) return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Obtain other dependent packages
		XMLTypePackage theXMLTypePackage = (XMLTypePackage)EPackage.Registry.INSTANCE.getEPackage(XMLTypePackage.eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes

		// Initialize classes and features; add operations and parameters
		initEClass(addressesTypeEClass, AddressesType.class, "AddressesType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getAddressesType_Url(), this.getUrlType(), null, "url", null, 1, -1, AddressesType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(agentIdentifierTypeEClass, AgentIdentifierType.class, "AgentIdentifierType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getAgentIdentifierType_Name(), theXMLTypePackage.getString(), "name", null, 1, 1, AgentIdentifierType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getAgentIdentifierType_Addresses(), this.getAddressesType(), null, "addresses", null, 0, 1, AgentIdentifierType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getAgentIdentifierType_Resolvers(), ecorePackage.getEObject(), null, "resolvers", null, 0, 1, AgentIdentifierType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getAgentIdentifierType_UserDefined(), this.getUserDefinedType(), null, "userDefined", null, 0, -1, AgentIdentifierType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(contentTypeEClass, ContentType.class, "ContentType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getContentType_Value(), theXMLTypePackage.getString(), "value", null, 0, 1, ContentType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getContentType_Valueref(), theXMLTypePackage.getIDREF(), "valueref", null, 0, 1, ContentType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getContentType_Class(), theXMLTypePackage.getString(), "class", null, 1, 1, ContentType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getContentType_Id(), theXMLTypePackage.getID(), "id", null, 0, 1, ContentType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(documentRootEClass, DocumentRoot.class, "DocumentRoot", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getDocumentRoot_Mixed(), ecorePackage.getEFeatureMapEntry(), "mixed", null, 0, -1, null, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDocumentRoot_XMLNSPrefixMap(), ecorePackage.getEStringToStringMapEntry(), null, "xMLNSPrefixMap", null, 0, -1, null, IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDocumentRoot_XSISchemaLocation(), ecorePackage.getEStringToStringMapEntry(), null, "xSISchemaLocation", null, 0, -1, null, IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDocumentRoot_FipaMessage(), this.getFipaMessageType(), null, "fipaMessage", null, 0, -2, null, IS_TRANSIENT, IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, IS_DERIVED, IS_ORDERED);

		initEClass(fipaMessageTypeEClass, FipaMessageType.class, "FipaMessageType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getFipaMessageType_Sender(), this.getSenderType(), null, "sender", null, 0, 1, FipaMessageType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getFipaMessageType_Receiver(), this.getReceiverType(), null, "receiver", null, 0, 1, FipaMessageType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getFipaMessageType_Content(), this.getContentType(), null, "content", null, 1, 1, FipaMessageType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getFipaMessageType_Language(), theXMLTypePackage.getString(), "language", null, 0, 1, FipaMessageType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getFipaMessageType_Encoding(), theXMLTypePackage.getString(), "encoding", null, 0, 1, FipaMessageType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getFipaMessageType_Ontology(), theXMLTypePackage.getString(), "ontology", null, 0, 1, FipaMessageType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getFipaMessageType_Protocol(), theXMLTypePackage.getString(), "protocol", null, 0, 1, FipaMessageType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getFipaMessageType_ReplyWith(), theXMLTypePackage.getString(), "replyWith", null, 0, 1, FipaMessageType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getFipaMessageType_InReplyTo(), theXMLTypePackage.getString(), "inReplyTo", null, 0, 1, FipaMessageType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getFipaMessageType_ReplyBy(), this.getReplyByType(), null, "replyBy", null, 0, 1, FipaMessageType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getFipaMessageType_ReplyTo(), this.getReplyToType(), null, "replyTo", null, 0, 1, FipaMessageType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getFipaMessageType_ConversationId(), theXMLTypePackage.getString(), "conversationId", null, 0, 1, FipaMessageType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getFipaMessageType_UserDefined(), this.getUserDefinedType(), null, "userDefined", null, 0, 1, FipaMessageType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getFipaMessageType_Act(), this.getActType(), "act", "ACCEPT-PROPOSAL", 1, 1, FipaMessageType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getFipaMessageType_Id(), theXMLTypePackage.getID(), "id", null, 0, 1, FipaMessageType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(receiverTypeEClass, ReceiverType.class, "ReceiverType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getReceiverType_AgentIdentifier(), this.getAgentIdentifierType(), null, "agentIdentifier", null, 1, -1, ReceiverType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(replyByTypeEClass, ReplyByType.class, "ReplyByType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getReplyByType_Href(), theXMLTypePackage.getString(), "href", null, 0, 1, ReplyByType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getReplyByType_Time(), theXMLTypePackage.getString(), "time", null, 1, 1, ReplyByType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(replyToTypeEClass, ReplyToType.class, "ReplyToType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getReplyToType_AgentIdentifier(), this.getAgentIdentifierType(), null, "agentIdentifier", null, 1, -1, ReplyToType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(resolversTypeEClass, ResolversType.class, "ResolversType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getResolversType_AgentIdentifier(), this.getAgentIdentifierType(), null, "agentIdentifier", null, 1, -1, ResolversType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(senderTypeEClass, SenderType.class, "SenderType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getSenderType_AgentIdentifier(), this.getAgentIdentifierType(), null, "agentIdentifier", null, 1, 1, SenderType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(urlTypeEClass, UrlType.class, "UrlType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getUrlType_Href(), theXMLTypePackage.getString(), "href", null, 0, 1, UrlType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(userDefinedTypeEClass, UserDefinedType.class, "UserDefinedType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getUserDefinedType_Mixed(), ecorePackage.getEFeatureMapEntry(), "mixed", null, 0, -1, UserDefinedType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getUserDefinedType_Href(), theXMLTypePackage.getString(), "href", null, 0, 1, UserDefinedType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		// Initialize enums and add enum literals
		initEEnum(actTypeEEnum, ActType.class, "ActType");
		addEEnumLiteral(actTypeEEnum, ActType.ACCEPTPROPOSAL);
		addEEnumLiteral(actTypeEEnum, ActType.AGREE);
		addEEnumLiteral(actTypeEEnum, ActType.CANCEL);
		addEEnumLiteral(actTypeEEnum, ActType.CFP);
		addEEnumLiteral(actTypeEEnum, ActType.CONFIRM);
		addEEnumLiteral(actTypeEEnum, ActType.DISCONFIRM);
		addEEnumLiteral(actTypeEEnum, ActType.FAILURE);
		addEEnumLiteral(actTypeEEnum, ActType.INFORM);
		addEEnumLiteral(actTypeEEnum, ActType.NOTUNDERSTOOD);
		addEEnumLiteral(actTypeEEnum, ActType.PROPOSE);
		addEEnumLiteral(actTypeEEnum, ActType.QUERYIF);
		addEEnumLiteral(actTypeEEnum, ActType.QUERYREF);
		addEEnumLiteral(actTypeEEnum, ActType.REFUSE);
		addEEnumLiteral(actTypeEEnum, ActType.REJECTPROPOSAL);
		addEEnumLiteral(actTypeEEnum, ActType.REQUEST);
		addEEnumLiteral(actTypeEEnum, ActType.REQUESTWHEN);
		addEEnumLiteral(actTypeEEnum, ActType.REQUESTWHENEVER);
		addEEnumLiteral(actTypeEEnum, ActType.SUBSCRIBE);
		addEEnumLiteral(actTypeEEnum, ActType.INFORMIF);
		addEEnumLiteral(actTypeEEnum, ActType.INFORMREF);
		addEEnumLiteral(actTypeEEnum, ActType.PROXY);
		addEEnumLiteral(actTypeEEnum, ActType.PROPAGATE);

		// Initialize data types
		initEDataType(actTypeObjectEDataType, ActType.class, "ActTypeObject", IS_SERIALIZABLE, IS_GENERATED_INSTANCE_CLASS);

		// Create resource
		createResource(eNS_URI);

		// Create annotations
		// http:///org/eclipse/emf/ecore/util/ExtendedMetaData
		createExtendedMetaDataAnnotations();
	}

	/**
	 * Initializes the annotations for <b>http:///org/eclipse/emf/ecore/util/ExtendedMetaData</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createExtendedMetaDataAnnotations() {
		String source = "http:///org/eclipse/emf/ecore/util/ExtendedMetaData";		
		addAnnotation
		  (actTypeEEnum, 
		   source, 
		   new String[] {
			 "name", "act_._type"
		   });		
		addAnnotation
		  (actTypeObjectEDataType, 
		   source, 
		   new String[] {
			 "name", "act_._type:Object",
			 "baseType", "act_._type"
		   });		
		addAnnotation
		  (addressesTypeEClass, 
		   source, 
		   new String[] {
			 "name", "AddressesType",
			 "kind", "elementOnly"
		   });		
		addAnnotation
		  (getAddressesType_Url(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "url",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (agentIdentifierTypeEClass, 
		   source, 
		   new String[] {
			 "name", "Agent-identifierType",
			 "kind", "elementOnly"
		   });		
		addAnnotation
		  (getAgentIdentifierType_Name(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "name",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getAgentIdentifierType_Addresses(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "addresses",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getAgentIdentifierType_Resolvers(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "resolvers",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getAgentIdentifierType_UserDefined(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "user-defined",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (contentTypeEClass, 
		   source, 
		   new String[] {
			 "name", "ContentType",
			 "kind", "elementOnly"
		   });		
		addAnnotation
		  (getContentType_Value(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "value",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getContentType_Valueref(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "valueref",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getContentType_Class(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "class"
		   });		
		addAnnotation
		  (getContentType_Id(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "id"
		   });		
		addAnnotation
		  (documentRootEClass, 
		   source, 
		   new String[] {
			 "name", "",
			 "kind", "mixed"
		   });		
		addAnnotation
		  (getDocumentRoot_Mixed(), 
		   source, 
		   new String[] {
			 "kind", "elementWildcard",
			 "name", ":mixed"
		   });		
		addAnnotation
		  (getDocumentRoot_XMLNSPrefixMap(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "xmlns:prefix"
		   });		
		addAnnotation
		  (getDocumentRoot_XSISchemaLocation(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "xsi:schemaLocation"
		   });		
		addAnnotation
		  (getDocumentRoot_FipaMessage(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "fipa-message",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (fipaMessageTypeEClass, 
		   source, 
		   new String[] {
			 "name", "fipa-messageType",
			 "kind", "elementOnly"
		   });		
		addAnnotation
		  (getFipaMessageType_Sender(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "sender",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getFipaMessageType_Receiver(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "receiver",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getFipaMessageType_Content(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "content",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getFipaMessageType_Language(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "language",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getFipaMessageType_Encoding(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "encoding",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getFipaMessageType_Ontology(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "ontology",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getFipaMessageType_Protocol(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "protocol",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getFipaMessageType_ReplyWith(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "reply-with",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getFipaMessageType_InReplyTo(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "in-reply-to",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getFipaMessageType_ReplyBy(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "reply-by",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getFipaMessageType_ReplyTo(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "reply-to",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getFipaMessageType_ConversationId(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "conversation-id",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getFipaMessageType_UserDefined(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "user-defined",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getFipaMessageType_Act(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "act"
		   });		
		addAnnotation
		  (getFipaMessageType_Id(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "id"
		   });		
		addAnnotation
		  (receiverTypeEClass, 
		   source, 
		   new String[] {
			 "name", "ReceiverType",
			 "kind", "elementOnly"
		   });		
		addAnnotation
		  (getReceiverType_AgentIdentifier(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "agent-identifier",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (replyByTypeEClass, 
		   source, 
		   new String[] {
			 "name", "Reply-byType",
			 "kind", "empty"
		   });		
		addAnnotation
		  (getReplyByType_Href(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "href"
		   });		
		addAnnotation
		  (getReplyByType_Time(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "time"
		   });		
		addAnnotation
		  (replyToTypeEClass, 
		   source, 
		   new String[] {
			 "name", "Reply-toType",
			 "kind", "elementOnly"
		   });		
		addAnnotation
		  (getReplyToType_AgentIdentifier(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "agent-identifier",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (resolversTypeEClass, 
		   source, 
		   new String[] {
			 "name", "ResolversType",
			 "kind", "elementOnly"
		   });		
		addAnnotation
		  (getResolversType_AgentIdentifier(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "agent-identifier",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (senderTypeEClass, 
		   source, 
		   new String[] {
			 "name", "SenderType",
			 "kind", "elementOnly"
		   });		
		addAnnotation
		  (getSenderType_AgentIdentifier(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "agent-identifier",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (urlTypeEClass, 
		   source, 
		   new String[] {
			 "name", "UrlType",
			 "kind", "empty"
		   });		
		addAnnotation
		  (getUrlType_Href(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "href"
		   });		
		addAnnotation
		  (userDefinedTypeEClass, 
		   source, 
		   new String[] {
			 "name", "User-definedType",
			 "kind", "mixed"
		   });		
		addAnnotation
		  (getUserDefinedType_Mixed(), 
		   source, 
		   new String[] {
			 "kind", "elementWildcard",
			 "name", ":mixed"
		   });		
		addAnnotation
		  (getUserDefinedType_Href(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "href"
		   });
	}

} //SchemaPackageImpl
