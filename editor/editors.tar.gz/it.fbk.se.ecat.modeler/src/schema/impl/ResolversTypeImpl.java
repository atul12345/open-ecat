/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package schema.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import schema.AgentIdentifierType;
import schema.ResolversType;
import schema.SchemaPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Resolvers Type</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link schema.impl.ResolversTypeImpl#getAgentIdentifier <em>Agent Identifier</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class ResolversTypeImpl extends EObjectImpl implements ResolversType {
	/**
	 * The cached value of the '{@link #getAgentIdentifier() <em>Agent Identifier</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAgentIdentifier()
	 * @generated
	 * @ordered
	 */
	protected EList<AgentIdentifierType> agentIdentifier;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ResolversTypeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SchemaPackage.Literals.RESOLVERS_TYPE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<AgentIdentifierType> getAgentIdentifier() {
		if (agentIdentifier == null) {
			agentIdentifier = new EObjectContainmentEList<AgentIdentifierType>(AgentIdentifierType.class, this, SchemaPackage.RESOLVERS_TYPE__AGENT_IDENTIFIER);
		}
		return agentIdentifier;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case SchemaPackage.RESOLVERS_TYPE__AGENT_IDENTIFIER:
				return ((InternalEList<?>)getAgentIdentifier()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case SchemaPackage.RESOLVERS_TYPE__AGENT_IDENTIFIER:
				return getAgentIdentifier();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case SchemaPackage.RESOLVERS_TYPE__AGENT_IDENTIFIER:
				getAgentIdentifier().clear();
				getAgentIdentifier().addAll((Collection<? extends AgentIdentifierType>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case SchemaPackage.RESOLVERS_TYPE__AGENT_IDENTIFIER:
				getAgentIdentifier().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case SchemaPackage.RESOLVERS_TYPE__AGENT_IDENTIFIER:
				return agentIdentifier != null && !agentIdentifier.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //ResolversTypeImpl
