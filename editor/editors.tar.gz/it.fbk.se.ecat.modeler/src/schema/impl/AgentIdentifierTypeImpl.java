/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package schema.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import schema.AddressesType;
import schema.AgentIdentifierType;
import schema.SchemaPackage;
import schema.UserDefinedType;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Agent Identifier Type</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link schema.impl.AgentIdentifierTypeImpl#getName <em>Name</em>}</li>
 *   <li>{@link schema.impl.AgentIdentifierTypeImpl#getAddresses <em>Addresses</em>}</li>
 *   <li>{@link schema.impl.AgentIdentifierTypeImpl#getResolvers <em>Resolvers</em>}</li>
 *   <li>{@link schema.impl.AgentIdentifierTypeImpl#getUserDefined <em>User Defined</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class AgentIdentifierTypeImpl extends EObjectImpl implements AgentIdentifierType {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getAddresses() <em>Addresses</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAddresses()
	 * @generated
	 * @ordered
	 */
	protected AddressesType addresses;

	/**
	 * The cached value of the '{@link #getResolvers() <em>Resolvers</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getResolvers()
	 * @generated
	 * @ordered
	 */
	protected EObject resolvers;

	/**
	 * The cached value of the '{@link #getUserDefined() <em>User Defined</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getUserDefined()
	 * @generated
	 * @ordered
	 */
	protected EList<UserDefinedType> userDefined;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AgentIdentifierTypeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SchemaPackage.Literals.AGENT_IDENTIFIER_TYPE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SchemaPackage.AGENT_IDENTIFIER_TYPE__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AddressesType getAddresses() {
		return addresses;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetAddresses(AddressesType newAddresses, NotificationChain msgs) {
		AddressesType oldAddresses = addresses;
		addresses = newAddresses;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, SchemaPackage.AGENT_IDENTIFIER_TYPE__ADDRESSES, oldAddresses, newAddresses);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAddresses(AddressesType newAddresses) {
		if (newAddresses != addresses) {
			NotificationChain msgs = null;
			if (addresses != null)
				msgs = ((InternalEObject)addresses).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - SchemaPackage.AGENT_IDENTIFIER_TYPE__ADDRESSES, null, msgs);
			if (newAddresses != null)
				msgs = ((InternalEObject)newAddresses).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - SchemaPackage.AGENT_IDENTIFIER_TYPE__ADDRESSES, null, msgs);
			msgs = basicSetAddresses(newAddresses, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SchemaPackage.AGENT_IDENTIFIER_TYPE__ADDRESSES, newAddresses, newAddresses));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EObject getResolvers() {
		return resolvers;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetResolvers(EObject newResolvers, NotificationChain msgs) {
		EObject oldResolvers = resolvers;
		resolvers = newResolvers;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, SchemaPackage.AGENT_IDENTIFIER_TYPE__RESOLVERS, oldResolvers, newResolvers);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setResolvers(EObject newResolvers) {
		if (newResolvers != resolvers) {
			NotificationChain msgs = null;
			if (resolvers != null)
				msgs = ((InternalEObject)resolvers).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - SchemaPackage.AGENT_IDENTIFIER_TYPE__RESOLVERS, null, msgs);
			if (newResolvers != null)
				msgs = ((InternalEObject)newResolvers).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - SchemaPackage.AGENT_IDENTIFIER_TYPE__RESOLVERS, null, msgs);
			msgs = basicSetResolvers(newResolvers, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SchemaPackage.AGENT_IDENTIFIER_TYPE__RESOLVERS, newResolvers, newResolvers));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<UserDefinedType> getUserDefined() {
		if (userDefined == null) {
			userDefined = new EObjectContainmentEList<UserDefinedType>(UserDefinedType.class, this, SchemaPackage.AGENT_IDENTIFIER_TYPE__USER_DEFINED);
		}
		return userDefined;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case SchemaPackage.AGENT_IDENTIFIER_TYPE__ADDRESSES:
				return basicSetAddresses(null, msgs);
			case SchemaPackage.AGENT_IDENTIFIER_TYPE__RESOLVERS:
				return basicSetResolvers(null, msgs);
			case SchemaPackage.AGENT_IDENTIFIER_TYPE__USER_DEFINED:
				return ((InternalEList<?>)getUserDefined()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case SchemaPackage.AGENT_IDENTIFIER_TYPE__NAME:
				return getName();
			case SchemaPackage.AGENT_IDENTIFIER_TYPE__ADDRESSES:
				return getAddresses();
			case SchemaPackage.AGENT_IDENTIFIER_TYPE__RESOLVERS:
				return getResolvers();
			case SchemaPackage.AGENT_IDENTIFIER_TYPE__USER_DEFINED:
				return getUserDefined();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case SchemaPackage.AGENT_IDENTIFIER_TYPE__NAME:
				setName((String)newValue);
				return;
			case SchemaPackage.AGENT_IDENTIFIER_TYPE__ADDRESSES:
				setAddresses((AddressesType)newValue);
				return;
			case SchemaPackage.AGENT_IDENTIFIER_TYPE__RESOLVERS:
				setResolvers((EObject)newValue);
				return;
			case SchemaPackage.AGENT_IDENTIFIER_TYPE__USER_DEFINED:
				getUserDefined().clear();
				getUserDefined().addAll((Collection<? extends UserDefinedType>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case SchemaPackage.AGENT_IDENTIFIER_TYPE__NAME:
				setName(NAME_EDEFAULT);
				return;
			case SchemaPackage.AGENT_IDENTIFIER_TYPE__ADDRESSES:
				setAddresses((AddressesType)null);
				return;
			case SchemaPackage.AGENT_IDENTIFIER_TYPE__RESOLVERS:
				setResolvers((EObject)null);
				return;
			case SchemaPackage.AGENT_IDENTIFIER_TYPE__USER_DEFINED:
				getUserDefined().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case SchemaPackage.AGENT_IDENTIFIER_TYPE__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case SchemaPackage.AGENT_IDENTIFIER_TYPE__ADDRESSES:
				return addresses != null;
			case SchemaPackage.AGENT_IDENTIFIER_TYPE__RESOLVERS:
				return resolvers != null;
			case SchemaPackage.AGENT_IDENTIFIER_TYPE__USER_DEFINED:
				return userDefined != null && !userDefined.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //AgentIdentifierTypeImpl
