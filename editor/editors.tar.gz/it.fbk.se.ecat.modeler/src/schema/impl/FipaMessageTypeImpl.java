/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package schema.impl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import schema.ActType;
import schema.ContentType;
import schema.FipaMessageType;
import schema.ReceiverType;
import schema.ReplyByType;
import schema.ReplyToType;
import schema.SchemaPackage;
import schema.SenderType;
import schema.UserDefinedType;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Fipa Message Type</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link schema.impl.FipaMessageTypeImpl#getSender <em>Sender</em>}</li>
 *   <li>{@link schema.impl.FipaMessageTypeImpl#getReceiver <em>Receiver</em>}</li>
 *   <li>{@link schema.impl.FipaMessageTypeImpl#getContent <em>Content</em>}</li>
 *   <li>{@link schema.impl.FipaMessageTypeImpl#getLanguage <em>Language</em>}</li>
 *   <li>{@link schema.impl.FipaMessageTypeImpl#getEncoding <em>Encoding</em>}</li>
 *   <li>{@link schema.impl.FipaMessageTypeImpl#getOntology <em>Ontology</em>}</li>
 *   <li>{@link schema.impl.FipaMessageTypeImpl#getProtocol <em>Protocol</em>}</li>
 *   <li>{@link schema.impl.FipaMessageTypeImpl#getReplyWith <em>Reply With</em>}</li>
 *   <li>{@link schema.impl.FipaMessageTypeImpl#getInReplyTo <em>In Reply To</em>}</li>
 *   <li>{@link schema.impl.FipaMessageTypeImpl#getReplyBy <em>Reply By</em>}</li>
 *   <li>{@link schema.impl.FipaMessageTypeImpl#getReplyTo <em>Reply To</em>}</li>
 *   <li>{@link schema.impl.FipaMessageTypeImpl#getConversationId <em>Conversation Id</em>}</li>
 *   <li>{@link schema.impl.FipaMessageTypeImpl#getUserDefined <em>User Defined</em>}</li>
 *   <li>{@link schema.impl.FipaMessageTypeImpl#getAct <em>Act</em>}</li>
 *   <li>{@link schema.impl.FipaMessageTypeImpl#getId <em>Id</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class FipaMessageTypeImpl extends EObjectImpl implements FipaMessageType {
	/**
	 * The cached value of the '{@link #getSender() <em>Sender</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSender()
	 * @generated
	 * @ordered
	 */
	protected SenderType sender;

	/**
	 * The cached value of the '{@link #getReceiver() <em>Receiver</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getReceiver()
	 * @generated
	 * @ordered
	 */
	protected ReceiverType receiver;

	/**
	 * The cached value of the '{@link #getContent() <em>Content</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getContent()
	 * @generated
	 * @ordered
	 */
	protected ContentType content;

	/**
	 * The default value of the '{@link #getLanguage() <em>Language</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLanguage()
	 * @generated
	 * @ordered
	 */
	protected static final String LANGUAGE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getLanguage() <em>Language</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLanguage()
	 * @generated
	 * @ordered
	 */
	protected String language = LANGUAGE_EDEFAULT;

	/**
	 * The default value of the '{@link #getEncoding() <em>Encoding</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEncoding()
	 * @generated
	 * @ordered
	 */
	protected static final String ENCODING_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getEncoding() <em>Encoding</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEncoding()
	 * @generated
	 * @ordered
	 */
	protected String encoding = ENCODING_EDEFAULT;

	/**
	 * The default value of the '{@link #getOntology() <em>Ontology</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOntology()
	 * @generated
	 * @ordered
	 */
	protected static final String ONTOLOGY_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getOntology() <em>Ontology</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOntology()
	 * @generated
	 * @ordered
	 */
	protected String ontology = ONTOLOGY_EDEFAULT;

	/**
	 * The default value of the '{@link #getProtocol() <em>Protocol</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProtocol()
	 * @generated
	 * @ordered
	 */
	protected static final String PROTOCOL_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getProtocol() <em>Protocol</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProtocol()
	 * @generated
	 * @ordered
	 */
	protected String protocol = PROTOCOL_EDEFAULT;

	/**
	 * The default value of the '{@link #getReplyWith() <em>Reply With</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getReplyWith()
	 * @generated
	 * @ordered
	 */
	protected static final String REPLY_WITH_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getReplyWith() <em>Reply With</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getReplyWith()
	 * @generated
	 * @ordered
	 */
	protected String replyWith = REPLY_WITH_EDEFAULT;

	/**
	 * The default value of the '{@link #getInReplyTo() <em>In Reply To</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInReplyTo()
	 * @generated
	 * @ordered
	 */
	protected static final String IN_REPLY_TO_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getInReplyTo() <em>In Reply To</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInReplyTo()
	 * @generated
	 * @ordered
	 */
	protected String inReplyTo = IN_REPLY_TO_EDEFAULT;

	/**
	 * The cached value of the '{@link #getReplyBy() <em>Reply By</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getReplyBy()
	 * @generated
	 * @ordered
	 */
	protected ReplyByType replyBy;

	/**
	 * The cached value of the '{@link #getReplyTo() <em>Reply To</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getReplyTo()
	 * @generated
	 * @ordered
	 */
	protected ReplyToType replyTo;

	/**
	 * The default value of the '{@link #getConversationId() <em>Conversation Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getConversationId()
	 * @generated
	 * @ordered
	 */
	protected static final String CONVERSATION_ID_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getConversationId() <em>Conversation Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getConversationId()
	 * @generated
	 * @ordered
	 */
	protected String conversationId = CONVERSATION_ID_EDEFAULT;

	/**
	 * The cached value of the '{@link #getUserDefined() <em>User Defined</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getUserDefined()
	 * @generated
	 * @ordered
	 */
	protected UserDefinedType userDefined;

	/**
	 * The default value of the '{@link #getAct() <em>Act</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAct()
	 * @generated
	 * @ordered
	 */
	protected static final ActType ACT_EDEFAULT = ActType.ACCEPTPROPOSAL;

	/**
	 * The cached value of the '{@link #getAct() <em>Act</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAct()
	 * @generated
	 * @ordered
	 */
	protected ActType act = ACT_EDEFAULT;

	/**
	 * This is true if the Act attribute has been set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	protected boolean actESet;

	/**
	 * The default value of the '{@link #getId() <em>Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getId()
	 * @generated
	 * @ordered
	 */
	protected static final String ID_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getId() <em>Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getId()
	 * @generated
	 * @ordered
	 */
	protected String id = ID_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FipaMessageTypeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SchemaPackage.Literals.FIPA_MESSAGE_TYPE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SenderType getSender() {
		return sender;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetSender(SenderType newSender, NotificationChain msgs) {
		SenderType oldSender = sender;
		sender = newSender;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, SchemaPackage.FIPA_MESSAGE_TYPE__SENDER, oldSender, newSender);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSender(SenderType newSender) {
		if (newSender != sender) {
			NotificationChain msgs = null;
			if (sender != null)
				msgs = ((InternalEObject)sender).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - SchemaPackage.FIPA_MESSAGE_TYPE__SENDER, null, msgs);
			if (newSender != null)
				msgs = ((InternalEObject)newSender).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - SchemaPackage.FIPA_MESSAGE_TYPE__SENDER, null, msgs);
			msgs = basicSetSender(newSender, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SchemaPackage.FIPA_MESSAGE_TYPE__SENDER, newSender, newSender));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ReceiverType getReceiver() {
		return receiver;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetReceiver(ReceiverType newReceiver, NotificationChain msgs) {
		ReceiverType oldReceiver = receiver;
		receiver = newReceiver;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, SchemaPackage.FIPA_MESSAGE_TYPE__RECEIVER, oldReceiver, newReceiver);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setReceiver(ReceiverType newReceiver) {
		if (newReceiver != receiver) {
			NotificationChain msgs = null;
			if (receiver != null)
				msgs = ((InternalEObject)receiver).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - SchemaPackage.FIPA_MESSAGE_TYPE__RECEIVER, null, msgs);
			if (newReceiver != null)
				msgs = ((InternalEObject)newReceiver).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - SchemaPackage.FIPA_MESSAGE_TYPE__RECEIVER, null, msgs);
			msgs = basicSetReceiver(newReceiver, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SchemaPackage.FIPA_MESSAGE_TYPE__RECEIVER, newReceiver, newReceiver));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ContentType getContent() {
		return content;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetContent(ContentType newContent, NotificationChain msgs) {
		ContentType oldContent = content;
		content = newContent;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, SchemaPackage.FIPA_MESSAGE_TYPE__CONTENT, oldContent, newContent);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setContent(ContentType newContent) {
		if (newContent != content) {
			NotificationChain msgs = null;
			if (content != null)
				msgs = ((InternalEObject)content).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - SchemaPackage.FIPA_MESSAGE_TYPE__CONTENT, null, msgs);
			if (newContent != null)
				msgs = ((InternalEObject)newContent).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - SchemaPackage.FIPA_MESSAGE_TYPE__CONTENT, null, msgs);
			msgs = basicSetContent(newContent, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SchemaPackage.FIPA_MESSAGE_TYPE__CONTENT, newContent, newContent));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLanguage() {
		return language;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setLanguage(String newLanguage) {
		String oldLanguage = language;
		language = newLanguage;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SchemaPackage.FIPA_MESSAGE_TYPE__LANGUAGE, oldLanguage, language));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getEncoding() {
		return encoding;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setEncoding(String newEncoding) {
		String oldEncoding = encoding;
		encoding = newEncoding;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SchemaPackage.FIPA_MESSAGE_TYPE__ENCODING, oldEncoding, encoding));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getOntology() {
		return ontology;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setOntology(String newOntology) {
		String oldOntology = ontology;
		ontology = newOntology;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SchemaPackage.FIPA_MESSAGE_TYPE__ONTOLOGY, oldOntology, ontology));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getProtocol() {
		return protocol;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setProtocol(String newProtocol) {
		String oldProtocol = protocol;
		protocol = newProtocol;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SchemaPackage.FIPA_MESSAGE_TYPE__PROTOCOL, oldProtocol, protocol));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getReplyWith() {
		return replyWith;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setReplyWith(String newReplyWith) {
		String oldReplyWith = replyWith;
		replyWith = newReplyWith;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SchemaPackage.FIPA_MESSAGE_TYPE__REPLY_WITH, oldReplyWith, replyWith));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getInReplyTo() {
		return inReplyTo;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setInReplyTo(String newInReplyTo) {
		String oldInReplyTo = inReplyTo;
		inReplyTo = newInReplyTo;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SchemaPackage.FIPA_MESSAGE_TYPE__IN_REPLY_TO, oldInReplyTo, inReplyTo));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ReplyByType getReplyBy() {
		return replyBy;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetReplyBy(ReplyByType newReplyBy, NotificationChain msgs) {
		ReplyByType oldReplyBy = replyBy;
		replyBy = newReplyBy;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, SchemaPackage.FIPA_MESSAGE_TYPE__REPLY_BY, oldReplyBy, newReplyBy);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setReplyBy(ReplyByType newReplyBy) {
		if (newReplyBy != replyBy) {
			NotificationChain msgs = null;
			if (replyBy != null)
				msgs = ((InternalEObject)replyBy).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - SchemaPackage.FIPA_MESSAGE_TYPE__REPLY_BY, null, msgs);
			if (newReplyBy != null)
				msgs = ((InternalEObject)newReplyBy).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - SchemaPackage.FIPA_MESSAGE_TYPE__REPLY_BY, null, msgs);
			msgs = basicSetReplyBy(newReplyBy, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SchemaPackage.FIPA_MESSAGE_TYPE__REPLY_BY, newReplyBy, newReplyBy));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ReplyToType getReplyTo() {
		return replyTo;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetReplyTo(ReplyToType newReplyTo, NotificationChain msgs) {
		ReplyToType oldReplyTo = replyTo;
		replyTo = newReplyTo;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, SchemaPackage.FIPA_MESSAGE_TYPE__REPLY_TO, oldReplyTo, newReplyTo);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setReplyTo(ReplyToType newReplyTo) {
		if (newReplyTo != replyTo) {
			NotificationChain msgs = null;
			if (replyTo != null)
				msgs = ((InternalEObject)replyTo).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - SchemaPackage.FIPA_MESSAGE_TYPE__REPLY_TO, null, msgs);
			if (newReplyTo != null)
				msgs = ((InternalEObject)newReplyTo).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - SchemaPackage.FIPA_MESSAGE_TYPE__REPLY_TO, null, msgs);
			msgs = basicSetReplyTo(newReplyTo, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SchemaPackage.FIPA_MESSAGE_TYPE__REPLY_TO, newReplyTo, newReplyTo));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getConversationId() {
		return conversationId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setConversationId(String newConversationId) {
		String oldConversationId = conversationId;
		conversationId = newConversationId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SchemaPackage.FIPA_MESSAGE_TYPE__CONVERSATION_ID, oldConversationId, conversationId));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public UserDefinedType getUserDefined() {
		return userDefined;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetUserDefined(UserDefinedType newUserDefined, NotificationChain msgs) {
		UserDefinedType oldUserDefined = userDefined;
		userDefined = newUserDefined;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, SchemaPackage.FIPA_MESSAGE_TYPE__USER_DEFINED, oldUserDefined, newUserDefined);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setUserDefined(UserDefinedType newUserDefined) {
		if (newUserDefined != userDefined) {
			NotificationChain msgs = null;
			if (userDefined != null)
				msgs = ((InternalEObject)userDefined).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - SchemaPackage.FIPA_MESSAGE_TYPE__USER_DEFINED, null, msgs);
			if (newUserDefined != null)
				msgs = ((InternalEObject)newUserDefined).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - SchemaPackage.FIPA_MESSAGE_TYPE__USER_DEFINED, null, msgs);
			msgs = basicSetUserDefined(newUserDefined, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SchemaPackage.FIPA_MESSAGE_TYPE__USER_DEFINED, newUserDefined, newUserDefined));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ActType getAct() {
		return act;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAct(ActType newAct) {
		ActType oldAct = act;
		act = newAct == null ? ACT_EDEFAULT : newAct;
		boolean oldActESet = actESet;
		actESet = true;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SchemaPackage.FIPA_MESSAGE_TYPE__ACT, oldAct, act, !oldActESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetAct() {
		ActType oldAct = act;
		boolean oldActESet = actESet;
		act = ACT_EDEFAULT;
		actESet = false;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.UNSET, SchemaPackage.FIPA_MESSAGE_TYPE__ACT, oldAct, ACT_EDEFAULT, oldActESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetAct() {
		return actESet;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getId() {
		return id;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setId(String newId) {
		String oldId = id;
		id = newId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SchemaPackage.FIPA_MESSAGE_TYPE__ID, oldId, id));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case SchemaPackage.FIPA_MESSAGE_TYPE__SENDER:
				return basicSetSender(null, msgs);
			case SchemaPackage.FIPA_MESSAGE_TYPE__RECEIVER:
				return basicSetReceiver(null, msgs);
			case SchemaPackage.FIPA_MESSAGE_TYPE__CONTENT:
				return basicSetContent(null, msgs);
			case SchemaPackage.FIPA_MESSAGE_TYPE__REPLY_BY:
				return basicSetReplyBy(null, msgs);
			case SchemaPackage.FIPA_MESSAGE_TYPE__REPLY_TO:
				return basicSetReplyTo(null, msgs);
			case SchemaPackage.FIPA_MESSAGE_TYPE__USER_DEFINED:
				return basicSetUserDefined(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case SchemaPackage.FIPA_MESSAGE_TYPE__SENDER:
				return getSender();
			case SchemaPackage.FIPA_MESSAGE_TYPE__RECEIVER:
				return getReceiver();
			case SchemaPackage.FIPA_MESSAGE_TYPE__CONTENT:
				return getContent();
			case SchemaPackage.FIPA_MESSAGE_TYPE__LANGUAGE:
				return getLanguage();
			case SchemaPackage.FIPA_MESSAGE_TYPE__ENCODING:
				return getEncoding();
			case SchemaPackage.FIPA_MESSAGE_TYPE__ONTOLOGY:
				return getOntology();
			case SchemaPackage.FIPA_MESSAGE_TYPE__PROTOCOL:
				return getProtocol();
			case SchemaPackage.FIPA_MESSAGE_TYPE__REPLY_WITH:
				return getReplyWith();
			case SchemaPackage.FIPA_MESSAGE_TYPE__IN_REPLY_TO:
				return getInReplyTo();
			case SchemaPackage.FIPA_MESSAGE_TYPE__REPLY_BY:
				return getReplyBy();
			case SchemaPackage.FIPA_MESSAGE_TYPE__REPLY_TO:
				return getReplyTo();
			case SchemaPackage.FIPA_MESSAGE_TYPE__CONVERSATION_ID:
				return getConversationId();
			case SchemaPackage.FIPA_MESSAGE_TYPE__USER_DEFINED:
				return getUserDefined();
			case SchemaPackage.FIPA_MESSAGE_TYPE__ACT:
				return getAct();
			case SchemaPackage.FIPA_MESSAGE_TYPE__ID:
				return getId();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case SchemaPackage.FIPA_MESSAGE_TYPE__SENDER:
				setSender((SenderType)newValue);
				return;
			case SchemaPackage.FIPA_MESSAGE_TYPE__RECEIVER:
				setReceiver((ReceiverType)newValue);
				return;
			case SchemaPackage.FIPA_MESSAGE_TYPE__CONTENT:
				setContent((ContentType)newValue);
				return;
			case SchemaPackage.FIPA_MESSAGE_TYPE__LANGUAGE:
				setLanguage((String)newValue);
				return;
			case SchemaPackage.FIPA_MESSAGE_TYPE__ENCODING:
				setEncoding((String)newValue);
				return;
			case SchemaPackage.FIPA_MESSAGE_TYPE__ONTOLOGY:
				setOntology((String)newValue);
				return;
			case SchemaPackage.FIPA_MESSAGE_TYPE__PROTOCOL:
				setProtocol((String)newValue);
				return;
			case SchemaPackage.FIPA_MESSAGE_TYPE__REPLY_WITH:
				setReplyWith((String)newValue);
				return;
			case SchemaPackage.FIPA_MESSAGE_TYPE__IN_REPLY_TO:
				setInReplyTo((String)newValue);
				return;
			case SchemaPackage.FIPA_MESSAGE_TYPE__REPLY_BY:
				setReplyBy((ReplyByType)newValue);
				return;
			case SchemaPackage.FIPA_MESSAGE_TYPE__REPLY_TO:
				setReplyTo((ReplyToType)newValue);
				return;
			case SchemaPackage.FIPA_MESSAGE_TYPE__CONVERSATION_ID:
				setConversationId((String)newValue);
				return;
			case SchemaPackage.FIPA_MESSAGE_TYPE__USER_DEFINED:
				setUserDefined((UserDefinedType)newValue);
				return;
			case SchemaPackage.FIPA_MESSAGE_TYPE__ACT:
				setAct((ActType)newValue);
				return;
			case SchemaPackage.FIPA_MESSAGE_TYPE__ID:
				setId((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case SchemaPackage.FIPA_MESSAGE_TYPE__SENDER:
				setSender((SenderType)null);
				return;
			case SchemaPackage.FIPA_MESSAGE_TYPE__RECEIVER:
				setReceiver((ReceiverType)null);
				return;
			case SchemaPackage.FIPA_MESSAGE_TYPE__CONTENT:
				setContent((ContentType)null);
				return;
			case SchemaPackage.FIPA_MESSAGE_TYPE__LANGUAGE:
				setLanguage(LANGUAGE_EDEFAULT);
				return;
			case SchemaPackage.FIPA_MESSAGE_TYPE__ENCODING:
				setEncoding(ENCODING_EDEFAULT);
				return;
			case SchemaPackage.FIPA_MESSAGE_TYPE__ONTOLOGY:
				setOntology(ONTOLOGY_EDEFAULT);
				return;
			case SchemaPackage.FIPA_MESSAGE_TYPE__PROTOCOL:
				setProtocol(PROTOCOL_EDEFAULT);
				return;
			case SchemaPackage.FIPA_MESSAGE_TYPE__REPLY_WITH:
				setReplyWith(REPLY_WITH_EDEFAULT);
				return;
			case SchemaPackage.FIPA_MESSAGE_TYPE__IN_REPLY_TO:
				setInReplyTo(IN_REPLY_TO_EDEFAULT);
				return;
			case SchemaPackage.FIPA_MESSAGE_TYPE__REPLY_BY:
				setReplyBy((ReplyByType)null);
				return;
			case SchemaPackage.FIPA_MESSAGE_TYPE__REPLY_TO:
				setReplyTo((ReplyToType)null);
				return;
			case SchemaPackage.FIPA_MESSAGE_TYPE__CONVERSATION_ID:
				setConversationId(CONVERSATION_ID_EDEFAULT);
				return;
			case SchemaPackage.FIPA_MESSAGE_TYPE__USER_DEFINED:
				setUserDefined((UserDefinedType)null);
				return;
			case SchemaPackage.FIPA_MESSAGE_TYPE__ACT:
				unsetAct();
				return;
			case SchemaPackage.FIPA_MESSAGE_TYPE__ID:
				setId(ID_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case SchemaPackage.FIPA_MESSAGE_TYPE__SENDER:
				return sender != null;
			case SchemaPackage.FIPA_MESSAGE_TYPE__RECEIVER:
				return receiver != null;
			case SchemaPackage.FIPA_MESSAGE_TYPE__CONTENT:
				return content != null;
			case SchemaPackage.FIPA_MESSAGE_TYPE__LANGUAGE:
				return LANGUAGE_EDEFAULT == null ? language != null : !LANGUAGE_EDEFAULT.equals(language);
			case SchemaPackage.FIPA_MESSAGE_TYPE__ENCODING:
				return ENCODING_EDEFAULT == null ? encoding != null : !ENCODING_EDEFAULT.equals(encoding);
			case SchemaPackage.FIPA_MESSAGE_TYPE__ONTOLOGY:
				return ONTOLOGY_EDEFAULT == null ? ontology != null : !ONTOLOGY_EDEFAULT.equals(ontology);
			case SchemaPackage.FIPA_MESSAGE_TYPE__PROTOCOL:
				return PROTOCOL_EDEFAULT == null ? protocol != null : !PROTOCOL_EDEFAULT.equals(protocol);
			case SchemaPackage.FIPA_MESSAGE_TYPE__REPLY_WITH:
				return REPLY_WITH_EDEFAULT == null ? replyWith != null : !REPLY_WITH_EDEFAULT.equals(replyWith);
			case SchemaPackage.FIPA_MESSAGE_TYPE__IN_REPLY_TO:
				return IN_REPLY_TO_EDEFAULT == null ? inReplyTo != null : !IN_REPLY_TO_EDEFAULT.equals(inReplyTo);
			case SchemaPackage.FIPA_MESSAGE_TYPE__REPLY_BY:
				return replyBy != null;
			case SchemaPackage.FIPA_MESSAGE_TYPE__REPLY_TO:
				return replyTo != null;
			case SchemaPackage.FIPA_MESSAGE_TYPE__CONVERSATION_ID:
				return CONVERSATION_ID_EDEFAULT == null ? conversationId != null : !CONVERSATION_ID_EDEFAULT.equals(conversationId);
			case SchemaPackage.FIPA_MESSAGE_TYPE__USER_DEFINED:
				return userDefined != null;
			case SchemaPackage.FIPA_MESSAGE_TYPE__ACT:
				return isSetAct();
			case SchemaPackage.FIPA_MESSAGE_TYPE__ID:
				return ID_EDEFAULT == null ? id != null : !ID_EDEFAULT.equals(id);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (language: ");
		result.append(language);
		result.append(", encoding: ");
		result.append(encoding);
		result.append(", ontology: ");
		result.append(ontology);
		result.append(", protocol: ");
		result.append(protocol);
		result.append(", replyWith: ");
		result.append(replyWith);
		result.append(", inReplyTo: ");
		result.append(inReplyTo);
		result.append(", conversationId: ");
		result.append(conversationId);
		result.append(", act: ");
		if (actESet) result.append(act); else result.append("<unset>");
		result.append(", id: ");
		result.append(id);
		result.append(')');
		return result.toString();
	}

} //FipaMessageTypeImpl
