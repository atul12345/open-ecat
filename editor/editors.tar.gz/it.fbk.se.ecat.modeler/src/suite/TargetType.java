/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package suite;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Target Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link suite.TargetType#getAgent <em>Agent</em>}</li>
 *   <li>{@link suite.TargetType#getGoalPlan <em>Goal Plan</em>}</li>
 * </ul>
 * </p>
 *
 * @see suite.SuitePackage#getTargetType()
 * @model extendedMetaData="name='TargetType' kind='elementOnly'"
 * @generated
 */
public interface TargetType extends EObject {
	/**
	 * Returns the value of the '<em><b>Agent</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Agent</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Agent</em>' attribute.
	 * @see #setAgent(String)
	 * @see suite.SuitePackage#getTargetType_Agent()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.String" required="true"
	 *        extendedMetaData="kind='element' name='Agent' namespace='##targetNamespace'"
	 * @generated
	 */
	String getAgent();

	/**
	 * Sets the value of the '{@link suite.TargetType#getAgent <em>Agent</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Agent</em>' attribute.
	 * @see #getAgent()
	 * @generated
	 */
	void setAgent(String value);

	/**
	 * Returns the value of the '<em><b>Goal Plan</b></em>' containment reference list.
	 * The list contents are of type {@link suite.GoalPlanType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Goal Plan</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Goal Plan</em>' containment reference list.
	 * @see suite.SuitePackage#getTargetType_GoalPlan()
	 * @model containment="true" required="true"
	 *        extendedMetaData="kind='element' name='GoalPlan' namespace='##targetNamespace'"
	 * @generated
	 */
	EList<GoalPlanType> getGoalPlan();

} // TargetType
