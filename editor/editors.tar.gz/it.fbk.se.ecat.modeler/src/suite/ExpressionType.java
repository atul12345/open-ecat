/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package suite;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Expression Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link suite.ExpressionType#getValue <em>Value</em>}</li>
 *   <li>{@link suite.ExpressionType#isExecutable <em>Executable</em>}</li>
 * </ul>
 * </p>
 *
 * @see suite.SuitePackage#getExpressionType()
 * @model extendedMetaData="name='Expression_._type' kind='elementOnly'"
 * @generated
 */
public interface ExpressionType extends EObject {
	/**
	 * Returns the value of the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Value</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Value</em>' attribute.
	 * @see #setValue(String)
	 * @see suite.SuitePackage#getExpressionType_Value()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.String" required="true"
	 *        extendedMetaData="kind='element' name='Value' namespace='##targetNamespace'"
	 * @generated
	 */
	String getValue();

	/**
	 * Sets the value of the '{@link suite.ExpressionType#getValue <em>Value</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Value</em>' attribute.
	 * @see #getValue()
	 * @generated
	 */
	void setValue(String value);

	/**
	 * Returns the value of the '<em><b>Executable</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Executable</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Executable</em>' attribute.
	 * @see #isSetExecutable()
	 * @see #unsetExecutable()
	 * @see #setExecutable(boolean)
	 * @see suite.SuitePackage#getExpressionType_Executable()
	 * @model unsettable="true" dataType="org.eclipse.emf.ecore.xml.type.Boolean"
	 *        extendedMetaData="kind='attribute' name='Executable'"
	 * @generated
	 */
	boolean isExecutable();

	/**
	 * Sets the value of the '{@link suite.ExpressionType#isExecutable <em>Executable</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Executable</em>' attribute.
	 * @see #isSetExecutable()
	 * @see #unsetExecutable()
	 * @see #isExecutable()
	 * @generated
	 */
	void setExecutable(boolean value);

	/**
	 * Unsets the value of the '{@link suite.ExpressionType#isExecutable <em>Executable</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetExecutable()
	 * @see #isExecutable()
	 * @see #setExecutable(boolean)
	 * @generated
	 */
	void unsetExecutable();

	/**
	 * Returns whether the value of the '{@link suite.ExpressionType#isExecutable <em>Executable</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Executable</em>' attribute is set.
	 * @see #unsetExecutable()
	 * @see #isExecutable()
	 * @see #setExecutable(boolean)
	 * @generated
	 */
	boolean isSetExecutable();

} // ExpressionType
