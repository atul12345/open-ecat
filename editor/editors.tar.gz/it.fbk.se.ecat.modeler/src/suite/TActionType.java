/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package suite;

import org.eclipse.emf.ecore.EObject;

import schema.FipaMessageType;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>TAction Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link suite.TActionType#getID <em>ID</em>}</li>
 *   <li>{@link suite.TActionType#getInitiator <em>Initiator</em>}</li>
 *   <li>{@link suite.TActionType#getResponder <em>Responder</em>}</li>
 *   <li>{@link suite.TActionType#getActType <em>Act Type</em>}</li>
 *   <li>{@link suite.TActionType#getNextAction <em>Next Action</em>}</li>
 *   <li>{@link suite.TActionType#getNextIfTrue <em>Next If True</em>}</li>
 *   <li>{@link suite.TActionType#getNextIfFalse <em>Next If False</em>}</li>
 *   <li>{@link suite.TActionType#getMessage <em>Message</em>}</li>
 *   <li>{@link suite.TActionType#getVerdict <em>Verdict</em>}</li>
 *   <li>{@link suite.TActionType#getTimeout <em>Timeout</em>}</li>
 * </ul>
 * </p>
 *
 * @see suite.SuitePackage#getTActionType()
 * @model extendedMetaData="name='TActionType' kind='elementOnly'"
 * @generated
 */
public interface TActionType extends EObject {
	/**
	 * Returns the value of the '<em><b>ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>ID</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>ID</em>' attribute.
	 * @see #setID(String)
	 * @see suite.SuitePackage#getTActionType_ID()
	 * @model id="true" dataType="org.eclipse.emf.ecore.xml.type.ID" required="true"
	 *        extendedMetaData="kind='element' name='ID' namespace='##targetNamespace'"
	 * @generated
	 */
	String getID();

	/**
	 * Sets the value of the '{@link suite.TActionType#getID <em>ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>ID</em>' attribute.
	 * @see #getID()
	 * @generated
	 */
	void setID(String value);

	/**
	 * Returns the value of the '<em><b>Initiator</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Initiator</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Initiator</em>' attribute.
	 * @see #setInitiator(String)
	 * @see suite.SuitePackage#getTActionType_Initiator()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.String"
	 *        extendedMetaData="kind='element' name='Initiator' namespace='##targetNamespace'"
	 * @generated
	 */
	String getInitiator();

	/**
	 * Sets the value of the '{@link suite.TActionType#getInitiator <em>Initiator</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Initiator</em>' attribute.
	 * @see #getInitiator()
	 * @generated
	 */
	void setInitiator(String value);

	/**
	 * Returns the value of the '<em><b>Responder</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Responder</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Responder</em>' attribute.
	 * @see #setResponder(String)
	 * @see suite.SuitePackage#getTActionType_Responder()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.String"
	 *        extendedMetaData="kind='element' name='Responder' namespace='##targetNamespace'"
	 * @generated
	 */
	String getResponder();

	/**
	 * Sets the value of the '{@link suite.TActionType#getResponder <em>Responder</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Responder</em>' attribute.
	 * @see #getResponder()
	 * @generated
	 */
	void setResponder(String value);

	/**
	 * Returns the value of the '<em><b>Act Type</b></em>' attribute.
	 * The default value is <code>"Initial"</code>.
	 * The literals are from the enumeration {@link suite.AType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Act Type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Act Type</em>' attribute.
	 * @see suite.AType
	 * @see #isSetActType()
	 * @see #unsetActType()
	 * @see #setActType(AType)
	 * @see suite.SuitePackage#getTActionType_ActType()
	 * @model default="Initial" unsettable="true" required="true"
	 *        extendedMetaData="kind='element' name='ActType' namespace='##targetNamespace'"
	 * @generated
	 */
	AType getActType();

	/**
	 * Sets the value of the '{@link suite.TActionType#getActType <em>Act Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Act Type</em>' attribute.
	 * @see suite.AType
	 * @see #isSetActType()
	 * @see #unsetActType()
	 * @see #getActType()
	 * @generated
	 */
	void setActType(AType value);

	/**
	 * Unsets the value of the '{@link suite.TActionType#getActType <em>Act Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetActType()
	 * @see #getActType()
	 * @see #setActType(AType)
	 * @generated
	 */
	void unsetActType();

	/**
	 * Returns whether the value of the '{@link suite.TActionType#getActType <em>Act Type</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Act Type</em>' attribute is set.
	 * @see #unsetActType()
	 * @see #getActType()
	 * @see #setActType(AType)
	 * @generated
	 */
	boolean isSetActType();

	/**
	 * Returns the value of the '<em><b>Next Action</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Next Action</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Next Action</em>' attribute.
	 * @see #setNextAction(String)
	 * @see suite.SuitePackage#getTActionType_NextAction()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.IDREF"
	 *        extendedMetaData="kind='element' name='NextAction' namespace='##targetNamespace'"
	 * @generated
	 */
	String getNextAction();

	/**
	 * Sets the value of the '{@link suite.TActionType#getNextAction <em>Next Action</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Next Action</em>' attribute.
	 * @see #getNextAction()
	 * @generated
	 */
	void setNextAction(String value);

	/**
	 * Returns the value of the '<em><b>Next If True</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Next If True</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Next If True</em>' attribute.
	 * @see #setNextIfTrue(String)
	 * @see suite.SuitePackage#getTActionType_NextIfTrue()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.IDREF"
	 *        extendedMetaData="kind='element' name='NextIfTrue' namespace='##targetNamespace'"
	 * @generated
	 */
	String getNextIfTrue();

	/**
	 * Sets the value of the '{@link suite.TActionType#getNextIfTrue <em>Next If True</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Next If True</em>' attribute.
	 * @see #getNextIfTrue()
	 * @generated
	 */
	void setNextIfTrue(String value);

	/**
	 * Returns the value of the '<em><b>Next If False</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Next If False</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Next If False</em>' attribute.
	 * @see #setNextIfFalse(String)
	 * @see suite.SuitePackage#getTActionType_NextIfFalse()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.IDREF"
	 *        extendedMetaData="kind='element' name='NextIfFalse' namespace='##targetNamespace'"
	 * @generated
	 */
	String getNextIfFalse();

	/**
	 * Sets the value of the '{@link suite.TActionType#getNextIfFalse <em>Next If False</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Next If False</em>' attribute.
	 * @see #getNextIfFalse()
	 * @generated
	 */
	void setNextIfFalse(String value);

	/**
	 * Returns the value of the '<em><b>Message</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Message</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Message</em>' containment reference.
	 * @see #setMessage(FipaMessageType)
	 * @see suite.SuitePackage#getTActionType_Message()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='Message' namespace='##targetNamespace'"
	 * @generated
	 */
	FipaMessageType getMessage();

	/**
	 * Sets the value of the '{@link suite.TActionType#getMessage <em>Message</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Message</em>' containment reference.
	 * @see #getMessage()
	 * @generated
	 */
	void setMessage(FipaMessageType value);

	/**
	 * Returns the value of the '<em><b>Verdict</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Verdict</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Verdict</em>' containment reference.
	 * @see #setVerdict(CheckType)
	 * @see suite.SuitePackage#getTActionType_Verdict()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='Verdict' namespace='##targetNamespace'"
	 * @generated
	 */
	CheckType getVerdict();

	/**
	 * Sets the value of the '{@link suite.TActionType#getVerdict <em>Verdict</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Verdict</em>' containment reference.
	 * @see #getVerdict()
	 * @generated
	 */
	void setVerdict(CheckType value);

	/**
	 * Returns the value of the '<em><b>Timeout</b></em>' attribute.
	 * The default value is <code>"1000"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Timeout</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Timeout</em>' attribute.
	 * @see #isSetTimeout()
	 * @see #unsetTimeout()
	 * @see #setTimeout(int)
	 * @see suite.SuitePackage#getTActionType_Timeout()
	 * @model default="1000" unsettable="true" dataType="org.eclipse.emf.ecore.xml.type.Int"
	 *        extendedMetaData="kind='element' name='Timeout' namespace='##targetNamespace'"
	 * @generated
	 */
	int getTimeout();

	/**
	 * Sets the value of the '{@link suite.TActionType#getTimeout <em>Timeout</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Timeout</em>' attribute.
	 * @see #isSetTimeout()
	 * @see #unsetTimeout()
	 * @see #getTimeout()
	 * @generated
	 */
	void setTimeout(int value);

	/**
	 * Unsets the value of the '{@link suite.TActionType#getTimeout <em>Timeout</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetTimeout()
	 * @see #getTimeout()
	 * @see #setTimeout(int)
	 * @generated
	 */
	void unsetTimeout();

	/**
	 * Returns whether the value of the '{@link suite.TActionType#getTimeout <em>Timeout</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Timeout</em>' attribute is set.
	 * @see #unsetTimeout()
	 * @see #getTimeout()
	 * @see #setTimeout(int)
	 * @generated
	 */
	boolean isSetTimeout();

} // TActionType
