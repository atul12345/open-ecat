/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package suite;

import org.eclipse.emf.common.util.EMap;

import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.util.FeatureMap;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Document Root</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link suite.DocumentRoot#getMixed <em>Mixed</em>}</li>
 *   <li>{@link suite.DocumentRoot#getXMLNSPrefixMap <em>XMLNS Prefix Map</em>}</li>
 *   <li>{@link suite.DocumentRoot#getXSISchemaLocation <em>XSI Schema Location</em>}</li>
 *   <li>{@link suite.DocumentRoot#getTestCase <em>Test Case</em>}</li>
 *   <li>{@link suite.DocumentRoot#getTestScenario <em>Test Scenario</em>}</li>
 *   <li>{@link suite.DocumentRoot#getTestSuite <em>Test Suite</em>}</li>
 * </ul>
 * </p>
 *
 * @see suite.SuitePackage#getDocumentRoot()
 * @model extendedMetaData="name='' kind='mixed'"
 * @generated
 */
public interface DocumentRoot extends EObject {
	/**
	 * Returns the value of the '<em><b>Mixed</b></em>' attribute list.
	 * The list contents are of type {@link org.eclipse.emf.ecore.util.FeatureMap.Entry}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Mixed</em>' attribute list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Mixed</em>' attribute list.
	 * @see suite.SuitePackage#getDocumentRoot_Mixed()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.EFeatureMapEntry" many="true"
	 *        extendedMetaData="kind='elementWildcard' name=':mixed'"
	 * @generated
	 */
	FeatureMap getMixed();

	/**
	 * Returns the value of the '<em><b>XMLNS Prefix Map</b></em>' map.
	 * The key is of type {@link java.lang.String},
	 * and the value is of type {@link java.lang.String},
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>XMLNS Prefix Map</em>' map isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>XMLNS Prefix Map</em>' map.
	 * @see suite.SuitePackage#getDocumentRoot_XMLNSPrefixMap()
	 * @model mapType="org.eclipse.emf.ecore.EStringToStringMapEntry<org.eclipse.emf.ecore.EString, org.eclipse.emf.ecore.EString>" transient="true"
	 *        extendedMetaData="kind='attribute' name='xmlns:prefix'"
	 * @generated
	 */
	EMap<String, String> getXMLNSPrefixMap();

	/**
	 * Returns the value of the '<em><b>XSI Schema Location</b></em>' map.
	 * The key is of type {@link java.lang.String},
	 * and the value is of type {@link java.lang.String},
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>XSI Schema Location</em>' map isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>XSI Schema Location</em>' map.
	 * @see suite.SuitePackage#getDocumentRoot_XSISchemaLocation()
	 * @model mapType="org.eclipse.emf.ecore.EStringToStringMapEntry<org.eclipse.emf.ecore.EString, org.eclipse.emf.ecore.EString>" transient="true"
	 *        extendedMetaData="kind='attribute' name='xsi:schemaLocation'"
	 * @generated
	 */
	EMap<String, String> getXSISchemaLocation();

	/**
	 * Returns the value of the '<em><b>Test Case</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Test case structure
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Test Case</em>' containment reference.
	 * @see #setTestCase(TestCaseType)
	 * @see suite.SuitePackage#getDocumentRoot_TestCase()
	 * @model containment="true" upper="-2" transient="true" volatile="true" derived="true"
	 *        extendedMetaData="kind='element' name='TestCase' namespace='##targetNamespace'"
	 * @generated
	 */
	TestCaseType getTestCase();

	/**
	 * Sets the value of the '{@link suite.DocumentRoot#getTestCase <em>Test Case</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Test Case</em>' containment reference.
	 * @see #getTestCase()
	 * @generated
	 */
	void setTestCase(TestCaseType value);

	/**
	 * Returns the value of the '<em><b>Test Scenario</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Goal-oriented test case scenario
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Test Scenario</em>' containment reference.
	 * @see #setTestScenario(TestScenarioType)
	 * @see suite.SuitePackage#getDocumentRoot_TestScenario()
	 * @model containment="true" upper="-2" transient="true" volatile="true" derived="true"
	 *        extendedMetaData="kind='element' name='TestScenario' namespace='##targetNamespace'"
	 * @generated
	 */
	TestScenarioType getTestScenario();

	/**
	 * Sets the value of the '{@link suite.DocumentRoot#getTestScenario <em>Test Scenario</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Test Scenario</em>' containment reference.
	 * @see #getTestScenario()
	 * @generated
	 */
	void setTestScenario(TestScenarioType value);

	/**
	 * Returns the value of the '<em><b>Test Suite</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Test suite structure
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Test Suite</em>' containment reference.
	 * @see #setTestSuite(TestSuiteType)
	 * @see suite.SuitePackage#getDocumentRoot_TestSuite()
	 * @model containment="true" upper="-2" transient="true" volatile="true" derived="true"
	 *        extendedMetaData="kind='element' name='TestSuite' namespace='##targetNamespace'"
	 * @generated
	 */
	TestSuiteType getTestSuite();

	/**
	 * Sets the value of the '{@link suite.DocumentRoot#getTestSuite <em>Test Suite</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Test Suite</em>' containment reference.
	 * @see #getTestSuite()
	 * @generated
	 */
	void setTestSuite(TestSuiteType value);

} // DocumentRoot
