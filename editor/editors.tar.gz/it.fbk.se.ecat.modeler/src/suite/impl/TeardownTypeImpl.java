/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package suite.impl;

import org.eclipse.emf.ecore.EClass;

import suite.SuitePackage;
import suite.TeardownType;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Teardown Type</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class TeardownTypeImpl extends TestSupportTypeImpl implements TeardownType {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TeardownTypeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SuitePackage.Literals.TEARDOWN_TYPE;
	}

} //TeardownTypeImpl
