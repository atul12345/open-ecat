/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package suite.impl;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

import suite.*;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class SuiteFactoryImpl extends EFactoryImpl implements SuiteFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static SuiteFactory init() {
		try {
			SuiteFactory theSuiteFactory = (SuiteFactory)EPackage.Registry.INSTANCE.getEFactory("http://sra.itc.it/se/TestSuite"); 
			if (theSuiteFactory != null) {
				return theSuiteFactory;
			}
		}
		catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new SuiteFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SuiteFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
			case SuitePackage.CHECK_TYPE: return createCheckType();
			case SuitePackage.CONDITION_TYPE: return createConditionType();
			case SuitePackage.DOCUMENT_ROOT: return createDocumentRoot();
			case SuitePackage.EXPRESSION_TYPE: return createExpressionType();
			case SuitePackage.GOAL_PLAN_TYPE: return createGoalPlanType();
			case SuitePackage.PARAM_TYPE: return createParamType();
			case SuitePackage.TACTION_TYPE: return createTActionType();
			case SuitePackage.TARGET_TYPE: return createTargetType();
			case SuitePackage.TASK_TYPE1: return createTaskType1();
			case SuitePackage.TEST_CASE_TYPE: return createTestCaseType();
			case SuitePackage.TEST_SCENARIO_TYPE: return createTestScenarioType();
			case SuitePackage.TEST_SUITE_TYPE: return createTestSuiteType();
			case SuitePackage.TEST_SUPPORT_TYPE: return createTestSupportType();
			case SuitePackage.ORDER_LINK_TYPE: return createOrderLinkType();
			case SuitePackage.SETUP_TYPE: return createSetupType();
			case SuitePackage.TEARDOWN_TYPE: return createTeardownType();
			case SuitePackage.GOAL_LINK_TYPE: return createGoalLinkType();
			case SuitePackage.SEND_LINK_TYPE: return createSendLinkType();
			case SuitePackage.RECEIVE_LINK_TYPE: return createReceiveLinkType();
			default:
				throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object createFromString(EDataType eDataType, String initialValue) {
		switch (eDataType.getClassifierID()) {
			case SuitePackage.ATYPE:
				return createATypeFromString(eDataType, initialValue);
			case SuitePackage.GOAL_REACH_TYPE:
				return createGoalReachTypeFromString(eDataType, initialValue);
			case SuitePackage.OPERATOR_TYPE:
				return createOperatorTypeFromString(eDataType, initialValue);
			case SuitePackage.RELATIONSHIP_TYPE:
				return createRelationshipTypeFromString(eDataType, initialValue);
			case SuitePackage.TASK_TYPE:
				return createTaskTypeFromString(eDataType, initialValue);
			case SuitePackage.ORDER_TYPE:
				return createOrderTypeFromString(eDataType, initialValue);
			case SuitePackage.ATYPE_OBJECT:
				return createATypeObjectFromString(eDataType, initialValue);
			case SuitePackage.GOAL_REACH_TYPE_OBJECT:
				return createGoalReachTypeObjectFromString(eDataType, initialValue);
			case SuitePackage.OPERATOR_TYPE_OBJECT:
				return createOperatorTypeObjectFromString(eDataType, initialValue);
			case SuitePackage.RELATIONSHIP_TYPE_OBJECT:
				return createRelationshipTypeObjectFromString(eDataType, initialValue);
			case SuitePackage.TASK_TYPE_OBJECT:
				return createTaskTypeObjectFromString(eDataType, initialValue);
			default:
				throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String convertToString(EDataType eDataType, Object instanceValue) {
		switch (eDataType.getClassifierID()) {
			case SuitePackage.ATYPE:
				return convertATypeToString(eDataType, instanceValue);
			case SuitePackage.GOAL_REACH_TYPE:
				return convertGoalReachTypeToString(eDataType, instanceValue);
			case SuitePackage.OPERATOR_TYPE:
				return convertOperatorTypeToString(eDataType, instanceValue);
			case SuitePackage.RELATIONSHIP_TYPE:
				return convertRelationshipTypeToString(eDataType, instanceValue);
			case SuitePackage.TASK_TYPE:
				return convertTaskTypeToString(eDataType, instanceValue);
			case SuitePackage.ORDER_TYPE:
				return convertOrderTypeToString(eDataType, instanceValue);
			case SuitePackage.ATYPE_OBJECT:
				return convertATypeObjectToString(eDataType, instanceValue);
			case SuitePackage.GOAL_REACH_TYPE_OBJECT:
				return convertGoalReachTypeObjectToString(eDataType, instanceValue);
			case SuitePackage.OPERATOR_TYPE_OBJECT:
				return convertOperatorTypeObjectToString(eDataType, instanceValue);
			case SuitePackage.RELATIONSHIP_TYPE_OBJECT:
				return convertRelationshipTypeObjectToString(eDataType, instanceValue);
			case SuitePackage.TASK_TYPE_OBJECT:
				return convertTaskTypeObjectToString(eDataType, instanceValue);
			default:
				throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CheckType createCheckType() {
		CheckTypeImpl checkType = new CheckTypeImpl();
		return checkType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ConditionType createConditionType() {
		ConditionTypeImpl conditionType = new ConditionTypeImpl();
		return conditionType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DocumentRoot createDocumentRoot() {
		DocumentRootImpl documentRoot = new DocumentRootImpl();
		return documentRoot;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ExpressionType createExpressionType() {
		ExpressionTypeImpl expressionType = new ExpressionTypeImpl();
		return expressionType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public GoalPlanType createGoalPlanType() {
		GoalPlanTypeImpl goalPlanType = new GoalPlanTypeImpl();
		return goalPlanType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ParamType createParamType() {
		ParamTypeImpl paramType = new ParamTypeImpl();
		return paramType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TActionType createTActionType() {
		TActionTypeImpl tActionType = new TActionTypeImpl();
		return tActionType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TargetType createTargetType() {
		TargetTypeImpl targetType = new TargetTypeImpl();
		return targetType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TaskType1 createTaskType1() {
		TaskType1Impl taskType1 = new TaskType1Impl();
		return taskType1;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TestCaseType createTestCaseType() {
		TestCaseTypeImpl testCaseType = new TestCaseTypeImpl();
		return testCaseType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TestScenarioType createTestScenarioType() {
		TestScenarioTypeImpl testScenarioType = new TestScenarioTypeImpl();
		return testScenarioType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TestSuiteType createTestSuiteType() {
		TestSuiteTypeImpl testSuiteType = new TestSuiteTypeImpl();
		return testSuiteType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TestSupportType createTestSupportType() {
		TestSupportTypeImpl testSupportType = new TestSupportTypeImpl();
		return testSupportType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OrderLinkType createOrderLinkType() {
		OrderLinkTypeImpl orderLinkType = new OrderLinkTypeImpl();
		return orderLinkType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SetupType createSetupType() {
		SetupTypeImpl setupType = new SetupTypeImpl();
		return setupType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TeardownType createTeardownType() {
		TeardownTypeImpl teardownType = new TeardownTypeImpl();
		return teardownType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public GoalLinkType createGoalLinkType() {
		GoalLinkTypeImpl goalLinkType = new GoalLinkTypeImpl();
		return goalLinkType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SendLinkType createSendLinkType() {
		SendLinkTypeImpl sendLinkType = new SendLinkTypeImpl();
		return sendLinkType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ReceiveLinkType createReceiveLinkType() {
		ReceiveLinkTypeImpl receiveLinkType = new ReceiveLinkTypeImpl();
		return receiveLinkType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AType createATypeFromString(EDataType eDataType, String initialValue) {
		AType result = AType.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertATypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public GoalReachType createGoalReachTypeFromString(EDataType eDataType, String initialValue) {
		GoalReachType result = GoalReachType.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertGoalReachTypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OperatorType createOperatorTypeFromString(EDataType eDataType, String initialValue) {
		OperatorType result = OperatorType.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertOperatorTypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RelationshipType createRelationshipTypeFromString(EDataType eDataType, String initialValue) {
		RelationshipType result = RelationshipType.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertRelationshipTypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TaskType createTaskTypeFromString(EDataType eDataType, String initialValue) {
		TaskType result = TaskType.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertTaskTypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OrderType createOrderTypeFromString(EDataType eDataType, String initialValue) {
		OrderType result = OrderType.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertOrderTypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AType createATypeObjectFromString(EDataType eDataType, String initialValue) {
		return createATypeFromString(SuitePackage.Literals.ATYPE, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertATypeObjectToString(EDataType eDataType, Object instanceValue) {
		return convertATypeToString(SuitePackage.Literals.ATYPE, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public GoalReachType createGoalReachTypeObjectFromString(EDataType eDataType, String initialValue) {
		return createGoalReachTypeFromString(SuitePackage.Literals.GOAL_REACH_TYPE, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertGoalReachTypeObjectToString(EDataType eDataType, Object instanceValue) {
		return convertGoalReachTypeToString(SuitePackage.Literals.GOAL_REACH_TYPE, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OperatorType createOperatorTypeObjectFromString(EDataType eDataType, String initialValue) {
		return createOperatorTypeFromString(SuitePackage.Literals.OPERATOR_TYPE, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertOperatorTypeObjectToString(EDataType eDataType, Object instanceValue) {
		return convertOperatorTypeToString(SuitePackage.Literals.OPERATOR_TYPE, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RelationshipType createRelationshipTypeObjectFromString(EDataType eDataType, String initialValue) {
		return createRelationshipTypeFromString(SuitePackage.Literals.RELATIONSHIP_TYPE, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertRelationshipTypeObjectToString(EDataType eDataType, Object instanceValue) {
		return convertRelationshipTypeToString(SuitePackage.Literals.RELATIONSHIP_TYPE, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TaskType createTaskTypeObjectFromString(EDataType eDataType, String initialValue) {
		return createTaskTypeFromString(SuitePackage.Literals.TASK_TYPE, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertTaskTypeObjectToString(EDataType eDataType, Object instanceValue) {
		return convertTaskTypeToString(SuitePackage.Literals.TASK_TYPE, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SuitePackage getSuitePackage() {
		return (SuitePackage)getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static SuitePackage getPackage() {
		return SuitePackage.eINSTANCE;
	}

} //SuiteFactoryImpl
