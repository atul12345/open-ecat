/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package suite.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import suite.GoalPlanType;
import suite.SuitePackage;
import suite.TargetType;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Target Type</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link suite.impl.TargetTypeImpl#getAgent <em>Agent</em>}</li>
 *   <li>{@link suite.impl.TargetTypeImpl#getGoalPlan <em>Goal Plan</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class TargetTypeImpl extends EObjectImpl implements TargetType {
	/**
	 * The default value of the '{@link #getAgent() <em>Agent</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAgent()
	 * @generated
	 * @ordered
	 */
	protected static final String AGENT_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getAgent() <em>Agent</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAgent()
	 * @generated
	 * @ordered
	 */
	protected String agent = AGENT_EDEFAULT;

	/**
	 * The cached value of the '{@link #getGoalPlan() <em>Goal Plan</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGoalPlan()
	 * @generated
	 * @ordered
	 */
	protected EList<GoalPlanType> goalPlan;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TargetTypeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SuitePackage.Literals.TARGET_TYPE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getAgent() {
		return agent;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAgent(String newAgent) {
		String oldAgent = agent;
		agent = newAgent;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SuitePackage.TARGET_TYPE__AGENT, oldAgent, agent));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<GoalPlanType> getGoalPlan() {
		if (goalPlan == null) {
			goalPlan = new EObjectContainmentEList<GoalPlanType>(GoalPlanType.class, this, SuitePackage.TARGET_TYPE__GOAL_PLAN);
		}
		return goalPlan;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case SuitePackage.TARGET_TYPE__GOAL_PLAN:
				return ((InternalEList<?>)getGoalPlan()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case SuitePackage.TARGET_TYPE__AGENT:
				return getAgent();
			case SuitePackage.TARGET_TYPE__GOAL_PLAN:
				return getGoalPlan();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case SuitePackage.TARGET_TYPE__AGENT:
				setAgent((String)newValue);
				return;
			case SuitePackage.TARGET_TYPE__GOAL_PLAN:
				getGoalPlan().clear();
				getGoalPlan().addAll((Collection<? extends GoalPlanType>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case SuitePackage.TARGET_TYPE__AGENT:
				setAgent(AGENT_EDEFAULT);
				return;
			case SuitePackage.TARGET_TYPE__GOAL_PLAN:
				getGoalPlan().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case SuitePackage.TARGET_TYPE__AGENT:
				return AGENT_EDEFAULT == null ? agent != null : !AGENT_EDEFAULT.equals(agent);
			case SuitePackage.TARGET_TYPE__GOAL_PLAN:
				return goalPlan != null && !goalPlan.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (agent: ");
		result.append(agent);
		result.append(')');
		return result.toString();
	}

} //TargetTypeImpl
