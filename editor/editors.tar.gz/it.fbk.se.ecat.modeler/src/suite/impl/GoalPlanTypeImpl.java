/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package suite.impl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import suite.ConditionType;
import suite.GoalPlanType;
import suite.RelationshipType;
import suite.SuitePackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Goal Plan Type</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link suite.impl.GoalPlanTypeImpl#getGoal <em>Goal</em>}</li>
 *   <li>{@link suite.impl.GoalPlanTypeImpl#getPlan <em>Plan</em>}</li>
 *   <li>{@link suite.impl.GoalPlanTypeImpl#getRelationship <em>Relationship</em>}</li>
 *   <li>{@link suite.impl.GoalPlanTypeImpl#getPreCondition <em>Pre Condition</em>}</li>
 *   <li>{@link suite.impl.GoalPlanTypeImpl#getPostCondition <em>Post Condition</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class GoalPlanTypeImpl extends EObjectImpl implements GoalPlanType {
	/**
	 * The default value of the '{@link #getGoal() <em>Goal</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGoal()
	 * @generated
	 * @ordered
	 */
	protected static final String GOAL_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getGoal() <em>Goal</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGoal()
	 * @generated
	 * @ordered
	 */
	protected String goal = GOAL_EDEFAULT;

	/**
	 * The default value of the '{@link #getPlan() <em>Plan</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPlan()
	 * @generated
	 * @ordered
	 */
	protected static final String PLAN_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getPlan() <em>Plan</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPlan()
	 * @generated
	 * @ordered
	 */
	protected String plan = PLAN_EDEFAULT;

	/**
	 * The default value of the '{@link #getRelationship() <em>Relationship</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRelationship()
	 * @generated
	 * @ordered
	 */
	protected static final RelationshipType RELATIONSHIP_EDEFAULT = RelationshipType.MEANS_END;

	/**
	 * The cached value of the '{@link #getRelationship() <em>Relationship</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRelationship()
	 * @generated
	 * @ordered
	 */
	protected RelationshipType relationship = RELATIONSHIP_EDEFAULT;

	/**
	 * This is true if the Relationship attribute has been set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	protected boolean relationshipESet;

	/**
	 * The cached value of the '{@link #getPreCondition() <em>Pre Condition</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPreCondition()
	 * @generated
	 * @ordered
	 */
	protected ConditionType preCondition;

	/**
	 * The cached value of the '{@link #getPostCondition() <em>Post Condition</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPostCondition()
	 * @generated
	 * @ordered
	 */
	protected ConditionType postCondition;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected GoalPlanTypeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SuitePackage.Literals.GOAL_PLAN_TYPE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getGoal() {
		return goal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setGoal(String newGoal) {
		String oldGoal = goal;
		goal = newGoal;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SuitePackage.GOAL_PLAN_TYPE__GOAL, oldGoal, goal));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getPlan() {
		return plan;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPlan(String newPlan) {
		String oldPlan = plan;
		plan = newPlan;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SuitePackage.GOAL_PLAN_TYPE__PLAN, oldPlan, plan));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RelationshipType getRelationship() {
		return relationship;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setRelationship(RelationshipType newRelationship) {
		RelationshipType oldRelationship = relationship;
		relationship = newRelationship == null ? RELATIONSHIP_EDEFAULT : newRelationship;
		boolean oldRelationshipESet = relationshipESet;
		relationshipESet = true;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SuitePackage.GOAL_PLAN_TYPE__RELATIONSHIP, oldRelationship, relationship, !oldRelationshipESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetRelationship() {
		RelationshipType oldRelationship = relationship;
		boolean oldRelationshipESet = relationshipESet;
		relationship = RELATIONSHIP_EDEFAULT;
		relationshipESet = false;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.UNSET, SuitePackage.GOAL_PLAN_TYPE__RELATIONSHIP, oldRelationship, RELATIONSHIP_EDEFAULT, oldRelationshipESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetRelationship() {
		return relationshipESet;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ConditionType getPreCondition() {
		return preCondition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetPreCondition(ConditionType newPreCondition, NotificationChain msgs) {
		ConditionType oldPreCondition = preCondition;
		preCondition = newPreCondition;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, SuitePackage.GOAL_PLAN_TYPE__PRE_CONDITION, oldPreCondition, newPreCondition);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPreCondition(ConditionType newPreCondition) {
		if (newPreCondition != preCondition) {
			NotificationChain msgs = null;
			if (preCondition != null)
				msgs = ((InternalEObject)preCondition).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - SuitePackage.GOAL_PLAN_TYPE__PRE_CONDITION, null, msgs);
			if (newPreCondition != null)
				msgs = ((InternalEObject)newPreCondition).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - SuitePackage.GOAL_PLAN_TYPE__PRE_CONDITION, null, msgs);
			msgs = basicSetPreCondition(newPreCondition, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SuitePackage.GOAL_PLAN_TYPE__PRE_CONDITION, newPreCondition, newPreCondition));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ConditionType getPostCondition() {
		return postCondition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetPostCondition(ConditionType newPostCondition, NotificationChain msgs) {
		ConditionType oldPostCondition = postCondition;
		postCondition = newPostCondition;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, SuitePackage.GOAL_PLAN_TYPE__POST_CONDITION, oldPostCondition, newPostCondition);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPostCondition(ConditionType newPostCondition) {
		if (newPostCondition != postCondition) {
			NotificationChain msgs = null;
			if (postCondition != null)
				msgs = ((InternalEObject)postCondition).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - SuitePackage.GOAL_PLAN_TYPE__POST_CONDITION, null, msgs);
			if (newPostCondition != null)
				msgs = ((InternalEObject)newPostCondition).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - SuitePackage.GOAL_PLAN_TYPE__POST_CONDITION, null, msgs);
			msgs = basicSetPostCondition(newPostCondition, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SuitePackage.GOAL_PLAN_TYPE__POST_CONDITION, newPostCondition, newPostCondition));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case SuitePackage.GOAL_PLAN_TYPE__PRE_CONDITION:
				return basicSetPreCondition(null, msgs);
			case SuitePackage.GOAL_PLAN_TYPE__POST_CONDITION:
				return basicSetPostCondition(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case SuitePackage.GOAL_PLAN_TYPE__GOAL:
				return getGoal();
			case SuitePackage.GOAL_PLAN_TYPE__PLAN:
				return getPlan();
			case SuitePackage.GOAL_PLAN_TYPE__RELATIONSHIP:
				return getRelationship();
			case SuitePackage.GOAL_PLAN_TYPE__PRE_CONDITION:
				return getPreCondition();
			case SuitePackage.GOAL_PLAN_TYPE__POST_CONDITION:
				return getPostCondition();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case SuitePackage.GOAL_PLAN_TYPE__GOAL:
				setGoal((String)newValue);
				return;
			case SuitePackage.GOAL_PLAN_TYPE__PLAN:
				setPlan((String)newValue);
				return;
			case SuitePackage.GOAL_PLAN_TYPE__RELATIONSHIP:
				setRelationship((RelationshipType)newValue);
				return;
			case SuitePackage.GOAL_PLAN_TYPE__PRE_CONDITION:
				setPreCondition((ConditionType)newValue);
				return;
			case SuitePackage.GOAL_PLAN_TYPE__POST_CONDITION:
				setPostCondition((ConditionType)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case SuitePackage.GOAL_PLAN_TYPE__GOAL:
				setGoal(GOAL_EDEFAULT);
				return;
			case SuitePackage.GOAL_PLAN_TYPE__PLAN:
				setPlan(PLAN_EDEFAULT);
				return;
			case SuitePackage.GOAL_PLAN_TYPE__RELATIONSHIP:
				unsetRelationship();
				return;
			case SuitePackage.GOAL_PLAN_TYPE__PRE_CONDITION:
				setPreCondition((ConditionType)null);
				return;
			case SuitePackage.GOAL_PLAN_TYPE__POST_CONDITION:
				setPostCondition((ConditionType)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case SuitePackage.GOAL_PLAN_TYPE__GOAL:
				return GOAL_EDEFAULT == null ? goal != null : !GOAL_EDEFAULT.equals(goal);
			case SuitePackage.GOAL_PLAN_TYPE__PLAN:
				return PLAN_EDEFAULT == null ? plan != null : !PLAN_EDEFAULT.equals(plan);
			case SuitePackage.GOAL_PLAN_TYPE__RELATIONSHIP:
				return isSetRelationship();
			case SuitePackage.GOAL_PLAN_TYPE__PRE_CONDITION:
				return preCondition != null;
			case SuitePackage.GOAL_PLAN_TYPE__POST_CONDITION:
				return postCondition != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (goal: ");
		result.append(goal);
		result.append(", plan: ");
		result.append(plan);
		result.append(", relationship: ");
		if (relationshipESet) result.append(relationship); else result.append("<unset>");
		result.append(')');
		return result.toString();
	}

} //GoalPlanTypeImpl
