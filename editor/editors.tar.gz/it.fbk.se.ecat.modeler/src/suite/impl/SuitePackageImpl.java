/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package suite.impl;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

import org.eclipse.emf.ecore.xml.type.XMLTypePackage;

import schema.SchemaPackage;

import schema.impl.SchemaPackageImpl;

import suite.AType;
import suite.CheckType;
import suite.ConditionType;
import suite.DocumentRoot;
import suite.ExpressionType;
import suite.GoalLinkType;
import suite.GoalPlanType;
import suite.GoalReachType;
import suite.OperatorType;
import suite.OrderLinkType;
import suite.OrderType;
import suite.ParamType;
import suite.ReceiveLinkType;
import suite.RelationshipType;
import suite.SendLinkType;
import suite.SetupType;
import suite.SuiteFactory;
import suite.SuitePackage;
import suite.TActionType;
import suite.TargetType;
import suite.TaskType;
import suite.TaskType1;
import suite.TeardownType;
import suite.TestCaseType;
import suite.TestScenarioType;
import suite.TestSuiteType;
import suite.TestSupportType;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class SuitePackageImpl extends EPackageImpl implements SuitePackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass checkTypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass conditionTypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass documentRootEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass expressionTypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass goalPlanTypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass paramTypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass tActionTypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass targetTypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass taskType1EClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass testCaseTypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass testScenarioTypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass testSuiteTypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass testSupportTypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass orderLinkTypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass setupTypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass teardownTypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass goalLinkTypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass sendLinkTypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass receiveLinkTypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum aTypeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum goalReachTypeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum operatorTypeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum relationshipTypeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum taskTypeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum orderTypeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType aTypeObjectEDataType = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType goalReachTypeObjectEDataType = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType operatorTypeObjectEDataType = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType relationshipTypeObjectEDataType = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType taskTypeObjectEDataType = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see suite.SuitePackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private SuitePackageImpl() {
		super(eNS_URI, SuiteFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this
	 * model, and for any others upon which it depends.  Simple
	 * dependencies are satisfied by calling this method on all
	 * dependent packages before doing anything else.  This method drives
	 * initialization for interdependent packages directly, in parallel
	 * with this package, itself.
	 * <p>Of this package and its interdependencies, all packages which
	 * have not yet been registered by their URI values are first created
	 * and registered.  The packages are then initialized in two steps:
	 * meta-model objects for all of the packages are created before any
	 * are initialized, since one package's meta-model objects may refer to
	 * those of another.
	 * <p>Invocation of this method will not affect any packages that have
	 * already been initialized.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static SuitePackage init() {
		if (isInited) return (SuitePackage)EPackage.Registry.INSTANCE.getEPackage(SuitePackage.eNS_URI);

		// Obtain or create and register package
		SuitePackageImpl theSuitePackage = (SuitePackageImpl)(EPackage.Registry.INSTANCE.getEPackage(eNS_URI) instanceof SuitePackageImpl ? EPackage.Registry.INSTANCE.getEPackage(eNS_URI) : new SuitePackageImpl());

		isInited = true;

		// Initialize simple dependencies
		XMLTypePackage.eINSTANCE.eClass();

		// Obtain or create and register interdependencies
		SchemaPackageImpl theSchemaPackage = (SchemaPackageImpl)(EPackage.Registry.INSTANCE.getEPackage(SchemaPackage.eNS_URI) instanceof SchemaPackageImpl ? EPackage.Registry.INSTANCE.getEPackage(SchemaPackage.eNS_URI) : SchemaPackage.eINSTANCE);

		// Create package meta-data objects
		theSuitePackage.createPackageContents();
		theSchemaPackage.createPackageContents();

		// Initialize created meta-data
		theSuitePackage.initializePackageContents();
		theSchemaPackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theSuitePackage.freeze();

		return theSuitePackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCheckType() {
		return checkTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCheckType_CheckOperator() {
		return (EAttribute)checkTypeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCheckType_ExpectedValue() {
		return (EReference)checkTypeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getConditionType() {
		return conditionTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getConditionType_Expression() {
		return (EReference)conditionTypeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDocumentRoot() {
		return documentRootEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDocumentRoot_Mixed() {
		return (EAttribute)documentRootEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDocumentRoot_XMLNSPrefixMap() {
		return (EReference)documentRootEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDocumentRoot_XSISchemaLocation() {
		return (EReference)documentRootEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDocumentRoot_TestCase() {
		return (EReference)documentRootEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDocumentRoot_TestScenario() {
		return (EReference)documentRootEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDocumentRoot_TestSuite() {
		return (EReference)documentRootEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getExpressionType() {
		return expressionTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getExpressionType_Value() {
		return (EAttribute)expressionTypeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getExpressionType_Executable() {
		return (EAttribute)expressionTypeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getGoalPlanType() {
		return goalPlanTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getGoalPlanType_Goal() {
		return (EAttribute)goalPlanTypeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getGoalPlanType_Plan() {
		return (EAttribute)goalPlanTypeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getGoalPlanType_Relationship() {
		return (EAttribute)goalPlanTypeEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getGoalPlanType_PreCondition() {
		return (EReference)goalPlanTypeEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getGoalPlanType_PostCondition() {
		return (EReference)goalPlanTypeEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getParamType() {
		return paramTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getParamType_Value() {
		return (EAttribute)paramTypeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getParamType_Ref() {
		return (EAttribute)paramTypeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getParamType_Class() {
		return (EAttribute)paramTypeEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getParamType_Name() {
		return (EAttribute)paramTypeEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTActionType() {
		return tActionTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTActionType_ID() {
		return (EAttribute)tActionTypeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTActionType_Initiator() {
		return (EAttribute)tActionTypeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTActionType_Responder() {
		return (EAttribute)tActionTypeEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTActionType_ActType() {
		return (EAttribute)tActionTypeEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTActionType_NextAction() {
		return (EAttribute)tActionTypeEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTActionType_NextIfTrue() {
		return (EAttribute)tActionTypeEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTActionType_NextIfFalse() {
		return (EAttribute)tActionTypeEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTActionType_Message() {
		return (EReference)tActionTypeEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTActionType_Verdict() {
		return (EReference)tActionTypeEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTActionType_Timeout() {
		return (EAttribute)tActionTypeEClass.getEStructuralFeatures().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTargetType() {
		return targetTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTargetType_Agent() {
		return (EAttribute)targetTypeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTargetType_GoalPlan() {
		return (EReference)targetTypeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTaskType1() {
		return taskType1EClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTaskType1_Param() {
		return (EReference)taskType1EClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTaskType1_Class() {
		return (EAttribute)taskType1EClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTaskType1_Desc() {
		return (EAttribute)taskType1EClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTaskType1_Name() {
		return (EAttribute)taskType1EClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTaskType1_Type() {
		return (EAttribute)taskType1EClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTestCaseType() {
		return testCaseTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTestCaseType_ID() {
		return (EAttribute)testCaseTypeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTestCaseType_Name() {
		return (EAttribute)testCaseTypeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTestCaseType_Type() {
		return (EAttribute)testCaseTypeEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTestCaseType_Description() {
		return (EAttribute)testCaseTypeEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTestCaseType_Setup() {
		return (EReference)testCaseTypeEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTestCaseType_Teardown() {
		return (EReference)testCaseTypeEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTestCaseType_Scenario() {
		return (EReference)testCaseTypeEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTestCaseType_PreCondition() {
		return (EReference)testCaseTypeEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTestCaseType_PostCondition() {
		return (EReference)testCaseTypeEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTestCaseType_Active() {
		return (EAttribute)testCaseTypeEClass.getEStructuralFeatures().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTestCaseType_Priority() {
		return (EAttribute)testCaseTypeEClass.getEStructuralFeatures().get(10);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTestScenarioType() {
		return testScenarioTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTestScenarioType_TestAction() {
		return (EReference)testScenarioTypeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTestScenarioType_Link() {
		return (EReference)testScenarioTypeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTestSuiteType() {
		return testSuiteTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTestSuiteType_ID() {
		return (EAttribute)testSuiteTypeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTestSuiteType_Name() {
		return (EAttribute)testSuiteTypeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTestSuiteType_CreatedBy() {
		return (EAttribute)testSuiteTypeEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTestSuiteType_Version() {
		return (EAttribute)testSuiteTypeEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTestSuiteType_CreatedDate() {
		return (EAttribute)testSuiteTypeEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTestSuiteType_Description() {
		return (EAttribute)testSuiteTypeEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTestSuiteType_Target() {
		return (EReference)testSuiteTypeEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTestSuiteType_TestCase() {
		return (EReference)testSuiteTypeEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTestSuiteType_Setup() {
		return (EReference)testSuiteTypeEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTestSuiteType_Teardown() {
		return (EReference)testSuiteTypeEClass.getEStructuralFeatures().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTestSuiteType_GoalLink() {
		return (EReference)testSuiteTypeEClass.getEStructuralFeatures().get(10);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTestSuiteType_SendLink() {
		return (EReference)testSuiteTypeEClass.getEStructuralFeatures().get(11);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTestSuiteType_ReceiveLink() {
		return (EReference)testSuiteTypeEClass.getEStructuralFeatures().get(12);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTestSupportType() {
		return testSupportTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTestSupportType_Task() {
		return (EReference)testSupportTypeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTestSupportType_Name() {
		return (EAttribute)testSupportTypeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getOrderLinkType() {
		return orderLinkTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getOrderLinkType_Desc() {
		return (EAttribute)orderLinkTypeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getOrderLinkType_Source() {
		return (EReference)orderLinkTypeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getOrderLinkType_Target() {
		return (EReference)orderLinkTypeEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getOrderLinkType_OrderType() {
		return (EAttribute)orderLinkTypeEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSetupType() {
		return setupTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTeardownType() {
		return teardownTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getGoalLinkType() {
		return goalLinkTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getGoalLinkType_Source() {
		return (EReference)goalLinkTypeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getGoalLinkType_Target() {
		return (EReference)goalLinkTypeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getGoalLinkType_Name() {
		return (EAttribute)goalLinkTypeEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSendLinkType() {
		return sendLinkTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getSendLinkType_Source() {
		return (EReference)sendLinkTypeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getSendLinkType_Target() {
		return (EReference)sendLinkTypeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSendLinkType_Name() {
		return (EAttribute)sendLinkTypeEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getReceiveLinkType() {
		return receiveLinkTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getReceiveLinkType_Target() {
		return (EReference)receiveLinkTypeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getReceiveLinkType_Source() {
		return (EReference)receiveLinkTypeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getReceiveLinkType_Name() {
		return (EAttribute)receiveLinkTypeEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getAType() {
		return aTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getGoalReachType() {
		return goalReachTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getOperatorType() {
		return operatorTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getRelationshipType() {
		return relationshipTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getTaskType() {
		return taskTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getOrderType() {
		return orderTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getATypeObject() {
		return aTypeObjectEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getGoalReachTypeObject() {
		return goalReachTypeObjectEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getOperatorTypeObject() {
		return operatorTypeObjectEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getRelationshipTypeObject() {
		return relationshipTypeObjectEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getTaskTypeObject() {
		return taskTypeObjectEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SuiteFactory getSuiteFactory() {
		return (SuiteFactory)getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated) return;
		isCreated = true;

		// Create classes and their features
		checkTypeEClass = createEClass(CHECK_TYPE);
		createEAttribute(checkTypeEClass, CHECK_TYPE__CHECK_OPERATOR);
		createEReference(checkTypeEClass, CHECK_TYPE__EXPECTED_VALUE);

		conditionTypeEClass = createEClass(CONDITION_TYPE);
		createEReference(conditionTypeEClass, CONDITION_TYPE__EXPRESSION);

		documentRootEClass = createEClass(DOCUMENT_ROOT);
		createEAttribute(documentRootEClass, DOCUMENT_ROOT__MIXED);
		createEReference(documentRootEClass, DOCUMENT_ROOT__XMLNS_PREFIX_MAP);
		createEReference(documentRootEClass, DOCUMENT_ROOT__XSI_SCHEMA_LOCATION);
		createEReference(documentRootEClass, DOCUMENT_ROOT__TEST_CASE);
		createEReference(documentRootEClass, DOCUMENT_ROOT__TEST_SCENARIO);
		createEReference(documentRootEClass, DOCUMENT_ROOT__TEST_SUITE);

		expressionTypeEClass = createEClass(EXPRESSION_TYPE);
		createEAttribute(expressionTypeEClass, EXPRESSION_TYPE__VALUE);
		createEAttribute(expressionTypeEClass, EXPRESSION_TYPE__EXECUTABLE);

		goalPlanTypeEClass = createEClass(GOAL_PLAN_TYPE);
		createEAttribute(goalPlanTypeEClass, GOAL_PLAN_TYPE__GOAL);
		createEAttribute(goalPlanTypeEClass, GOAL_PLAN_TYPE__PLAN);
		createEAttribute(goalPlanTypeEClass, GOAL_PLAN_TYPE__RELATIONSHIP);
		createEReference(goalPlanTypeEClass, GOAL_PLAN_TYPE__PRE_CONDITION);
		createEReference(goalPlanTypeEClass, GOAL_PLAN_TYPE__POST_CONDITION);

		paramTypeEClass = createEClass(PARAM_TYPE);
		createEAttribute(paramTypeEClass, PARAM_TYPE__VALUE);
		createEAttribute(paramTypeEClass, PARAM_TYPE__REF);
		createEAttribute(paramTypeEClass, PARAM_TYPE__CLASS);
		createEAttribute(paramTypeEClass, PARAM_TYPE__NAME);

		tActionTypeEClass = createEClass(TACTION_TYPE);
		createEAttribute(tActionTypeEClass, TACTION_TYPE__ID);
		createEAttribute(tActionTypeEClass, TACTION_TYPE__INITIATOR);
		createEAttribute(tActionTypeEClass, TACTION_TYPE__RESPONDER);
		createEAttribute(tActionTypeEClass, TACTION_TYPE__ACT_TYPE);
		createEAttribute(tActionTypeEClass, TACTION_TYPE__NEXT_ACTION);
		createEAttribute(tActionTypeEClass, TACTION_TYPE__NEXT_IF_TRUE);
		createEAttribute(tActionTypeEClass, TACTION_TYPE__NEXT_IF_FALSE);
		createEReference(tActionTypeEClass, TACTION_TYPE__MESSAGE);
		createEReference(tActionTypeEClass, TACTION_TYPE__VERDICT);
		createEAttribute(tActionTypeEClass, TACTION_TYPE__TIMEOUT);

		targetTypeEClass = createEClass(TARGET_TYPE);
		createEAttribute(targetTypeEClass, TARGET_TYPE__AGENT);
		createEReference(targetTypeEClass, TARGET_TYPE__GOAL_PLAN);

		taskType1EClass = createEClass(TASK_TYPE1);
		createEReference(taskType1EClass, TASK_TYPE1__PARAM);
		createEAttribute(taskType1EClass, TASK_TYPE1__CLASS);
		createEAttribute(taskType1EClass, TASK_TYPE1__DESC);
		createEAttribute(taskType1EClass, TASK_TYPE1__NAME);
		createEAttribute(taskType1EClass, TASK_TYPE1__TYPE);

		testCaseTypeEClass = createEClass(TEST_CASE_TYPE);
		createEAttribute(testCaseTypeEClass, TEST_CASE_TYPE__ID);
		createEAttribute(testCaseTypeEClass, TEST_CASE_TYPE__NAME);
		createEAttribute(testCaseTypeEClass, TEST_CASE_TYPE__TYPE);
		createEAttribute(testCaseTypeEClass, TEST_CASE_TYPE__DESCRIPTION);
		createEReference(testCaseTypeEClass, TEST_CASE_TYPE__SETUP);
		createEReference(testCaseTypeEClass, TEST_CASE_TYPE__TEARDOWN);
		createEReference(testCaseTypeEClass, TEST_CASE_TYPE__SCENARIO);
		createEReference(testCaseTypeEClass, TEST_CASE_TYPE__PRE_CONDITION);
		createEReference(testCaseTypeEClass, TEST_CASE_TYPE__POST_CONDITION);
		createEAttribute(testCaseTypeEClass, TEST_CASE_TYPE__ACTIVE);
		createEAttribute(testCaseTypeEClass, TEST_CASE_TYPE__PRIORITY);

		testScenarioTypeEClass = createEClass(TEST_SCENARIO_TYPE);
		createEReference(testScenarioTypeEClass, TEST_SCENARIO_TYPE__TEST_ACTION);
		createEReference(testScenarioTypeEClass, TEST_SCENARIO_TYPE__LINK);

		testSuiteTypeEClass = createEClass(TEST_SUITE_TYPE);
		createEAttribute(testSuiteTypeEClass, TEST_SUITE_TYPE__ID);
		createEAttribute(testSuiteTypeEClass, TEST_SUITE_TYPE__NAME);
		createEAttribute(testSuiteTypeEClass, TEST_SUITE_TYPE__CREATED_BY);
		createEAttribute(testSuiteTypeEClass, TEST_SUITE_TYPE__VERSION);
		createEAttribute(testSuiteTypeEClass, TEST_SUITE_TYPE__CREATED_DATE);
		createEAttribute(testSuiteTypeEClass, TEST_SUITE_TYPE__DESCRIPTION);
		createEReference(testSuiteTypeEClass, TEST_SUITE_TYPE__TARGET);
		createEReference(testSuiteTypeEClass, TEST_SUITE_TYPE__TEST_CASE);
		createEReference(testSuiteTypeEClass, TEST_SUITE_TYPE__SETUP);
		createEReference(testSuiteTypeEClass, TEST_SUITE_TYPE__TEARDOWN);
		createEReference(testSuiteTypeEClass, TEST_SUITE_TYPE__GOAL_LINK);
		createEReference(testSuiteTypeEClass, TEST_SUITE_TYPE__SEND_LINK);
		createEReference(testSuiteTypeEClass, TEST_SUITE_TYPE__RECEIVE_LINK);

		testSupportTypeEClass = createEClass(TEST_SUPPORT_TYPE);
		createEReference(testSupportTypeEClass, TEST_SUPPORT_TYPE__TASK);
		createEAttribute(testSupportTypeEClass, TEST_SUPPORT_TYPE__NAME);

		orderLinkTypeEClass = createEClass(ORDER_LINK_TYPE);
		createEAttribute(orderLinkTypeEClass, ORDER_LINK_TYPE__DESC);
		createEReference(orderLinkTypeEClass, ORDER_LINK_TYPE__SOURCE);
		createEReference(orderLinkTypeEClass, ORDER_LINK_TYPE__TARGET);
		createEAttribute(orderLinkTypeEClass, ORDER_LINK_TYPE__ORDER_TYPE);

		setupTypeEClass = createEClass(SETUP_TYPE);

		teardownTypeEClass = createEClass(TEARDOWN_TYPE);

		goalLinkTypeEClass = createEClass(GOAL_LINK_TYPE);
		createEReference(goalLinkTypeEClass, GOAL_LINK_TYPE__SOURCE);
		createEReference(goalLinkTypeEClass, GOAL_LINK_TYPE__TARGET);
		createEAttribute(goalLinkTypeEClass, GOAL_LINK_TYPE__NAME);

		sendLinkTypeEClass = createEClass(SEND_LINK_TYPE);
		createEReference(sendLinkTypeEClass, SEND_LINK_TYPE__SOURCE);
		createEReference(sendLinkTypeEClass, SEND_LINK_TYPE__TARGET);
		createEAttribute(sendLinkTypeEClass, SEND_LINK_TYPE__NAME);

		receiveLinkTypeEClass = createEClass(RECEIVE_LINK_TYPE);
		createEReference(receiveLinkTypeEClass, RECEIVE_LINK_TYPE__TARGET);
		createEReference(receiveLinkTypeEClass, RECEIVE_LINK_TYPE__SOURCE);
		createEAttribute(receiveLinkTypeEClass, RECEIVE_LINK_TYPE__NAME);

		// Create enums
		aTypeEEnum = createEEnum(ATYPE);
		goalReachTypeEEnum = createEEnum(GOAL_REACH_TYPE);
		operatorTypeEEnum = createEEnum(OPERATOR_TYPE);
		relationshipTypeEEnum = createEEnum(RELATIONSHIP_TYPE);
		taskTypeEEnum = createEEnum(TASK_TYPE);
		orderTypeEEnum = createEEnum(ORDER_TYPE);

		// Create data types
		aTypeObjectEDataType = createEDataType(ATYPE_OBJECT);
		goalReachTypeObjectEDataType = createEDataType(GOAL_REACH_TYPE_OBJECT);
		operatorTypeObjectEDataType = createEDataType(OPERATOR_TYPE_OBJECT);
		relationshipTypeObjectEDataType = createEDataType(RELATIONSHIP_TYPE_OBJECT);
		taskTypeObjectEDataType = createEDataType(TASK_TYPE_OBJECT);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized) return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Obtain other dependent packages
		SchemaPackage theSchemaPackage = (SchemaPackage)EPackage.Registry.INSTANCE.getEPackage(SchemaPackage.eNS_URI);
		XMLTypePackage theXMLTypePackage = (XMLTypePackage)EPackage.Registry.INSTANCE.getEPackage(XMLTypePackage.eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		setupTypeEClass.getESuperTypes().add(this.getTestSupportType());
		teardownTypeEClass.getESuperTypes().add(this.getTestSupportType());

		// Initialize classes and features; add operations and parameters
		initEClass(checkTypeEClass, CheckType.class, "CheckType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getCheckType_CheckOperator(), this.getOperatorType(), "checkOperator", "equal", 1, 1, CheckType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCheckType_ExpectedValue(), theSchemaPackage.getFipaMessageType(), null, "expectedValue", null, 1, 1, CheckType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(conditionTypeEClass, ConditionType.class, "ConditionType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getConditionType_Expression(), this.getExpressionType(), null, "expression", null, 0, -1, ConditionType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(documentRootEClass, DocumentRoot.class, "DocumentRoot", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getDocumentRoot_Mixed(), ecorePackage.getEFeatureMapEntry(), "mixed", null, 0, -1, null, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDocumentRoot_XMLNSPrefixMap(), ecorePackage.getEStringToStringMapEntry(), null, "xMLNSPrefixMap", null, 0, -1, null, IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDocumentRoot_XSISchemaLocation(), ecorePackage.getEStringToStringMapEntry(), null, "xSISchemaLocation", null, 0, -1, null, IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDocumentRoot_TestCase(), this.getTestCaseType(), null, "testCase", null, 0, -2, null, IS_TRANSIENT, IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, IS_DERIVED, IS_ORDERED);
		initEReference(getDocumentRoot_TestScenario(), this.getTestScenarioType(), null, "testScenario", null, 0, -2, null, IS_TRANSIENT, IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, IS_DERIVED, IS_ORDERED);
		initEReference(getDocumentRoot_TestSuite(), this.getTestSuiteType(), null, "testSuite", null, 0, -2, null, IS_TRANSIENT, IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, IS_DERIVED, IS_ORDERED);

		initEClass(expressionTypeEClass, ExpressionType.class, "ExpressionType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getExpressionType_Value(), theXMLTypePackage.getString(), "value", null, 1, 1, ExpressionType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getExpressionType_Executable(), theXMLTypePackage.getBoolean(), "executable", null, 0, 1, ExpressionType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(goalPlanTypeEClass, GoalPlanType.class, "GoalPlanType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getGoalPlanType_Goal(), theXMLTypePackage.getString(), "goal", null, 1, 1, GoalPlanType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getGoalPlanType_Plan(), theXMLTypePackage.getString(), "plan", null, 1, 1, GoalPlanType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getGoalPlanType_Relationship(), this.getRelationshipType(), "relationship", "Means-End", 1, 1, GoalPlanType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getGoalPlanType_PreCondition(), this.getConditionType(), null, "preCondition", null, 0, 1, GoalPlanType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getGoalPlanType_PostCondition(), this.getConditionType(), null, "postCondition", null, 0, 1, GoalPlanType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(paramTypeEClass, ParamType.class, "ParamType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getParamType_Value(), theXMLTypePackage.getString(), "value", null, 0, 1, ParamType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getParamType_Ref(), theXMLTypePackage.getIDREF(), "ref", null, 0, 1, ParamType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getParamType_Class(), theXMLTypePackage.getString(), "class", null, 0, 1, ParamType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getParamType_Name(), theXMLTypePackage.getString(), "name", null, 0, 1, ParamType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(tActionTypeEClass, TActionType.class, "TActionType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getTActionType_ID(), theXMLTypePackage.getID(), "iD", null, 1, 1, TActionType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTActionType_Initiator(), theXMLTypePackage.getString(), "initiator", null, 0, 1, TActionType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTActionType_Responder(), theXMLTypePackage.getString(), "responder", null, 0, 1, TActionType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTActionType_ActType(), this.getAType(), "actType", "Initial", 1, 1, TActionType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTActionType_NextAction(), theXMLTypePackage.getIDREF(), "nextAction", null, 0, 1, TActionType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTActionType_NextIfTrue(), theXMLTypePackage.getIDREF(), "nextIfTrue", null, 0, 1, TActionType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTActionType_NextIfFalse(), theXMLTypePackage.getIDREF(), "nextIfFalse", null, 0, 1, TActionType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTActionType_Message(), theSchemaPackage.getFipaMessageType(), null, "message", null, 0, 1, TActionType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTActionType_Verdict(), this.getCheckType(), null, "verdict", null, 0, 1, TActionType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTActionType_Timeout(), theXMLTypePackage.getInt(), "timeout", "1000", 0, 1, TActionType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(targetTypeEClass, TargetType.class, "TargetType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getTargetType_Agent(), theXMLTypePackage.getString(), "agent", null, 1, 1, TargetType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTargetType_GoalPlan(), this.getGoalPlanType(), null, "goalPlan", null, 1, -1, TargetType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(taskType1EClass, TaskType1.class, "TaskType1", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getTaskType1_Param(), this.getParamType(), null, "param", null, 0, -1, TaskType1.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTaskType1_Class(), theXMLTypePackage.getString(), "class", null, 0, 1, TaskType1.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTaskType1_Desc(), theXMLTypePackage.getString(), "desc", null, 0, 1, TaskType1.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTaskType1_Name(), theXMLTypePackage.getString(), "name", null, 0, 1, TaskType1.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTaskType1_Type(), this.getTaskType(), "type", "Register-Agent", 1, 1, TaskType1.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(testCaseTypeEClass, TestCaseType.class, "TestCaseType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getTestCaseType_ID(), theXMLTypePackage.getID(), "iD", null, 1, 1, TestCaseType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTestCaseType_Name(), theXMLTypePackage.getString(), "name", null, 1, 1, TestCaseType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTestCaseType_Type(), this.getGoalReachType(), "type", "Possitive", 0, 1, TestCaseType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTestCaseType_Description(), theXMLTypePackage.getString(), "description", null, 0, 1, TestCaseType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTestCaseType_Setup(), this.getSetupType(), null, "setup", null, 0, 1, TestCaseType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTestCaseType_Teardown(), this.getTeardownType(), null, "teardown", null, 0, 1, TestCaseType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTestCaseType_Scenario(), this.getTestScenarioType(), null, "scenario", null, 1, 1, TestCaseType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTestCaseType_PreCondition(), this.getConditionType(), null, "preCondition", null, 0, 1, TestCaseType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTestCaseType_PostCondition(), this.getConditionType(), null, "postCondition", null, 0, 1, TestCaseType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTestCaseType_Active(), theXMLTypePackage.getBoolean(), "active", null, 1, 1, TestCaseType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTestCaseType_Priority(), theXMLTypePackage.getDouble(), "priority", null, 1, 1, TestCaseType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(testScenarioTypeEClass, TestScenarioType.class, "TestScenarioType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getTestScenarioType_TestAction(), this.getTActionType(), null, "testAction", null, 1, -1, TestScenarioType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTestScenarioType_Link(), this.getOrderLinkType(), null, "link", null, 0, -1, TestScenarioType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(testSuiteTypeEClass, TestSuiteType.class, "TestSuiteType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getTestSuiteType_ID(), theXMLTypePackage.getID(), "iD", null, 1, 1, TestSuiteType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTestSuiteType_Name(), theXMLTypePackage.getString(), "name", null, 1, 1, TestSuiteType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTestSuiteType_CreatedBy(), theXMLTypePackage.getString(), "createdBy", null, 1, 1, TestSuiteType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTestSuiteType_Version(), theXMLTypePackage.getString(), "version", null, 1, 1, TestSuiteType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTestSuiteType_CreatedDate(), theXMLTypePackage.getDate(), "createdDate", null, 1, 1, TestSuiteType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTestSuiteType_Description(), theXMLTypePackage.getString(), "description", null, 1, 1, TestSuiteType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTestSuiteType_Target(), this.getTargetType(), null, "target", null, 1, -1, TestSuiteType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTestSuiteType_TestCase(), this.getTestCaseType(), null, "testCase", null, 0, -1, TestSuiteType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTestSuiteType_Setup(), this.getSetupType(), null, "setup", null, 0, 1, TestSuiteType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTestSuiteType_Teardown(), this.getTeardownType(), null, "teardown", null, 0, 1, TestSuiteType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTestSuiteType_GoalLink(), this.getGoalLinkType(), null, "goalLink", null, 0, -1, TestSuiteType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTestSuiteType_SendLink(), this.getSendLinkType(), null, "sendLink", null, 0, -1, TestSuiteType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTestSuiteType_ReceiveLink(), this.getReceiveLinkType(), null, "receiveLink", null, 0, -1, TestSuiteType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(testSupportTypeEClass, TestSupportType.class, "TestSupportType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getTestSupportType_Task(), this.getTaskType1(), null, "task", null, 0, -1, TestSupportType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTestSupportType_Name(), theXMLTypePackage.getString(), "name", null, 0, 1, TestSupportType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(orderLinkTypeEClass, OrderLinkType.class, "OrderLinkType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getOrderLinkType_Desc(), ecorePackage.getEString(), "desc", null, 0, 1, OrderLinkType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getOrderLinkType_Source(), this.getTActionType(), null, "source", null, 0, 1, OrderLinkType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getOrderLinkType_Target(), this.getTActionType(), null, "target", null, 0, 1, OrderLinkType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getOrderLinkType_OrderType(), this.getOrderType(), "orderType", null, 0, 1, OrderLinkType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(setupTypeEClass, SetupType.class, "SetupType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(teardownTypeEClass, TeardownType.class, "TeardownType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(goalLinkTypeEClass, GoalLinkType.class, "GoalLinkType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getGoalLinkType_Source(), this.getTActionType(), null, "source", null, 0, 1, GoalLinkType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getGoalLinkType_Target(), this.getGoalPlanType(), null, "target", null, 0, 1, GoalLinkType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getGoalLinkType_Name(), theXMLTypePackage.getString(), "name", null, 0, 1, GoalLinkType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(sendLinkTypeEClass, SendLinkType.class, "SendLinkType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getSendLinkType_Source(), this.getTActionType(), null, "source", null, 0, 1, SendLinkType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getSendLinkType_Target(), this.getTargetType(), null, "target", null, 0, 1, SendLinkType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSendLinkType_Name(), theXMLTypePackage.getString(), "name", null, 0, 1, SendLinkType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(receiveLinkTypeEClass, ReceiveLinkType.class, "ReceiveLinkType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getReceiveLinkType_Target(), this.getTActionType(), null, "target", null, 0, 1, ReceiveLinkType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getReceiveLinkType_Source(), this.getTargetType(), null, "source", null, 0, 1, ReceiveLinkType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getReceiveLinkType_Name(), theXMLTypePackage.getString(), "name", null, 0, 1, ReceiveLinkType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		// Initialize enums and add enum literals
		initEEnum(aTypeEEnum, AType.class, "AType");
		addEEnumLiteral(aTypeEEnum, AType.INITIAL);
		addEEnumLiteral(aTypeEEnum, AType.FINAL);
		addEEnumLiteral(aTypeEEnum, AType.COMMUNICATION);
		addEEnumLiteral(aTypeEEnum, AType.BRANCH);
		addEEnumLiteral(aTypeEEnum, AType.CHECKPOINT);
		addEEnumLiteral(aTypeEEnum, AType.WAIT);
		addEEnumLiteral(aTypeEEnum, AType.ENV_EFFECT);

		initEEnum(goalReachTypeEEnum, GoalReachType.class, "GoalReachType");
		addEEnumLiteral(goalReachTypeEEnum, GoalReachType.POSSITIVE);
		addEEnumLiteral(goalReachTypeEEnum, GoalReachType.NEGATIVE);
		addEEnumLiteral(goalReachTypeEEnum, GoalReachType.UNSPECIFIED);

		initEEnum(operatorTypeEEnum, OperatorType.class, "OperatorType");
		addEEnumLiteral(operatorTypeEEnum, OperatorType.EQUAL);
		addEEnumLiteral(operatorTypeEEnum, OperatorType.NOT_EQUAL);
		addEEnumLiteral(operatorTypeEEnum, OperatorType.GREATER_OR_EQUAL);
		addEEnumLiteral(operatorTypeEEnum, OperatorType.LESS_OR_EQUAL);
		addEEnumLiteral(operatorTypeEEnum, OperatorType.GREATER);
		addEEnumLiteral(operatorTypeEEnum, OperatorType.LESS);
		addEEnumLiteral(operatorTypeEEnum, OperatorType.CONTAINS);
		addEEnumLiteral(operatorTypeEEnum, OperatorType.NOT_CONTAINS);
		addEEnumLiteral(operatorTypeEEnum, OperatorType.IS_NULL);
		addEEnumLiteral(operatorTypeEEnum, OperatorType.NOT_NULL);
		addEEnumLiteral(operatorTypeEEnum, OperatorType.INSTANCE_OF);
		addEEnumLiteral(operatorTypeEEnum, OperatorType.IS_VALID);

		initEEnum(relationshipTypeEEnum, RelationshipType.class, "RelationshipType");
		addEEnumLiteral(relationshipTypeEEnum, RelationshipType.MEANS_END);
		addEEnumLiteral(relationshipTypeEEnum, RelationshipType.CONTRIBUTION);
		addEEnumLiteral(relationshipTypeEEnum, RelationshipType.CONTRIBUTION1);
		addEEnumLiteral(relationshipTypeEEnum, RelationshipType.CONTRIBUTION2);
		addEEnumLiteral(relationshipTypeEEnum, RelationshipType.CONTRIBUTION3);
		addEEnumLiteral(relationshipTypeEEnum, RelationshipType.DECOMPOSITION_AND);
		addEEnumLiteral(relationshipTypeEEnum, RelationshipType.DECOMPOSITION_OR);

		initEEnum(taskTypeEEnum, TaskType.class, "TaskType");
		addEEnumLiteral(taskTypeEEnum, TaskType.REGISTER_AGENT);
		addEEnumLiteral(taskTypeEEnum, TaskType.DEREGISTER_AGENT);
		addEEnumLiteral(taskTypeEEnum, TaskType.START_AGENT);
		addEEnumLiteral(taskTypeEEnum, TaskType.KILL_AGENT);
		addEEnumLiteral(taskTypeEEnum, TaskType.SUSPEND_AGENT);
		addEEnumLiteral(taskTypeEEnum, TaskType.ACTIVATE_AGENT);
		addEEnumLiteral(taskTypeEEnum, TaskType.EXECUTE_CAPABILITY);
		addEEnumLiteral(taskTypeEEnum, TaskType.EXECUTE_JAVA);
		addEEnumLiteral(taskTypeEEnum, TaskType.NON_EXECUTABLE);

		initEEnum(orderTypeEEnum, OrderType.class, "OrderType");
		addEEnumLiteral(orderTypeEEnum, OrderType.SUBSEQUENCE);
		addEEnumLiteral(orderTypeEEnum, OrderType.ONLY_IF_TRUE);
		addEEnumLiteral(orderTypeEEnum, OrderType.ONLY_IF_FALSE);

		// Initialize data types
		initEDataType(aTypeObjectEDataType, AType.class, "ATypeObject", IS_SERIALIZABLE, IS_GENERATED_INSTANCE_CLASS);
		initEDataType(goalReachTypeObjectEDataType, GoalReachType.class, "GoalReachTypeObject", IS_SERIALIZABLE, IS_GENERATED_INSTANCE_CLASS);
		initEDataType(operatorTypeObjectEDataType, OperatorType.class, "OperatorTypeObject", IS_SERIALIZABLE, IS_GENERATED_INSTANCE_CLASS);
		initEDataType(relationshipTypeObjectEDataType, RelationshipType.class, "RelationshipTypeObject", IS_SERIALIZABLE, IS_GENERATED_INSTANCE_CLASS);
		initEDataType(taskTypeObjectEDataType, TaskType.class, "TaskTypeObject", IS_SERIALIZABLE, IS_GENERATED_INSTANCE_CLASS);

		// Create resource
		createResource(eNS_URI);

		// Create annotations
		// http:///org/eclipse/emf/ecore/util/ExtendedMetaData
		createExtendedMetaDataAnnotations();
	}

	/**
	 * Initializes the annotations for <b>http:///org/eclipse/emf/ecore/util/ExtendedMetaData</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createExtendedMetaDataAnnotations() {
		String source = "http:///org/eclipse/emf/ecore/util/ExtendedMetaData";		
		addAnnotation
		  (aTypeEEnum, 
		   source, 
		   new String[] {
			 "name", "AType"
		   });		
		addAnnotation
		  (aTypeObjectEDataType, 
		   source, 
		   new String[] {
			 "name", "AType:Object",
			 "baseType", "AType"
		   });		
		addAnnotation
		  (checkTypeEClass, 
		   source, 
		   new String[] {
			 "name", "CheckType",
			 "kind", "elementOnly"
		   });		
		addAnnotation
		  (getCheckType_CheckOperator(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "CheckOperator",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getCheckType_ExpectedValue(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "ExpectedValue",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (conditionTypeEClass, 
		   source, 
		   new String[] {
			 "name", "ConditionType",
			 "kind", "elementOnly"
		   });		
		addAnnotation
		  (getConditionType_Expression(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "Expression",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (documentRootEClass, 
		   source, 
		   new String[] {
			 "name", "",
			 "kind", "mixed"
		   });		
		addAnnotation
		  (getDocumentRoot_Mixed(), 
		   source, 
		   new String[] {
			 "kind", "elementWildcard",
			 "name", ":mixed"
		   });		
		addAnnotation
		  (getDocumentRoot_XMLNSPrefixMap(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "xmlns:prefix"
		   });		
		addAnnotation
		  (getDocumentRoot_XSISchemaLocation(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "xsi:schemaLocation"
		   });			
		addAnnotation
		  (getDocumentRoot_TestCase(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "TestCase",
			 "namespace", "##targetNamespace"
		   });			
		addAnnotation
		  (getDocumentRoot_TestScenario(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "TestScenario",
			 "namespace", "##targetNamespace"
		   });			
		addAnnotation
		  (getDocumentRoot_TestSuite(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "TestSuite",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (expressionTypeEClass, 
		   source, 
		   new String[] {
			 "name", "Expression_._type",
			 "kind", "elementOnly"
		   });		
		addAnnotation
		  (getExpressionType_Value(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "Value",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getExpressionType_Executable(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "Executable"
		   });		
		addAnnotation
		  (goalPlanTypeEClass, 
		   source, 
		   new String[] {
			 "name", "GoalPlanType",
			 "kind", "elementOnly"
		   });		
		addAnnotation
		  (getGoalPlanType_Goal(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "Goal",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getGoalPlanType_Plan(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "Plan",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getGoalPlanType_Relationship(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "Relationship",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getGoalPlanType_PreCondition(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "PreCondition",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getGoalPlanType_PostCondition(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "PostCondition",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (goalReachTypeEEnum, 
		   source, 
		   new String[] {
			 "name", "GoalReachType"
		   });		
		addAnnotation
		  (goalReachTypeObjectEDataType, 
		   source, 
		   new String[] {
			 "name", "GoalReachType:Object",
			 "baseType", "GoalReachType"
		   });		
		addAnnotation
		  (operatorTypeEEnum, 
		   source, 
		   new String[] {
			 "name", "OperatorType"
		   });		
		addAnnotation
		  (operatorTypeObjectEDataType, 
		   source, 
		   new String[] {
			 "name", "OperatorType:Object",
			 "baseType", "OperatorType"
		   });		
		addAnnotation
		  (paramTypeEClass, 
		   source, 
		   new String[] {
			 "name", "ParamType",
			 "kind", "elementOnly"
		   });		
		addAnnotation
		  (getParamType_Value(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "Value",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getParamType_Ref(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "Ref",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getParamType_Class(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "Class"
		   });		
		addAnnotation
		  (getParamType_Name(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "Name"
		   });		
		addAnnotation
		  (relationshipTypeEEnum, 
		   source, 
		   new String[] {
			 "name", "RelationshipType"
		   });		
		addAnnotation
		  (relationshipTypeObjectEDataType, 
		   source, 
		   new String[] {
			 "name", "RelationshipType:Object",
			 "baseType", "RelationshipType"
		   });		
		addAnnotation
		  (tActionTypeEClass, 
		   source, 
		   new String[] {
			 "name", "TActionType",
			 "kind", "elementOnly"
		   });		
		addAnnotation
		  (getTActionType_ID(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "ID",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getTActionType_Initiator(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "Initiator",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getTActionType_Responder(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "Responder",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getTActionType_ActType(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "ActType",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getTActionType_NextAction(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "NextAction",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getTActionType_NextIfTrue(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "NextIfTrue",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getTActionType_NextIfFalse(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "NextIfFalse",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getTActionType_Message(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "Message",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getTActionType_Verdict(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "Verdict",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getTActionType_Timeout(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "Timeout",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (targetTypeEClass, 
		   source, 
		   new String[] {
			 "name", "TargetType",
			 "kind", "elementOnly"
		   });		
		addAnnotation
		  (getTargetType_Agent(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "Agent",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getTargetType_GoalPlan(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "GoalPlan",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (taskTypeEEnum, 
		   source, 
		   new String[] {
			 "name", "TaskType"
		   });		
		addAnnotation
		  (taskType1EClass, 
		   source, 
		   new String[] {
			 "name", "Task_._type",
			 "kind", "elementOnly"
		   });		
		addAnnotation
		  (getTaskType1_Param(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "Param",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getTaskType1_Class(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "Class"
		   });		
		addAnnotation
		  (getTaskType1_Desc(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "Desc"
		   });		
		addAnnotation
		  (getTaskType1_Name(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "Name"
		   });		
		addAnnotation
		  (getTaskType1_Type(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "Type"
		   });		
		addAnnotation
		  (taskTypeObjectEDataType, 
		   source, 
		   new String[] {
			 "name", "TaskType:Object",
			 "baseType", "TaskType"
		   });		
		addAnnotation
		  (testCaseTypeEClass, 
		   source, 
		   new String[] {
			 "name", "TestCaseType",
			 "kind", "elementOnly"
		   });		
		addAnnotation
		  (getTestCaseType_ID(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "ID",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getTestCaseType_Name(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "Name",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getTestCaseType_Type(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "Type",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getTestCaseType_Description(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "Description",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getTestCaseType_Setup(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "Setup",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getTestCaseType_Teardown(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "Teardown",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getTestCaseType_Scenario(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "Scenario",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getTestCaseType_PreCondition(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "PreCondition",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getTestCaseType_PostCondition(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "PostCondition",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getTestCaseType_Active(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "Active",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getTestCaseType_Priority(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "Priority",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (testScenarioTypeEClass, 
		   source, 
		   new String[] {
			 "name", "TestScenarioType",
			 "kind", "elementOnly"
		   });		
		addAnnotation
		  (getTestScenarioType_TestAction(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "TestAction",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getTestScenarioType_Link(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "Link",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (testSuiteTypeEClass, 
		   source, 
		   new String[] {
			 "name", "TestSuite_._type",
			 "kind", "elementOnly"
		   });		
		addAnnotation
		  (getTestSuiteType_ID(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "ID",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getTestSuiteType_Name(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "Name",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getTestSuiteType_CreatedBy(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "CreatedBy",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getTestSuiteType_Version(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "Version",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getTestSuiteType_CreatedDate(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "CreatedDate",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getTestSuiteType_Description(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "Description",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getTestSuiteType_Target(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "Target",
			 "namespace", "##targetNamespace"
		   });			
		addAnnotation
		  (getTestSuiteType_TestCase(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "TestCase",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getTestSuiteType_Setup(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "Setup",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getTestSuiteType_Teardown(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "Teardown",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getTestSuiteType_GoalLink(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "GoalLink",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getTestSuiteType_SendLink(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "SendLink",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getTestSuiteType_ReceiveLink(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "ReceiveLink",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (testSupportTypeEClass, 
		   source, 
		   new String[] {
			 "name", "TestSupportType",
			 "kind", "elementOnly"
		   });		
		addAnnotation
		  (getTestSupportType_Task(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "Task",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getTestSupportType_Name(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "Name"
		   });
	}

} //SuitePackageImpl
