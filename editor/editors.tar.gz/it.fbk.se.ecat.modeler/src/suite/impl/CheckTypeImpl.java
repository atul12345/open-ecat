/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package suite.impl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import schema.FipaMessageType;

import suite.CheckType;
import suite.OperatorType;
import suite.SuitePackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Check Type</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link suite.impl.CheckTypeImpl#getCheckOperator <em>Check Operator</em>}</li>
 *   <li>{@link suite.impl.CheckTypeImpl#getExpectedValue <em>Expected Value</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class CheckTypeImpl extends EObjectImpl implements CheckType {
	/**
	 * The default value of the '{@link #getCheckOperator() <em>Check Operator</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCheckOperator()
	 * @generated
	 * @ordered
	 */
	protected static final OperatorType CHECK_OPERATOR_EDEFAULT = OperatorType.EQUAL;

	/**
	 * The cached value of the '{@link #getCheckOperator() <em>Check Operator</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCheckOperator()
	 * @generated
	 * @ordered
	 */
	protected OperatorType checkOperator = CHECK_OPERATOR_EDEFAULT;

	/**
	 * This is true if the Check Operator attribute has been set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	protected boolean checkOperatorESet;

	/**
	 * The cached value of the '{@link #getExpectedValue() <em>Expected Value</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getExpectedValue()
	 * @generated
	 * @ordered
	 */
	protected FipaMessageType expectedValue;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CheckTypeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SuitePackage.Literals.CHECK_TYPE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OperatorType getCheckOperator() {
		return checkOperator;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCheckOperator(OperatorType newCheckOperator) {
		OperatorType oldCheckOperator = checkOperator;
		checkOperator = newCheckOperator == null ? CHECK_OPERATOR_EDEFAULT : newCheckOperator;
		boolean oldCheckOperatorESet = checkOperatorESet;
		checkOperatorESet = true;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SuitePackage.CHECK_TYPE__CHECK_OPERATOR, oldCheckOperator, checkOperator, !oldCheckOperatorESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetCheckOperator() {
		OperatorType oldCheckOperator = checkOperator;
		boolean oldCheckOperatorESet = checkOperatorESet;
		checkOperator = CHECK_OPERATOR_EDEFAULT;
		checkOperatorESet = false;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.UNSET, SuitePackage.CHECK_TYPE__CHECK_OPERATOR, oldCheckOperator, CHECK_OPERATOR_EDEFAULT, oldCheckOperatorESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetCheckOperator() {
		return checkOperatorESet;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FipaMessageType getExpectedValue() {
		return expectedValue;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetExpectedValue(FipaMessageType newExpectedValue, NotificationChain msgs) {
		FipaMessageType oldExpectedValue = expectedValue;
		expectedValue = newExpectedValue;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, SuitePackage.CHECK_TYPE__EXPECTED_VALUE, oldExpectedValue, newExpectedValue);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setExpectedValue(FipaMessageType newExpectedValue) {
		if (newExpectedValue != expectedValue) {
			NotificationChain msgs = null;
			if (expectedValue != null)
				msgs = ((InternalEObject)expectedValue).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - SuitePackage.CHECK_TYPE__EXPECTED_VALUE, null, msgs);
			if (newExpectedValue != null)
				msgs = ((InternalEObject)newExpectedValue).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - SuitePackage.CHECK_TYPE__EXPECTED_VALUE, null, msgs);
			msgs = basicSetExpectedValue(newExpectedValue, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SuitePackage.CHECK_TYPE__EXPECTED_VALUE, newExpectedValue, newExpectedValue));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case SuitePackage.CHECK_TYPE__EXPECTED_VALUE:
				return basicSetExpectedValue(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case SuitePackage.CHECK_TYPE__CHECK_OPERATOR:
				return getCheckOperator();
			case SuitePackage.CHECK_TYPE__EXPECTED_VALUE:
				return getExpectedValue();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case SuitePackage.CHECK_TYPE__CHECK_OPERATOR:
				setCheckOperator((OperatorType)newValue);
				return;
			case SuitePackage.CHECK_TYPE__EXPECTED_VALUE:
				setExpectedValue((FipaMessageType)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case SuitePackage.CHECK_TYPE__CHECK_OPERATOR:
				unsetCheckOperator();
				return;
			case SuitePackage.CHECK_TYPE__EXPECTED_VALUE:
				setExpectedValue((FipaMessageType)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case SuitePackage.CHECK_TYPE__CHECK_OPERATOR:
				return isSetCheckOperator();
			case SuitePackage.CHECK_TYPE__EXPECTED_VALUE:
				return expectedValue != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (checkOperator: ");
		if (checkOperatorESet) result.append(checkOperator); else result.append("<unset>");
		result.append(')');
		return result.toString();
	}

} //CheckTypeImpl
