/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package suite.impl;

import java.util.Collection;

import javax.xml.datatype.XMLGregorianCalendar;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import suite.GoalLinkType;
import suite.ReceiveLinkType;
import suite.SendLinkType;
import suite.SetupType;
import suite.SuitePackage;
import suite.TargetType;
import suite.TeardownType;
import suite.TestCaseType;
import suite.TestSuiteType;
import suite.TestSupportType;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Test Suite Type</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link suite.impl.TestSuiteTypeImpl#getID <em>ID</em>}</li>
 *   <li>{@link suite.impl.TestSuiteTypeImpl#getName <em>Name</em>}</li>
 *   <li>{@link suite.impl.TestSuiteTypeImpl#getCreatedBy <em>Created By</em>}</li>
 *   <li>{@link suite.impl.TestSuiteTypeImpl#getVersion <em>Version</em>}</li>
 *   <li>{@link suite.impl.TestSuiteTypeImpl#getCreatedDate <em>Created Date</em>}</li>
 *   <li>{@link suite.impl.TestSuiteTypeImpl#getDescription <em>Description</em>}</li>
 *   <li>{@link suite.impl.TestSuiteTypeImpl#getTarget <em>Target</em>}</li>
 *   <li>{@link suite.impl.TestSuiteTypeImpl#getTestCase <em>Test Case</em>}</li>
 *   <li>{@link suite.impl.TestSuiteTypeImpl#getSetup <em>Setup</em>}</li>
 *   <li>{@link suite.impl.TestSuiteTypeImpl#getTeardown <em>Teardown</em>}</li>
 *   <li>{@link suite.impl.TestSuiteTypeImpl#getGoalLink <em>Goal Link</em>}</li>
 *   <li>{@link suite.impl.TestSuiteTypeImpl#getSendLink <em>Send Link</em>}</li>
 *   <li>{@link suite.impl.TestSuiteTypeImpl#getReceiveLink <em>Receive Link</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class TestSuiteTypeImpl extends EObjectImpl implements TestSuiteType {
	/**
	 * The default value of the '{@link #getID() <em>ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getID()
	 * @generated
	 * @ordered
	 */
	protected static final String ID_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getID() <em>ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getID()
	 * @generated
	 * @ordered
	 */
	protected String iD = ID_EDEFAULT;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getCreatedBy() <em>Created By</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCreatedBy()
	 * @generated
	 * @ordered
	 */
	protected static final String CREATED_BY_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getCreatedBy() <em>Created By</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCreatedBy()
	 * @generated
	 * @ordered
	 */
	protected String createdBy = CREATED_BY_EDEFAULT;

	/**
	 * The default value of the '{@link #getVersion() <em>Version</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVersion()
	 * @generated
	 * @ordered
	 */
	protected static final String VERSION_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getVersion() <em>Version</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVersion()
	 * @generated
	 * @ordered
	 */
	protected String version = VERSION_EDEFAULT;

	/**
	 * The default value of the '{@link #getCreatedDate() <em>Created Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCreatedDate()
	 * @generated
	 * @ordered
	 */
	protected static final XMLGregorianCalendar CREATED_DATE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getCreatedDate() <em>Created Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCreatedDate()
	 * @generated
	 * @ordered
	 */
	protected XMLGregorianCalendar createdDate = CREATED_DATE_EDEFAULT;

	/**
	 * The default value of the '{@link #getDescription() <em>Description</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDescription()
	 * @generated
	 * @ordered
	 */
	protected static final String DESCRIPTION_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getDescription() <em>Description</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDescription()
	 * @generated
	 * @ordered
	 */
	protected String description = DESCRIPTION_EDEFAULT;

	/**
	 * The cached value of the '{@link #getTarget() <em>Target</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTarget()
	 * @generated
	 * @ordered
	 */
	protected EList<TargetType> target;

	/**
	 * The cached value of the '{@link #getTestCase() <em>Test Case</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTestCase()
	 * @generated
	 * @ordered
	 */
	protected EList<TestCaseType> testCase;

	/**
	 * The cached value of the '{@link #getSetup() <em>Setup</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSetup()
	 * @generated
	 * @ordered
	 */
	protected SetupType setup;

	/**
	 * The cached value of the '{@link #getTeardown() <em>Teardown</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTeardown()
	 * @generated
	 * @ordered
	 */
	protected TeardownType teardown;

	/**
	 * The cached value of the '{@link #getGoalLink() <em>Goal Link</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGoalLink()
	 * @generated
	 * @ordered
	 */
	protected EList<GoalLinkType> goalLink;

	/**
	 * The cached value of the '{@link #getSendLink() <em>Send Link</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSendLink()
	 * @generated
	 * @ordered
	 */
	protected EList<SendLinkType> sendLink;

	/**
	 * The cached value of the '{@link #getReceiveLink() <em>Receive Link</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getReceiveLink()
	 * @generated
	 * @ordered
	 */
	protected EList<ReceiveLinkType> receiveLink;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TestSuiteTypeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SuitePackage.Literals.TEST_SUITE_TYPE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getID() {
		return iD;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setID(String newID) {
		String oldID = iD;
		iD = newID;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SuitePackage.TEST_SUITE_TYPE__ID, oldID, iD));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SuitePackage.TEST_SUITE_TYPE__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCreatedBy(String newCreatedBy) {
		String oldCreatedBy = createdBy;
		createdBy = newCreatedBy;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SuitePackage.TEST_SUITE_TYPE__CREATED_BY, oldCreatedBy, createdBy));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getVersion() {
		return version;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setVersion(String newVersion) {
		String oldVersion = version;
		version = newVersion;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SuitePackage.TEST_SUITE_TYPE__VERSION, oldVersion, version));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public XMLGregorianCalendar getCreatedDate() {
		return createdDate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCreatedDate(XMLGregorianCalendar newCreatedDate) {
		XMLGregorianCalendar oldCreatedDate = createdDate;
		createdDate = newCreatedDate;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SuitePackage.TEST_SUITE_TYPE__CREATED_DATE, oldCreatedDate, createdDate));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDescription(String newDescription) {
		String oldDescription = description;
		description = newDescription;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SuitePackage.TEST_SUITE_TYPE__DESCRIPTION, oldDescription, description));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<TargetType> getTarget() {
		if (target == null) {
			target = new EObjectContainmentEList<TargetType>(TargetType.class, this, SuitePackage.TEST_SUITE_TYPE__TARGET);
		}
		return target;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<TestCaseType> getTestCase() {
		if (testCase == null) {
			testCase = new EObjectContainmentEList<TestCaseType>(TestCaseType.class, this, SuitePackage.TEST_SUITE_TYPE__TEST_CASE);
		}
		return testCase;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SetupType getSetup() {
		return setup;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetSetup(SetupType newSetup, NotificationChain msgs) {
		SetupType oldSetup = setup;
		setup = newSetup;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, SuitePackage.TEST_SUITE_TYPE__SETUP, oldSetup, newSetup);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSetup(SetupType newSetup) {
		if (newSetup != setup) {
			NotificationChain msgs = null;
			if (setup != null)
				msgs = ((InternalEObject)setup).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - SuitePackage.TEST_SUITE_TYPE__SETUP, null, msgs);
			if (newSetup != null)
				msgs = ((InternalEObject)newSetup).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - SuitePackage.TEST_SUITE_TYPE__SETUP, null, msgs);
			msgs = basicSetSetup(newSetup, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SuitePackage.TEST_SUITE_TYPE__SETUP, newSetup, newSetup));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TeardownType getTeardown() {
		return teardown;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetTeardown(TeardownType newTeardown, NotificationChain msgs) {
		TeardownType oldTeardown = teardown;
		teardown = newTeardown;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, SuitePackage.TEST_SUITE_TYPE__TEARDOWN, oldTeardown, newTeardown);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTeardown(TeardownType newTeardown) {
		if (newTeardown != teardown) {
			NotificationChain msgs = null;
			if (teardown != null)
				msgs = ((InternalEObject)teardown).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - SuitePackage.TEST_SUITE_TYPE__TEARDOWN, null, msgs);
			if (newTeardown != null)
				msgs = ((InternalEObject)newTeardown).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - SuitePackage.TEST_SUITE_TYPE__TEARDOWN, null, msgs);
			msgs = basicSetTeardown(newTeardown, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SuitePackage.TEST_SUITE_TYPE__TEARDOWN, newTeardown, newTeardown));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<GoalLinkType> getGoalLink() {
		if (goalLink == null) {
			goalLink = new EObjectContainmentEList<GoalLinkType>(GoalLinkType.class, this, SuitePackage.TEST_SUITE_TYPE__GOAL_LINK);
		}
		return goalLink;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<SendLinkType> getSendLink() {
		if (sendLink == null) {
			sendLink = new EObjectContainmentEList<SendLinkType>(SendLinkType.class, this, SuitePackage.TEST_SUITE_TYPE__SEND_LINK);
		}
		return sendLink;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<ReceiveLinkType> getReceiveLink() {
		if (receiveLink == null) {
			receiveLink = new EObjectContainmentEList<ReceiveLinkType>(ReceiveLinkType.class, this, SuitePackage.TEST_SUITE_TYPE__RECEIVE_LINK);
		}
		return receiveLink;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case SuitePackage.TEST_SUITE_TYPE__TARGET:
				return ((InternalEList<?>)getTarget()).basicRemove(otherEnd, msgs);
			case SuitePackage.TEST_SUITE_TYPE__TEST_CASE:
				return ((InternalEList<?>)getTestCase()).basicRemove(otherEnd, msgs);
			case SuitePackage.TEST_SUITE_TYPE__SETUP:
				return basicSetSetup(null, msgs);
			case SuitePackage.TEST_SUITE_TYPE__TEARDOWN:
				return basicSetTeardown(null, msgs);
			case SuitePackage.TEST_SUITE_TYPE__GOAL_LINK:
				return ((InternalEList<?>)getGoalLink()).basicRemove(otherEnd, msgs);
			case SuitePackage.TEST_SUITE_TYPE__SEND_LINK:
				return ((InternalEList<?>)getSendLink()).basicRemove(otherEnd, msgs);
			case SuitePackage.TEST_SUITE_TYPE__RECEIVE_LINK:
				return ((InternalEList<?>)getReceiveLink()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case SuitePackage.TEST_SUITE_TYPE__ID:
				return getID();
			case SuitePackage.TEST_SUITE_TYPE__NAME:
				return getName();
			case SuitePackage.TEST_SUITE_TYPE__CREATED_BY:
				return getCreatedBy();
			case SuitePackage.TEST_SUITE_TYPE__VERSION:
				return getVersion();
			case SuitePackage.TEST_SUITE_TYPE__CREATED_DATE:
				return getCreatedDate();
			case SuitePackage.TEST_SUITE_TYPE__DESCRIPTION:
				return getDescription();
			case SuitePackage.TEST_SUITE_TYPE__TARGET:
				return getTarget();
			case SuitePackage.TEST_SUITE_TYPE__TEST_CASE:
				return getTestCase();
			case SuitePackage.TEST_SUITE_TYPE__SETUP:
				return getSetup();
			case SuitePackage.TEST_SUITE_TYPE__TEARDOWN:
				return getTeardown();
			case SuitePackage.TEST_SUITE_TYPE__GOAL_LINK:
				return getGoalLink();
			case SuitePackage.TEST_SUITE_TYPE__SEND_LINK:
				return getSendLink();
			case SuitePackage.TEST_SUITE_TYPE__RECEIVE_LINK:
				return getReceiveLink();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case SuitePackage.TEST_SUITE_TYPE__ID:
				setID((String)newValue);
				return;
			case SuitePackage.TEST_SUITE_TYPE__NAME:
				setName((String)newValue);
				return;
			case SuitePackage.TEST_SUITE_TYPE__CREATED_BY:
				setCreatedBy((String)newValue);
				return;
			case SuitePackage.TEST_SUITE_TYPE__VERSION:
				setVersion((String)newValue);
				return;
			case SuitePackage.TEST_SUITE_TYPE__CREATED_DATE:
				setCreatedDate((XMLGregorianCalendar)newValue);
				return;
			case SuitePackage.TEST_SUITE_TYPE__DESCRIPTION:
				setDescription((String)newValue);
				return;
			case SuitePackage.TEST_SUITE_TYPE__TARGET:
				getTarget().clear();
				getTarget().addAll((Collection<? extends TargetType>)newValue);
				return;
			case SuitePackage.TEST_SUITE_TYPE__TEST_CASE:
				getTestCase().clear();
				getTestCase().addAll((Collection<? extends TestCaseType>)newValue);
				return;
			case SuitePackage.TEST_SUITE_TYPE__SETUP:
				setSetup((SetupType)newValue);
				return;
			case SuitePackage.TEST_SUITE_TYPE__TEARDOWN:
				setTeardown((TeardownType)newValue);
				return;
			case SuitePackage.TEST_SUITE_TYPE__GOAL_LINK:
				getGoalLink().clear();
				getGoalLink().addAll((Collection<? extends GoalLinkType>)newValue);
				return;
			case SuitePackage.TEST_SUITE_TYPE__SEND_LINK:
				getSendLink().clear();
				getSendLink().addAll((Collection<? extends SendLinkType>)newValue);
				return;
			case SuitePackage.TEST_SUITE_TYPE__RECEIVE_LINK:
				getReceiveLink().clear();
				getReceiveLink().addAll((Collection<? extends ReceiveLinkType>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case SuitePackage.TEST_SUITE_TYPE__ID:
				setID(ID_EDEFAULT);
				return;
			case SuitePackage.TEST_SUITE_TYPE__NAME:
				setName(NAME_EDEFAULT);
				return;
			case SuitePackage.TEST_SUITE_TYPE__CREATED_BY:
				setCreatedBy(CREATED_BY_EDEFAULT);
				return;
			case SuitePackage.TEST_SUITE_TYPE__VERSION:
				setVersion(VERSION_EDEFAULT);
				return;
			case SuitePackage.TEST_SUITE_TYPE__CREATED_DATE:
				setCreatedDate(CREATED_DATE_EDEFAULT);
				return;
			case SuitePackage.TEST_SUITE_TYPE__DESCRIPTION:
				setDescription(DESCRIPTION_EDEFAULT);
				return;
			case SuitePackage.TEST_SUITE_TYPE__TARGET:
				getTarget().clear();
				return;
			case SuitePackage.TEST_SUITE_TYPE__TEST_CASE:
				getTestCase().clear();
				return;
			case SuitePackage.TEST_SUITE_TYPE__SETUP:
				setSetup((SetupType)null);
				return;
			case SuitePackage.TEST_SUITE_TYPE__TEARDOWN:
				setTeardown((TeardownType)null);
				return;
			case SuitePackage.TEST_SUITE_TYPE__GOAL_LINK:
				getGoalLink().clear();
				return;
			case SuitePackage.TEST_SUITE_TYPE__SEND_LINK:
				getSendLink().clear();
				return;
			case SuitePackage.TEST_SUITE_TYPE__RECEIVE_LINK:
				getReceiveLink().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case SuitePackage.TEST_SUITE_TYPE__ID:
				return ID_EDEFAULT == null ? iD != null : !ID_EDEFAULT.equals(iD);
			case SuitePackage.TEST_SUITE_TYPE__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case SuitePackage.TEST_SUITE_TYPE__CREATED_BY:
				return CREATED_BY_EDEFAULT == null ? createdBy != null : !CREATED_BY_EDEFAULT.equals(createdBy);
			case SuitePackage.TEST_SUITE_TYPE__VERSION:
				return VERSION_EDEFAULT == null ? version != null : !VERSION_EDEFAULT.equals(version);
			case SuitePackage.TEST_SUITE_TYPE__CREATED_DATE:
				return CREATED_DATE_EDEFAULT == null ? createdDate != null : !CREATED_DATE_EDEFAULT.equals(createdDate);
			case SuitePackage.TEST_SUITE_TYPE__DESCRIPTION:
				return DESCRIPTION_EDEFAULT == null ? description != null : !DESCRIPTION_EDEFAULT.equals(description);
			case SuitePackage.TEST_SUITE_TYPE__TARGET:
				return target != null && !target.isEmpty();
			case SuitePackage.TEST_SUITE_TYPE__TEST_CASE:
				return testCase != null && !testCase.isEmpty();
			case SuitePackage.TEST_SUITE_TYPE__SETUP:
				return setup != null;
			case SuitePackage.TEST_SUITE_TYPE__TEARDOWN:
				return teardown != null;
			case SuitePackage.TEST_SUITE_TYPE__GOAL_LINK:
				return goalLink != null && !goalLink.isEmpty();
			case SuitePackage.TEST_SUITE_TYPE__SEND_LINK:
				return sendLink != null && !sendLink.isEmpty();
			case SuitePackage.TEST_SUITE_TYPE__RECEIVE_LINK:
				return receiveLink != null && !receiveLink.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (iD: ");
		result.append(iD);
		result.append(", name: ");
		result.append(name);
		result.append(", createdBy: ");
		result.append(createdBy);
		result.append(", version: ");
		result.append(version);
		result.append(", createdDate: ");
		result.append(createdDate);
		result.append(", description: ");
		result.append(description);
		result.append(')');
		return result.toString();
	}

} //TestSuiteTypeImpl
