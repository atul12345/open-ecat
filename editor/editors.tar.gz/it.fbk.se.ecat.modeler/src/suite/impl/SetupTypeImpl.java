/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package suite.impl;

import org.eclipse.emf.ecore.EClass;

import suite.SetupType;
import suite.SuitePackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Setup Type</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class SetupTypeImpl extends TestSupportTypeImpl implements SetupType {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SetupTypeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SuitePackage.Literals.SETUP_TYPE;
	}

} //SetupTypeImpl
