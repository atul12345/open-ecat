/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package suite.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import suite.OrderLinkType;
import suite.SuitePackage;
import suite.TActionType;
import suite.TestScenarioType;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Test Scenario Type</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link suite.impl.TestScenarioTypeImpl#getTestAction <em>Test Action</em>}</li>
 *   <li>{@link suite.impl.TestScenarioTypeImpl#getLink <em>Link</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class TestScenarioTypeImpl extends EObjectImpl implements TestScenarioType {
	/**
	 * The cached value of the '{@link #getTestAction() <em>Test Action</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTestAction()
	 * @generated
	 * @ordered
	 */
	protected EList<TActionType> testAction;

	/**
	 * The cached value of the '{@link #getLink() <em>Link</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLink()
	 * @generated
	 * @ordered
	 */
	protected EList<OrderLinkType> link;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TestScenarioTypeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SuitePackage.Literals.TEST_SCENARIO_TYPE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<TActionType> getTestAction() {
		if (testAction == null) {
			testAction = new EObjectContainmentEList<TActionType>(TActionType.class, this, SuitePackage.TEST_SCENARIO_TYPE__TEST_ACTION);
		}
		return testAction;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<OrderLinkType> getLink() {
		if (link == null) {
			link = new EObjectContainmentEList<OrderLinkType>(OrderLinkType.class, this, SuitePackage.TEST_SCENARIO_TYPE__LINK);
		}
		return link;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case SuitePackage.TEST_SCENARIO_TYPE__TEST_ACTION:
				return ((InternalEList<?>)getTestAction()).basicRemove(otherEnd, msgs);
			case SuitePackage.TEST_SCENARIO_TYPE__LINK:
				return ((InternalEList<?>)getLink()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case SuitePackage.TEST_SCENARIO_TYPE__TEST_ACTION:
				return getTestAction();
			case SuitePackage.TEST_SCENARIO_TYPE__LINK:
				return getLink();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case SuitePackage.TEST_SCENARIO_TYPE__TEST_ACTION:
				getTestAction().clear();
				getTestAction().addAll((Collection<? extends TActionType>)newValue);
				return;
			case SuitePackage.TEST_SCENARIO_TYPE__LINK:
				getLink().clear();
				getLink().addAll((Collection<? extends OrderLinkType>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case SuitePackage.TEST_SCENARIO_TYPE__TEST_ACTION:
				getTestAction().clear();
				return;
			case SuitePackage.TEST_SCENARIO_TYPE__LINK:
				getLink().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case SuitePackage.TEST_SCENARIO_TYPE__TEST_ACTION:
				return testAction != null && !testAction.isEmpty();
			case SuitePackage.TEST_SCENARIO_TYPE__LINK:
				return link != null && !link.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //TestScenarioTypeImpl
