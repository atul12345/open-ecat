/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package suite.impl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import schema.FipaMessageType;

import suite.AType;
import suite.CheckType;
import suite.SuitePackage;
import suite.TActionType;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>TAction Type</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link suite.impl.TActionTypeImpl#getID <em>ID</em>}</li>
 *   <li>{@link suite.impl.TActionTypeImpl#getInitiator <em>Initiator</em>}</li>
 *   <li>{@link suite.impl.TActionTypeImpl#getResponder <em>Responder</em>}</li>
 *   <li>{@link suite.impl.TActionTypeImpl#getActType <em>Act Type</em>}</li>
 *   <li>{@link suite.impl.TActionTypeImpl#getNextAction <em>Next Action</em>}</li>
 *   <li>{@link suite.impl.TActionTypeImpl#getNextIfTrue <em>Next If True</em>}</li>
 *   <li>{@link suite.impl.TActionTypeImpl#getNextIfFalse <em>Next If False</em>}</li>
 *   <li>{@link suite.impl.TActionTypeImpl#getMessage <em>Message</em>}</li>
 *   <li>{@link suite.impl.TActionTypeImpl#getVerdict <em>Verdict</em>}</li>
 *   <li>{@link suite.impl.TActionTypeImpl#getTimeout <em>Timeout</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class TActionTypeImpl extends EObjectImpl implements TActionType {
	/**
	 * The default value of the '{@link #getID() <em>ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getID()
	 * @generated
	 * @ordered
	 */
	protected static final String ID_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getID() <em>ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getID()
	 * @generated
	 * @ordered
	 */
	protected String iD = ID_EDEFAULT;

	/**
	 * The default value of the '{@link #getInitiator() <em>Initiator</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInitiator()
	 * @generated
	 * @ordered
	 */
	protected static final String INITIATOR_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getInitiator() <em>Initiator</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInitiator()
	 * @generated
	 * @ordered
	 */
	protected String initiator = INITIATOR_EDEFAULT;

	/**
	 * The default value of the '{@link #getResponder() <em>Responder</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getResponder()
	 * @generated
	 * @ordered
	 */
	protected static final String RESPONDER_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getResponder() <em>Responder</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getResponder()
	 * @generated
	 * @ordered
	 */
	protected String responder = RESPONDER_EDEFAULT;

	/**
	 * The default value of the '{@link #getActType() <em>Act Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getActType()
	 * @generated
	 * @ordered
	 */
	protected static final AType ACT_TYPE_EDEFAULT = AType.INITIAL;

	/**
	 * The cached value of the '{@link #getActType() <em>Act Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getActType()
	 * @generated
	 * @ordered
	 */
	protected AType actType = ACT_TYPE_EDEFAULT;

	/**
	 * This is true if the Act Type attribute has been set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	protected boolean actTypeESet;

	/**
	 * The default value of the '{@link #getNextAction() <em>Next Action</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNextAction()
	 * @generated
	 * @ordered
	 */
	protected static final String NEXT_ACTION_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getNextAction() <em>Next Action</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNextAction()
	 * @generated
	 * @ordered
	 */
	protected String nextAction = NEXT_ACTION_EDEFAULT;

	/**
	 * The default value of the '{@link #getNextIfTrue() <em>Next If True</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNextIfTrue()
	 * @generated
	 * @ordered
	 */
	protected static final String NEXT_IF_TRUE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getNextIfTrue() <em>Next If True</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNextIfTrue()
	 * @generated
	 * @ordered
	 */
	protected String nextIfTrue = NEXT_IF_TRUE_EDEFAULT;

	/**
	 * The default value of the '{@link #getNextIfFalse() <em>Next If False</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNextIfFalse()
	 * @generated
	 * @ordered
	 */
	protected static final String NEXT_IF_FALSE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getNextIfFalse() <em>Next If False</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNextIfFalse()
	 * @generated
	 * @ordered
	 */
	protected String nextIfFalse = NEXT_IF_FALSE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getMessage() <em>Message</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMessage()
	 * @generated
	 * @ordered
	 */
	protected FipaMessageType message;

	/**
	 * The cached value of the '{@link #getVerdict() <em>Verdict</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVerdict()
	 * @generated
	 * @ordered
	 */
	protected CheckType verdict;

	/**
	 * The default value of the '{@link #getTimeout() <em>Timeout</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTimeout()
	 * @generated
	 * @ordered
	 */
	protected static final int TIMEOUT_EDEFAULT = 1000;

	/**
	 * The cached value of the '{@link #getTimeout() <em>Timeout</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTimeout()
	 * @generated
	 * @ordered
	 */
	protected int timeout = TIMEOUT_EDEFAULT;

	/**
	 * This is true if the Timeout attribute has been set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	protected boolean timeoutESet;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TActionTypeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SuitePackage.Literals.TACTION_TYPE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getID() {
		return iD;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setID(String newID) {
		String oldID = iD;
		iD = newID;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SuitePackage.TACTION_TYPE__ID, oldID, iD));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getInitiator() {
		return initiator;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setInitiator(String newInitiator) {
		String oldInitiator = initiator;
		initiator = newInitiator;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SuitePackage.TACTION_TYPE__INITIATOR, oldInitiator, initiator));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getResponder() {
		return responder;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setResponder(String newResponder) {
		String oldResponder = responder;
		responder = newResponder;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SuitePackage.TACTION_TYPE__RESPONDER, oldResponder, responder));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AType getActType() {
		return actType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setActType(AType newActType) {
		AType oldActType = actType;
		actType = newActType == null ? ACT_TYPE_EDEFAULT : newActType;
		boolean oldActTypeESet = actTypeESet;
		actTypeESet = true;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SuitePackage.TACTION_TYPE__ACT_TYPE, oldActType, actType, !oldActTypeESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetActType() {
		AType oldActType = actType;
		boolean oldActTypeESet = actTypeESet;
		actType = ACT_TYPE_EDEFAULT;
		actTypeESet = false;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.UNSET, SuitePackage.TACTION_TYPE__ACT_TYPE, oldActType, ACT_TYPE_EDEFAULT, oldActTypeESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetActType() {
		return actTypeESet;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getNextAction() {
		return nextAction;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setNextAction(String newNextAction) {
		String oldNextAction = nextAction;
		nextAction = newNextAction;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SuitePackage.TACTION_TYPE__NEXT_ACTION, oldNextAction, nextAction));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getNextIfTrue() {
		return nextIfTrue;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setNextIfTrue(String newNextIfTrue) {
		String oldNextIfTrue = nextIfTrue;
		nextIfTrue = newNextIfTrue;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SuitePackage.TACTION_TYPE__NEXT_IF_TRUE, oldNextIfTrue, nextIfTrue));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getNextIfFalse() {
		return nextIfFalse;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setNextIfFalse(String newNextIfFalse) {
		String oldNextIfFalse = nextIfFalse;
		nextIfFalse = newNextIfFalse;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SuitePackage.TACTION_TYPE__NEXT_IF_FALSE, oldNextIfFalse, nextIfFalse));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FipaMessageType getMessage() {
		return message;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetMessage(FipaMessageType newMessage, NotificationChain msgs) {
		FipaMessageType oldMessage = message;
		message = newMessage;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, SuitePackage.TACTION_TYPE__MESSAGE, oldMessage, newMessage);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setMessage(FipaMessageType newMessage) {
		if (newMessage != message) {
			NotificationChain msgs = null;
			if (message != null)
				msgs = ((InternalEObject)message).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - SuitePackage.TACTION_TYPE__MESSAGE, null, msgs);
			if (newMessage != null)
				msgs = ((InternalEObject)newMessage).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - SuitePackage.TACTION_TYPE__MESSAGE, null, msgs);
			msgs = basicSetMessage(newMessage, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SuitePackage.TACTION_TYPE__MESSAGE, newMessage, newMessage));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CheckType getVerdict() {
		return verdict;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetVerdict(CheckType newVerdict, NotificationChain msgs) {
		CheckType oldVerdict = verdict;
		verdict = newVerdict;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, SuitePackage.TACTION_TYPE__VERDICT, oldVerdict, newVerdict);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setVerdict(CheckType newVerdict) {
		if (newVerdict != verdict) {
			NotificationChain msgs = null;
			if (verdict != null)
				msgs = ((InternalEObject)verdict).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - SuitePackage.TACTION_TYPE__VERDICT, null, msgs);
			if (newVerdict != null)
				msgs = ((InternalEObject)newVerdict).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - SuitePackage.TACTION_TYPE__VERDICT, null, msgs);
			msgs = basicSetVerdict(newVerdict, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SuitePackage.TACTION_TYPE__VERDICT, newVerdict, newVerdict));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getTimeout() {
		return timeout;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTimeout(int newTimeout) {
		int oldTimeout = timeout;
		timeout = newTimeout;
		boolean oldTimeoutESet = timeoutESet;
		timeoutESet = true;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SuitePackage.TACTION_TYPE__TIMEOUT, oldTimeout, timeout, !oldTimeoutESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetTimeout() {
		int oldTimeout = timeout;
		boolean oldTimeoutESet = timeoutESet;
		timeout = TIMEOUT_EDEFAULT;
		timeoutESet = false;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.UNSET, SuitePackage.TACTION_TYPE__TIMEOUT, oldTimeout, TIMEOUT_EDEFAULT, oldTimeoutESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetTimeout() {
		return timeoutESet;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case SuitePackage.TACTION_TYPE__MESSAGE:
				return basicSetMessage(null, msgs);
			case SuitePackage.TACTION_TYPE__VERDICT:
				return basicSetVerdict(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case SuitePackage.TACTION_TYPE__ID:
				return getID();
			case SuitePackage.TACTION_TYPE__INITIATOR:
				return getInitiator();
			case SuitePackage.TACTION_TYPE__RESPONDER:
				return getResponder();
			case SuitePackage.TACTION_TYPE__ACT_TYPE:
				return getActType();
			case SuitePackage.TACTION_TYPE__NEXT_ACTION:
				return getNextAction();
			case SuitePackage.TACTION_TYPE__NEXT_IF_TRUE:
				return getNextIfTrue();
			case SuitePackage.TACTION_TYPE__NEXT_IF_FALSE:
				return getNextIfFalse();
			case SuitePackage.TACTION_TYPE__MESSAGE:
				return getMessage();
			case SuitePackage.TACTION_TYPE__VERDICT:
				return getVerdict();
			case SuitePackage.TACTION_TYPE__TIMEOUT:
				return new Integer(getTimeout());
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case SuitePackage.TACTION_TYPE__ID:
				setID((String)newValue);
				return;
			case SuitePackage.TACTION_TYPE__INITIATOR:
				setInitiator((String)newValue);
				return;
			case SuitePackage.TACTION_TYPE__RESPONDER:
				setResponder((String)newValue);
				return;
			case SuitePackage.TACTION_TYPE__ACT_TYPE:
				setActType((AType)newValue);
				return;
			case SuitePackage.TACTION_TYPE__NEXT_ACTION:
				setNextAction((String)newValue);
				return;
			case SuitePackage.TACTION_TYPE__NEXT_IF_TRUE:
				setNextIfTrue((String)newValue);
				return;
			case SuitePackage.TACTION_TYPE__NEXT_IF_FALSE:
				setNextIfFalse((String)newValue);
				return;
			case SuitePackage.TACTION_TYPE__MESSAGE:
				setMessage((FipaMessageType)newValue);
				return;
			case SuitePackage.TACTION_TYPE__VERDICT:
				setVerdict((CheckType)newValue);
				return;
			case SuitePackage.TACTION_TYPE__TIMEOUT:
				setTimeout(((Integer)newValue).intValue());
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case SuitePackage.TACTION_TYPE__ID:
				setID(ID_EDEFAULT);
				return;
			case SuitePackage.TACTION_TYPE__INITIATOR:
				setInitiator(INITIATOR_EDEFAULT);
				return;
			case SuitePackage.TACTION_TYPE__RESPONDER:
				setResponder(RESPONDER_EDEFAULT);
				return;
			case SuitePackage.TACTION_TYPE__ACT_TYPE:
				unsetActType();
				return;
			case SuitePackage.TACTION_TYPE__NEXT_ACTION:
				setNextAction(NEXT_ACTION_EDEFAULT);
				return;
			case SuitePackage.TACTION_TYPE__NEXT_IF_TRUE:
				setNextIfTrue(NEXT_IF_TRUE_EDEFAULT);
				return;
			case SuitePackage.TACTION_TYPE__NEXT_IF_FALSE:
				setNextIfFalse(NEXT_IF_FALSE_EDEFAULT);
				return;
			case SuitePackage.TACTION_TYPE__MESSAGE:
				setMessage((FipaMessageType)null);
				return;
			case SuitePackage.TACTION_TYPE__VERDICT:
				setVerdict((CheckType)null);
				return;
			case SuitePackage.TACTION_TYPE__TIMEOUT:
				unsetTimeout();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case SuitePackage.TACTION_TYPE__ID:
				return ID_EDEFAULT == null ? iD != null : !ID_EDEFAULT.equals(iD);
			case SuitePackage.TACTION_TYPE__INITIATOR:
				return INITIATOR_EDEFAULT == null ? initiator != null : !INITIATOR_EDEFAULT.equals(initiator);
			case SuitePackage.TACTION_TYPE__RESPONDER:
				return RESPONDER_EDEFAULT == null ? responder != null : !RESPONDER_EDEFAULT.equals(responder);
			case SuitePackage.TACTION_TYPE__ACT_TYPE:
				return isSetActType();
			case SuitePackage.TACTION_TYPE__NEXT_ACTION:
				return NEXT_ACTION_EDEFAULT == null ? nextAction != null : !NEXT_ACTION_EDEFAULT.equals(nextAction);
			case SuitePackage.TACTION_TYPE__NEXT_IF_TRUE:
				return NEXT_IF_TRUE_EDEFAULT == null ? nextIfTrue != null : !NEXT_IF_TRUE_EDEFAULT.equals(nextIfTrue);
			case SuitePackage.TACTION_TYPE__NEXT_IF_FALSE:
				return NEXT_IF_FALSE_EDEFAULT == null ? nextIfFalse != null : !NEXT_IF_FALSE_EDEFAULT.equals(nextIfFalse);
			case SuitePackage.TACTION_TYPE__MESSAGE:
				return message != null;
			case SuitePackage.TACTION_TYPE__VERDICT:
				return verdict != null;
			case SuitePackage.TACTION_TYPE__TIMEOUT:
				return isSetTimeout();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (iD: ");
		result.append(iD);
		result.append(", initiator: ");
		result.append(initiator);
		result.append(", responder: ");
		result.append(responder);
		result.append(", actType: ");
		if (actTypeESet) result.append(actType); else result.append("<unset>");
		result.append(", nextAction: ");
		result.append(nextAction);
		result.append(", nextIfTrue: ");
		result.append(nextIfTrue);
		result.append(", nextIfFalse: ");
		result.append(nextIfFalse);
		result.append(", timeout: ");
		if (timeoutESet) result.append(timeout); else result.append("<unset>");
		result.append(')');
		return result.toString();
	}

} //TActionTypeImpl
