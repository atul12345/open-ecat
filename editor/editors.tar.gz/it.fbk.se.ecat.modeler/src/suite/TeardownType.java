/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package suite;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Teardown Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see suite.SuitePackage#getTeardownType()
 * @model
 * @generated
 */
public interface TeardownType extends TestSupportType {
} // TeardownType
