/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package suite;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see suite.SuitePackage
 * @generated
 */
public interface SuiteFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	SuiteFactory eINSTANCE = suite.impl.SuiteFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>Check Type</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Check Type</em>'.
	 * @generated
	 */
	CheckType createCheckType();

	/**
	 * Returns a new object of class '<em>Condition Type</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Condition Type</em>'.
	 * @generated
	 */
	ConditionType createConditionType();

	/**
	 * Returns a new object of class '<em>Document Root</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Document Root</em>'.
	 * @generated
	 */
	DocumentRoot createDocumentRoot();

	/**
	 * Returns a new object of class '<em>Expression Type</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Expression Type</em>'.
	 * @generated
	 */
	ExpressionType createExpressionType();

	/**
	 * Returns a new object of class '<em>Goal Plan Type</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Goal Plan Type</em>'.
	 * @generated
	 */
	GoalPlanType createGoalPlanType();

	/**
	 * Returns a new object of class '<em>Param Type</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Param Type</em>'.
	 * @generated
	 */
	ParamType createParamType();

	/**
	 * Returns a new object of class '<em>TAction Type</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>TAction Type</em>'.
	 * @generated
	 */
	TActionType createTActionType();

	/**
	 * Returns a new object of class '<em>Target Type</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Target Type</em>'.
	 * @generated
	 */
	TargetType createTargetType();

	/**
	 * Returns a new object of class '<em>Task Type1</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Task Type1</em>'.
	 * @generated
	 */
	TaskType1 createTaskType1();

	/**
	 * Returns a new object of class '<em>Test Case Type</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Test Case Type</em>'.
	 * @generated
	 */
	TestCaseType createTestCaseType();

	/**
	 * Returns a new object of class '<em>Test Scenario Type</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Test Scenario Type</em>'.
	 * @generated
	 */
	TestScenarioType createTestScenarioType();

	/**
	 * Returns a new object of class '<em>Test Suite Type</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Test Suite Type</em>'.
	 * @generated
	 */
	TestSuiteType createTestSuiteType();

	/**
	 * Returns a new object of class '<em>Test Support Type</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Test Support Type</em>'.
	 * @generated
	 */
	TestSupportType createTestSupportType();

	/**
	 * Returns a new object of class '<em>Order Link Type</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Order Link Type</em>'.
	 * @generated
	 */
	OrderLinkType createOrderLinkType();

	/**
	 * Returns a new object of class '<em>Setup Type</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Setup Type</em>'.
	 * @generated
	 */
	SetupType createSetupType();

	/**
	 * Returns a new object of class '<em>Teardown Type</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Teardown Type</em>'.
	 * @generated
	 */
	TeardownType createTeardownType();

	/**
	 * Returns a new object of class '<em>Goal Link Type</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Goal Link Type</em>'.
	 * @generated
	 */
	GoalLinkType createGoalLinkType();

	/**
	 * Returns a new object of class '<em>Send Link Type</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Send Link Type</em>'.
	 * @generated
	 */
	SendLinkType createSendLinkType();

	/**
	 * Returns a new object of class '<em>Receive Link Type</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Receive Link Type</em>'.
	 * @generated
	 */
	ReceiveLinkType createReceiveLinkType();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	SuitePackage getSuitePackage();

} //SuiteFactory
