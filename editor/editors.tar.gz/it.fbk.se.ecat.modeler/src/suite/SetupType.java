/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package suite;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Setup Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see suite.SuitePackage#getSetupType()
 * @model
 * @generated
 */
public interface SetupType extends TestSupportType {
} // SetupType
