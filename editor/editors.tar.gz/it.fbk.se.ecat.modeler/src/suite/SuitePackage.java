/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package suite;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see suite.SuiteFactory
 * @model kind="package"
 * @generated
 */
public interface SuitePackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "suite";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://sra.itc.it/se/TestSuite";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "suite";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	SuitePackage eINSTANCE = suite.impl.SuitePackageImpl.init();

	/**
	 * The meta object id for the '{@link suite.impl.CheckTypeImpl <em>Check Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see suite.impl.CheckTypeImpl
	 * @see suite.impl.SuitePackageImpl#getCheckType()
	 * @generated
	 */
	int CHECK_TYPE = 0;

	/**
	 * The feature id for the '<em><b>Check Operator</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CHECK_TYPE__CHECK_OPERATOR = 0;

	/**
	 * The feature id for the '<em><b>Expected Value</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CHECK_TYPE__EXPECTED_VALUE = 1;

	/**
	 * The number of structural features of the '<em>Check Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CHECK_TYPE_FEATURE_COUNT = 2;

	/**
	 * The meta object id for the '{@link suite.impl.ConditionTypeImpl <em>Condition Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see suite.impl.ConditionTypeImpl
	 * @see suite.impl.SuitePackageImpl#getConditionType()
	 * @generated
	 */
	int CONDITION_TYPE = 1;

	/**
	 * The feature id for the '<em><b>Expression</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONDITION_TYPE__EXPRESSION = 0;

	/**
	 * The number of structural features of the '<em>Condition Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONDITION_TYPE_FEATURE_COUNT = 1;

	/**
	 * The meta object id for the '{@link suite.impl.DocumentRootImpl <em>Document Root</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see suite.impl.DocumentRootImpl
	 * @see suite.impl.SuitePackageImpl#getDocumentRoot()
	 * @generated
	 */
	int DOCUMENT_ROOT = 2;

	/**
	 * The feature id for the '<em><b>Mixed</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT_ROOT__MIXED = 0;

	/**
	 * The feature id for the '<em><b>XMLNS Prefix Map</b></em>' map.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT_ROOT__XMLNS_PREFIX_MAP = 1;

	/**
	 * The feature id for the '<em><b>XSI Schema Location</b></em>' map.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT_ROOT__XSI_SCHEMA_LOCATION = 2;

	/**
	 * The feature id for the '<em><b>Test Case</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT_ROOT__TEST_CASE = 3;

	/**
	 * The feature id for the '<em><b>Test Scenario</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT_ROOT__TEST_SCENARIO = 4;

	/**
	 * The feature id for the '<em><b>Test Suite</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT_ROOT__TEST_SUITE = 5;

	/**
	 * The number of structural features of the '<em>Document Root</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT_ROOT_FEATURE_COUNT = 6;

	/**
	 * The meta object id for the '{@link suite.impl.ExpressionTypeImpl <em>Expression Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see suite.impl.ExpressionTypeImpl
	 * @see suite.impl.SuitePackageImpl#getExpressionType()
	 * @generated
	 */
	int EXPRESSION_TYPE = 3;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EXPRESSION_TYPE__VALUE = 0;

	/**
	 * The feature id for the '<em><b>Executable</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EXPRESSION_TYPE__EXECUTABLE = 1;

	/**
	 * The number of structural features of the '<em>Expression Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EXPRESSION_TYPE_FEATURE_COUNT = 2;

	/**
	 * The meta object id for the '{@link suite.impl.GoalPlanTypeImpl <em>Goal Plan Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see suite.impl.GoalPlanTypeImpl
	 * @see suite.impl.SuitePackageImpl#getGoalPlanType()
	 * @generated
	 */
	int GOAL_PLAN_TYPE = 4;

	/**
	 * The feature id for the '<em><b>Goal</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL_PLAN_TYPE__GOAL = 0;

	/**
	 * The feature id for the '<em><b>Plan</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL_PLAN_TYPE__PLAN = 1;

	/**
	 * The feature id for the '<em><b>Relationship</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL_PLAN_TYPE__RELATIONSHIP = 2;

	/**
	 * The feature id for the '<em><b>Pre Condition</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL_PLAN_TYPE__PRE_CONDITION = 3;

	/**
	 * The feature id for the '<em><b>Post Condition</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL_PLAN_TYPE__POST_CONDITION = 4;

	/**
	 * The number of structural features of the '<em>Goal Plan Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL_PLAN_TYPE_FEATURE_COUNT = 5;

	/**
	 * The meta object id for the '{@link suite.impl.ParamTypeImpl <em>Param Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see suite.impl.ParamTypeImpl
	 * @see suite.impl.SuitePackageImpl#getParamType()
	 * @generated
	 */
	int PARAM_TYPE = 5;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARAM_TYPE__VALUE = 0;

	/**
	 * The feature id for the '<em><b>Ref</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARAM_TYPE__REF = 1;

	/**
	 * The feature id for the '<em><b>Class</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARAM_TYPE__CLASS = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARAM_TYPE__NAME = 3;

	/**
	 * The number of structural features of the '<em>Param Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARAM_TYPE_FEATURE_COUNT = 4;

	/**
	 * The meta object id for the '{@link suite.impl.TActionTypeImpl <em>TAction Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see suite.impl.TActionTypeImpl
	 * @see suite.impl.SuitePackageImpl#getTActionType()
	 * @generated
	 */
	int TACTION_TYPE = 6;

	/**
	 * The feature id for the '<em><b>ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TACTION_TYPE__ID = 0;

	/**
	 * The feature id for the '<em><b>Initiator</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TACTION_TYPE__INITIATOR = 1;

	/**
	 * The feature id for the '<em><b>Responder</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TACTION_TYPE__RESPONDER = 2;

	/**
	 * The feature id for the '<em><b>Act Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TACTION_TYPE__ACT_TYPE = 3;

	/**
	 * The feature id for the '<em><b>Next Action</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TACTION_TYPE__NEXT_ACTION = 4;

	/**
	 * The feature id for the '<em><b>Next If True</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TACTION_TYPE__NEXT_IF_TRUE = 5;

	/**
	 * The feature id for the '<em><b>Next If False</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TACTION_TYPE__NEXT_IF_FALSE = 6;

	/**
	 * The feature id for the '<em><b>Message</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TACTION_TYPE__MESSAGE = 7;

	/**
	 * The feature id for the '<em><b>Verdict</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TACTION_TYPE__VERDICT = 8;

	/**
	 * The feature id for the '<em><b>Timeout</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TACTION_TYPE__TIMEOUT = 9;

	/**
	 * The number of structural features of the '<em>TAction Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TACTION_TYPE_FEATURE_COUNT = 10;

	/**
	 * The meta object id for the '{@link suite.impl.TargetTypeImpl <em>Target Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see suite.impl.TargetTypeImpl
	 * @see suite.impl.SuitePackageImpl#getTargetType()
	 * @generated
	 */
	int TARGET_TYPE = 7;

	/**
	 * The feature id for the '<em><b>Agent</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TARGET_TYPE__AGENT = 0;

	/**
	 * The feature id for the '<em><b>Goal Plan</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TARGET_TYPE__GOAL_PLAN = 1;

	/**
	 * The number of structural features of the '<em>Target Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TARGET_TYPE_FEATURE_COUNT = 2;

	/**
	 * The meta object id for the '{@link suite.impl.TaskType1Impl <em>Task Type1</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see suite.impl.TaskType1Impl
	 * @see suite.impl.SuitePackageImpl#getTaskType1()
	 * @generated
	 */
	int TASK_TYPE1 = 8;

	/**
	 * The feature id for the '<em><b>Param</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TASK_TYPE1__PARAM = 0;

	/**
	 * The feature id for the '<em><b>Class</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TASK_TYPE1__CLASS = 1;

	/**
	 * The feature id for the '<em><b>Desc</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TASK_TYPE1__DESC = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TASK_TYPE1__NAME = 3;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TASK_TYPE1__TYPE = 4;

	/**
	 * The number of structural features of the '<em>Task Type1</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TASK_TYPE1_FEATURE_COUNT = 5;

	/**
	 * The meta object id for the '{@link suite.impl.TestCaseTypeImpl <em>Test Case Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see suite.impl.TestCaseTypeImpl
	 * @see suite.impl.SuitePackageImpl#getTestCaseType()
	 * @generated
	 */
	int TEST_CASE_TYPE = 9;

	/**
	 * The feature id for the '<em><b>ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST_CASE_TYPE__ID = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST_CASE_TYPE__NAME = 1;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST_CASE_TYPE__TYPE = 2;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST_CASE_TYPE__DESCRIPTION = 3;

	/**
	 * The feature id for the '<em><b>Setup</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST_CASE_TYPE__SETUP = 4;

	/**
	 * The feature id for the '<em><b>Teardown</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST_CASE_TYPE__TEARDOWN = 5;

	/**
	 * The feature id for the '<em><b>Scenario</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST_CASE_TYPE__SCENARIO = 6;

	/**
	 * The feature id for the '<em><b>Pre Condition</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST_CASE_TYPE__PRE_CONDITION = 7;

	/**
	 * The feature id for the '<em><b>Post Condition</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST_CASE_TYPE__POST_CONDITION = 8;

	/**
	 * The feature id for the '<em><b>Active</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST_CASE_TYPE__ACTIVE = 9;

	/**
	 * The feature id for the '<em><b>Priority</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST_CASE_TYPE__PRIORITY = 10;

	/**
	 * The number of structural features of the '<em>Test Case Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST_CASE_TYPE_FEATURE_COUNT = 11;

	/**
	 * The meta object id for the '{@link suite.impl.TestScenarioTypeImpl <em>Test Scenario Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see suite.impl.TestScenarioTypeImpl
	 * @see suite.impl.SuitePackageImpl#getTestScenarioType()
	 * @generated
	 */
	int TEST_SCENARIO_TYPE = 10;

	/**
	 * The feature id for the '<em><b>Test Action</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST_SCENARIO_TYPE__TEST_ACTION = 0;

	/**
	 * The feature id for the '<em><b>Link</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST_SCENARIO_TYPE__LINK = 1;

	/**
	 * The number of structural features of the '<em>Test Scenario Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST_SCENARIO_TYPE_FEATURE_COUNT = 2;

	/**
	 * The meta object id for the '{@link suite.impl.TestSuiteTypeImpl <em>Test Suite Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see suite.impl.TestSuiteTypeImpl
	 * @see suite.impl.SuitePackageImpl#getTestSuiteType()
	 * @generated
	 */
	int TEST_SUITE_TYPE = 11;

	/**
	 * The feature id for the '<em><b>ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST_SUITE_TYPE__ID = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST_SUITE_TYPE__NAME = 1;

	/**
	 * The feature id for the '<em><b>Created By</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST_SUITE_TYPE__CREATED_BY = 2;

	/**
	 * The feature id for the '<em><b>Version</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST_SUITE_TYPE__VERSION = 3;

	/**
	 * The feature id for the '<em><b>Created Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST_SUITE_TYPE__CREATED_DATE = 4;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST_SUITE_TYPE__DESCRIPTION = 5;

	/**
	 * The feature id for the '<em><b>Target</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST_SUITE_TYPE__TARGET = 6;

	/**
	 * The feature id for the '<em><b>Test Case</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST_SUITE_TYPE__TEST_CASE = 7;

	/**
	 * The feature id for the '<em><b>Setup</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST_SUITE_TYPE__SETUP = 8;

	/**
	 * The feature id for the '<em><b>Teardown</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST_SUITE_TYPE__TEARDOWN = 9;

	/**
	 * The feature id for the '<em><b>Goal Link</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST_SUITE_TYPE__GOAL_LINK = 10;

	/**
	 * The feature id for the '<em><b>Send Link</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST_SUITE_TYPE__SEND_LINK = 11;

	/**
	 * The feature id for the '<em><b>Receive Link</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST_SUITE_TYPE__RECEIVE_LINK = 12;

	/**
	 * The number of structural features of the '<em>Test Suite Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST_SUITE_TYPE_FEATURE_COUNT = 13;

	/**
	 * The meta object id for the '{@link suite.impl.TestSupportTypeImpl <em>Test Support Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see suite.impl.TestSupportTypeImpl
	 * @see suite.impl.SuitePackageImpl#getTestSupportType()
	 * @generated
	 */
	int TEST_SUPPORT_TYPE = 12;

	/**
	 * The feature id for the '<em><b>Task</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST_SUPPORT_TYPE__TASK = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST_SUPPORT_TYPE__NAME = 1;

	/**
	 * The number of structural features of the '<em>Test Support Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST_SUPPORT_TYPE_FEATURE_COUNT = 2;

	/**
	 * The meta object id for the '{@link suite.impl.OrderLinkTypeImpl <em>Order Link Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see suite.impl.OrderLinkTypeImpl
	 * @see suite.impl.SuitePackageImpl#getOrderLinkType()
	 * @generated
	 */
	int ORDER_LINK_TYPE = 13;

	/**
	 * The feature id for the '<em><b>Desc</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER_LINK_TYPE__DESC = 0;

	/**
	 * The feature id for the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER_LINK_TYPE__SOURCE = 1;

	/**
	 * The feature id for the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER_LINK_TYPE__TARGET = 2;

	/**
	 * The feature id for the '<em><b>Order Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER_LINK_TYPE__ORDER_TYPE = 3;

	/**
	 * The number of structural features of the '<em>Order Link Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER_LINK_TYPE_FEATURE_COUNT = 4;

	/**
	 * The meta object id for the '{@link suite.impl.SetupTypeImpl <em>Setup Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see suite.impl.SetupTypeImpl
	 * @see suite.impl.SuitePackageImpl#getSetupType()
	 * @generated
	 */
	int SETUP_TYPE = 14;

	/**
	 * The feature id for the '<em><b>Task</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SETUP_TYPE__TASK = TEST_SUPPORT_TYPE__TASK;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SETUP_TYPE__NAME = TEST_SUPPORT_TYPE__NAME;

	/**
	 * The number of structural features of the '<em>Setup Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SETUP_TYPE_FEATURE_COUNT = TEST_SUPPORT_TYPE_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link suite.impl.TeardownTypeImpl <em>Teardown Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see suite.impl.TeardownTypeImpl
	 * @see suite.impl.SuitePackageImpl#getTeardownType()
	 * @generated
	 */
	int TEARDOWN_TYPE = 15;

	/**
	 * The feature id for the '<em><b>Task</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEARDOWN_TYPE__TASK = TEST_SUPPORT_TYPE__TASK;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEARDOWN_TYPE__NAME = TEST_SUPPORT_TYPE__NAME;

	/**
	 * The number of structural features of the '<em>Teardown Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEARDOWN_TYPE_FEATURE_COUNT = TEST_SUPPORT_TYPE_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link suite.impl.GoalLinkTypeImpl <em>Goal Link Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see suite.impl.GoalLinkTypeImpl
	 * @see suite.impl.SuitePackageImpl#getGoalLinkType()
	 * @generated
	 */
	int GOAL_LINK_TYPE = 16;

	/**
	 * The feature id for the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL_LINK_TYPE__SOURCE = 0;

	/**
	 * The feature id for the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL_LINK_TYPE__TARGET = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL_LINK_TYPE__NAME = 2;

	/**
	 * The number of structural features of the '<em>Goal Link Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL_LINK_TYPE_FEATURE_COUNT = 3;

	/**
	 * The meta object id for the '{@link suite.impl.SendLinkTypeImpl <em>Send Link Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see suite.impl.SendLinkTypeImpl
	 * @see suite.impl.SuitePackageImpl#getSendLinkType()
	 * @generated
	 */
	int SEND_LINK_TYPE = 17;

	/**
	 * The feature id for the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEND_LINK_TYPE__SOURCE = 0;

	/**
	 * The feature id for the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEND_LINK_TYPE__TARGET = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEND_LINK_TYPE__NAME = 2;

	/**
	 * The number of structural features of the '<em>Send Link Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEND_LINK_TYPE_FEATURE_COUNT = 3;

	/**
	 * The meta object id for the '{@link suite.impl.ReceiveLinkTypeImpl <em>Receive Link Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see suite.impl.ReceiveLinkTypeImpl
	 * @see suite.impl.SuitePackageImpl#getReceiveLinkType()
	 * @generated
	 */
	int RECEIVE_LINK_TYPE = 18;

	/**
	 * The feature id for the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RECEIVE_LINK_TYPE__TARGET = 0;

	/**
	 * The feature id for the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RECEIVE_LINK_TYPE__SOURCE = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RECEIVE_LINK_TYPE__NAME = 2;

	/**
	 * The number of structural features of the '<em>Receive Link Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RECEIVE_LINK_TYPE_FEATURE_COUNT = 3;

	/**
	 * The meta object id for the '{@link suite.AType <em>AType</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see suite.AType
	 * @see suite.impl.SuitePackageImpl#getAType()
	 * @generated
	 */
	int ATYPE = 19;

	/**
	 * The meta object id for the '{@link suite.GoalReachType <em>Goal Reach Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see suite.GoalReachType
	 * @see suite.impl.SuitePackageImpl#getGoalReachType()
	 * @generated
	 */
	int GOAL_REACH_TYPE = 20;

	/**
	 * The meta object id for the '{@link suite.OperatorType <em>Operator Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see suite.OperatorType
	 * @see suite.impl.SuitePackageImpl#getOperatorType()
	 * @generated
	 */
	int OPERATOR_TYPE = 21;

	/**
	 * The meta object id for the '{@link suite.RelationshipType <em>Relationship Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see suite.RelationshipType
	 * @see suite.impl.SuitePackageImpl#getRelationshipType()
	 * @generated
	 */
	int RELATIONSHIP_TYPE = 22;

	/**
	 * The meta object id for the '{@link suite.TaskType <em>Task Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see suite.TaskType
	 * @see suite.impl.SuitePackageImpl#getTaskType()
	 * @generated
	 */
	int TASK_TYPE = 23;

	/**
	 * The meta object id for the '{@link suite.OrderType <em>Order Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see suite.OrderType
	 * @see suite.impl.SuitePackageImpl#getOrderType()
	 * @generated
	 */
	int ORDER_TYPE = 24;

	/**
	 * The meta object id for the '<em>AType Object</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see suite.AType
	 * @see suite.impl.SuitePackageImpl#getATypeObject()
	 * @generated
	 */
	int ATYPE_OBJECT = 25;

	/**
	 * The meta object id for the '<em>Goal Reach Type Object</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see suite.GoalReachType
	 * @see suite.impl.SuitePackageImpl#getGoalReachTypeObject()
	 * @generated
	 */
	int GOAL_REACH_TYPE_OBJECT = 26;

	/**
	 * The meta object id for the '<em>Operator Type Object</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see suite.OperatorType
	 * @see suite.impl.SuitePackageImpl#getOperatorTypeObject()
	 * @generated
	 */
	int OPERATOR_TYPE_OBJECT = 27;

	/**
	 * The meta object id for the '<em>Relationship Type Object</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see suite.RelationshipType
	 * @see suite.impl.SuitePackageImpl#getRelationshipTypeObject()
	 * @generated
	 */
	int RELATIONSHIP_TYPE_OBJECT = 28;

	/**
	 * The meta object id for the '<em>Task Type Object</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see suite.TaskType
	 * @see suite.impl.SuitePackageImpl#getTaskTypeObject()
	 * @generated
	 */
	int TASK_TYPE_OBJECT = 29;


	/**
	 * Returns the meta object for class '{@link suite.CheckType <em>Check Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Check Type</em>'.
	 * @see suite.CheckType
	 * @generated
	 */
	EClass getCheckType();

	/**
	 * Returns the meta object for the attribute '{@link suite.CheckType#getCheckOperator <em>Check Operator</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Check Operator</em>'.
	 * @see suite.CheckType#getCheckOperator()
	 * @see #getCheckType()
	 * @generated
	 */
	EAttribute getCheckType_CheckOperator();

	/**
	 * Returns the meta object for the containment reference '{@link suite.CheckType#getExpectedValue <em>Expected Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Expected Value</em>'.
	 * @see suite.CheckType#getExpectedValue()
	 * @see #getCheckType()
	 * @generated
	 */
	EReference getCheckType_ExpectedValue();

	/**
	 * Returns the meta object for class '{@link suite.ConditionType <em>Condition Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Condition Type</em>'.
	 * @see suite.ConditionType
	 * @generated
	 */
	EClass getConditionType();

	/**
	 * Returns the meta object for the containment reference list '{@link suite.ConditionType#getExpression <em>Expression</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Expression</em>'.
	 * @see suite.ConditionType#getExpression()
	 * @see #getConditionType()
	 * @generated
	 */
	EReference getConditionType_Expression();

	/**
	 * Returns the meta object for class '{@link suite.DocumentRoot <em>Document Root</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Document Root</em>'.
	 * @see suite.DocumentRoot
	 * @generated
	 */
	EClass getDocumentRoot();

	/**
	 * Returns the meta object for the attribute list '{@link suite.DocumentRoot#getMixed <em>Mixed</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute list '<em>Mixed</em>'.
	 * @see suite.DocumentRoot#getMixed()
	 * @see #getDocumentRoot()
	 * @generated
	 */
	EAttribute getDocumentRoot_Mixed();

	/**
	 * Returns the meta object for the map '{@link suite.DocumentRoot#getXMLNSPrefixMap <em>XMLNS Prefix Map</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the map '<em>XMLNS Prefix Map</em>'.
	 * @see suite.DocumentRoot#getXMLNSPrefixMap()
	 * @see #getDocumentRoot()
	 * @generated
	 */
	EReference getDocumentRoot_XMLNSPrefixMap();

	/**
	 * Returns the meta object for the map '{@link suite.DocumentRoot#getXSISchemaLocation <em>XSI Schema Location</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the map '<em>XSI Schema Location</em>'.
	 * @see suite.DocumentRoot#getXSISchemaLocation()
	 * @see #getDocumentRoot()
	 * @generated
	 */
	EReference getDocumentRoot_XSISchemaLocation();

	/**
	 * Returns the meta object for the containment reference '{@link suite.DocumentRoot#getTestCase <em>Test Case</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Test Case</em>'.
	 * @see suite.DocumentRoot#getTestCase()
	 * @see #getDocumentRoot()
	 * @generated
	 */
	EReference getDocumentRoot_TestCase();

	/**
	 * Returns the meta object for the containment reference '{@link suite.DocumentRoot#getTestScenario <em>Test Scenario</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Test Scenario</em>'.
	 * @see suite.DocumentRoot#getTestScenario()
	 * @see #getDocumentRoot()
	 * @generated
	 */
	EReference getDocumentRoot_TestScenario();

	/**
	 * Returns the meta object for the containment reference '{@link suite.DocumentRoot#getTestSuite <em>Test Suite</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Test Suite</em>'.
	 * @see suite.DocumentRoot#getTestSuite()
	 * @see #getDocumentRoot()
	 * @generated
	 */
	EReference getDocumentRoot_TestSuite();

	/**
	 * Returns the meta object for class '{@link suite.ExpressionType <em>Expression Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Expression Type</em>'.
	 * @see suite.ExpressionType
	 * @generated
	 */
	EClass getExpressionType();

	/**
	 * Returns the meta object for the attribute '{@link suite.ExpressionType#getValue <em>Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Value</em>'.
	 * @see suite.ExpressionType#getValue()
	 * @see #getExpressionType()
	 * @generated
	 */
	EAttribute getExpressionType_Value();

	/**
	 * Returns the meta object for the attribute '{@link suite.ExpressionType#isExecutable <em>Executable</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Executable</em>'.
	 * @see suite.ExpressionType#isExecutable()
	 * @see #getExpressionType()
	 * @generated
	 */
	EAttribute getExpressionType_Executable();

	/**
	 * Returns the meta object for class '{@link suite.GoalPlanType <em>Goal Plan Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Goal Plan Type</em>'.
	 * @see suite.GoalPlanType
	 * @generated
	 */
	EClass getGoalPlanType();

	/**
	 * Returns the meta object for the attribute '{@link suite.GoalPlanType#getGoal <em>Goal</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Goal</em>'.
	 * @see suite.GoalPlanType#getGoal()
	 * @see #getGoalPlanType()
	 * @generated
	 */
	EAttribute getGoalPlanType_Goal();

	/**
	 * Returns the meta object for the attribute '{@link suite.GoalPlanType#getPlan <em>Plan</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Plan</em>'.
	 * @see suite.GoalPlanType#getPlan()
	 * @see #getGoalPlanType()
	 * @generated
	 */
	EAttribute getGoalPlanType_Plan();

	/**
	 * Returns the meta object for the attribute '{@link suite.GoalPlanType#getRelationship <em>Relationship</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Relationship</em>'.
	 * @see suite.GoalPlanType#getRelationship()
	 * @see #getGoalPlanType()
	 * @generated
	 */
	EAttribute getGoalPlanType_Relationship();

	/**
	 * Returns the meta object for the containment reference '{@link suite.GoalPlanType#getPreCondition <em>Pre Condition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Pre Condition</em>'.
	 * @see suite.GoalPlanType#getPreCondition()
	 * @see #getGoalPlanType()
	 * @generated
	 */
	EReference getGoalPlanType_PreCondition();

	/**
	 * Returns the meta object for the containment reference '{@link suite.GoalPlanType#getPostCondition <em>Post Condition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Post Condition</em>'.
	 * @see suite.GoalPlanType#getPostCondition()
	 * @see #getGoalPlanType()
	 * @generated
	 */
	EReference getGoalPlanType_PostCondition();

	/**
	 * Returns the meta object for class '{@link suite.ParamType <em>Param Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Param Type</em>'.
	 * @see suite.ParamType
	 * @generated
	 */
	EClass getParamType();

	/**
	 * Returns the meta object for the attribute '{@link suite.ParamType#getValue <em>Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Value</em>'.
	 * @see suite.ParamType#getValue()
	 * @see #getParamType()
	 * @generated
	 */
	EAttribute getParamType_Value();

	/**
	 * Returns the meta object for the attribute '{@link suite.ParamType#getRef <em>Ref</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Ref</em>'.
	 * @see suite.ParamType#getRef()
	 * @see #getParamType()
	 * @generated
	 */
	EAttribute getParamType_Ref();

	/**
	 * Returns the meta object for the attribute '{@link suite.ParamType#getClass_ <em>Class</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Class</em>'.
	 * @see suite.ParamType#getClass_()
	 * @see #getParamType()
	 * @generated
	 */
	EAttribute getParamType_Class();

	/**
	 * Returns the meta object for the attribute '{@link suite.ParamType#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see suite.ParamType#getName()
	 * @see #getParamType()
	 * @generated
	 */
	EAttribute getParamType_Name();

	/**
	 * Returns the meta object for class '{@link suite.TActionType <em>TAction Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>TAction Type</em>'.
	 * @see suite.TActionType
	 * @generated
	 */
	EClass getTActionType();

	/**
	 * Returns the meta object for the attribute '{@link suite.TActionType#getID <em>ID</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>ID</em>'.
	 * @see suite.TActionType#getID()
	 * @see #getTActionType()
	 * @generated
	 */
	EAttribute getTActionType_ID();

	/**
	 * Returns the meta object for the attribute '{@link suite.TActionType#getInitiator <em>Initiator</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Initiator</em>'.
	 * @see suite.TActionType#getInitiator()
	 * @see #getTActionType()
	 * @generated
	 */
	EAttribute getTActionType_Initiator();

	/**
	 * Returns the meta object for the attribute '{@link suite.TActionType#getResponder <em>Responder</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Responder</em>'.
	 * @see suite.TActionType#getResponder()
	 * @see #getTActionType()
	 * @generated
	 */
	EAttribute getTActionType_Responder();

	/**
	 * Returns the meta object for the attribute '{@link suite.TActionType#getActType <em>Act Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Act Type</em>'.
	 * @see suite.TActionType#getActType()
	 * @see #getTActionType()
	 * @generated
	 */
	EAttribute getTActionType_ActType();

	/**
	 * Returns the meta object for the attribute '{@link suite.TActionType#getNextAction <em>Next Action</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Next Action</em>'.
	 * @see suite.TActionType#getNextAction()
	 * @see #getTActionType()
	 * @generated
	 */
	EAttribute getTActionType_NextAction();

	/**
	 * Returns the meta object for the attribute '{@link suite.TActionType#getNextIfTrue <em>Next If True</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Next If True</em>'.
	 * @see suite.TActionType#getNextIfTrue()
	 * @see #getTActionType()
	 * @generated
	 */
	EAttribute getTActionType_NextIfTrue();

	/**
	 * Returns the meta object for the attribute '{@link suite.TActionType#getNextIfFalse <em>Next If False</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Next If False</em>'.
	 * @see suite.TActionType#getNextIfFalse()
	 * @see #getTActionType()
	 * @generated
	 */
	EAttribute getTActionType_NextIfFalse();

	/**
	 * Returns the meta object for the containment reference '{@link suite.TActionType#getMessage <em>Message</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Message</em>'.
	 * @see suite.TActionType#getMessage()
	 * @see #getTActionType()
	 * @generated
	 */
	EReference getTActionType_Message();

	/**
	 * Returns the meta object for the containment reference '{@link suite.TActionType#getVerdict <em>Verdict</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Verdict</em>'.
	 * @see suite.TActionType#getVerdict()
	 * @see #getTActionType()
	 * @generated
	 */
	EReference getTActionType_Verdict();

	/**
	 * Returns the meta object for the attribute '{@link suite.TActionType#getTimeout <em>Timeout</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Timeout</em>'.
	 * @see suite.TActionType#getTimeout()
	 * @see #getTActionType()
	 * @generated
	 */
	EAttribute getTActionType_Timeout();

	/**
	 * Returns the meta object for class '{@link suite.TargetType <em>Target Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Target Type</em>'.
	 * @see suite.TargetType
	 * @generated
	 */
	EClass getTargetType();

	/**
	 * Returns the meta object for the attribute '{@link suite.TargetType#getAgent <em>Agent</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Agent</em>'.
	 * @see suite.TargetType#getAgent()
	 * @see #getTargetType()
	 * @generated
	 */
	EAttribute getTargetType_Agent();

	/**
	 * Returns the meta object for the containment reference list '{@link suite.TargetType#getGoalPlan <em>Goal Plan</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Goal Plan</em>'.
	 * @see suite.TargetType#getGoalPlan()
	 * @see #getTargetType()
	 * @generated
	 */
	EReference getTargetType_GoalPlan();

	/**
	 * Returns the meta object for class '{@link suite.TaskType1 <em>Task Type1</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Task Type1</em>'.
	 * @see suite.TaskType1
	 * @generated
	 */
	EClass getTaskType1();

	/**
	 * Returns the meta object for the containment reference list '{@link suite.TaskType1#getParam <em>Param</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Param</em>'.
	 * @see suite.TaskType1#getParam()
	 * @see #getTaskType1()
	 * @generated
	 */
	EReference getTaskType1_Param();

	/**
	 * Returns the meta object for the attribute '{@link suite.TaskType1#getClass_ <em>Class</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Class</em>'.
	 * @see suite.TaskType1#getClass_()
	 * @see #getTaskType1()
	 * @generated
	 */
	EAttribute getTaskType1_Class();

	/**
	 * Returns the meta object for the attribute '{@link suite.TaskType1#getDesc <em>Desc</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Desc</em>'.
	 * @see suite.TaskType1#getDesc()
	 * @see #getTaskType1()
	 * @generated
	 */
	EAttribute getTaskType1_Desc();

	/**
	 * Returns the meta object for the attribute '{@link suite.TaskType1#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see suite.TaskType1#getName()
	 * @see #getTaskType1()
	 * @generated
	 */
	EAttribute getTaskType1_Name();

	/**
	 * Returns the meta object for the attribute '{@link suite.TaskType1#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see suite.TaskType1#getType()
	 * @see #getTaskType1()
	 * @generated
	 */
	EAttribute getTaskType1_Type();

	/**
	 * Returns the meta object for class '{@link suite.TestCaseType <em>Test Case Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Test Case Type</em>'.
	 * @see suite.TestCaseType
	 * @generated
	 */
	EClass getTestCaseType();

	/**
	 * Returns the meta object for the attribute '{@link suite.TestCaseType#getID <em>ID</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>ID</em>'.
	 * @see suite.TestCaseType#getID()
	 * @see #getTestCaseType()
	 * @generated
	 */
	EAttribute getTestCaseType_ID();

	/**
	 * Returns the meta object for the attribute '{@link suite.TestCaseType#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see suite.TestCaseType#getName()
	 * @see #getTestCaseType()
	 * @generated
	 */
	EAttribute getTestCaseType_Name();

	/**
	 * Returns the meta object for the attribute '{@link suite.TestCaseType#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see suite.TestCaseType#getType()
	 * @see #getTestCaseType()
	 * @generated
	 */
	EAttribute getTestCaseType_Type();

	/**
	 * Returns the meta object for the attribute '{@link suite.TestCaseType#getDescription <em>Description</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Description</em>'.
	 * @see suite.TestCaseType#getDescription()
	 * @see #getTestCaseType()
	 * @generated
	 */
	EAttribute getTestCaseType_Description();

	/**
	 * Returns the meta object for the containment reference '{@link suite.TestCaseType#getSetup <em>Setup</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Setup</em>'.
	 * @see suite.TestCaseType#getSetup()
	 * @see #getTestCaseType()
	 * @generated
	 */
	EReference getTestCaseType_Setup();

	/**
	 * Returns the meta object for the containment reference '{@link suite.TestCaseType#getTeardown <em>Teardown</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Teardown</em>'.
	 * @see suite.TestCaseType#getTeardown()
	 * @see #getTestCaseType()
	 * @generated
	 */
	EReference getTestCaseType_Teardown();

	/**
	 * Returns the meta object for the containment reference '{@link suite.TestCaseType#getScenario <em>Scenario</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Scenario</em>'.
	 * @see suite.TestCaseType#getScenario()
	 * @see #getTestCaseType()
	 * @generated
	 */
	EReference getTestCaseType_Scenario();

	/**
	 * Returns the meta object for the containment reference '{@link suite.TestCaseType#getPreCondition <em>Pre Condition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Pre Condition</em>'.
	 * @see suite.TestCaseType#getPreCondition()
	 * @see #getTestCaseType()
	 * @generated
	 */
	EReference getTestCaseType_PreCondition();

	/**
	 * Returns the meta object for the containment reference '{@link suite.TestCaseType#getPostCondition <em>Post Condition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Post Condition</em>'.
	 * @see suite.TestCaseType#getPostCondition()
	 * @see #getTestCaseType()
	 * @generated
	 */
	EReference getTestCaseType_PostCondition();

	/**
	 * Returns the meta object for the attribute '{@link suite.TestCaseType#isActive <em>Active</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Active</em>'.
	 * @see suite.TestCaseType#isActive()
	 * @see #getTestCaseType()
	 * @generated
	 */
	EAttribute getTestCaseType_Active();

	/**
	 * Returns the meta object for the attribute '{@link suite.TestCaseType#getPriority <em>Priority</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Priority</em>'.
	 * @see suite.TestCaseType#getPriority()
	 * @see #getTestCaseType()
	 * @generated
	 */
	EAttribute getTestCaseType_Priority();

	/**
	 * Returns the meta object for class '{@link suite.TestScenarioType <em>Test Scenario Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Test Scenario Type</em>'.
	 * @see suite.TestScenarioType
	 * @generated
	 */
	EClass getTestScenarioType();

	/**
	 * Returns the meta object for the containment reference list '{@link suite.TestScenarioType#getTestAction <em>Test Action</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Test Action</em>'.
	 * @see suite.TestScenarioType#getTestAction()
	 * @see #getTestScenarioType()
	 * @generated
	 */
	EReference getTestScenarioType_TestAction();

	/**
	 * Returns the meta object for the containment reference list '{@link suite.TestScenarioType#getLink <em>Link</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Link</em>'.
	 * @see suite.TestScenarioType#getLink()
	 * @see #getTestScenarioType()
	 * @generated
	 */
	EReference getTestScenarioType_Link();

	/**
	 * Returns the meta object for class '{@link suite.TestSuiteType <em>Test Suite Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Test Suite Type</em>'.
	 * @see suite.TestSuiteType
	 * @generated
	 */
	EClass getTestSuiteType();

	/**
	 * Returns the meta object for the attribute '{@link suite.TestSuiteType#getID <em>ID</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>ID</em>'.
	 * @see suite.TestSuiteType#getID()
	 * @see #getTestSuiteType()
	 * @generated
	 */
	EAttribute getTestSuiteType_ID();

	/**
	 * Returns the meta object for the attribute '{@link suite.TestSuiteType#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see suite.TestSuiteType#getName()
	 * @see #getTestSuiteType()
	 * @generated
	 */
	EAttribute getTestSuiteType_Name();

	/**
	 * Returns the meta object for the attribute '{@link suite.TestSuiteType#getCreatedBy <em>Created By</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Created By</em>'.
	 * @see suite.TestSuiteType#getCreatedBy()
	 * @see #getTestSuiteType()
	 * @generated
	 */
	EAttribute getTestSuiteType_CreatedBy();

	/**
	 * Returns the meta object for the attribute '{@link suite.TestSuiteType#getVersion <em>Version</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Version</em>'.
	 * @see suite.TestSuiteType#getVersion()
	 * @see #getTestSuiteType()
	 * @generated
	 */
	EAttribute getTestSuiteType_Version();

	/**
	 * Returns the meta object for the attribute '{@link suite.TestSuiteType#getCreatedDate <em>Created Date</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Created Date</em>'.
	 * @see suite.TestSuiteType#getCreatedDate()
	 * @see #getTestSuiteType()
	 * @generated
	 */
	EAttribute getTestSuiteType_CreatedDate();

	/**
	 * Returns the meta object for the attribute '{@link suite.TestSuiteType#getDescription <em>Description</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Description</em>'.
	 * @see suite.TestSuiteType#getDescription()
	 * @see #getTestSuiteType()
	 * @generated
	 */
	EAttribute getTestSuiteType_Description();

	/**
	 * Returns the meta object for the containment reference list '{@link suite.TestSuiteType#getTarget <em>Target</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Target</em>'.
	 * @see suite.TestSuiteType#getTarget()
	 * @see #getTestSuiteType()
	 * @generated
	 */
	EReference getTestSuiteType_Target();

	/**
	 * Returns the meta object for the containment reference list '{@link suite.TestSuiteType#getTestCase <em>Test Case</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Test Case</em>'.
	 * @see suite.TestSuiteType#getTestCase()
	 * @see #getTestSuiteType()
	 * @generated
	 */
	EReference getTestSuiteType_TestCase();

	/**
	 * Returns the meta object for the containment reference '{@link suite.TestSuiteType#getSetup <em>Setup</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Setup</em>'.
	 * @see suite.TestSuiteType#getSetup()
	 * @see #getTestSuiteType()
	 * @generated
	 */
	EReference getTestSuiteType_Setup();

	/**
	 * Returns the meta object for the containment reference '{@link suite.TestSuiteType#getTeardown <em>Teardown</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Teardown</em>'.
	 * @see suite.TestSuiteType#getTeardown()
	 * @see #getTestSuiteType()
	 * @generated
	 */
	EReference getTestSuiteType_Teardown();

	/**
	 * Returns the meta object for the containment reference list '{@link suite.TestSuiteType#getGoalLink <em>Goal Link</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Goal Link</em>'.
	 * @see suite.TestSuiteType#getGoalLink()
	 * @see #getTestSuiteType()
	 * @generated
	 */
	EReference getTestSuiteType_GoalLink();

	/**
	 * Returns the meta object for the containment reference list '{@link suite.TestSuiteType#getSendLink <em>Send Link</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Send Link</em>'.
	 * @see suite.TestSuiteType#getSendLink()
	 * @see #getTestSuiteType()
	 * @generated
	 */
	EReference getTestSuiteType_SendLink();

	/**
	 * Returns the meta object for the containment reference list '{@link suite.TestSuiteType#getReceiveLink <em>Receive Link</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Receive Link</em>'.
	 * @see suite.TestSuiteType#getReceiveLink()
	 * @see #getTestSuiteType()
	 * @generated
	 */
	EReference getTestSuiteType_ReceiveLink();

	/**
	 * Returns the meta object for class '{@link suite.TestSupportType <em>Test Support Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Test Support Type</em>'.
	 * @see suite.TestSupportType
	 * @generated
	 */
	EClass getTestSupportType();

	/**
	 * Returns the meta object for the containment reference list '{@link suite.TestSupportType#getTask <em>Task</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Task</em>'.
	 * @see suite.TestSupportType#getTask()
	 * @see #getTestSupportType()
	 * @generated
	 */
	EReference getTestSupportType_Task();

	/**
	 * Returns the meta object for the attribute '{@link suite.TestSupportType#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see suite.TestSupportType#getName()
	 * @see #getTestSupportType()
	 * @generated
	 */
	EAttribute getTestSupportType_Name();

	/**
	 * Returns the meta object for class '{@link suite.OrderLinkType <em>Order Link Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Order Link Type</em>'.
	 * @see suite.OrderLinkType
	 * @generated
	 */
	EClass getOrderLinkType();

	/**
	 * Returns the meta object for the attribute '{@link suite.OrderLinkType#getDesc <em>Desc</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Desc</em>'.
	 * @see suite.OrderLinkType#getDesc()
	 * @see #getOrderLinkType()
	 * @generated
	 */
	EAttribute getOrderLinkType_Desc();

	/**
	 * Returns the meta object for the reference '{@link suite.OrderLinkType#getSource <em>Source</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Source</em>'.
	 * @see suite.OrderLinkType#getSource()
	 * @see #getOrderLinkType()
	 * @generated
	 */
	EReference getOrderLinkType_Source();

	/**
	 * Returns the meta object for the reference '{@link suite.OrderLinkType#getTarget <em>Target</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Target</em>'.
	 * @see suite.OrderLinkType#getTarget()
	 * @see #getOrderLinkType()
	 * @generated
	 */
	EReference getOrderLinkType_Target();

	/**
	 * Returns the meta object for the attribute '{@link suite.OrderLinkType#getOrderType <em>Order Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Order Type</em>'.
	 * @see suite.OrderLinkType#getOrderType()
	 * @see #getOrderLinkType()
	 * @generated
	 */
	EAttribute getOrderLinkType_OrderType();

	/**
	 * Returns the meta object for class '{@link suite.SetupType <em>Setup Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Setup Type</em>'.
	 * @see suite.SetupType
	 * @generated
	 */
	EClass getSetupType();

	/**
	 * Returns the meta object for class '{@link suite.TeardownType <em>Teardown Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Teardown Type</em>'.
	 * @see suite.TeardownType
	 * @generated
	 */
	EClass getTeardownType();

	/**
	 * Returns the meta object for class '{@link suite.GoalLinkType <em>Goal Link Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Goal Link Type</em>'.
	 * @see suite.GoalLinkType
	 * @generated
	 */
	EClass getGoalLinkType();

	/**
	 * Returns the meta object for the reference '{@link suite.GoalLinkType#getSource <em>Source</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Source</em>'.
	 * @see suite.GoalLinkType#getSource()
	 * @see #getGoalLinkType()
	 * @generated
	 */
	EReference getGoalLinkType_Source();

	/**
	 * Returns the meta object for the reference '{@link suite.GoalLinkType#getTarget <em>Target</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Target</em>'.
	 * @see suite.GoalLinkType#getTarget()
	 * @see #getGoalLinkType()
	 * @generated
	 */
	EReference getGoalLinkType_Target();

	/**
	 * Returns the meta object for the attribute '{@link suite.GoalLinkType#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see suite.GoalLinkType#getName()
	 * @see #getGoalLinkType()
	 * @generated
	 */
	EAttribute getGoalLinkType_Name();

	/**
	 * Returns the meta object for class '{@link suite.SendLinkType <em>Send Link Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Send Link Type</em>'.
	 * @see suite.SendLinkType
	 * @generated
	 */
	EClass getSendLinkType();

	/**
	 * Returns the meta object for the reference '{@link suite.SendLinkType#getSource <em>Source</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Source</em>'.
	 * @see suite.SendLinkType#getSource()
	 * @see #getSendLinkType()
	 * @generated
	 */
	EReference getSendLinkType_Source();

	/**
	 * Returns the meta object for the reference '{@link suite.SendLinkType#getTarget <em>Target</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Target</em>'.
	 * @see suite.SendLinkType#getTarget()
	 * @see #getSendLinkType()
	 * @generated
	 */
	EReference getSendLinkType_Target();

	/**
	 * Returns the meta object for the attribute '{@link suite.SendLinkType#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see suite.SendLinkType#getName()
	 * @see #getSendLinkType()
	 * @generated
	 */
	EAttribute getSendLinkType_Name();

	/**
	 * Returns the meta object for class '{@link suite.ReceiveLinkType <em>Receive Link Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Receive Link Type</em>'.
	 * @see suite.ReceiveLinkType
	 * @generated
	 */
	EClass getReceiveLinkType();

	/**
	 * Returns the meta object for the reference '{@link suite.ReceiveLinkType#getTarget <em>Target</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Target</em>'.
	 * @see suite.ReceiveLinkType#getTarget()
	 * @see #getReceiveLinkType()
	 * @generated
	 */
	EReference getReceiveLinkType_Target();

	/**
	 * Returns the meta object for the reference '{@link suite.ReceiveLinkType#getSource <em>Source</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Source</em>'.
	 * @see suite.ReceiveLinkType#getSource()
	 * @see #getReceiveLinkType()
	 * @generated
	 */
	EReference getReceiveLinkType_Source();

	/**
	 * Returns the meta object for the attribute '{@link suite.ReceiveLinkType#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see suite.ReceiveLinkType#getName()
	 * @see #getReceiveLinkType()
	 * @generated
	 */
	EAttribute getReceiveLinkType_Name();

	/**
	 * Returns the meta object for enum '{@link suite.AType <em>AType</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>AType</em>'.
	 * @see suite.AType
	 * @generated
	 */
	EEnum getAType();

	/**
	 * Returns the meta object for enum '{@link suite.GoalReachType <em>Goal Reach Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Goal Reach Type</em>'.
	 * @see suite.GoalReachType
	 * @generated
	 */
	EEnum getGoalReachType();

	/**
	 * Returns the meta object for enum '{@link suite.OperatorType <em>Operator Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Operator Type</em>'.
	 * @see suite.OperatorType
	 * @generated
	 */
	EEnum getOperatorType();

	/**
	 * Returns the meta object for enum '{@link suite.RelationshipType <em>Relationship Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Relationship Type</em>'.
	 * @see suite.RelationshipType
	 * @generated
	 */
	EEnum getRelationshipType();

	/**
	 * Returns the meta object for enum '{@link suite.TaskType <em>Task Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Task Type</em>'.
	 * @see suite.TaskType
	 * @generated
	 */
	EEnum getTaskType();

	/**
	 * Returns the meta object for enum '{@link suite.OrderType <em>Order Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Order Type</em>'.
	 * @see suite.OrderType
	 * @generated
	 */
	EEnum getOrderType();

	/**
	 * Returns the meta object for data type '{@link suite.AType <em>AType Object</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>AType Object</em>'.
	 * @see suite.AType
	 * @model instanceClass="suite.AType"
	 *        extendedMetaData="name='AType:Object' baseType='AType'"
	 * @generated
	 */
	EDataType getATypeObject();

	/**
	 * Returns the meta object for data type '{@link suite.GoalReachType <em>Goal Reach Type Object</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Goal Reach Type Object</em>'.
	 * @see suite.GoalReachType
	 * @model instanceClass="suite.GoalReachType"
	 *        extendedMetaData="name='GoalReachType:Object' baseType='GoalReachType'"
	 * @generated
	 */
	EDataType getGoalReachTypeObject();

	/**
	 * Returns the meta object for data type '{@link suite.OperatorType <em>Operator Type Object</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Operator Type Object</em>'.
	 * @see suite.OperatorType
	 * @model instanceClass="suite.OperatorType"
	 *        extendedMetaData="name='OperatorType:Object' baseType='OperatorType'"
	 * @generated
	 */
	EDataType getOperatorTypeObject();

	/**
	 * Returns the meta object for data type '{@link suite.RelationshipType <em>Relationship Type Object</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Relationship Type Object</em>'.
	 * @see suite.RelationshipType
	 * @model instanceClass="suite.RelationshipType"
	 *        extendedMetaData="name='RelationshipType:Object' baseType='RelationshipType'"
	 * @generated
	 */
	EDataType getRelationshipTypeObject();

	/**
	 * Returns the meta object for data type '{@link suite.TaskType <em>Task Type Object</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Task Type Object</em>'.
	 * @see suite.TaskType
	 * @model instanceClass="suite.TaskType"
	 *        extendedMetaData="name='TaskType:Object' baseType='TaskType'"
	 * @generated
	 */
	EDataType getTaskTypeObject();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	SuiteFactory getSuiteFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link suite.impl.CheckTypeImpl <em>Check Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see suite.impl.CheckTypeImpl
		 * @see suite.impl.SuitePackageImpl#getCheckType()
		 * @generated
		 */
		EClass CHECK_TYPE = eINSTANCE.getCheckType();

		/**
		 * The meta object literal for the '<em><b>Check Operator</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CHECK_TYPE__CHECK_OPERATOR = eINSTANCE.getCheckType_CheckOperator();

		/**
		 * The meta object literal for the '<em><b>Expected Value</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CHECK_TYPE__EXPECTED_VALUE = eINSTANCE.getCheckType_ExpectedValue();

		/**
		 * The meta object literal for the '{@link suite.impl.ConditionTypeImpl <em>Condition Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see suite.impl.ConditionTypeImpl
		 * @see suite.impl.SuitePackageImpl#getConditionType()
		 * @generated
		 */
		EClass CONDITION_TYPE = eINSTANCE.getConditionType();

		/**
		 * The meta object literal for the '<em><b>Expression</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONDITION_TYPE__EXPRESSION = eINSTANCE.getConditionType_Expression();

		/**
		 * The meta object literal for the '{@link suite.impl.DocumentRootImpl <em>Document Root</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see suite.impl.DocumentRootImpl
		 * @see suite.impl.SuitePackageImpl#getDocumentRoot()
		 * @generated
		 */
		EClass DOCUMENT_ROOT = eINSTANCE.getDocumentRoot();

		/**
		 * The meta object literal for the '<em><b>Mixed</b></em>' attribute list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DOCUMENT_ROOT__MIXED = eINSTANCE.getDocumentRoot_Mixed();

		/**
		 * The meta object literal for the '<em><b>XMLNS Prefix Map</b></em>' map feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOCUMENT_ROOT__XMLNS_PREFIX_MAP = eINSTANCE.getDocumentRoot_XMLNSPrefixMap();

		/**
		 * The meta object literal for the '<em><b>XSI Schema Location</b></em>' map feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOCUMENT_ROOT__XSI_SCHEMA_LOCATION = eINSTANCE.getDocumentRoot_XSISchemaLocation();

		/**
		 * The meta object literal for the '<em><b>Test Case</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOCUMENT_ROOT__TEST_CASE = eINSTANCE.getDocumentRoot_TestCase();

		/**
		 * The meta object literal for the '<em><b>Test Scenario</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOCUMENT_ROOT__TEST_SCENARIO = eINSTANCE.getDocumentRoot_TestScenario();

		/**
		 * The meta object literal for the '<em><b>Test Suite</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOCUMENT_ROOT__TEST_SUITE = eINSTANCE.getDocumentRoot_TestSuite();

		/**
		 * The meta object literal for the '{@link suite.impl.ExpressionTypeImpl <em>Expression Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see suite.impl.ExpressionTypeImpl
		 * @see suite.impl.SuitePackageImpl#getExpressionType()
		 * @generated
		 */
		EClass EXPRESSION_TYPE = eINSTANCE.getExpressionType();

		/**
		 * The meta object literal for the '<em><b>Value</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute EXPRESSION_TYPE__VALUE = eINSTANCE.getExpressionType_Value();

		/**
		 * The meta object literal for the '<em><b>Executable</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute EXPRESSION_TYPE__EXECUTABLE = eINSTANCE.getExpressionType_Executable();

		/**
		 * The meta object literal for the '{@link suite.impl.GoalPlanTypeImpl <em>Goal Plan Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see suite.impl.GoalPlanTypeImpl
		 * @see suite.impl.SuitePackageImpl#getGoalPlanType()
		 * @generated
		 */
		EClass GOAL_PLAN_TYPE = eINSTANCE.getGoalPlanType();

		/**
		 * The meta object literal for the '<em><b>Goal</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GOAL_PLAN_TYPE__GOAL = eINSTANCE.getGoalPlanType_Goal();

		/**
		 * The meta object literal for the '<em><b>Plan</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GOAL_PLAN_TYPE__PLAN = eINSTANCE.getGoalPlanType_Plan();

		/**
		 * The meta object literal for the '<em><b>Relationship</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GOAL_PLAN_TYPE__RELATIONSHIP = eINSTANCE.getGoalPlanType_Relationship();

		/**
		 * The meta object literal for the '<em><b>Pre Condition</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GOAL_PLAN_TYPE__PRE_CONDITION = eINSTANCE.getGoalPlanType_PreCondition();

		/**
		 * The meta object literal for the '<em><b>Post Condition</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GOAL_PLAN_TYPE__POST_CONDITION = eINSTANCE.getGoalPlanType_PostCondition();

		/**
		 * The meta object literal for the '{@link suite.impl.ParamTypeImpl <em>Param Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see suite.impl.ParamTypeImpl
		 * @see suite.impl.SuitePackageImpl#getParamType()
		 * @generated
		 */
		EClass PARAM_TYPE = eINSTANCE.getParamType();

		/**
		 * The meta object literal for the '<em><b>Value</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PARAM_TYPE__VALUE = eINSTANCE.getParamType_Value();

		/**
		 * The meta object literal for the '<em><b>Ref</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PARAM_TYPE__REF = eINSTANCE.getParamType_Ref();

		/**
		 * The meta object literal for the '<em><b>Class</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PARAM_TYPE__CLASS = eINSTANCE.getParamType_Class();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PARAM_TYPE__NAME = eINSTANCE.getParamType_Name();

		/**
		 * The meta object literal for the '{@link suite.impl.TActionTypeImpl <em>TAction Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see suite.impl.TActionTypeImpl
		 * @see suite.impl.SuitePackageImpl#getTActionType()
		 * @generated
		 */
		EClass TACTION_TYPE = eINSTANCE.getTActionType();

		/**
		 * The meta object literal for the '<em><b>ID</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TACTION_TYPE__ID = eINSTANCE.getTActionType_ID();

		/**
		 * The meta object literal for the '<em><b>Initiator</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TACTION_TYPE__INITIATOR = eINSTANCE.getTActionType_Initiator();

		/**
		 * The meta object literal for the '<em><b>Responder</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TACTION_TYPE__RESPONDER = eINSTANCE.getTActionType_Responder();

		/**
		 * The meta object literal for the '<em><b>Act Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TACTION_TYPE__ACT_TYPE = eINSTANCE.getTActionType_ActType();

		/**
		 * The meta object literal for the '<em><b>Next Action</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TACTION_TYPE__NEXT_ACTION = eINSTANCE.getTActionType_NextAction();

		/**
		 * The meta object literal for the '<em><b>Next If True</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TACTION_TYPE__NEXT_IF_TRUE = eINSTANCE.getTActionType_NextIfTrue();

		/**
		 * The meta object literal for the '<em><b>Next If False</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TACTION_TYPE__NEXT_IF_FALSE = eINSTANCE.getTActionType_NextIfFalse();

		/**
		 * The meta object literal for the '<em><b>Message</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TACTION_TYPE__MESSAGE = eINSTANCE.getTActionType_Message();

		/**
		 * The meta object literal for the '<em><b>Verdict</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TACTION_TYPE__VERDICT = eINSTANCE.getTActionType_Verdict();

		/**
		 * The meta object literal for the '<em><b>Timeout</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TACTION_TYPE__TIMEOUT = eINSTANCE.getTActionType_Timeout();

		/**
		 * The meta object literal for the '{@link suite.impl.TargetTypeImpl <em>Target Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see suite.impl.TargetTypeImpl
		 * @see suite.impl.SuitePackageImpl#getTargetType()
		 * @generated
		 */
		EClass TARGET_TYPE = eINSTANCE.getTargetType();

		/**
		 * The meta object literal for the '<em><b>Agent</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TARGET_TYPE__AGENT = eINSTANCE.getTargetType_Agent();

		/**
		 * The meta object literal for the '<em><b>Goal Plan</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TARGET_TYPE__GOAL_PLAN = eINSTANCE.getTargetType_GoalPlan();

		/**
		 * The meta object literal for the '{@link suite.impl.TaskType1Impl <em>Task Type1</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see suite.impl.TaskType1Impl
		 * @see suite.impl.SuitePackageImpl#getTaskType1()
		 * @generated
		 */
		EClass TASK_TYPE1 = eINSTANCE.getTaskType1();

		/**
		 * The meta object literal for the '<em><b>Param</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TASK_TYPE1__PARAM = eINSTANCE.getTaskType1_Param();

		/**
		 * The meta object literal for the '<em><b>Class</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TASK_TYPE1__CLASS = eINSTANCE.getTaskType1_Class();

		/**
		 * The meta object literal for the '<em><b>Desc</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TASK_TYPE1__DESC = eINSTANCE.getTaskType1_Desc();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TASK_TYPE1__NAME = eINSTANCE.getTaskType1_Name();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TASK_TYPE1__TYPE = eINSTANCE.getTaskType1_Type();

		/**
		 * The meta object literal for the '{@link suite.impl.TestCaseTypeImpl <em>Test Case Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see suite.impl.TestCaseTypeImpl
		 * @see suite.impl.SuitePackageImpl#getTestCaseType()
		 * @generated
		 */
		EClass TEST_CASE_TYPE = eINSTANCE.getTestCaseType();

		/**
		 * The meta object literal for the '<em><b>ID</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TEST_CASE_TYPE__ID = eINSTANCE.getTestCaseType_ID();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TEST_CASE_TYPE__NAME = eINSTANCE.getTestCaseType_Name();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TEST_CASE_TYPE__TYPE = eINSTANCE.getTestCaseType_Type();

		/**
		 * The meta object literal for the '<em><b>Description</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TEST_CASE_TYPE__DESCRIPTION = eINSTANCE.getTestCaseType_Description();

		/**
		 * The meta object literal for the '<em><b>Setup</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TEST_CASE_TYPE__SETUP = eINSTANCE.getTestCaseType_Setup();

		/**
		 * The meta object literal for the '<em><b>Teardown</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TEST_CASE_TYPE__TEARDOWN = eINSTANCE.getTestCaseType_Teardown();

		/**
		 * The meta object literal for the '<em><b>Scenario</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TEST_CASE_TYPE__SCENARIO = eINSTANCE.getTestCaseType_Scenario();

		/**
		 * The meta object literal for the '<em><b>Pre Condition</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TEST_CASE_TYPE__PRE_CONDITION = eINSTANCE.getTestCaseType_PreCondition();

		/**
		 * The meta object literal for the '<em><b>Post Condition</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TEST_CASE_TYPE__POST_CONDITION = eINSTANCE.getTestCaseType_PostCondition();

		/**
		 * The meta object literal for the '<em><b>Active</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TEST_CASE_TYPE__ACTIVE = eINSTANCE.getTestCaseType_Active();

		/**
		 * The meta object literal for the '<em><b>Priority</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TEST_CASE_TYPE__PRIORITY = eINSTANCE.getTestCaseType_Priority();

		/**
		 * The meta object literal for the '{@link suite.impl.TestScenarioTypeImpl <em>Test Scenario Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see suite.impl.TestScenarioTypeImpl
		 * @see suite.impl.SuitePackageImpl#getTestScenarioType()
		 * @generated
		 */
		EClass TEST_SCENARIO_TYPE = eINSTANCE.getTestScenarioType();

		/**
		 * The meta object literal for the '<em><b>Test Action</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TEST_SCENARIO_TYPE__TEST_ACTION = eINSTANCE.getTestScenarioType_TestAction();

		/**
		 * The meta object literal for the '<em><b>Link</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TEST_SCENARIO_TYPE__LINK = eINSTANCE.getTestScenarioType_Link();

		/**
		 * The meta object literal for the '{@link suite.impl.TestSuiteTypeImpl <em>Test Suite Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see suite.impl.TestSuiteTypeImpl
		 * @see suite.impl.SuitePackageImpl#getTestSuiteType()
		 * @generated
		 */
		EClass TEST_SUITE_TYPE = eINSTANCE.getTestSuiteType();

		/**
		 * The meta object literal for the '<em><b>ID</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TEST_SUITE_TYPE__ID = eINSTANCE.getTestSuiteType_ID();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TEST_SUITE_TYPE__NAME = eINSTANCE.getTestSuiteType_Name();

		/**
		 * The meta object literal for the '<em><b>Created By</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TEST_SUITE_TYPE__CREATED_BY = eINSTANCE.getTestSuiteType_CreatedBy();

		/**
		 * The meta object literal for the '<em><b>Version</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TEST_SUITE_TYPE__VERSION = eINSTANCE.getTestSuiteType_Version();

		/**
		 * The meta object literal for the '<em><b>Created Date</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TEST_SUITE_TYPE__CREATED_DATE = eINSTANCE.getTestSuiteType_CreatedDate();

		/**
		 * The meta object literal for the '<em><b>Description</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TEST_SUITE_TYPE__DESCRIPTION = eINSTANCE.getTestSuiteType_Description();

		/**
		 * The meta object literal for the '<em><b>Target</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TEST_SUITE_TYPE__TARGET = eINSTANCE.getTestSuiteType_Target();

		/**
		 * The meta object literal for the '<em><b>Test Case</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TEST_SUITE_TYPE__TEST_CASE = eINSTANCE.getTestSuiteType_TestCase();

		/**
		 * The meta object literal for the '<em><b>Setup</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TEST_SUITE_TYPE__SETUP = eINSTANCE.getTestSuiteType_Setup();

		/**
		 * The meta object literal for the '<em><b>Teardown</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TEST_SUITE_TYPE__TEARDOWN = eINSTANCE.getTestSuiteType_Teardown();

		/**
		 * The meta object literal for the '<em><b>Goal Link</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TEST_SUITE_TYPE__GOAL_LINK = eINSTANCE.getTestSuiteType_GoalLink();

		/**
		 * The meta object literal for the '<em><b>Send Link</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TEST_SUITE_TYPE__SEND_LINK = eINSTANCE.getTestSuiteType_SendLink();

		/**
		 * The meta object literal for the '<em><b>Receive Link</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TEST_SUITE_TYPE__RECEIVE_LINK = eINSTANCE.getTestSuiteType_ReceiveLink();

		/**
		 * The meta object literal for the '{@link suite.impl.TestSupportTypeImpl <em>Test Support Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see suite.impl.TestSupportTypeImpl
		 * @see suite.impl.SuitePackageImpl#getTestSupportType()
		 * @generated
		 */
		EClass TEST_SUPPORT_TYPE = eINSTANCE.getTestSupportType();

		/**
		 * The meta object literal for the '<em><b>Task</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TEST_SUPPORT_TYPE__TASK = eINSTANCE.getTestSupportType_Task();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TEST_SUPPORT_TYPE__NAME = eINSTANCE.getTestSupportType_Name();

		/**
		 * The meta object literal for the '{@link suite.impl.OrderLinkTypeImpl <em>Order Link Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see suite.impl.OrderLinkTypeImpl
		 * @see suite.impl.SuitePackageImpl#getOrderLinkType()
		 * @generated
		 */
		EClass ORDER_LINK_TYPE = eINSTANCE.getOrderLinkType();

		/**
		 * The meta object literal for the '<em><b>Desc</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ORDER_LINK_TYPE__DESC = eINSTANCE.getOrderLinkType_Desc();

		/**
		 * The meta object literal for the '<em><b>Source</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ORDER_LINK_TYPE__SOURCE = eINSTANCE.getOrderLinkType_Source();

		/**
		 * The meta object literal for the '<em><b>Target</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ORDER_LINK_TYPE__TARGET = eINSTANCE.getOrderLinkType_Target();

		/**
		 * The meta object literal for the '<em><b>Order Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ORDER_LINK_TYPE__ORDER_TYPE = eINSTANCE.getOrderLinkType_OrderType();

		/**
		 * The meta object literal for the '{@link suite.impl.SetupTypeImpl <em>Setup Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see suite.impl.SetupTypeImpl
		 * @see suite.impl.SuitePackageImpl#getSetupType()
		 * @generated
		 */
		EClass SETUP_TYPE = eINSTANCE.getSetupType();

		/**
		 * The meta object literal for the '{@link suite.impl.TeardownTypeImpl <em>Teardown Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see suite.impl.TeardownTypeImpl
		 * @see suite.impl.SuitePackageImpl#getTeardownType()
		 * @generated
		 */
		EClass TEARDOWN_TYPE = eINSTANCE.getTeardownType();

		/**
		 * The meta object literal for the '{@link suite.impl.GoalLinkTypeImpl <em>Goal Link Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see suite.impl.GoalLinkTypeImpl
		 * @see suite.impl.SuitePackageImpl#getGoalLinkType()
		 * @generated
		 */
		EClass GOAL_LINK_TYPE = eINSTANCE.getGoalLinkType();

		/**
		 * The meta object literal for the '<em><b>Source</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GOAL_LINK_TYPE__SOURCE = eINSTANCE.getGoalLinkType_Source();

		/**
		 * The meta object literal for the '<em><b>Target</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GOAL_LINK_TYPE__TARGET = eINSTANCE.getGoalLinkType_Target();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GOAL_LINK_TYPE__NAME = eINSTANCE.getGoalLinkType_Name();

		/**
		 * The meta object literal for the '{@link suite.impl.SendLinkTypeImpl <em>Send Link Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see suite.impl.SendLinkTypeImpl
		 * @see suite.impl.SuitePackageImpl#getSendLinkType()
		 * @generated
		 */
		EClass SEND_LINK_TYPE = eINSTANCE.getSendLinkType();

		/**
		 * The meta object literal for the '<em><b>Source</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SEND_LINK_TYPE__SOURCE = eINSTANCE.getSendLinkType_Source();

		/**
		 * The meta object literal for the '<em><b>Target</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SEND_LINK_TYPE__TARGET = eINSTANCE.getSendLinkType_Target();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SEND_LINK_TYPE__NAME = eINSTANCE.getSendLinkType_Name();

		/**
		 * The meta object literal for the '{@link suite.impl.ReceiveLinkTypeImpl <em>Receive Link Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see suite.impl.ReceiveLinkTypeImpl
		 * @see suite.impl.SuitePackageImpl#getReceiveLinkType()
		 * @generated
		 */
		EClass RECEIVE_LINK_TYPE = eINSTANCE.getReceiveLinkType();

		/**
		 * The meta object literal for the '<em><b>Target</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference RECEIVE_LINK_TYPE__TARGET = eINSTANCE.getReceiveLinkType_Target();

		/**
		 * The meta object literal for the '<em><b>Source</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference RECEIVE_LINK_TYPE__SOURCE = eINSTANCE.getReceiveLinkType_Source();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute RECEIVE_LINK_TYPE__NAME = eINSTANCE.getReceiveLinkType_Name();

		/**
		 * The meta object literal for the '{@link suite.AType <em>AType</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see suite.AType
		 * @see suite.impl.SuitePackageImpl#getAType()
		 * @generated
		 */
		EEnum ATYPE = eINSTANCE.getAType();

		/**
		 * The meta object literal for the '{@link suite.GoalReachType <em>Goal Reach Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see suite.GoalReachType
		 * @see suite.impl.SuitePackageImpl#getGoalReachType()
		 * @generated
		 */
		EEnum GOAL_REACH_TYPE = eINSTANCE.getGoalReachType();

		/**
		 * The meta object literal for the '{@link suite.OperatorType <em>Operator Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see suite.OperatorType
		 * @see suite.impl.SuitePackageImpl#getOperatorType()
		 * @generated
		 */
		EEnum OPERATOR_TYPE = eINSTANCE.getOperatorType();

		/**
		 * The meta object literal for the '{@link suite.RelationshipType <em>Relationship Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see suite.RelationshipType
		 * @see suite.impl.SuitePackageImpl#getRelationshipType()
		 * @generated
		 */
		EEnum RELATIONSHIP_TYPE = eINSTANCE.getRelationshipType();

		/**
		 * The meta object literal for the '{@link suite.TaskType <em>Task Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see suite.TaskType
		 * @see suite.impl.SuitePackageImpl#getTaskType()
		 * @generated
		 */
		EEnum TASK_TYPE = eINSTANCE.getTaskType();

		/**
		 * The meta object literal for the '{@link suite.OrderType <em>Order Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see suite.OrderType
		 * @see suite.impl.SuitePackageImpl#getOrderType()
		 * @generated
		 */
		EEnum ORDER_TYPE = eINSTANCE.getOrderType();

		/**
		 * The meta object literal for the '<em>AType Object</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see suite.AType
		 * @see suite.impl.SuitePackageImpl#getATypeObject()
		 * @generated
		 */
		EDataType ATYPE_OBJECT = eINSTANCE.getATypeObject();

		/**
		 * The meta object literal for the '<em>Goal Reach Type Object</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see suite.GoalReachType
		 * @see suite.impl.SuitePackageImpl#getGoalReachTypeObject()
		 * @generated
		 */
		EDataType GOAL_REACH_TYPE_OBJECT = eINSTANCE.getGoalReachTypeObject();

		/**
		 * The meta object literal for the '<em>Operator Type Object</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see suite.OperatorType
		 * @see suite.impl.SuitePackageImpl#getOperatorTypeObject()
		 * @generated
		 */
		EDataType OPERATOR_TYPE_OBJECT = eINSTANCE.getOperatorTypeObject();

		/**
		 * The meta object literal for the '<em>Relationship Type Object</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see suite.RelationshipType
		 * @see suite.impl.SuitePackageImpl#getRelationshipTypeObject()
		 * @generated
		 */
		EDataType RELATIONSHIP_TYPE_OBJECT = eINSTANCE.getRelationshipTypeObject();

		/**
		 * The meta object literal for the '<em>Task Type Object</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see suite.TaskType
		 * @see suite.impl.SuitePackageImpl#getTaskTypeObject()
		 * @generated
		 */
		EDataType TASK_TYPE_OBJECT = eINSTANCE.getTaskTypeObject();

	}

} //SuitePackage
