/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package suite;

import javax.xml.datatype.XMLGregorianCalendar;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Test Suite Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link suite.TestSuiteType#getID <em>ID</em>}</li>
 *   <li>{@link suite.TestSuiteType#getName <em>Name</em>}</li>
 *   <li>{@link suite.TestSuiteType#getCreatedBy <em>Created By</em>}</li>
 *   <li>{@link suite.TestSuiteType#getVersion <em>Version</em>}</li>
 *   <li>{@link suite.TestSuiteType#getCreatedDate <em>Created Date</em>}</li>
 *   <li>{@link suite.TestSuiteType#getDescription <em>Description</em>}</li>
 *   <li>{@link suite.TestSuiteType#getTarget <em>Target</em>}</li>
 *   <li>{@link suite.TestSuiteType#getTestCase <em>Test Case</em>}</li>
 *   <li>{@link suite.TestSuiteType#getSetup <em>Setup</em>}</li>
 *   <li>{@link suite.TestSuiteType#getTeardown <em>Teardown</em>}</li>
 *   <li>{@link suite.TestSuiteType#getGoalLink <em>Goal Link</em>}</li>
 *   <li>{@link suite.TestSuiteType#getSendLink <em>Send Link</em>}</li>
 *   <li>{@link suite.TestSuiteType#getReceiveLink <em>Receive Link</em>}</li>
 * </ul>
 * </p>
 *
 * @see suite.SuitePackage#getTestSuiteType()
 * @model extendedMetaData="name='TestSuite_._type' kind='elementOnly'"
 * @generated
 */
public interface TestSuiteType extends EObject {
	/**
	 * Returns the value of the '<em><b>ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>ID</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>ID</em>' attribute.
	 * @see #setID(String)
	 * @see suite.SuitePackage#getTestSuiteType_ID()
	 * @model id="true" dataType="org.eclipse.emf.ecore.xml.type.ID" required="true"
	 *        extendedMetaData="kind='element' name='ID' namespace='##targetNamespace'"
	 * @generated
	 */
	String getID();

	/**
	 * Sets the value of the '{@link suite.TestSuiteType#getID <em>ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>ID</em>' attribute.
	 * @see #getID()
	 * @generated
	 */
	void setID(String value);

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see suite.SuitePackage#getTestSuiteType_Name()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.String" required="true"
	 *        extendedMetaData="kind='element' name='Name' namespace='##targetNamespace'"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link suite.TestSuiteType#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Created By</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Created By</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Created By</em>' attribute.
	 * @see #setCreatedBy(String)
	 * @see suite.SuitePackage#getTestSuiteType_CreatedBy()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.String" required="true"
	 *        extendedMetaData="kind='element' name='CreatedBy' namespace='##targetNamespace'"
	 * @generated
	 */
	String getCreatedBy();

	/**
	 * Sets the value of the '{@link suite.TestSuiteType#getCreatedBy <em>Created By</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Created By</em>' attribute.
	 * @see #getCreatedBy()
	 * @generated
	 */
	void setCreatedBy(String value);

	/**
	 * Returns the value of the '<em><b>Version</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Version</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Version</em>' attribute.
	 * @see #setVersion(String)
	 * @see suite.SuitePackage#getTestSuiteType_Version()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.String" required="true"
	 *        extendedMetaData="kind='element' name='Version' namespace='##targetNamespace'"
	 * @generated
	 */
	String getVersion();

	/**
	 * Sets the value of the '{@link suite.TestSuiteType#getVersion <em>Version</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Version</em>' attribute.
	 * @see #getVersion()
	 * @generated
	 */
	void setVersion(String value);

	/**
	 * Returns the value of the '<em><b>Created Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Created Date</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Created Date</em>' attribute.
	 * @see #setCreatedDate(XMLGregorianCalendar)
	 * @see suite.SuitePackage#getTestSuiteType_CreatedDate()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.Date" required="true"
	 *        extendedMetaData="kind='element' name='CreatedDate' namespace='##targetNamespace'"
	 * @generated
	 */
	XMLGregorianCalendar getCreatedDate();

	/**
	 * Sets the value of the '{@link suite.TestSuiteType#getCreatedDate <em>Created Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Created Date</em>' attribute.
	 * @see #getCreatedDate()
	 * @generated
	 */
	void setCreatedDate(XMLGregorianCalendar value);

	/**
	 * Returns the value of the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Description</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Description</em>' attribute.
	 * @see #setDescription(String)
	 * @see suite.SuitePackage#getTestSuiteType_Description()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.String" required="true"
	 *        extendedMetaData="kind='element' name='Description' namespace='##targetNamespace'"
	 * @generated
	 */
	String getDescription();

	/**
	 * Sets the value of the '{@link suite.TestSuiteType#getDescription <em>Description</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Description</em>' attribute.
	 * @see #getDescription()
	 * @generated
	 */
	void setDescription(String value);

	/**
	 * Returns the value of the '<em><b>Target</b></em>' containment reference list.
	 * The list contents are of type {@link suite.TargetType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Target</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Target</em>' containment reference list.
	 * @see suite.SuitePackage#getTestSuiteType_Target()
	 * @model containment="true" required="true"
	 *        extendedMetaData="kind='element' name='Target' namespace='##targetNamespace'"
	 * @generated
	 */
	EList<TargetType> getTarget();

	/**
	 * Returns the value of the '<em><b>Test Case</b></em>' containment reference list.
	 * The list contents are of type {@link suite.TestCaseType}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Test case structure
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Test Case</em>' containment reference list.
	 * @see suite.SuitePackage#getTestSuiteType_TestCase()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='TestCase' namespace='##targetNamespace'"
	 * @generated
	 */
	EList<TestCaseType> getTestCase();

	/**
	 * Returns the value of the '<em><b>Setup</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Setup</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Setup</em>' containment reference.
	 * @see #setSetup(SetupType)
	 * @see suite.SuitePackage#getTestSuiteType_Setup()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='Setup' namespace='##targetNamespace'"
	 * @generated
	 */
	SetupType getSetup();

	/**
	 * Sets the value of the '{@link suite.TestSuiteType#getSetup <em>Setup</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Setup</em>' containment reference.
	 * @see #getSetup()
	 * @generated
	 */
	void setSetup(SetupType value);

	/**
	 * Returns the value of the '<em><b>Teardown</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Teardown</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Teardown</em>' containment reference.
	 * @see #setTeardown(TeardownType)
	 * @see suite.SuitePackage#getTestSuiteType_Teardown()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='Teardown' namespace='##targetNamespace'"
	 * @generated
	 */
	TeardownType getTeardown();

	/**
	 * Sets the value of the '{@link suite.TestSuiteType#getTeardown <em>Teardown</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Teardown</em>' containment reference.
	 * @see #getTeardown()
	 * @generated
	 */
	void setTeardown(TeardownType value);

	/**
	 * Returns the value of the '<em><b>Goal Link</b></em>' containment reference list.
	 * The list contents are of type {@link suite.GoalLinkType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Goal Link</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Goal Link</em>' containment reference list.
	 * @see suite.SuitePackage#getTestSuiteType_GoalLink()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='GoalLink' namespace='##targetNamespace'"
	 * @generated
	 */
	EList<GoalLinkType> getGoalLink();

	/**
	 * Returns the value of the '<em><b>Send Link</b></em>' containment reference list.
	 * The list contents are of type {@link suite.SendLinkType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Send Link</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Send Link</em>' containment reference list.
	 * @see suite.SuitePackage#getTestSuiteType_SendLink()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='SendLink' namespace='##targetNamespace'"
	 * @generated
	 */
	EList<SendLinkType> getSendLink();

	/**
	 * Returns the value of the '<em><b>Receive Link</b></em>' containment reference list.
	 * The list contents are of type {@link suite.ReceiveLinkType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Receive Link</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Receive Link</em>' containment reference list.
	 * @see suite.SuitePackage#getTestSuiteType_ReceiveLink()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='ReceiveLink' namespace='##targetNamespace'"
	 * @generated
	 */
	EList<ReceiveLinkType> getReceiveLink();

} // TestSuiteType
