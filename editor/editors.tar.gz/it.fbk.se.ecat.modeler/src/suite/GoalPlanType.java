/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package suite;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Goal Plan Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link suite.GoalPlanType#getGoal <em>Goal</em>}</li>
 *   <li>{@link suite.GoalPlanType#getPlan <em>Plan</em>}</li>
 *   <li>{@link suite.GoalPlanType#getRelationship <em>Relationship</em>}</li>
 *   <li>{@link suite.GoalPlanType#getPreCondition <em>Pre Condition</em>}</li>
 *   <li>{@link suite.GoalPlanType#getPostCondition <em>Post Condition</em>}</li>
 * </ul>
 * </p>
 *
 * @see suite.SuitePackage#getGoalPlanType()
 * @model extendedMetaData="name='GoalPlanType' kind='elementOnly'"
 * @generated
 */
public interface GoalPlanType extends EObject {
	/**
	 * Returns the value of the '<em><b>Goal</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Goal</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Goal</em>' attribute.
	 * @see #setGoal(String)
	 * @see suite.SuitePackage#getGoalPlanType_Goal()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.String" required="true"
	 *        extendedMetaData="kind='element' name='Goal' namespace='##targetNamespace'"
	 * @generated
	 */
	String getGoal();

	/**
	 * Sets the value of the '{@link suite.GoalPlanType#getGoal <em>Goal</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Goal</em>' attribute.
	 * @see #getGoal()
	 * @generated
	 */
	void setGoal(String value);

	/**
	 * Returns the value of the '<em><b>Plan</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Plan</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Plan</em>' attribute.
	 * @see #setPlan(String)
	 * @see suite.SuitePackage#getGoalPlanType_Plan()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.String" required="true"
	 *        extendedMetaData="kind='element' name='Plan' namespace='##targetNamespace'"
	 * @generated
	 */
	String getPlan();

	/**
	 * Sets the value of the '{@link suite.GoalPlanType#getPlan <em>Plan</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Plan</em>' attribute.
	 * @see #getPlan()
	 * @generated
	 */
	void setPlan(String value);

	/**
	 * Returns the value of the '<em><b>Relationship</b></em>' attribute.
	 * The default value is <code>"Means-End"</code>.
	 * The literals are from the enumeration {@link suite.RelationshipType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Relationship</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Relationship</em>' attribute.
	 * @see suite.RelationshipType
	 * @see #isSetRelationship()
	 * @see #unsetRelationship()
	 * @see #setRelationship(RelationshipType)
	 * @see suite.SuitePackage#getGoalPlanType_Relationship()
	 * @model default="Means-End" unsettable="true" required="true"
	 *        extendedMetaData="kind='element' name='Relationship' namespace='##targetNamespace'"
	 * @generated
	 */
	RelationshipType getRelationship();

	/**
	 * Sets the value of the '{@link suite.GoalPlanType#getRelationship <em>Relationship</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Relationship</em>' attribute.
	 * @see suite.RelationshipType
	 * @see #isSetRelationship()
	 * @see #unsetRelationship()
	 * @see #getRelationship()
	 * @generated
	 */
	void setRelationship(RelationshipType value);

	/**
	 * Unsets the value of the '{@link suite.GoalPlanType#getRelationship <em>Relationship</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetRelationship()
	 * @see #getRelationship()
	 * @see #setRelationship(RelationshipType)
	 * @generated
	 */
	void unsetRelationship();

	/**
	 * Returns whether the value of the '{@link suite.GoalPlanType#getRelationship <em>Relationship</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Relationship</em>' attribute is set.
	 * @see #unsetRelationship()
	 * @see #getRelationship()
	 * @see #setRelationship(RelationshipType)
	 * @generated
	 */
	boolean isSetRelationship();

	/**
	 * Returns the value of the '<em><b>Pre Condition</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Pre Condition</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Pre Condition</em>' containment reference.
	 * @see #setPreCondition(ConditionType)
	 * @see suite.SuitePackage#getGoalPlanType_PreCondition()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='PreCondition' namespace='##targetNamespace'"
	 * @generated
	 */
	ConditionType getPreCondition();

	/**
	 * Sets the value of the '{@link suite.GoalPlanType#getPreCondition <em>Pre Condition</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Pre Condition</em>' containment reference.
	 * @see #getPreCondition()
	 * @generated
	 */
	void setPreCondition(ConditionType value);

	/**
	 * Returns the value of the '<em><b>Post Condition</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Post Condition</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Post Condition</em>' containment reference.
	 * @see #setPostCondition(ConditionType)
	 * @see suite.SuitePackage#getGoalPlanType_PostCondition()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='PostCondition' namespace='##targetNamespace'"
	 * @generated
	 */
	ConditionType getPostCondition();

	/**
	 * Sets the value of the '{@link suite.GoalPlanType#getPostCondition <em>Post Condition</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Post Condition</em>' containment reference.
	 * @see #getPostCondition()
	 * @generated
	 */
	void setPostCondition(ConditionType value);

} // GoalPlanType
