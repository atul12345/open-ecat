/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package suite;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Test Scenario Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link suite.TestScenarioType#getTestAction <em>Test Action</em>}</li>
 *   <li>{@link suite.TestScenarioType#getLink <em>Link</em>}</li>
 * </ul>
 * </p>
 *
 * @see suite.SuitePackage#getTestScenarioType()
 * @model extendedMetaData="name='TestScenarioType' kind='elementOnly'"
 * @generated
 */
public interface TestScenarioType extends EObject {
	/**
	 * Returns the value of the '<em><b>Test Action</b></em>' containment reference list.
	 * The list contents are of type {@link suite.TActionType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Test Action</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Test Action</em>' containment reference list.
	 * @see suite.SuitePackage#getTestScenarioType_TestAction()
	 * @model containment="true" required="true"
	 *        extendedMetaData="kind='element' name='TestAction' namespace='##targetNamespace'"
	 * @generated
	 */
	EList<TActionType> getTestAction();

	/**
	 * Returns the value of the '<em><b>Link</b></em>' containment reference list.
	 * The list contents are of type {@link suite.OrderLinkType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Link</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Link</em>' containment reference list.
	 * @see suite.SuitePackage#getTestScenarioType_Link()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='Link' namespace='##targetNamespace'"
	 * @generated
	 */
	EList<OrderLinkType> getLink();

} // TestScenarioType
