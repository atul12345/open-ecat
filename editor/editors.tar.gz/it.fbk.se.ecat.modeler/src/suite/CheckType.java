/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package suite;

import org.eclipse.emf.ecore.EObject;

import schema.FipaMessageType;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Check Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link suite.CheckType#getCheckOperator <em>Check Operator</em>}</li>
 *   <li>{@link suite.CheckType#getExpectedValue <em>Expected Value</em>}</li>
 * </ul>
 * </p>
 *
 * @see suite.SuitePackage#getCheckType()
 * @model extendedMetaData="name='CheckType' kind='elementOnly'"
 * @generated
 */
public interface CheckType extends EObject {
	/**
	 * Returns the value of the '<em><b>Check Operator</b></em>' attribute.
	 * The default value is <code>"equal"</code>.
	 * The literals are from the enumeration {@link suite.OperatorType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Check Operator</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Check Operator</em>' attribute.
	 * @see suite.OperatorType
	 * @see #isSetCheckOperator()
	 * @see #unsetCheckOperator()
	 * @see #setCheckOperator(OperatorType)
	 * @see suite.SuitePackage#getCheckType_CheckOperator()
	 * @model default="equal" unsettable="true" required="true"
	 *        extendedMetaData="kind='element' name='CheckOperator' namespace='##targetNamespace'"
	 * @generated
	 */
	OperatorType getCheckOperator();

	/**
	 * Sets the value of the '{@link suite.CheckType#getCheckOperator <em>Check Operator</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Check Operator</em>' attribute.
	 * @see suite.OperatorType
	 * @see #isSetCheckOperator()
	 * @see #unsetCheckOperator()
	 * @see #getCheckOperator()
	 * @generated
	 */
	void setCheckOperator(OperatorType value);

	/**
	 * Unsets the value of the '{@link suite.CheckType#getCheckOperator <em>Check Operator</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetCheckOperator()
	 * @see #getCheckOperator()
	 * @see #setCheckOperator(OperatorType)
	 * @generated
	 */
	void unsetCheckOperator();

	/**
	 * Returns whether the value of the '{@link suite.CheckType#getCheckOperator <em>Check Operator</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Check Operator</em>' attribute is set.
	 * @see #unsetCheckOperator()
	 * @see #getCheckOperator()
	 * @see #setCheckOperator(OperatorType)
	 * @generated
	 */
	boolean isSetCheckOperator();

	/**
	 * Returns the value of the '<em><b>Expected Value</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Expected Value</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Expected Value</em>' containment reference.
	 * @see #setExpectedValue(FipaMessageType)
	 * @see suite.SuitePackage#getCheckType_ExpectedValue()
	 * @model containment="true" required="true"
	 *        extendedMetaData="kind='element' name='ExpectedValue' namespace='##targetNamespace'"
	 * @generated
	 */
	FipaMessageType getExpectedValue();

	/**
	 * Sets the value of the '{@link suite.CheckType#getExpectedValue <em>Expected Value</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Expected Value</em>' containment reference.
	 * @see #getExpectedValue()
	 * @generated
	 */
	void setExpectedValue(FipaMessageType value);

} // CheckType
