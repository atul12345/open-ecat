/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package suite;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.Enumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>Task Type</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see suite.SuitePackage#getTaskType()
 * @model extendedMetaData="name='TaskType'"
 * @generated
 */
public enum TaskType implements Enumerator {
	/**
	 * The '<em><b>Register Agent</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #REGISTER_AGENT_VALUE
	 * @generated
	 * @ordered
	 */
	REGISTER_AGENT(0, "RegisterAgent", "Register-Agent"),

	/**
	 * The '<em><b>Deregister Agent</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #DEREGISTER_AGENT_VALUE
	 * @generated
	 * @ordered
	 */
	DEREGISTER_AGENT(1, "DeregisterAgent", "Deregister-Agent"),

	/**
	 * The '<em><b>Start Agent</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #START_AGENT_VALUE
	 * @generated
	 * @ordered
	 */
	START_AGENT(2, "StartAgent", "Start-Agent"),

	/**
	 * The '<em><b>Kill Agent</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #KILL_AGENT_VALUE
	 * @generated
	 * @ordered
	 */
	KILL_AGENT(3, "KillAgent", "Kill-Agent"),

	/**
	 * The '<em><b>Suspend Agent</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #SUSPEND_AGENT_VALUE
	 * @generated
	 * @ordered
	 */
	SUSPEND_AGENT(4, "SuspendAgent", "Suspend-Agent"),

	/**
	 * The '<em><b>Activate Agent</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #ACTIVATE_AGENT_VALUE
	 * @generated
	 * @ordered
	 */
	ACTIVATE_AGENT(5, "ActivateAgent", "Activate-Agent"),

	/**
	 * The '<em><b>Execute Capability</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #EXECUTE_CAPABILITY_VALUE
	 * @generated
	 * @ordered
	 */
	EXECUTE_CAPABILITY(6, "ExecuteCapability", "Execute-Capability"),

	/**
	 * The '<em><b>Execute Java</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #EXECUTE_JAVA_VALUE
	 * @generated
	 * @ordered
	 */
	EXECUTE_JAVA(7, "ExecuteJava", "Execute-Java"),

	/**
	 * The '<em><b>Non Executable</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #NON_EXECUTABLE_VALUE
	 * @generated
	 * @ordered
	 */
	NON_EXECUTABLE(8, "NonExecutable", "Non-Executable");

	/**
	 * The '<em><b>Register Agent</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Register Agent</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #REGISTER_AGENT
	 * @model name="RegisterAgent" literal="Register-Agent"
	 * @generated
	 * @ordered
	 */
	public static final int REGISTER_AGENT_VALUE = 0;

	/**
	 * The '<em><b>Deregister Agent</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Deregister Agent</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #DEREGISTER_AGENT
	 * @model name="DeregisterAgent" literal="Deregister-Agent"
	 * @generated
	 * @ordered
	 */
	public static final int DEREGISTER_AGENT_VALUE = 1;

	/**
	 * The '<em><b>Start Agent</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Start Agent</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #START_AGENT
	 * @model name="StartAgent" literal="Start-Agent"
	 * @generated
	 * @ordered
	 */
	public static final int START_AGENT_VALUE = 2;

	/**
	 * The '<em><b>Kill Agent</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Kill Agent</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #KILL_AGENT
	 * @model name="KillAgent" literal="Kill-Agent"
	 * @generated
	 * @ordered
	 */
	public static final int KILL_AGENT_VALUE = 3;

	/**
	 * The '<em><b>Suspend Agent</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Suspend Agent</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #SUSPEND_AGENT
	 * @model name="SuspendAgent" literal="Suspend-Agent"
	 * @generated
	 * @ordered
	 */
	public static final int SUSPEND_AGENT_VALUE = 4;

	/**
	 * The '<em><b>Activate Agent</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Activate Agent</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #ACTIVATE_AGENT
	 * @model name="ActivateAgent" literal="Activate-Agent"
	 * @generated
	 * @ordered
	 */
	public static final int ACTIVATE_AGENT_VALUE = 5;

	/**
	 * The '<em><b>Execute Capability</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Execute Capability</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #EXECUTE_CAPABILITY
	 * @model name="ExecuteCapability" literal="Execute-Capability"
	 * @generated
	 * @ordered
	 */
	public static final int EXECUTE_CAPABILITY_VALUE = 6;

	/**
	 * The '<em><b>Execute Java</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Execute Java</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #EXECUTE_JAVA
	 * @model name="ExecuteJava" literal="Execute-Java"
	 * @generated
	 * @ordered
	 */
	public static final int EXECUTE_JAVA_VALUE = 7;

	/**
	 * The '<em><b>Non Executable</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Non Executable</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #NON_EXECUTABLE
	 * @model name="NonExecutable" literal="Non-Executable"
	 * @generated
	 * @ordered
	 */
	public static final int NON_EXECUTABLE_VALUE = 8;

	/**
	 * An array of all the '<em><b>Task Type</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final TaskType[] VALUES_ARRAY =
		new TaskType[] {
			REGISTER_AGENT,
			DEREGISTER_AGENT,
			START_AGENT,
			KILL_AGENT,
			SUSPEND_AGENT,
			ACTIVATE_AGENT,
			EXECUTE_CAPABILITY,
			EXECUTE_JAVA,
			NON_EXECUTABLE,
		};

	/**
	 * A public read-only list of all the '<em><b>Task Type</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final List<TaskType> VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>Task Type</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static TaskType get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			TaskType result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Task Type</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static TaskType getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			TaskType result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Task Type</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static TaskType get(int value) {
		switch (value) {
			case REGISTER_AGENT_VALUE: return REGISTER_AGENT;
			case DEREGISTER_AGENT_VALUE: return DEREGISTER_AGENT;
			case START_AGENT_VALUE: return START_AGENT;
			case KILL_AGENT_VALUE: return KILL_AGENT;
			case SUSPEND_AGENT_VALUE: return SUSPEND_AGENT;
			case ACTIVATE_AGENT_VALUE: return ACTIVATE_AGENT;
			case EXECUTE_CAPABILITY_VALUE: return EXECUTE_CAPABILITY;
			case EXECUTE_JAVA_VALUE: return EXECUTE_JAVA;
			case NON_EXECUTABLE_VALUE: return NON_EXECUTABLE;
		}
		return null;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final int value;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String name;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String literal;

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private TaskType(int value, String name, String literal) {
		this.value = value;
		this.name = name;
		this.literal = literal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getValue() {
	  return value;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
	  return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLiteral() {
	  return literal;
	}

	/**
	 * Returns the literal value of the enumerator, which is its string representation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		return literal;
	}
	
} //TaskType
