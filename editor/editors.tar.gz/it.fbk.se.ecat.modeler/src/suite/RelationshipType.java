/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package suite;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.Enumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>Relationship Type</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see suite.SuitePackage#getRelationshipType()
 * @model extendedMetaData="name='RelationshipType'"
 * @generated
 */
public enum RelationshipType implements Enumerator {
	/**
	 * The '<em><b>Means End</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #MEANS_END_VALUE
	 * @generated
	 * @ordered
	 */
	MEANS_END(0, "MeansEnd", "Means-End"),

	/**
	 * The '<em><b>Contribution</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #CONTRIBUTION_VALUE
	 * @generated
	 * @ordered
	 */
	CONTRIBUTION(1, "Contribution", "Contribution--"),

	/**
	 * The '<em><b>Contribution1</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #CONTRIBUTION1_VALUE
	 * @generated
	 * @ordered
	 */
	CONTRIBUTION1(2, "Contribution1", "Contribution-"),

	/**
	 * The '<em><b>Contribution2</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #CONTRIBUTION2_VALUE
	 * @generated
	 * @ordered
	 */
	CONTRIBUTION2(3, "Contribution2", "Contribution+"),

	/**
	 * The '<em><b>Contribution3</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #CONTRIBUTION3_VALUE
	 * @generated
	 * @ordered
	 */
	CONTRIBUTION3(4, "Contribution3", "Contribution++"),

	/**
	 * The '<em><b>Decomposition AND</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #DECOMPOSITION_AND_VALUE
	 * @generated
	 * @ordered
	 */
	DECOMPOSITION_AND(5, "DecompositionAND", "DecompositionAND"),

	/**
	 * The '<em><b>Decomposition OR</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #DECOMPOSITION_OR_VALUE
	 * @generated
	 * @ordered
	 */
	DECOMPOSITION_OR(6, "DecompositionOR", "DecompositionOR");

	/**
	 * The '<em><b>Means End</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Means End</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #MEANS_END
	 * @model name="MeansEnd" literal="Means-End"
	 * @generated
	 * @ordered
	 */
	public static final int MEANS_END_VALUE = 0;

	/**
	 * The '<em><b>Contribution</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Contribution</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #CONTRIBUTION
	 * @model name="Contribution" literal="Contribution--"
	 * @generated
	 * @ordered
	 */
	public static final int CONTRIBUTION_VALUE = 1;

	/**
	 * The '<em><b>Contribution1</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Contribution1</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #CONTRIBUTION1
	 * @model name="Contribution1" literal="Contribution-"
	 * @generated
	 * @ordered
	 */
	public static final int CONTRIBUTION1_VALUE = 2;

	/**
	 * The '<em><b>Contribution2</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Contribution2</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #CONTRIBUTION2
	 * @model name="Contribution2" literal="Contribution+"
	 * @generated
	 * @ordered
	 */
	public static final int CONTRIBUTION2_VALUE = 3;

	/**
	 * The '<em><b>Contribution3</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Contribution3</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #CONTRIBUTION3
	 * @model name="Contribution3" literal="Contribution++"
	 * @generated
	 * @ordered
	 */
	public static final int CONTRIBUTION3_VALUE = 4;

	/**
	 * The '<em><b>Decomposition AND</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Decomposition AND</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #DECOMPOSITION_AND
	 * @model name="DecompositionAND"
	 * @generated
	 * @ordered
	 */
	public static final int DECOMPOSITION_AND_VALUE = 5;

	/**
	 * The '<em><b>Decomposition OR</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Decomposition OR</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #DECOMPOSITION_OR
	 * @model name="DecompositionOR"
	 * @generated
	 * @ordered
	 */
	public static final int DECOMPOSITION_OR_VALUE = 6;

	/**
	 * An array of all the '<em><b>Relationship Type</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final RelationshipType[] VALUES_ARRAY =
		new RelationshipType[] {
			MEANS_END,
			CONTRIBUTION,
			CONTRIBUTION1,
			CONTRIBUTION2,
			CONTRIBUTION3,
			DECOMPOSITION_AND,
			DECOMPOSITION_OR,
		};

	/**
	 * A public read-only list of all the '<em><b>Relationship Type</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final List<RelationshipType> VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>Relationship Type</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static RelationshipType get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			RelationshipType result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Relationship Type</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static RelationshipType getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			RelationshipType result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Relationship Type</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static RelationshipType get(int value) {
		switch (value) {
			case MEANS_END_VALUE: return MEANS_END;
			case CONTRIBUTION_VALUE: return CONTRIBUTION;
			case CONTRIBUTION1_VALUE: return CONTRIBUTION1;
			case CONTRIBUTION2_VALUE: return CONTRIBUTION2;
			case CONTRIBUTION3_VALUE: return CONTRIBUTION3;
			case DECOMPOSITION_AND_VALUE: return DECOMPOSITION_AND;
			case DECOMPOSITION_OR_VALUE: return DECOMPOSITION_OR;
		}
		return null;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final int value;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String name;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String literal;

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private RelationshipType(int value, String name, String literal) {
		this.value = value;
		this.name = name;
		this.literal = literal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getValue() {
	  return value;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
	  return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLiteral() {
	  return literal;
	}

	/**
	 * Returns the literal value of the enumerator, which is its string representation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		return literal;
	}
	
} //RelationshipType
