/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package it.itc.sra.se.test.config;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see it.itc.sra.se.test.config.ConfigFactory
 * @model kind="package"
 * @generated
 */
public interface ConfigPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "config";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://sra.itc.it/se/TestConfig";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "config";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	ConfigPackage eINSTANCE = it.itc.sra.se.test.config.impl.ConfigPackageImpl.init();

	/**
	 * The meta object id for the '{@link it.itc.sra.se.test.config.impl.ClasspathentryTypeImpl <em>Classpathentry Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see it.itc.sra.se.test.config.impl.ClasspathentryTypeImpl
	 * @see it.itc.sra.se.test.config.impl.ConfigPackageImpl#getClasspathentryType()
	 * @generated
	 */
	int CLASSPATHENTRY_TYPE = 0;

	/**
	 * The feature id for the '<em><b>Kind</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASSPATHENTRY_TYPE__KIND = 0;

	/**
	 * The feature id for the '<em><b>Path</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASSPATHENTRY_TYPE__PATH = 1;

	/**
	 * The number of structural features of the '<em>Classpathentry Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASSPATHENTRY_TYPE_FEATURE_COUNT = 2;

	/**
	 * The meta object id for the '{@link it.itc.sra.se.test.config.impl.DitributedNodeConfigTypeImpl <em>Ditributed Node Config Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see it.itc.sra.se.test.config.impl.DitributedNodeConfigTypeImpl
	 * @see it.itc.sra.se.test.config.impl.ConfigPackageImpl#getDitributedNodeConfigType()
	 * @generated
	 */
	int DITRIBUTED_NODE_CONFIG_TYPE = 1;

	/**
	 * The feature id for the '<em><b>Node</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DITRIBUTED_NODE_CONFIG_TYPE__NODE = 0;

	/**
	 * The number of structural features of the '<em>Ditributed Node Config Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DITRIBUTED_NODE_CONFIG_TYPE_FEATURE_COUNT = 1;

	/**
	 * The meta object id for the '{@link it.itc.sra.se.test.config.impl.DocumentRootImpl <em>Document Root</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see it.itc.sra.se.test.config.impl.DocumentRootImpl
	 * @see it.itc.sra.se.test.config.impl.ConfigPackageImpl#getDocumentRoot()
	 * @generated
	 */
	int DOCUMENT_ROOT = 2;

	/**
	 * The feature id for the '<em><b>Mixed</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT_ROOT__MIXED = 0;

	/**
	 * The feature id for the '<em><b>XMLNS Prefix Map</b></em>' map.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT_ROOT__XMLNS_PREFIX_MAP = 1;

	/**
	 * The feature id for the '<em><b>XSI Schema Location</b></em>' map.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT_ROOT__XSI_SCHEMA_LOCATION = 2;

	/**
	 * The feature id for the '<em><b>Test Config</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT_ROOT__TEST_CONFIG = 3;

	/**
	 * The number of structural features of the '<em>Document Root</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT_ROOT_FEATURE_COUNT = 4;

	/**
	 * The meta object id for the '{@link it.itc.sra.se.test.config.impl.JavaPathTypeImpl <em>Java Path Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see it.itc.sra.se.test.config.impl.JavaPathTypeImpl
	 * @see it.itc.sra.se.test.config.impl.ConfigPackageImpl#getJavaPathType()
	 * @generated
	 */
	int JAVA_PATH_TYPE = 3;

	/**
	 * The feature id for the '<em><b>Classpathentry</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_PATH_TYPE__CLASSPATHENTRY = 0;

	/**
	 * The number of structural features of the '<em>Java Path Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_PATH_TYPE_FEATURE_COUNT = 1;

	/**
	 * The meta object id for the '{@link it.itc.sra.se.test.config.impl.NodeTypeImpl <em>Node Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see it.itc.sra.se.test.config.impl.NodeTypeImpl
	 * @see it.itc.sra.se.test.config.impl.ConfigPackageImpl#getNodeType()
	 * @generated
	 */
	int NODE_TYPE = 4;

	/**
	 * The feature id for the '<em><b>Node Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NODE_TYPE__NODE_NAME = 0;

	/**
	 * The feature id for the '<em><b>Node Address</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NODE_TYPE__NODE_ADDRESS = 1;

	/**
	 * The feature id for the '<em><b>Node Hap</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NODE_TYPE__NODE_HAP = 2;

	/**
	 * The feature id for the '<em><b>Remote Monitoring Agent</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NODE_TYPE__REMOTE_MONITORING_AGENT = 3;

	/**
	 * The feature id for the '<em><b>Recovery Agent</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NODE_TYPE__RECOVERY_AGENT = 4;

	/**
	 * The feature id for the '<em><b>Remote Executor Agent</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NODE_TYPE__REMOTE_EXECUTOR_AGENT = 5;

	/**
	 * The feature id for the '<em><b>Monitored Agent List</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NODE_TYPE__MONITORED_AGENT_LIST = 6;

	/**
	 * The number of structural features of the '<em>Node Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NODE_TYPE_FEATURE_COUNT = 7;

	/**
	 * The meta object id for the '{@link it.itc.sra.se.test.config.impl.OntologyTypeImpl <em>Ontology Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see it.itc.sra.se.test.config.impl.OntologyTypeImpl
	 * @see it.itc.sra.se.test.config.impl.ConfigPackageImpl#getOntologyType()
	 * @generated
	 */
	int ONTOLOGY_TYPE = 5;

	/**
	 * The feature id for the '<em><b>Protege Ontology Path</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ONTOLOGY_TYPE__PROTEGE_ONTOLOGY_PATH = 0;

	/**
	 * The feature id for the '<em><b>Ontology Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ONTOLOGY_TYPE__ONTOLOGY_NAME = 1;

	/**
	 * The feature id for the '<em><b>Language</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ONTOLOGY_TYPE__LANGUAGE = 2;

	/**
	 * The feature id for the '<em><b>Ontology Package</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ONTOLOGY_TYPE__ONTOLOGY_PACKAGE = 3;

	/**
	 * The feature id for the '<em><b>Codec</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ONTOLOGY_TYPE__CODEC = 4;

	/**
	 * The feature id for the '<em><b>Input Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ONTOLOGY_TYPE__INPUT_TYPE = 5;

	/**
	 * The feature id for the '<em><b>Classpath</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ONTOLOGY_TYPE__CLASSPATH = 6;

	/**
	 * The number of structural features of the '<em>Ontology Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ONTOLOGY_TYPE_FEATURE_COUNT = 7;

	/**
	 * The meta object id for the '{@link it.itc.sra.se.test.config.impl.TestConfigTypeImpl <em>Test Config Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see it.itc.sra.se.test.config.impl.TestConfigTypeImpl
	 * @see it.itc.sra.se.test.config.impl.ConfigPackageImpl#getTestConfigType()
	 * @generated
	 */
	int TEST_CONFIG_TYPE = 6;

	/**
	 * The feature id for the '<em><b>Platform</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST_CONFIG_TYPE__PLATFORM = 0;

	/**
	 * The feature id for the '<em><b>Prefered Strategy</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST_CONFIG_TYPE__PREFERED_STRATEGY = 1;

	/**
	 * The feature id for the '<em><b>Test Suite List</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST_CONFIG_TYPE__TEST_SUITE_LIST = 2;

	/**
	 * The feature id for the '<em><b>Protocol Path</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST_CONFIG_TYPE__PROTOCOL_PATH = 3;

	/**
	 * The feature id for the '<em><b>Domain Data Path</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST_CONFIG_TYPE__DOMAIN_DATA_PATH = 4;

	/**
	 * The feature id for the '<em><b>Max Random TC</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST_CONFIG_TYPE__MAX_RANDOM_TC = 5;

	/**
	 * The feature id for the '<em><b>Number Cycle</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST_CONFIG_TYPE__NUMBER_CYCLE = 6;

	/**
	 * The feature id for the '<em><b>Agent Under Test</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST_CONFIG_TYPE__AGENT_UNDER_TEST = 7;

	/**
	 * The feature id for the '<em><b>Max Mutation Gen</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST_CONFIG_TYPE__MAX_MUTATION_GEN = 8;

	/**
	 * The feature id for the '<em><b>Max Mutation Psize</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST_CONFIG_TYPE__MAX_MUTATION_PSIZE = 9;

	/**
	 * The feature id for the '<em><b>Mutation Prob</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST_CONFIG_TYPE__MUTATION_PROB = 10;

	/**
	 * The feature id for the '<em><b>Ontology Setting</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST_CONFIG_TYPE__ONTOLOGY_SETTING = 11;

	/**
	 * The feature id for the '<em><b>Ditributed Node Config</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST_CONFIG_TYPE__DITRIBUTED_NODE_CONFIG = 12;

	/**
	 * The number of structural features of the '<em>Test Config Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST_CONFIG_TYPE_FEATURE_COUNT = 13;

	/**
	 * The meta object id for the '{@link it.itc.sra.se.test.config.impl.TestSuiteListTypeImpl <em>Test Suite List Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see it.itc.sra.se.test.config.impl.TestSuiteListTypeImpl
	 * @see it.itc.sra.se.test.config.impl.ConfigPackageImpl#getTestSuiteListType()
	 * @generated
	 */
	int TEST_SUITE_LIST_TYPE = 7;

	/**
	 * The feature id for the '<em><b>Test Suite Path</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST_SUITE_LIST_TYPE__TEST_SUITE_PATH = 0;

	/**
	 * The number of structural features of the '<em>Test Suite List Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST_SUITE_LIST_TYPE_FEATURE_COUNT = 1;

	/**
	 * The meta object id for the '{@link it.itc.sra.se.test.config.ClassPathType <em>Class Path Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see it.itc.sra.se.test.config.ClassPathType
	 * @see it.itc.sra.se.test.config.impl.ConfigPackageImpl#getClassPathType()
	 * @generated
	 */
	int CLASS_PATH_TYPE = 8;

	/**
	 * The meta object id for the '{@link it.itc.sra.se.test.config.CodecType <em>Codec Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see it.itc.sra.se.test.config.CodecType
	 * @see it.itc.sra.se.test.config.impl.ConfigPackageImpl#getCodecType()
	 * @generated
	 */
	int CODEC_TYPE = 9;

	/**
	 * The meta object id for the '{@link it.itc.sra.se.test.config.InputGenType <em>Input Gen Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see it.itc.sra.se.test.config.InputGenType
	 * @see it.itc.sra.se.test.config.impl.ConfigPackageImpl#getInputGenType()
	 * @generated
	 */
	int INPUT_GEN_TYPE = 10;

	/**
	 * The meta object id for the '{@link it.itc.sra.se.test.config.PlatformType <em>Platform Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see it.itc.sra.se.test.config.PlatformType
	 * @see it.itc.sra.se.test.config.impl.ConfigPackageImpl#getPlatformType()
	 * @generated
	 */
	int PLATFORM_TYPE = 11;

	/**
	 * The meta object id for the '{@link it.itc.sra.se.test.config.PreferedStrategyType <em>Prefered Strategy Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see it.itc.sra.se.test.config.PreferedStrategyType
	 * @see it.itc.sra.se.test.config.impl.ConfigPackageImpl#getPreferedStrategyType()
	 * @generated
	 */
	int PREFERED_STRATEGY_TYPE = 12;

	/**
	 * The meta object id for the '<em>Class Path Type Object</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see it.itc.sra.se.test.config.ClassPathType
	 * @see it.itc.sra.se.test.config.impl.ConfigPackageImpl#getClassPathTypeObject()
	 * @generated
	 */
	int CLASS_PATH_TYPE_OBJECT = 13;

	/**
	 * The meta object id for the '<em>Codec Type Object</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see it.itc.sra.se.test.config.CodecType
	 * @see it.itc.sra.se.test.config.impl.ConfigPackageImpl#getCodecTypeObject()
	 * @generated
	 */
	int CODEC_TYPE_OBJECT = 14;

	/**
	 * The meta object id for the '<em>Input Gen Type Object</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see it.itc.sra.se.test.config.InputGenType
	 * @see it.itc.sra.se.test.config.impl.ConfigPackageImpl#getInputGenTypeObject()
	 * @generated
	 */
	int INPUT_GEN_TYPE_OBJECT = 15;

	/**
	 * The meta object id for the '<em>Platform Type Object</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see it.itc.sra.se.test.config.PlatformType
	 * @see it.itc.sra.se.test.config.impl.ConfigPackageImpl#getPlatformTypeObject()
	 * @generated
	 */
	int PLATFORM_TYPE_OBJECT = 16;

	/**
	 * The meta object id for the '<em>Prefered Strategy Type Object</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see it.itc.sra.se.test.config.PreferedStrategyType
	 * @see it.itc.sra.se.test.config.impl.ConfigPackageImpl#getPreferedStrategyTypeObject()
	 * @generated
	 */
	int PREFERED_STRATEGY_TYPE_OBJECT = 17;


	/**
	 * Returns the meta object for class '{@link it.itc.sra.se.test.config.ClasspathentryType <em>Classpathentry Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Classpathentry Type</em>'.
	 * @see it.itc.sra.se.test.config.ClasspathentryType
	 * @generated
	 */
	EClass getClasspathentryType();

	/**
	 * Returns the meta object for the attribute '{@link it.itc.sra.se.test.config.ClasspathentryType#getKind <em>Kind</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Kind</em>'.
	 * @see it.itc.sra.se.test.config.ClasspathentryType#getKind()
	 * @see #getClasspathentryType()
	 * @generated
	 */
	EAttribute getClasspathentryType_Kind();

	/**
	 * Returns the meta object for the attribute '{@link it.itc.sra.se.test.config.ClasspathentryType#getPath <em>Path</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Path</em>'.
	 * @see it.itc.sra.se.test.config.ClasspathentryType#getPath()
	 * @see #getClasspathentryType()
	 * @generated
	 */
	EAttribute getClasspathentryType_Path();

	/**
	 * Returns the meta object for class '{@link it.itc.sra.se.test.config.DitributedNodeConfigType <em>Ditributed Node Config Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Ditributed Node Config Type</em>'.
	 * @see it.itc.sra.se.test.config.DitributedNodeConfigType
	 * @generated
	 */
	EClass getDitributedNodeConfigType();

	/**
	 * Returns the meta object for the containment reference list '{@link it.itc.sra.se.test.config.DitributedNodeConfigType#getNode <em>Node</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Node</em>'.
	 * @see it.itc.sra.se.test.config.DitributedNodeConfigType#getNode()
	 * @see #getDitributedNodeConfigType()
	 * @generated
	 */
	EReference getDitributedNodeConfigType_Node();

	/**
	 * Returns the meta object for class '{@link it.itc.sra.se.test.config.DocumentRoot <em>Document Root</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Document Root</em>'.
	 * @see it.itc.sra.se.test.config.DocumentRoot
	 * @generated
	 */
	EClass getDocumentRoot();

	/**
	 * Returns the meta object for the attribute list '{@link it.itc.sra.se.test.config.DocumentRoot#getMixed <em>Mixed</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute list '<em>Mixed</em>'.
	 * @see it.itc.sra.se.test.config.DocumentRoot#getMixed()
	 * @see #getDocumentRoot()
	 * @generated
	 */
	EAttribute getDocumentRoot_Mixed();

	/**
	 * Returns the meta object for the map '{@link it.itc.sra.se.test.config.DocumentRoot#getXMLNSPrefixMap <em>XMLNS Prefix Map</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the map '<em>XMLNS Prefix Map</em>'.
	 * @see it.itc.sra.se.test.config.DocumentRoot#getXMLNSPrefixMap()
	 * @see #getDocumentRoot()
	 * @generated
	 */
	EReference getDocumentRoot_XMLNSPrefixMap();

	/**
	 * Returns the meta object for the map '{@link it.itc.sra.se.test.config.DocumentRoot#getXSISchemaLocation <em>XSI Schema Location</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the map '<em>XSI Schema Location</em>'.
	 * @see it.itc.sra.se.test.config.DocumentRoot#getXSISchemaLocation()
	 * @see #getDocumentRoot()
	 * @generated
	 */
	EReference getDocumentRoot_XSISchemaLocation();

	/**
	 * Returns the meta object for the containment reference '{@link it.itc.sra.se.test.config.DocumentRoot#getTestConfig <em>Test Config</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Test Config</em>'.
	 * @see it.itc.sra.se.test.config.DocumentRoot#getTestConfig()
	 * @see #getDocumentRoot()
	 * @generated
	 */
	EReference getDocumentRoot_TestConfig();

	/**
	 * Returns the meta object for class '{@link it.itc.sra.se.test.config.JavaPathType <em>Java Path Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Java Path Type</em>'.
	 * @see it.itc.sra.se.test.config.JavaPathType
	 * @generated
	 */
	EClass getJavaPathType();

	/**
	 * Returns the meta object for the containment reference list '{@link it.itc.sra.se.test.config.JavaPathType#getClasspathentry <em>Classpathentry</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Classpathentry</em>'.
	 * @see it.itc.sra.se.test.config.JavaPathType#getClasspathentry()
	 * @see #getJavaPathType()
	 * @generated
	 */
	EReference getJavaPathType_Classpathentry();

	/**
	 * Returns the meta object for class '{@link it.itc.sra.se.test.config.NodeType <em>Node Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Node Type</em>'.
	 * @see it.itc.sra.se.test.config.NodeType
	 * @generated
	 */
	EClass getNodeType();

	/**
	 * Returns the meta object for the attribute '{@link it.itc.sra.se.test.config.NodeType#getNodeName <em>Node Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Node Name</em>'.
	 * @see it.itc.sra.se.test.config.NodeType#getNodeName()
	 * @see #getNodeType()
	 * @generated
	 */
	EAttribute getNodeType_NodeName();

	/**
	 * Returns the meta object for the attribute '{@link it.itc.sra.se.test.config.NodeType#getNodeAddress <em>Node Address</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Node Address</em>'.
	 * @see it.itc.sra.se.test.config.NodeType#getNodeAddress()
	 * @see #getNodeType()
	 * @generated
	 */
	EAttribute getNodeType_NodeAddress();

	/**
	 * Returns the meta object for the attribute '{@link it.itc.sra.se.test.config.NodeType#getNodeHap <em>Node Hap</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Node Hap</em>'.
	 * @see it.itc.sra.se.test.config.NodeType#getNodeHap()
	 * @see #getNodeType()
	 * @generated
	 */
	EAttribute getNodeType_NodeHap();

	/**
	 * Returns the meta object for the attribute '{@link it.itc.sra.se.test.config.NodeType#getRemoteMonitoringAgent <em>Remote Monitoring Agent</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Remote Monitoring Agent</em>'.
	 * @see it.itc.sra.se.test.config.NodeType#getRemoteMonitoringAgent()
	 * @see #getNodeType()
	 * @generated
	 */
	EAttribute getNodeType_RemoteMonitoringAgent();

	/**
	 * Returns the meta object for the attribute '{@link it.itc.sra.se.test.config.NodeType#getRecoveryAgent <em>Recovery Agent</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Recovery Agent</em>'.
	 * @see it.itc.sra.se.test.config.NodeType#getRecoveryAgent()
	 * @see #getNodeType()
	 * @generated
	 */
	EAttribute getNodeType_RecoveryAgent();

	/**
	 * Returns the meta object for the attribute '{@link it.itc.sra.se.test.config.NodeType#getRemoteExecutorAgent <em>Remote Executor Agent</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Remote Executor Agent</em>'.
	 * @see it.itc.sra.se.test.config.NodeType#getRemoteExecutorAgent()
	 * @see #getNodeType()
	 * @generated
	 */
	EAttribute getNodeType_RemoteExecutorAgent();

	/**
	 * Returns the meta object for the attribute '{@link it.itc.sra.se.test.config.NodeType#getMonitoredAgentList <em>Monitored Agent List</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Monitored Agent List</em>'.
	 * @see it.itc.sra.se.test.config.NodeType#getMonitoredAgentList()
	 * @see #getNodeType()
	 * @generated
	 */
	EAttribute getNodeType_MonitoredAgentList();

	/**
	 * Returns the meta object for class '{@link it.itc.sra.se.test.config.OntologyType <em>Ontology Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Ontology Type</em>'.
	 * @see it.itc.sra.se.test.config.OntologyType
	 * @generated
	 */
	EClass getOntologyType();

	/**
	 * Returns the meta object for the attribute '{@link it.itc.sra.se.test.config.OntologyType#getProtegeOntologyPath <em>Protege Ontology Path</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Protege Ontology Path</em>'.
	 * @see it.itc.sra.se.test.config.OntologyType#getProtegeOntologyPath()
	 * @see #getOntologyType()
	 * @generated
	 */
	EAttribute getOntologyType_ProtegeOntologyPath();

	/**
	 * Returns the meta object for the attribute '{@link it.itc.sra.se.test.config.OntologyType#getOntologyName <em>Ontology Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Ontology Name</em>'.
	 * @see it.itc.sra.se.test.config.OntologyType#getOntologyName()
	 * @see #getOntologyType()
	 * @generated
	 */
	EAttribute getOntologyType_OntologyName();

	/**
	 * Returns the meta object for the attribute '{@link it.itc.sra.se.test.config.OntologyType#getLanguage <em>Language</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Language</em>'.
	 * @see it.itc.sra.se.test.config.OntologyType#getLanguage()
	 * @see #getOntologyType()
	 * @generated
	 */
	EAttribute getOntologyType_Language();

	/**
	 * Returns the meta object for the attribute '{@link it.itc.sra.se.test.config.OntologyType#getOntologyPackage <em>Ontology Package</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Ontology Package</em>'.
	 * @see it.itc.sra.se.test.config.OntologyType#getOntologyPackage()
	 * @see #getOntologyType()
	 * @generated
	 */
	EAttribute getOntologyType_OntologyPackage();

	/**
	 * Returns the meta object for the attribute '{@link it.itc.sra.se.test.config.OntologyType#getCodec <em>Codec</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Codec</em>'.
	 * @see it.itc.sra.se.test.config.OntologyType#getCodec()
	 * @see #getOntologyType()
	 * @generated
	 */
	EAttribute getOntologyType_Codec();

	/**
	 * Returns the meta object for the attribute '{@link it.itc.sra.se.test.config.OntologyType#getInputType <em>Input Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Input Type</em>'.
	 * @see it.itc.sra.se.test.config.OntologyType#getInputType()
	 * @see #getOntologyType()
	 * @generated
	 */
	EAttribute getOntologyType_InputType();

	/**
	 * Returns the meta object for the containment reference '{@link it.itc.sra.se.test.config.OntologyType#getClasspath <em>Classpath</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Classpath</em>'.
	 * @see it.itc.sra.se.test.config.OntologyType#getClasspath()
	 * @see #getOntologyType()
	 * @generated
	 */
	EReference getOntologyType_Classpath();

	/**
	 * Returns the meta object for class '{@link it.itc.sra.se.test.config.TestConfigType <em>Test Config Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Test Config Type</em>'.
	 * @see it.itc.sra.se.test.config.TestConfigType
	 * @generated
	 */
	EClass getTestConfigType();

	/**
	 * Returns the meta object for the attribute '{@link it.itc.sra.se.test.config.TestConfigType#getPlatform <em>Platform</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Platform</em>'.
	 * @see it.itc.sra.se.test.config.TestConfigType#getPlatform()
	 * @see #getTestConfigType()
	 * @generated
	 */
	EAttribute getTestConfigType_Platform();

	/**
	 * Returns the meta object for the attribute '{@link it.itc.sra.se.test.config.TestConfigType#getPreferedStrategy <em>Prefered Strategy</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Prefered Strategy</em>'.
	 * @see it.itc.sra.se.test.config.TestConfigType#getPreferedStrategy()
	 * @see #getTestConfigType()
	 * @generated
	 */
	EAttribute getTestConfigType_PreferedStrategy();

	/**
	 * Returns the meta object for the containment reference '{@link it.itc.sra.se.test.config.TestConfigType#getTestSuiteList <em>Test Suite List</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Test Suite List</em>'.
	 * @see it.itc.sra.se.test.config.TestConfigType#getTestSuiteList()
	 * @see #getTestConfigType()
	 * @generated
	 */
	EReference getTestConfigType_TestSuiteList();

	/**
	 * Returns the meta object for the attribute '{@link it.itc.sra.se.test.config.TestConfigType#getProtocolPath <em>Protocol Path</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Protocol Path</em>'.
	 * @see it.itc.sra.se.test.config.TestConfigType#getProtocolPath()
	 * @see #getTestConfigType()
	 * @generated
	 */
	EAttribute getTestConfigType_ProtocolPath();

	/**
	 * Returns the meta object for the attribute '{@link it.itc.sra.se.test.config.TestConfigType#getDomainDataPath <em>Domain Data Path</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Domain Data Path</em>'.
	 * @see it.itc.sra.se.test.config.TestConfigType#getDomainDataPath()
	 * @see #getTestConfigType()
	 * @generated
	 */
	EAttribute getTestConfigType_DomainDataPath();

	/**
	 * Returns the meta object for the attribute '{@link it.itc.sra.se.test.config.TestConfigType#getMaxRandomTC <em>Max Random TC</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Max Random TC</em>'.
	 * @see it.itc.sra.se.test.config.TestConfigType#getMaxRandomTC()
	 * @see #getTestConfigType()
	 * @generated
	 */
	EAttribute getTestConfigType_MaxRandomTC();

	/**
	 * Returns the meta object for the attribute '{@link it.itc.sra.se.test.config.TestConfigType#getNumberCycle <em>Number Cycle</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Number Cycle</em>'.
	 * @see it.itc.sra.se.test.config.TestConfigType#getNumberCycle()
	 * @see #getTestConfigType()
	 * @generated
	 */
	EAttribute getTestConfigType_NumberCycle();

	/**
	 * Returns the meta object for the attribute '{@link it.itc.sra.se.test.config.TestConfigType#getAgentUnderTest <em>Agent Under Test</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Agent Under Test</em>'.
	 * @see it.itc.sra.se.test.config.TestConfigType#getAgentUnderTest()
	 * @see #getTestConfigType()
	 * @generated
	 */
	EAttribute getTestConfigType_AgentUnderTest();

	/**
	 * Returns the meta object for the attribute '{@link it.itc.sra.se.test.config.TestConfigType#getMaxMutationGen <em>Max Mutation Gen</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Max Mutation Gen</em>'.
	 * @see it.itc.sra.se.test.config.TestConfigType#getMaxMutationGen()
	 * @see #getTestConfigType()
	 * @generated
	 */
	EAttribute getTestConfigType_MaxMutationGen();

	/**
	 * Returns the meta object for the attribute '{@link it.itc.sra.se.test.config.TestConfigType#getMaxMutationPsize <em>Max Mutation Psize</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Max Mutation Psize</em>'.
	 * @see it.itc.sra.se.test.config.TestConfigType#getMaxMutationPsize()
	 * @see #getTestConfigType()
	 * @generated
	 */
	EAttribute getTestConfigType_MaxMutationPsize();

	/**
	 * Returns the meta object for the attribute '{@link it.itc.sra.se.test.config.TestConfigType#getMutationProb <em>Mutation Prob</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Mutation Prob</em>'.
	 * @see it.itc.sra.se.test.config.TestConfigType#getMutationProb()
	 * @see #getTestConfigType()
	 * @generated
	 */
	EAttribute getTestConfigType_MutationProb();

	/**
	 * Returns the meta object for the containment reference '{@link it.itc.sra.se.test.config.TestConfigType#getOntologySetting <em>Ontology Setting</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Ontology Setting</em>'.
	 * @see it.itc.sra.se.test.config.TestConfigType#getOntologySetting()
	 * @see #getTestConfigType()
	 * @generated
	 */
	EReference getTestConfigType_OntologySetting();

	/**
	 * Returns the meta object for the containment reference '{@link it.itc.sra.se.test.config.TestConfigType#getDitributedNodeConfig <em>Ditributed Node Config</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Ditributed Node Config</em>'.
	 * @see it.itc.sra.se.test.config.TestConfigType#getDitributedNodeConfig()
	 * @see #getTestConfigType()
	 * @generated
	 */
	EReference getTestConfigType_DitributedNodeConfig();

	/**
	 * Returns the meta object for class '{@link it.itc.sra.se.test.config.TestSuiteListType <em>Test Suite List Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Test Suite List Type</em>'.
	 * @see it.itc.sra.se.test.config.TestSuiteListType
	 * @generated
	 */
	EClass getTestSuiteListType();

	/**
	 * Returns the meta object for the attribute list '{@link it.itc.sra.se.test.config.TestSuiteListType#getTestSuitePath <em>Test Suite Path</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute list '<em>Test Suite Path</em>'.
	 * @see it.itc.sra.se.test.config.TestSuiteListType#getTestSuitePath()
	 * @see #getTestSuiteListType()
	 * @generated
	 */
	EAttribute getTestSuiteListType_TestSuitePath();

	/**
	 * Returns the meta object for enum '{@link it.itc.sra.se.test.config.ClassPathType <em>Class Path Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Class Path Type</em>'.
	 * @see it.itc.sra.se.test.config.ClassPathType
	 * @generated
	 */
	EEnum getClassPathType();

	/**
	 * Returns the meta object for enum '{@link it.itc.sra.se.test.config.CodecType <em>Codec Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Codec Type</em>'.
	 * @see it.itc.sra.se.test.config.CodecType
	 * @generated
	 */
	EEnum getCodecType();

	/**
	 * Returns the meta object for enum '{@link it.itc.sra.se.test.config.InputGenType <em>Input Gen Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Input Gen Type</em>'.
	 * @see it.itc.sra.se.test.config.InputGenType
	 * @generated
	 */
	EEnum getInputGenType();

	/**
	 * Returns the meta object for enum '{@link it.itc.sra.se.test.config.PlatformType <em>Platform Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Platform Type</em>'.
	 * @see it.itc.sra.se.test.config.PlatformType
	 * @generated
	 */
	EEnum getPlatformType();

	/**
	 * Returns the meta object for enum '{@link it.itc.sra.se.test.config.PreferedStrategyType <em>Prefered Strategy Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Prefered Strategy Type</em>'.
	 * @see it.itc.sra.se.test.config.PreferedStrategyType
	 * @generated
	 */
	EEnum getPreferedStrategyType();

	/**
	 * Returns the meta object for data type '{@link it.itc.sra.se.test.config.ClassPathType <em>Class Path Type Object</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Class Path Type Object</em>'.
	 * @see it.itc.sra.se.test.config.ClassPathType
	 * @model instanceClass="it.itc.sra.se.test.config.ClassPathType"
	 *        extendedMetaData="name='ClassPathType:Object' baseType='ClassPathType'"
	 * @generated
	 */
	EDataType getClassPathTypeObject();

	/**
	 * Returns the meta object for data type '{@link it.itc.sra.se.test.config.CodecType <em>Codec Type Object</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Codec Type Object</em>'.
	 * @see it.itc.sra.se.test.config.CodecType
	 * @model instanceClass="it.itc.sra.se.test.config.CodecType"
	 *        extendedMetaData="name='CodecType:Object' baseType='CodecType'"
	 * @generated
	 */
	EDataType getCodecTypeObject();

	/**
	 * Returns the meta object for data type '{@link it.itc.sra.se.test.config.InputGenType <em>Input Gen Type Object</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Input Gen Type Object</em>'.
	 * @see it.itc.sra.se.test.config.InputGenType
	 * @model instanceClass="it.itc.sra.se.test.config.InputGenType"
	 *        extendedMetaData="name='InputGenType:Object' baseType='InputGenType'"
	 * @generated
	 */
	EDataType getInputGenTypeObject();

	/**
	 * Returns the meta object for data type '{@link it.itc.sra.se.test.config.PlatformType <em>Platform Type Object</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Platform Type Object</em>'.
	 * @see it.itc.sra.se.test.config.PlatformType
	 * @model instanceClass="it.itc.sra.se.test.config.PlatformType"
	 *        extendedMetaData="name='PlatformType:Object' baseType='PlatformType'"
	 * @generated
	 */
	EDataType getPlatformTypeObject();

	/**
	 * Returns the meta object for data type '{@link it.itc.sra.se.test.config.PreferedStrategyType <em>Prefered Strategy Type Object</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Prefered Strategy Type Object</em>'.
	 * @see it.itc.sra.se.test.config.PreferedStrategyType
	 * @model instanceClass="it.itc.sra.se.test.config.PreferedStrategyType"
	 *        extendedMetaData="name='PreferedStrategyType:Object' baseType='PreferedStrategyType'"
	 * @generated
	 */
	EDataType getPreferedStrategyTypeObject();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	ConfigFactory getConfigFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link it.itc.sra.se.test.config.impl.ClasspathentryTypeImpl <em>Classpathentry Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see it.itc.sra.se.test.config.impl.ClasspathentryTypeImpl
		 * @see it.itc.sra.se.test.config.impl.ConfigPackageImpl#getClasspathentryType()
		 * @generated
		 */
		EClass CLASSPATHENTRY_TYPE = eINSTANCE.getClasspathentryType();

		/**
		 * The meta object literal for the '<em><b>Kind</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CLASSPATHENTRY_TYPE__KIND = eINSTANCE.getClasspathentryType_Kind();

		/**
		 * The meta object literal for the '<em><b>Path</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CLASSPATHENTRY_TYPE__PATH = eINSTANCE.getClasspathentryType_Path();

		/**
		 * The meta object literal for the '{@link it.itc.sra.se.test.config.impl.DitributedNodeConfigTypeImpl <em>Ditributed Node Config Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see it.itc.sra.se.test.config.impl.DitributedNodeConfigTypeImpl
		 * @see it.itc.sra.se.test.config.impl.ConfigPackageImpl#getDitributedNodeConfigType()
		 * @generated
		 */
		EClass DITRIBUTED_NODE_CONFIG_TYPE = eINSTANCE.getDitributedNodeConfigType();

		/**
		 * The meta object literal for the '<em><b>Node</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DITRIBUTED_NODE_CONFIG_TYPE__NODE = eINSTANCE.getDitributedNodeConfigType_Node();

		/**
		 * The meta object literal for the '{@link it.itc.sra.se.test.config.impl.DocumentRootImpl <em>Document Root</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see it.itc.sra.se.test.config.impl.DocumentRootImpl
		 * @see it.itc.sra.se.test.config.impl.ConfigPackageImpl#getDocumentRoot()
		 * @generated
		 */
		EClass DOCUMENT_ROOT = eINSTANCE.getDocumentRoot();

		/**
		 * The meta object literal for the '<em><b>Mixed</b></em>' attribute list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DOCUMENT_ROOT__MIXED = eINSTANCE.getDocumentRoot_Mixed();

		/**
		 * The meta object literal for the '<em><b>XMLNS Prefix Map</b></em>' map feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOCUMENT_ROOT__XMLNS_PREFIX_MAP = eINSTANCE.getDocumentRoot_XMLNSPrefixMap();

		/**
		 * The meta object literal for the '<em><b>XSI Schema Location</b></em>' map feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOCUMENT_ROOT__XSI_SCHEMA_LOCATION = eINSTANCE.getDocumentRoot_XSISchemaLocation();

		/**
		 * The meta object literal for the '<em><b>Test Config</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOCUMENT_ROOT__TEST_CONFIG = eINSTANCE.getDocumentRoot_TestConfig();

		/**
		 * The meta object literal for the '{@link it.itc.sra.se.test.config.impl.JavaPathTypeImpl <em>Java Path Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see it.itc.sra.se.test.config.impl.JavaPathTypeImpl
		 * @see it.itc.sra.se.test.config.impl.ConfigPackageImpl#getJavaPathType()
		 * @generated
		 */
		EClass JAVA_PATH_TYPE = eINSTANCE.getJavaPathType();

		/**
		 * The meta object literal for the '<em><b>Classpathentry</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference JAVA_PATH_TYPE__CLASSPATHENTRY = eINSTANCE.getJavaPathType_Classpathentry();

		/**
		 * The meta object literal for the '{@link it.itc.sra.se.test.config.impl.NodeTypeImpl <em>Node Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see it.itc.sra.se.test.config.impl.NodeTypeImpl
		 * @see it.itc.sra.se.test.config.impl.ConfigPackageImpl#getNodeType()
		 * @generated
		 */
		EClass NODE_TYPE = eINSTANCE.getNodeType();

		/**
		 * The meta object literal for the '<em><b>Node Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute NODE_TYPE__NODE_NAME = eINSTANCE.getNodeType_NodeName();

		/**
		 * The meta object literal for the '<em><b>Node Address</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute NODE_TYPE__NODE_ADDRESS = eINSTANCE.getNodeType_NodeAddress();

		/**
		 * The meta object literal for the '<em><b>Node Hap</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute NODE_TYPE__NODE_HAP = eINSTANCE.getNodeType_NodeHap();

		/**
		 * The meta object literal for the '<em><b>Remote Monitoring Agent</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute NODE_TYPE__REMOTE_MONITORING_AGENT = eINSTANCE.getNodeType_RemoteMonitoringAgent();

		/**
		 * The meta object literal for the '<em><b>Recovery Agent</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute NODE_TYPE__RECOVERY_AGENT = eINSTANCE.getNodeType_RecoveryAgent();

		/**
		 * The meta object literal for the '<em><b>Remote Executor Agent</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute NODE_TYPE__REMOTE_EXECUTOR_AGENT = eINSTANCE.getNodeType_RemoteExecutorAgent();

		/**
		 * The meta object literal for the '<em><b>Monitored Agent List</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute NODE_TYPE__MONITORED_AGENT_LIST = eINSTANCE.getNodeType_MonitoredAgentList();

		/**
		 * The meta object literal for the '{@link it.itc.sra.se.test.config.impl.OntologyTypeImpl <em>Ontology Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see it.itc.sra.se.test.config.impl.OntologyTypeImpl
		 * @see it.itc.sra.se.test.config.impl.ConfigPackageImpl#getOntologyType()
		 * @generated
		 */
		EClass ONTOLOGY_TYPE = eINSTANCE.getOntologyType();

		/**
		 * The meta object literal for the '<em><b>Protege Ontology Path</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ONTOLOGY_TYPE__PROTEGE_ONTOLOGY_PATH = eINSTANCE.getOntologyType_ProtegeOntologyPath();

		/**
		 * The meta object literal for the '<em><b>Ontology Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ONTOLOGY_TYPE__ONTOLOGY_NAME = eINSTANCE.getOntologyType_OntologyName();

		/**
		 * The meta object literal for the '<em><b>Language</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ONTOLOGY_TYPE__LANGUAGE = eINSTANCE.getOntologyType_Language();

		/**
		 * The meta object literal for the '<em><b>Ontology Package</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ONTOLOGY_TYPE__ONTOLOGY_PACKAGE = eINSTANCE.getOntologyType_OntologyPackage();

		/**
		 * The meta object literal for the '<em><b>Codec</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ONTOLOGY_TYPE__CODEC = eINSTANCE.getOntologyType_Codec();

		/**
		 * The meta object literal for the '<em><b>Input Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ONTOLOGY_TYPE__INPUT_TYPE = eINSTANCE.getOntologyType_InputType();

		/**
		 * The meta object literal for the '<em><b>Classpath</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ONTOLOGY_TYPE__CLASSPATH = eINSTANCE.getOntologyType_Classpath();

		/**
		 * The meta object literal for the '{@link it.itc.sra.se.test.config.impl.TestConfigTypeImpl <em>Test Config Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see it.itc.sra.se.test.config.impl.TestConfigTypeImpl
		 * @see it.itc.sra.se.test.config.impl.ConfigPackageImpl#getTestConfigType()
		 * @generated
		 */
		EClass TEST_CONFIG_TYPE = eINSTANCE.getTestConfigType();

		/**
		 * The meta object literal for the '<em><b>Platform</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TEST_CONFIG_TYPE__PLATFORM = eINSTANCE.getTestConfigType_Platform();

		/**
		 * The meta object literal for the '<em><b>Prefered Strategy</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TEST_CONFIG_TYPE__PREFERED_STRATEGY = eINSTANCE.getTestConfigType_PreferedStrategy();

		/**
		 * The meta object literal for the '<em><b>Test Suite List</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TEST_CONFIG_TYPE__TEST_SUITE_LIST = eINSTANCE.getTestConfigType_TestSuiteList();

		/**
		 * The meta object literal for the '<em><b>Protocol Path</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TEST_CONFIG_TYPE__PROTOCOL_PATH = eINSTANCE.getTestConfigType_ProtocolPath();

		/**
		 * The meta object literal for the '<em><b>Domain Data Path</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TEST_CONFIG_TYPE__DOMAIN_DATA_PATH = eINSTANCE.getTestConfigType_DomainDataPath();

		/**
		 * The meta object literal for the '<em><b>Max Random TC</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TEST_CONFIG_TYPE__MAX_RANDOM_TC = eINSTANCE.getTestConfigType_MaxRandomTC();

		/**
		 * The meta object literal for the '<em><b>Number Cycle</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TEST_CONFIG_TYPE__NUMBER_CYCLE = eINSTANCE.getTestConfigType_NumberCycle();

		/**
		 * The meta object literal for the '<em><b>Agent Under Test</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TEST_CONFIG_TYPE__AGENT_UNDER_TEST = eINSTANCE.getTestConfigType_AgentUnderTest();

		/**
		 * The meta object literal for the '<em><b>Max Mutation Gen</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TEST_CONFIG_TYPE__MAX_MUTATION_GEN = eINSTANCE.getTestConfigType_MaxMutationGen();

		/**
		 * The meta object literal for the '<em><b>Max Mutation Psize</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TEST_CONFIG_TYPE__MAX_MUTATION_PSIZE = eINSTANCE.getTestConfigType_MaxMutationPsize();

		/**
		 * The meta object literal for the '<em><b>Mutation Prob</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TEST_CONFIG_TYPE__MUTATION_PROB = eINSTANCE.getTestConfigType_MutationProb();

		/**
		 * The meta object literal for the '<em><b>Ontology Setting</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TEST_CONFIG_TYPE__ONTOLOGY_SETTING = eINSTANCE.getTestConfigType_OntologySetting();

		/**
		 * The meta object literal for the '<em><b>Ditributed Node Config</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TEST_CONFIG_TYPE__DITRIBUTED_NODE_CONFIG = eINSTANCE.getTestConfigType_DitributedNodeConfig();

		/**
		 * The meta object literal for the '{@link it.itc.sra.se.test.config.impl.TestSuiteListTypeImpl <em>Test Suite List Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see it.itc.sra.se.test.config.impl.TestSuiteListTypeImpl
		 * @see it.itc.sra.se.test.config.impl.ConfigPackageImpl#getTestSuiteListType()
		 * @generated
		 */
		EClass TEST_SUITE_LIST_TYPE = eINSTANCE.getTestSuiteListType();

		/**
		 * The meta object literal for the '<em><b>Test Suite Path</b></em>' attribute list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TEST_SUITE_LIST_TYPE__TEST_SUITE_PATH = eINSTANCE.getTestSuiteListType_TestSuitePath();

		/**
		 * The meta object literal for the '{@link it.itc.sra.se.test.config.ClassPathType <em>Class Path Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see it.itc.sra.se.test.config.ClassPathType
		 * @see it.itc.sra.se.test.config.impl.ConfigPackageImpl#getClassPathType()
		 * @generated
		 */
		EEnum CLASS_PATH_TYPE = eINSTANCE.getClassPathType();

		/**
		 * The meta object literal for the '{@link it.itc.sra.se.test.config.CodecType <em>Codec Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see it.itc.sra.se.test.config.CodecType
		 * @see it.itc.sra.se.test.config.impl.ConfigPackageImpl#getCodecType()
		 * @generated
		 */
		EEnum CODEC_TYPE = eINSTANCE.getCodecType();

		/**
		 * The meta object literal for the '{@link it.itc.sra.se.test.config.InputGenType <em>Input Gen Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see it.itc.sra.se.test.config.InputGenType
		 * @see it.itc.sra.se.test.config.impl.ConfigPackageImpl#getInputGenType()
		 * @generated
		 */
		EEnum INPUT_GEN_TYPE = eINSTANCE.getInputGenType();

		/**
		 * The meta object literal for the '{@link it.itc.sra.se.test.config.PlatformType <em>Platform Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see it.itc.sra.se.test.config.PlatformType
		 * @see it.itc.sra.se.test.config.impl.ConfigPackageImpl#getPlatformType()
		 * @generated
		 */
		EEnum PLATFORM_TYPE = eINSTANCE.getPlatformType();

		/**
		 * The meta object literal for the '{@link it.itc.sra.se.test.config.PreferedStrategyType <em>Prefered Strategy Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see it.itc.sra.se.test.config.PreferedStrategyType
		 * @see it.itc.sra.se.test.config.impl.ConfigPackageImpl#getPreferedStrategyType()
		 * @generated
		 */
		EEnum PREFERED_STRATEGY_TYPE = eINSTANCE.getPreferedStrategyType();

		/**
		 * The meta object literal for the '<em>Class Path Type Object</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see it.itc.sra.se.test.config.ClassPathType
		 * @see it.itc.sra.se.test.config.impl.ConfigPackageImpl#getClassPathTypeObject()
		 * @generated
		 */
		EDataType CLASS_PATH_TYPE_OBJECT = eINSTANCE.getClassPathTypeObject();

		/**
		 * The meta object literal for the '<em>Codec Type Object</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see it.itc.sra.se.test.config.CodecType
		 * @see it.itc.sra.se.test.config.impl.ConfigPackageImpl#getCodecTypeObject()
		 * @generated
		 */
		EDataType CODEC_TYPE_OBJECT = eINSTANCE.getCodecTypeObject();

		/**
		 * The meta object literal for the '<em>Input Gen Type Object</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see it.itc.sra.se.test.config.InputGenType
		 * @see it.itc.sra.se.test.config.impl.ConfigPackageImpl#getInputGenTypeObject()
		 * @generated
		 */
		EDataType INPUT_GEN_TYPE_OBJECT = eINSTANCE.getInputGenTypeObject();

		/**
		 * The meta object literal for the '<em>Platform Type Object</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see it.itc.sra.se.test.config.PlatformType
		 * @see it.itc.sra.se.test.config.impl.ConfigPackageImpl#getPlatformTypeObject()
		 * @generated
		 */
		EDataType PLATFORM_TYPE_OBJECT = eINSTANCE.getPlatformTypeObject();

		/**
		 * The meta object literal for the '<em>Prefered Strategy Type Object</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see it.itc.sra.se.test.config.PreferedStrategyType
		 * @see it.itc.sra.se.test.config.impl.ConfigPackageImpl#getPreferedStrategyTypeObject()
		 * @generated
		 */
		EDataType PREFERED_STRATEGY_TYPE_OBJECT = eINSTANCE.getPreferedStrategyTypeObject();

	}

} //ConfigPackage
