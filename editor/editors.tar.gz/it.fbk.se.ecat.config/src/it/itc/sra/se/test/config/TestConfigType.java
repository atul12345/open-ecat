/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package it.itc.sra.se.test.config;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Test Config Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link it.itc.sra.se.test.config.TestConfigType#getPlatform <em>Platform</em>}</li>
 *   <li>{@link it.itc.sra.se.test.config.TestConfigType#getPreferedStrategy <em>Prefered Strategy</em>}</li>
 *   <li>{@link it.itc.sra.se.test.config.TestConfigType#getTestSuiteList <em>Test Suite List</em>}</li>
 *   <li>{@link it.itc.sra.se.test.config.TestConfigType#getProtocolPath <em>Protocol Path</em>}</li>
 *   <li>{@link it.itc.sra.se.test.config.TestConfigType#getDomainDataPath <em>Domain Data Path</em>}</li>
 *   <li>{@link it.itc.sra.se.test.config.TestConfigType#getMaxRandomTC <em>Max Random TC</em>}</li>
 *   <li>{@link it.itc.sra.se.test.config.TestConfigType#getNumberCycle <em>Number Cycle</em>}</li>
 *   <li>{@link it.itc.sra.se.test.config.TestConfigType#getAgentUnderTest <em>Agent Under Test</em>}</li>
 *   <li>{@link it.itc.sra.se.test.config.TestConfigType#getMaxMutationGen <em>Max Mutation Gen</em>}</li>
 *   <li>{@link it.itc.sra.se.test.config.TestConfigType#getMaxMutationPsize <em>Max Mutation Psize</em>}</li>
 *   <li>{@link it.itc.sra.se.test.config.TestConfigType#getMutationProb <em>Mutation Prob</em>}</li>
 *   <li>{@link it.itc.sra.se.test.config.TestConfigType#getOntologySetting <em>Ontology Setting</em>}</li>
 *   <li>{@link it.itc.sra.se.test.config.TestConfigType#getDitributedNodeConfig <em>Ditributed Node Config</em>}</li>
 * </ul>
 * </p>
 *
 * @see it.itc.sra.se.test.config.ConfigPackage#getTestConfigType()
 * @model extendedMetaData="name='TestConfig_._type' kind='elementOnly'"
 * @generated
 */
public interface TestConfigType extends EObject {
	/**
	 * Returns the value of the '<em><b>Platform</b></em>' attribute.
	 * The default value is <code>"JADE"</code>.
	 * The literals are from the enumeration {@link it.itc.sra.se.test.config.PlatformType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Platform</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Platform</em>' attribute.
	 * @see it.itc.sra.se.test.config.PlatformType
	 * @see #isSetPlatform()
	 * @see #unsetPlatform()
	 * @see #setPlatform(PlatformType)
	 * @see it.itc.sra.se.test.config.ConfigPackage#getTestConfigType_Platform()
	 * @model default="JADE" unsettable="true" required="true"
	 *        extendedMetaData="kind='element' name='Platform' namespace='##targetNamespace'"
	 * @generated
	 */
	PlatformType getPlatform();

	/**
	 * Sets the value of the '{@link it.itc.sra.se.test.config.TestConfigType#getPlatform <em>Platform</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Platform</em>' attribute.
	 * @see it.itc.sra.se.test.config.PlatformType
	 * @see #isSetPlatform()
	 * @see #unsetPlatform()
	 * @see #getPlatform()
	 * @generated
	 */
	void setPlatform(PlatformType value);

	/**
	 * Unsets the value of the '{@link it.itc.sra.se.test.config.TestConfigType#getPlatform <em>Platform</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetPlatform()
	 * @see #getPlatform()
	 * @see #setPlatform(PlatformType)
	 * @generated
	 */
	void unsetPlatform();

	/**
	 * Returns whether the value of the '{@link it.itc.sra.se.test.config.TestConfigType#getPlatform <em>Platform</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Platform</em>' attribute is set.
	 * @see #unsetPlatform()
	 * @see #getPlatform()
	 * @see #setPlatform(PlatformType)
	 * @generated
	 */
	boolean isSetPlatform();

	/**
	 * Returns the value of the '<em><b>Prefered Strategy</b></em>' attribute.
	 * The default value is <code>"Manual"</code>.
	 * The literals are from the enumeration {@link it.itc.sra.se.test.config.PreferedStrategyType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Prefered Strategy</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Prefered Strategy</em>' attribute.
	 * @see it.itc.sra.se.test.config.PreferedStrategyType
	 * @see #isSetPreferedStrategy()
	 * @see #unsetPreferedStrategy()
	 * @see #setPreferedStrategy(PreferedStrategyType)
	 * @see it.itc.sra.se.test.config.ConfigPackage#getTestConfigType_PreferedStrategy()
	 * @model default="Manual" unsettable="true" required="true"
	 *        extendedMetaData="kind='element' name='PreferedStrategy' namespace='##targetNamespace'"
	 * @generated
	 */
	PreferedStrategyType getPreferedStrategy();

	/**
	 * Sets the value of the '{@link it.itc.sra.se.test.config.TestConfigType#getPreferedStrategy <em>Prefered Strategy</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Prefered Strategy</em>' attribute.
	 * @see it.itc.sra.se.test.config.PreferedStrategyType
	 * @see #isSetPreferedStrategy()
	 * @see #unsetPreferedStrategy()
	 * @see #getPreferedStrategy()
	 * @generated
	 */
	void setPreferedStrategy(PreferedStrategyType value);

	/**
	 * Unsets the value of the '{@link it.itc.sra.se.test.config.TestConfigType#getPreferedStrategy <em>Prefered Strategy</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetPreferedStrategy()
	 * @see #getPreferedStrategy()
	 * @see #setPreferedStrategy(PreferedStrategyType)
	 * @generated
	 */
	void unsetPreferedStrategy();

	/**
	 * Returns whether the value of the '{@link it.itc.sra.se.test.config.TestConfigType#getPreferedStrategy <em>Prefered Strategy</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Prefered Strategy</em>' attribute is set.
	 * @see #unsetPreferedStrategy()
	 * @see #getPreferedStrategy()
	 * @see #setPreferedStrategy(PreferedStrategyType)
	 * @generated
	 */
	boolean isSetPreferedStrategy();

	/**
	 * Returns the value of the '<em><b>Test Suite List</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Test Suite List</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Test Suite List</em>' containment reference.
	 * @see #setTestSuiteList(TestSuiteListType)
	 * @see it.itc.sra.se.test.config.ConfigPackage#getTestConfigType_TestSuiteList()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='TestSuiteList' namespace='##targetNamespace'"
	 * @generated
	 */
	TestSuiteListType getTestSuiteList();

	/**
	 * Sets the value of the '{@link it.itc.sra.se.test.config.TestConfigType#getTestSuiteList <em>Test Suite List</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Test Suite List</em>' containment reference.
	 * @see #getTestSuiteList()
	 * @generated
	 */
	void setTestSuiteList(TestSuiteListType value);

	/**
	 * Returns the value of the '<em><b>Protocol Path</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Protocol Path</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Protocol Path</em>' attribute.
	 * @see #setProtocolPath(String)
	 * @see it.itc.sra.se.test.config.ConfigPackage#getTestConfigType_ProtocolPath()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.String"
	 *        extendedMetaData="kind='element' name='ProtocolPath' namespace='##targetNamespace'"
	 * @generated
	 */
	String getProtocolPath();

	/**
	 * Sets the value of the '{@link it.itc.sra.se.test.config.TestConfigType#getProtocolPath <em>Protocol Path</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Protocol Path</em>' attribute.
	 * @see #getProtocolPath()
	 * @generated
	 */
	void setProtocolPath(String value);

	/**
	 * Returns the value of the '<em><b>Domain Data Path</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Domain Data Path</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Domain Data Path</em>' attribute.
	 * @see #setDomainDataPath(String)
	 * @see it.itc.sra.se.test.config.ConfigPackage#getTestConfigType_DomainDataPath()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.String"
	 *        extendedMetaData="kind='element' name='DomainDataPath' namespace='##targetNamespace'"
	 * @generated
	 */
	String getDomainDataPath();

	/**
	 * Sets the value of the '{@link it.itc.sra.se.test.config.TestConfigType#getDomainDataPath <em>Domain Data Path</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Domain Data Path</em>' attribute.
	 * @see #getDomainDataPath()
	 * @generated
	 */
	void setDomainDataPath(String value);

	/**
	 * Returns the value of the '<em><b>Max Random TC</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Max Random TC</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Max Random TC</em>' attribute.
	 * @see #isSetMaxRandomTC()
	 * @see #unsetMaxRandomTC()
	 * @see #setMaxRandomTC(int)
	 * @see it.itc.sra.se.test.config.ConfigPackage#getTestConfigType_MaxRandomTC()
	 * @model unsettable="true" dataType="org.eclipse.emf.ecore.xml.type.Int"
	 *        extendedMetaData="kind='element' name='MaxRandomTC' namespace='##targetNamespace'"
	 * @generated
	 */
	int getMaxRandomTC();

	/**
	 * Sets the value of the '{@link it.itc.sra.se.test.config.TestConfigType#getMaxRandomTC <em>Max Random TC</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Max Random TC</em>' attribute.
	 * @see #isSetMaxRandomTC()
	 * @see #unsetMaxRandomTC()
	 * @see #getMaxRandomTC()
	 * @generated
	 */
	void setMaxRandomTC(int value);

	/**
	 * Unsets the value of the '{@link it.itc.sra.se.test.config.TestConfigType#getMaxRandomTC <em>Max Random TC</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetMaxRandomTC()
	 * @see #getMaxRandomTC()
	 * @see #setMaxRandomTC(int)
	 * @generated
	 */
	void unsetMaxRandomTC();

	/**
	 * Returns whether the value of the '{@link it.itc.sra.se.test.config.TestConfigType#getMaxRandomTC <em>Max Random TC</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Max Random TC</em>' attribute is set.
	 * @see #unsetMaxRandomTC()
	 * @see #getMaxRandomTC()
	 * @see #setMaxRandomTC(int)
	 * @generated
	 */
	boolean isSetMaxRandomTC();

	/**
	 * Returns the value of the '<em><b>Number Cycle</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Number Cycle</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Number Cycle</em>' attribute.
	 * @see #isSetNumberCycle()
	 * @see #unsetNumberCycle()
	 * @see #setNumberCycle(int)
	 * @see it.itc.sra.se.test.config.ConfigPackage#getTestConfigType_NumberCycle()
	 * @model unsettable="true" dataType="org.eclipse.emf.ecore.xml.type.Int"
	 *        extendedMetaData="kind='element' name='NumberCycle' namespace='##targetNamespace'"
	 * @generated
	 */
	int getNumberCycle();

	/**
	 * Sets the value of the '{@link it.itc.sra.se.test.config.TestConfigType#getNumberCycle <em>Number Cycle</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Number Cycle</em>' attribute.
	 * @see #isSetNumberCycle()
	 * @see #unsetNumberCycle()
	 * @see #getNumberCycle()
	 * @generated
	 */
	void setNumberCycle(int value);

	/**
	 * Unsets the value of the '{@link it.itc.sra.se.test.config.TestConfigType#getNumberCycle <em>Number Cycle</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetNumberCycle()
	 * @see #getNumberCycle()
	 * @see #setNumberCycle(int)
	 * @generated
	 */
	void unsetNumberCycle();

	/**
	 * Returns whether the value of the '{@link it.itc.sra.se.test.config.TestConfigType#getNumberCycle <em>Number Cycle</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Number Cycle</em>' attribute is set.
	 * @see #unsetNumberCycle()
	 * @see #getNumberCycle()
	 * @see #setNumberCycle(int)
	 * @generated
	 */
	boolean isSetNumberCycle();

	/**
	 * Returns the value of the '<em><b>Agent Under Test</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Agent Under Test</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Agent Under Test</em>' attribute.
	 * @see #setAgentUnderTest(String)
	 * @see it.itc.sra.se.test.config.ConfigPackage#getTestConfigType_AgentUnderTest()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.String"
	 *        extendedMetaData="kind='element' name='AgentUnderTest' namespace='##targetNamespace'"
	 * @generated
	 */
	String getAgentUnderTest();

	/**
	 * Sets the value of the '{@link it.itc.sra.se.test.config.TestConfigType#getAgentUnderTest <em>Agent Under Test</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Agent Under Test</em>' attribute.
	 * @see #getAgentUnderTest()
	 * @generated
	 */
	void setAgentUnderTest(String value);

	/**
	 * Returns the value of the '<em><b>Max Mutation Gen</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Max Mutation Gen</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Max Mutation Gen</em>' attribute.
	 * @see #isSetMaxMutationGen()
	 * @see #unsetMaxMutationGen()
	 * @see #setMaxMutationGen(int)
	 * @see it.itc.sra.se.test.config.ConfigPackage#getTestConfigType_MaxMutationGen()
	 * @model unsettable="true" dataType="org.eclipse.emf.ecore.xml.type.Int"
	 *        extendedMetaData="kind='element' name='MaxMutationGen' namespace='##targetNamespace'"
	 * @generated
	 */
	int getMaxMutationGen();

	/**
	 * Sets the value of the '{@link it.itc.sra.se.test.config.TestConfigType#getMaxMutationGen <em>Max Mutation Gen</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Max Mutation Gen</em>' attribute.
	 * @see #isSetMaxMutationGen()
	 * @see #unsetMaxMutationGen()
	 * @see #getMaxMutationGen()
	 * @generated
	 */
	void setMaxMutationGen(int value);

	/**
	 * Unsets the value of the '{@link it.itc.sra.se.test.config.TestConfigType#getMaxMutationGen <em>Max Mutation Gen</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetMaxMutationGen()
	 * @see #getMaxMutationGen()
	 * @see #setMaxMutationGen(int)
	 * @generated
	 */
	void unsetMaxMutationGen();

	/**
	 * Returns whether the value of the '{@link it.itc.sra.se.test.config.TestConfigType#getMaxMutationGen <em>Max Mutation Gen</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Max Mutation Gen</em>' attribute is set.
	 * @see #unsetMaxMutationGen()
	 * @see #getMaxMutationGen()
	 * @see #setMaxMutationGen(int)
	 * @generated
	 */
	boolean isSetMaxMutationGen();

	/**
	 * Returns the value of the '<em><b>Max Mutation Psize</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Max Mutation Psize</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Max Mutation Psize</em>' attribute.
	 * @see #isSetMaxMutationPsize()
	 * @see #unsetMaxMutationPsize()
	 * @see #setMaxMutationPsize(int)
	 * @see it.itc.sra.se.test.config.ConfigPackage#getTestConfigType_MaxMutationPsize()
	 * @model unsettable="true" dataType="org.eclipse.emf.ecore.xml.type.Int"
	 *        extendedMetaData="kind='element' name='MaxMutationPsize' namespace='##targetNamespace'"
	 * @generated
	 */
	int getMaxMutationPsize();

	/**
	 * Sets the value of the '{@link it.itc.sra.se.test.config.TestConfigType#getMaxMutationPsize <em>Max Mutation Psize</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Max Mutation Psize</em>' attribute.
	 * @see #isSetMaxMutationPsize()
	 * @see #unsetMaxMutationPsize()
	 * @see #getMaxMutationPsize()
	 * @generated
	 */
	void setMaxMutationPsize(int value);

	/**
	 * Unsets the value of the '{@link it.itc.sra.se.test.config.TestConfigType#getMaxMutationPsize <em>Max Mutation Psize</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetMaxMutationPsize()
	 * @see #getMaxMutationPsize()
	 * @see #setMaxMutationPsize(int)
	 * @generated
	 */
	void unsetMaxMutationPsize();

	/**
	 * Returns whether the value of the '{@link it.itc.sra.se.test.config.TestConfigType#getMaxMutationPsize <em>Max Mutation Psize</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Max Mutation Psize</em>' attribute is set.
	 * @see #unsetMaxMutationPsize()
	 * @see #getMaxMutationPsize()
	 * @see #setMaxMutationPsize(int)
	 * @generated
	 */
	boolean isSetMaxMutationPsize();

	/**
	 * Returns the value of the '<em><b>Mutation Prob</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Mutation Prob</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Mutation Prob</em>' attribute.
	 * @see #isSetMutationProb()
	 * @see #unsetMutationProb()
	 * @see #setMutationProb(double)
	 * @see it.itc.sra.se.test.config.ConfigPackage#getTestConfigType_MutationProb()
	 * @model unsettable="true" dataType="org.eclipse.emf.ecore.xml.type.Double"
	 *        extendedMetaData="kind='element' name='MutationProb' namespace='##targetNamespace'"
	 * @generated
	 */
	double getMutationProb();

	/**
	 * Sets the value of the '{@link it.itc.sra.se.test.config.TestConfigType#getMutationProb <em>Mutation Prob</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Mutation Prob</em>' attribute.
	 * @see #isSetMutationProb()
	 * @see #unsetMutationProb()
	 * @see #getMutationProb()
	 * @generated
	 */
	void setMutationProb(double value);

	/**
	 * Unsets the value of the '{@link it.itc.sra.se.test.config.TestConfigType#getMutationProb <em>Mutation Prob</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetMutationProb()
	 * @see #getMutationProb()
	 * @see #setMutationProb(double)
	 * @generated
	 */
	void unsetMutationProb();

	/**
	 * Returns whether the value of the '{@link it.itc.sra.se.test.config.TestConfigType#getMutationProb <em>Mutation Prob</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Mutation Prob</em>' attribute is set.
	 * @see #unsetMutationProb()
	 * @see #getMutationProb()
	 * @see #setMutationProb(double)
	 * @generated
	 */
	boolean isSetMutationProb();

	/**
	 * Returns the value of the '<em><b>Ontology Setting</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Ontology Setting</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ontology Setting</em>' containment reference.
	 * @see #setOntologySetting(OntologyType)
	 * @see it.itc.sra.se.test.config.ConfigPackage#getTestConfigType_OntologySetting()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='OntologySetting' namespace='##targetNamespace'"
	 * @generated
	 */
	OntologyType getOntologySetting();

	/**
	 * Sets the value of the '{@link it.itc.sra.se.test.config.TestConfigType#getOntologySetting <em>Ontology Setting</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Ontology Setting</em>' containment reference.
	 * @see #getOntologySetting()
	 * @generated
	 */
	void setOntologySetting(OntologyType value);

	/**
	 * Returns the value of the '<em><b>Ditributed Node Config</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Ditributed Node Config</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ditributed Node Config</em>' containment reference.
	 * @see #setDitributedNodeConfig(DitributedNodeConfigType)
	 * @see it.itc.sra.se.test.config.ConfigPackage#getTestConfigType_DitributedNodeConfig()
	 * @model containment="true" required="true"
	 *        extendedMetaData="kind='element' name='DitributedNodeConfig' namespace='##targetNamespace'"
	 * @generated
	 */
	DitributedNodeConfigType getDitributedNodeConfig();

	/**
	 * Sets the value of the '{@link it.itc.sra.se.test.config.TestConfigType#getDitributedNodeConfig <em>Ditributed Node Config</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Ditributed Node Config</em>' containment reference.
	 * @see #getDitributedNodeConfig()
	 * @generated
	 */
	void setDitributedNodeConfig(DitributedNodeConfigType value);

} // TestConfigType
