/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package it.itc.sra.se.test.config;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Classpathentry Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link it.itc.sra.se.test.config.ClasspathentryType#getKind <em>Kind</em>}</li>
 *   <li>{@link it.itc.sra.se.test.config.ClasspathentryType#getPath <em>Path</em>}</li>
 * </ul>
 * </p>
 *
 * @see it.itc.sra.se.test.config.ConfigPackage#getClasspathentryType()
 * @model extendedMetaData="name='classpathentry_._type' kind='empty'"
 * @generated
 */
public interface ClasspathentryType extends EObject {
	/**
	 * Returns the value of the '<em><b>Kind</b></em>' attribute.
	 * The default value is <code>"JAR"</code>.
	 * The literals are from the enumeration {@link it.itc.sra.se.test.config.ClassPathType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Kind</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Kind</em>' attribute.
	 * @see it.itc.sra.se.test.config.ClassPathType
	 * @see #isSetKind()
	 * @see #unsetKind()
	 * @see #setKind(ClassPathType)
	 * @see it.itc.sra.se.test.config.ConfigPackage#getClasspathentryType_Kind()
	 * @model default="JAR" unsettable="true"
	 *        extendedMetaData="kind='attribute' name='kind'"
	 * @generated
	 */
	ClassPathType getKind();

	/**
	 * Sets the value of the '{@link it.itc.sra.se.test.config.ClasspathentryType#getKind <em>Kind</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Kind</em>' attribute.
	 * @see it.itc.sra.se.test.config.ClassPathType
	 * @see #isSetKind()
	 * @see #unsetKind()
	 * @see #getKind()
	 * @generated
	 */
	void setKind(ClassPathType value);

	/**
	 * Unsets the value of the '{@link it.itc.sra.se.test.config.ClasspathentryType#getKind <em>Kind</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetKind()
	 * @see #getKind()
	 * @see #setKind(ClassPathType)
	 * @generated
	 */
	void unsetKind();

	/**
	 * Returns whether the value of the '{@link it.itc.sra.se.test.config.ClasspathentryType#getKind <em>Kind</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Kind</em>' attribute is set.
	 * @see #unsetKind()
	 * @see #getKind()
	 * @see #setKind(ClassPathType)
	 * @generated
	 */
	boolean isSetKind();

	/**
	 * Returns the value of the '<em><b>Path</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Path</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Path</em>' attribute.
	 * @see #setPath(String)
	 * @see it.itc.sra.se.test.config.ConfigPackage#getClasspathentryType_Path()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.String"
	 *        extendedMetaData="kind='attribute' name='path'"
	 * @generated
	 */
	String getPath();

	/**
	 * Sets the value of the '{@link it.itc.sra.se.test.config.ClasspathentryType#getPath <em>Path</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Path</em>' attribute.
	 * @see #getPath()
	 * @generated
	 */
	void setPath(String value);

} // ClasspathentryType
