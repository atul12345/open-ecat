/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package it.itc.sra.se.test.config.impl;

import it.itc.sra.se.test.config.CodecType;
import it.itc.sra.se.test.config.ConfigPackage;
import it.itc.sra.se.test.config.InputGenType;
import it.itc.sra.se.test.config.JavaPathType;
import it.itc.sra.se.test.config.OntologyType;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Ontology Type</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link it.itc.sra.se.test.config.impl.OntologyTypeImpl#getProtegeOntologyPath <em>Protege Ontology Path</em>}</li>
 *   <li>{@link it.itc.sra.se.test.config.impl.OntologyTypeImpl#getOntologyName <em>Ontology Name</em>}</li>
 *   <li>{@link it.itc.sra.se.test.config.impl.OntologyTypeImpl#getLanguage <em>Language</em>}</li>
 *   <li>{@link it.itc.sra.se.test.config.impl.OntologyTypeImpl#getOntologyPackage <em>Ontology Package</em>}</li>
 *   <li>{@link it.itc.sra.se.test.config.impl.OntologyTypeImpl#getCodec <em>Codec</em>}</li>
 *   <li>{@link it.itc.sra.se.test.config.impl.OntologyTypeImpl#getInputType <em>Input Type</em>}</li>
 *   <li>{@link it.itc.sra.se.test.config.impl.OntologyTypeImpl#getClasspath <em>Classpath</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class OntologyTypeImpl extends EObjectImpl implements OntologyType {
	/**
	 * The default value of the '{@link #getProtegeOntologyPath() <em>Protege Ontology Path</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProtegeOntologyPath()
	 * @generated
	 * @ordered
	 */
	protected static final String PROTEGE_ONTOLOGY_PATH_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getProtegeOntologyPath() <em>Protege Ontology Path</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProtegeOntologyPath()
	 * @generated
	 * @ordered
	 */
	protected String protegeOntologyPath = PROTEGE_ONTOLOGY_PATH_EDEFAULT;

	/**
	 * The default value of the '{@link #getOntologyName() <em>Ontology Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOntologyName()
	 * @generated
	 * @ordered
	 */
	protected static final String ONTOLOGY_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getOntologyName() <em>Ontology Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOntologyName()
	 * @generated
	 * @ordered
	 */
	protected String ontologyName = ONTOLOGY_NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getLanguage() <em>Language</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLanguage()
	 * @generated
	 * @ordered
	 */
	protected static final String LANGUAGE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getLanguage() <em>Language</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLanguage()
	 * @generated
	 * @ordered
	 */
	protected String language = LANGUAGE_EDEFAULT;

	/**
	 * The default value of the '{@link #getOntologyPackage() <em>Ontology Package</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOntologyPackage()
	 * @generated
	 * @ordered
	 */
	protected static final String ONTOLOGY_PACKAGE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getOntologyPackage() <em>Ontology Package</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOntologyPackage()
	 * @generated
	 * @ordered
	 */
	protected String ontologyPackage = ONTOLOGY_PACKAGE_EDEFAULT;

	/**
	 * The default value of the '{@link #getCodec() <em>Codec</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCodec()
	 * @generated
	 * @ordered
	 */
	protected static final CodecType CODEC_EDEFAULT = CodecType.JAVA_XML_CONTENT_CODEC;

	/**
	 * The cached value of the '{@link #getCodec() <em>Codec</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCodec()
	 * @generated
	 * @ordered
	 */
	protected CodecType codec = CODEC_EDEFAULT;

	/**
	 * This is true if the Codec attribute has been set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	protected boolean codecESet;

	/**
	 * The default value of the '{@link #getInputType() <em>Input Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInputType()
	 * @generated
	 * @ordered
	 */
	protected static final InputGenType INPUT_TYPE_EDEFAULT = InputGenType.VALID;

	/**
	 * The cached value of the '{@link #getInputType() <em>Input Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInputType()
	 * @generated
	 * @ordered
	 */
	protected InputGenType inputType = INPUT_TYPE_EDEFAULT;

	/**
	 * This is true if the Input Type attribute has been set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	protected boolean inputTypeESet;

	/**
	 * The cached value of the '{@link #getClasspath() <em>Classpath</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getClasspath()
	 * @generated
	 * @ordered
	 */
	protected JavaPathType classpath;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected OntologyTypeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ConfigPackage.Literals.ONTOLOGY_TYPE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getProtegeOntologyPath() {
		return protegeOntologyPath;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setProtegeOntologyPath(String newProtegeOntologyPath) {
		String oldProtegeOntologyPath = protegeOntologyPath;
		protegeOntologyPath = newProtegeOntologyPath;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ConfigPackage.ONTOLOGY_TYPE__PROTEGE_ONTOLOGY_PATH, oldProtegeOntologyPath, protegeOntologyPath));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getOntologyName() {
		return ontologyName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setOntologyName(String newOntologyName) {
		String oldOntologyName = ontologyName;
		ontologyName = newOntologyName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ConfigPackage.ONTOLOGY_TYPE__ONTOLOGY_NAME, oldOntologyName, ontologyName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLanguage() {
		return language;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setLanguage(String newLanguage) {
		String oldLanguage = language;
		language = newLanguage;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ConfigPackage.ONTOLOGY_TYPE__LANGUAGE, oldLanguage, language));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getOntologyPackage() {
		return ontologyPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setOntologyPackage(String newOntologyPackage) {
		String oldOntologyPackage = ontologyPackage;
		ontologyPackage = newOntologyPackage;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ConfigPackage.ONTOLOGY_TYPE__ONTOLOGY_PACKAGE, oldOntologyPackage, ontologyPackage));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CodecType getCodec() {
		return codec;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCodec(CodecType newCodec) {
		CodecType oldCodec = codec;
		codec = newCodec == null ? CODEC_EDEFAULT : newCodec;
		boolean oldCodecESet = codecESet;
		codecESet = true;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ConfigPackage.ONTOLOGY_TYPE__CODEC, oldCodec, codec, !oldCodecESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetCodec() {
		CodecType oldCodec = codec;
		boolean oldCodecESet = codecESet;
		codec = CODEC_EDEFAULT;
		codecESet = false;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.UNSET, ConfigPackage.ONTOLOGY_TYPE__CODEC, oldCodec, CODEC_EDEFAULT, oldCodecESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetCodec() {
		return codecESet;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public InputGenType getInputType() {
		return inputType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setInputType(InputGenType newInputType) {
		InputGenType oldInputType = inputType;
		inputType = newInputType == null ? INPUT_TYPE_EDEFAULT : newInputType;
		boolean oldInputTypeESet = inputTypeESet;
		inputTypeESet = true;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ConfigPackage.ONTOLOGY_TYPE__INPUT_TYPE, oldInputType, inputType, !oldInputTypeESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetInputType() {
		InputGenType oldInputType = inputType;
		boolean oldInputTypeESet = inputTypeESet;
		inputType = INPUT_TYPE_EDEFAULT;
		inputTypeESet = false;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.UNSET, ConfigPackage.ONTOLOGY_TYPE__INPUT_TYPE, oldInputType, INPUT_TYPE_EDEFAULT, oldInputTypeESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetInputType() {
		return inputTypeESet;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public JavaPathType getClasspath() {
		return classpath;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetClasspath(JavaPathType newClasspath, NotificationChain msgs) {
		JavaPathType oldClasspath = classpath;
		classpath = newClasspath;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ConfigPackage.ONTOLOGY_TYPE__CLASSPATH, oldClasspath, newClasspath);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setClasspath(JavaPathType newClasspath) {
		if (newClasspath != classpath) {
			NotificationChain msgs = null;
			if (classpath != null)
				msgs = ((InternalEObject)classpath).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - ConfigPackage.ONTOLOGY_TYPE__CLASSPATH, null, msgs);
			if (newClasspath != null)
				msgs = ((InternalEObject)newClasspath).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - ConfigPackage.ONTOLOGY_TYPE__CLASSPATH, null, msgs);
			msgs = basicSetClasspath(newClasspath, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ConfigPackage.ONTOLOGY_TYPE__CLASSPATH, newClasspath, newClasspath));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case ConfigPackage.ONTOLOGY_TYPE__CLASSPATH:
				return basicSetClasspath(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case ConfigPackage.ONTOLOGY_TYPE__PROTEGE_ONTOLOGY_PATH:
				return getProtegeOntologyPath();
			case ConfigPackage.ONTOLOGY_TYPE__ONTOLOGY_NAME:
				return getOntologyName();
			case ConfigPackage.ONTOLOGY_TYPE__LANGUAGE:
				return getLanguage();
			case ConfigPackage.ONTOLOGY_TYPE__ONTOLOGY_PACKAGE:
				return getOntologyPackage();
			case ConfigPackage.ONTOLOGY_TYPE__CODEC:
				return getCodec();
			case ConfigPackage.ONTOLOGY_TYPE__INPUT_TYPE:
				return getInputType();
			case ConfigPackage.ONTOLOGY_TYPE__CLASSPATH:
				return getClasspath();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case ConfigPackage.ONTOLOGY_TYPE__PROTEGE_ONTOLOGY_PATH:
				setProtegeOntologyPath((String)newValue);
				return;
			case ConfigPackage.ONTOLOGY_TYPE__ONTOLOGY_NAME:
				setOntologyName((String)newValue);
				return;
			case ConfigPackage.ONTOLOGY_TYPE__LANGUAGE:
				setLanguage((String)newValue);
				return;
			case ConfigPackage.ONTOLOGY_TYPE__ONTOLOGY_PACKAGE:
				setOntologyPackage((String)newValue);
				return;
			case ConfigPackage.ONTOLOGY_TYPE__CODEC:
				setCodec((CodecType)newValue);
				return;
			case ConfigPackage.ONTOLOGY_TYPE__INPUT_TYPE:
				setInputType((InputGenType)newValue);
				return;
			case ConfigPackage.ONTOLOGY_TYPE__CLASSPATH:
				setClasspath((JavaPathType)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case ConfigPackage.ONTOLOGY_TYPE__PROTEGE_ONTOLOGY_PATH:
				setProtegeOntologyPath(PROTEGE_ONTOLOGY_PATH_EDEFAULT);
				return;
			case ConfigPackage.ONTOLOGY_TYPE__ONTOLOGY_NAME:
				setOntologyName(ONTOLOGY_NAME_EDEFAULT);
				return;
			case ConfigPackage.ONTOLOGY_TYPE__LANGUAGE:
				setLanguage(LANGUAGE_EDEFAULT);
				return;
			case ConfigPackage.ONTOLOGY_TYPE__ONTOLOGY_PACKAGE:
				setOntologyPackage(ONTOLOGY_PACKAGE_EDEFAULT);
				return;
			case ConfigPackage.ONTOLOGY_TYPE__CODEC:
				unsetCodec();
				return;
			case ConfigPackage.ONTOLOGY_TYPE__INPUT_TYPE:
				unsetInputType();
				return;
			case ConfigPackage.ONTOLOGY_TYPE__CLASSPATH:
				setClasspath((JavaPathType)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case ConfigPackage.ONTOLOGY_TYPE__PROTEGE_ONTOLOGY_PATH:
				return PROTEGE_ONTOLOGY_PATH_EDEFAULT == null ? protegeOntologyPath != null : !PROTEGE_ONTOLOGY_PATH_EDEFAULT.equals(protegeOntologyPath);
			case ConfigPackage.ONTOLOGY_TYPE__ONTOLOGY_NAME:
				return ONTOLOGY_NAME_EDEFAULT == null ? ontologyName != null : !ONTOLOGY_NAME_EDEFAULT.equals(ontologyName);
			case ConfigPackage.ONTOLOGY_TYPE__LANGUAGE:
				return LANGUAGE_EDEFAULT == null ? language != null : !LANGUAGE_EDEFAULT.equals(language);
			case ConfigPackage.ONTOLOGY_TYPE__ONTOLOGY_PACKAGE:
				return ONTOLOGY_PACKAGE_EDEFAULT == null ? ontologyPackage != null : !ONTOLOGY_PACKAGE_EDEFAULT.equals(ontologyPackage);
			case ConfigPackage.ONTOLOGY_TYPE__CODEC:
				return isSetCodec();
			case ConfigPackage.ONTOLOGY_TYPE__INPUT_TYPE:
				return isSetInputType();
			case ConfigPackage.ONTOLOGY_TYPE__CLASSPATH:
				return classpath != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (protegeOntologyPath: ");
		result.append(protegeOntologyPath);
		result.append(", ontologyName: ");
		result.append(ontologyName);
		result.append(", language: ");
		result.append(language);
		result.append(", ontologyPackage: ");
		result.append(ontologyPackage);
		result.append(", codec: ");
		if (codecESet) result.append(codec); else result.append("<unset>");
		result.append(", inputType: ");
		if (inputTypeESet) result.append(inputType); else result.append("<unset>");
		result.append(')');
		return result.toString();
	}

} //OntologyTypeImpl
