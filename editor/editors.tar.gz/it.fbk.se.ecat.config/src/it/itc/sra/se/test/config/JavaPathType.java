/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package it.itc.sra.se.test.config;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Java Path Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link it.itc.sra.se.test.config.JavaPathType#getClasspathentry <em>Classpathentry</em>}</li>
 * </ul>
 * </p>
 *
 * @see it.itc.sra.se.test.config.ConfigPackage#getJavaPathType()
 * @model extendedMetaData="name='JavaPathType' kind='elementOnly'"
 * @generated
 */
public interface JavaPathType extends EObject {
	/**
	 * Returns the value of the '<em><b>Classpathentry</b></em>' containment reference list.
	 * The list contents are of type {@link it.itc.sra.se.test.config.ClasspathentryType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Classpathentry</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Classpathentry</em>' containment reference list.
	 * @see it.itc.sra.se.test.config.ConfigPackage#getJavaPathType_Classpathentry()
	 * @model containment="true" required="true"
	 *        extendedMetaData="kind='element' name='classpathentry' namespace='##targetNamespace'"
	 * @generated
	 */
	EList<ClasspathentryType> getClasspathentry();

} // JavaPathType
