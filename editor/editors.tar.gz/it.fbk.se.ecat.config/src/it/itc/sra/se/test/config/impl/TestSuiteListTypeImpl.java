/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package it.itc.sra.se.test.config.impl;

import it.itc.sra.se.test.config.ConfigPackage;
import it.itc.sra.se.test.config.TestSuiteListType;

import java.util.Collection;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eclipse.emf.ecore.util.EDataTypeEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Test Suite List Type</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link it.itc.sra.se.test.config.impl.TestSuiteListTypeImpl#getTestSuitePath <em>Test Suite Path</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class TestSuiteListTypeImpl extends EObjectImpl implements TestSuiteListType {
	/**
	 * The cached value of the '{@link #getTestSuitePath() <em>Test Suite Path</em>}' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTestSuitePath()
	 * @generated
	 * @ordered
	 */
	protected EList<String> testSuitePath;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TestSuiteListTypeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ConfigPackage.Literals.TEST_SUITE_LIST_TYPE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<String> getTestSuitePath() {
		if (testSuitePath == null) {
			testSuitePath = new EDataTypeEList<String>(String.class, this, ConfigPackage.TEST_SUITE_LIST_TYPE__TEST_SUITE_PATH);
		}
		return testSuitePath;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case ConfigPackage.TEST_SUITE_LIST_TYPE__TEST_SUITE_PATH:
				return getTestSuitePath();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case ConfigPackage.TEST_SUITE_LIST_TYPE__TEST_SUITE_PATH:
				getTestSuitePath().clear();
				getTestSuitePath().addAll((Collection<? extends String>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case ConfigPackage.TEST_SUITE_LIST_TYPE__TEST_SUITE_PATH:
				getTestSuitePath().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case ConfigPackage.TEST_SUITE_LIST_TYPE__TEST_SUITE_PATH:
				return testSuitePath != null && !testSuitePath.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (testSuitePath: ");
		result.append(testSuitePath);
		result.append(')');
		return result.toString();
	}

} //TestSuiteListTypeImpl
