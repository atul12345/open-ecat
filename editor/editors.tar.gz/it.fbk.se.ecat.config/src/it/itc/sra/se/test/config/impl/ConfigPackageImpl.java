/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package it.itc.sra.se.test.config.impl;

import it.itc.sra.se.test.config.ClassPathType;
import it.itc.sra.se.test.config.ClasspathentryType;
import it.itc.sra.se.test.config.CodecType;
import it.itc.sra.se.test.config.ConfigFactory;
import it.itc.sra.se.test.config.ConfigPackage;
import it.itc.sra.se.test.config.DitributedNodeConfigType;
import it.itc.sra.se.test.config.DocumentRoot;
import it.itc.sra.se.test.config.InputGenType;
import it.itc.sra.se.test.config.JavaPathType;
import it.itc.sra.se.test.config.NodeType;
import it.itc.sra.se.test.config.OntologyType;
import it.itc.sra.se.test.config.PlatformType;
import it.itc.sra.se.test.config.PreferedStrategyType;
import it.itc.sra.se.test.config.TestConfigType;
import it.itc.sra.se.test.config.TestSuiteListType;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

import org.eclipse.emf.ecore.xml.type.XMLTypePackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class ConfigPackageImpl extends EPackageImpl implements ConfigPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass classpathentryTypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass ditributedNodeConfigTypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass documentRootEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass javaPathTypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass nodeTypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass ontologyTypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass testConfigTypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass testSuiteListTypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum classPathTypeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum codecTypeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum inputGenTypeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum platformTypeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum preferedStrategyTypeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType classPathTypeObjectEDataType = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType codecTypeObjectEDataType = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType inputGenTypeObjectEDataType = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType platformTypeObjectEDataType = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType preferedStrategyTypeObjectEDataType = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see it.itc.sra.se.test.config.ConfigPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private ConfigPackageImpl() {
		super(eNS_URI, ConfigFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this
	 * model, and for any others upon which it depends.  Simple
	 * dependencies are satisfied by calling this method on all
	 * dependent packages before doing anything else.  This method drives
	 * initialization for interdependent packages directly, in parallel
	 * with this package, itself.
	 * <p>Of this package and its interdependencies, all packages which
	 * have not yet been registered by their URI values are first created
	 * and registered.  The packages are then initialized in two steps:
	 * meta-model objects for all of the packages are created before any
	 * are initialized, since one package's meta-model objects may refer to
	 * those of another.
	 * <p>Invocation of this method will not affect any packages that have
	 * already been initialized.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static ConfigPackage init() {
		if (isInited) return (ConfigPackage)EPackage.Registry.INSTANCE.getEPackage(ConfigPackage.eNS_URI);

		// Obtain or create and register package
		ConfigPackageImpl theConfigPackage = (ConfigPackageImpl)(EPackage.Registry.INSTANCE.getEPackage(eNS_URI) instanceof ConfigPackageImpl ? EPackage.Registry.INSTANCE.getEPackage(eNS_URI) : new ConfigPackageImpl());

		isInited = true;

		// Initialize simple dependencies
		XMLTypePackage.eINSTANCE.eClass();

		// Create package meta-data objects
		theConfigPackage.createPackageContents();

		// Initialize created meta-data
		theConfigPackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theConfigPackage.freeze();

		return theConfigPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getClasspathentryType() {
		return classpathentryTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getClasspathentryType_Kind() {
		return (EAttribute)classpathentryTypeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getClasspathentryType_Path() {
		return (EAttribute)classpathentryTypeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDitributedNodeConfigType() {
		return ditributedNodeConfigTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDitributedNodeConfigType_Node() {
		return (EReference)ditributedNodeConfigTypeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDocumentRoot() {
		return documentRootEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDocumentRoot_Mixed() {
		return (EAttribute)documentRootEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDocumentRoot_XMLNSPrefixMap() {
		return (EReference)documentRootEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDocumentRoot_XSISchemaLocation() {
		return (EReference)documentRootEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDocumentRoot_TestConfig() {
		return (EReference)documentRootEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getJavaPathType() {
		return javaPathTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getJavaPathType_Classpathentry() {
		return (EReference)javaPathTypeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getNodeType() {
		return nodeTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getNodeType_NodeName() {
		return (EAttribute)nodeTypeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getNodeType_NodeAddress() {
		return (EAttribute)nodeTypeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getNodeType_NodeHap() {
		return (EAttribute)nodeTypeEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getNodeType_RemoteMonitoringAgent() {
		return (EAttribute)nodeTypeEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getNodeType_RecoveryAgent() {
		return (EAttribute)nodeTypeEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getNodeType_RemoteExecutorAgent() {
		return (EAttribute)nodeTypeEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getNodeType_MonitoredAgentList() {
		return (EAttribute)nodeTypeEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getOntologyType() {
		return ontologyTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getOntologyType_ProtegeOntologyPath() {
		return (EAttribute)ontologyTypeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getOntologyType_OntologyName() {
		return (EAttribute)ontologyTypeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getOntologyType_Language() {
		return (EAttribute)ontologyTypeEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getOntologyType_OntologyPackage() {
		return (EAttribute)ontologyTypeEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getOntologyType_Codec() {
		return (EAttribute)ontologyTypeEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getOntologyType_InputType() {
		return (EAttribute)ontologyTypeEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getOntologyType_Classpath() {
		return (EReference)ontologyTypeEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTestConfigType() {
		return testConfigTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTestConfigType_Platform() {
		return (EAttribute)testConfigTypeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTestConfigType_PreferedStrategy() {
		return (EAttribute)testConfigTypeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTestConfigType_TestSuiteList() {
		return (EReference)testConfigTypeEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTestConfigType_ProtocolPath() {
		return (EAttribute)testConfigTypeEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTestConfigType_DomainDataPath() {
		return (EAttribute)testConfigTypeEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTestConfigType_MaxRandomTC() {
		return (EAttribute)testConfigTypeEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTestConfigType_NumberCycle() {
		return (EAttribute)testConfigTypeEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTestConfigType_AgentUnderTest() {
		return (EAttribute)testConfigTypeEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTestConfigType_MaxMutationGen() {
		return (EAttribute)testConfigTypeEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTestConfigType_MaxMutationPsize() {
		return (EAttribute)testConfigTypeEClass.getEStructuralFeatures().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTestConfigType_MutationProb() {
		return (EAttribute)testConfigTypeEClass.getEStructuralFeatures().get(10);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTestConfigType_OntologySetting() {
		return (EReference)testConfigTypeEClass.getEStructuralFeatures().get(11);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTestConfigType_DitributedNodeConfig() {
		return (EReference)testConfigTypeEClass.getEStructuralFeatures().get(12);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTestSuiteListType() {
		return testSuiteListTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTestSuiteListType_TestSuitePath() {
		return (EAttribute)testSuiteListTypeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getClassPathType() {
		return classPathTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getCodecType() {
		return codecTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getInputGenType() {
		return inputGenTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getPlatformType() {
		return platformTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getPreferedStrategyType() {
		return preferedStrategyTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getClassPathTypeObject() {
		return classPathTypeObjectEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getCodecTypeObject() {
		return codecTypeObjectEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getInputGenTypeObject() {
		return inputGenTypeObjectEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getPlatformTypeObject() {
		return platformTypeObjectEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getPreferedStrategyTypeObject() {
		return preferedStrategyTypeObjectEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ConfigFactory getConfigFactory() {
		return (ConfigFactory)getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated) return;
		isCreated = true;

		// Create classes and their features
		classpathentryTypeEClass = createEClass(CLASSPATHENTRY_TYPE);
		createEAttribute(classpathentryTypeEClass, CLASSPATHENTRY_TYPE__KIND);
		createEAttribute(classpathentryTypeEClass, CLASSPATHENTRY_TYPE__PATH);

		ditributedNodeConfigTypeEClass = createEClass(DITRIBUTED_NODE_CONFIG_TYPE);
		createEReference(ditributedNodeConfigTypeEClass, DITRIBUTED_NODE_CONFIG_TYPE__NODE);

		documentRootEClass = createEClass(DOCUMENT_ROOT);
		createEAttribute(documentRootEClass, DOCUMENT_ROOT__MIXED);
		createEReference(documentRootEClass, DOCUMENT_ROOT__XMLNS_PREFIX_MAP);
		createEReference(documentRootEClass, DOCUMENT_ROOT__XSI_SCHEMA_LOCATION);
		createEReference(documentRootEClass, DOCUMENT_ROOT__TEST_CONFIG);

		javaPathTypeEClass = createEClass(JAVA_PATH_TYPE);
		createEReference(javaPathTypeEClass, JAVA_PATH_TYPE__CLASSPATHENTRY);

		nodeTypeEClass = createEClass(NODE_TYPE);
		createEAttribute(nodeTypeEClass, NODE_TYPE__NODE_NAME);
		createEAttribute(nodeTypeEClass, NODE_TYPE__NODE_ADDRESS);
		createEAttribute(nodeTypeEClass, NODE_TYPE__NODE_HAP);
		createEAttribute(nodeTypeEClass, NODE_TYPE__REMOTE_MONITORING_AGENT);
		createEAttribute(nodeTypeEClass, NODE_TYPE__RECOVERY_AGENT);
		createEAttribute(nodeTypeEClass, NODE_TYPE__REMOTE_EXECUTOR_AGENT);
		createEAttribute(nodeTypeEClass, NODE_TYPE__MONITORED_AGENT_LIST);

		ontologyTypeEClass = createEClass(ONTOLOGY_TYPE);
		createEAttribute(ontologyTypeEClass, ONTOLOGY_TYPE__PROTEGE_ONTOLOGY_PATH);
		createEAttribute(ontologyTypeEClass, ONTOLOGY_TYPE__ONTOLOGY_NAME);
		createEAttribute(ontologyTypeEClass, ONTOLOGY_TYPE__LANGUAGE);
		createEAttribute(ontologyTypeEClass, ONTOLOGY_TYPE__ONTOLOGY_PACKAGE);
		createEAttribute(ontologyTypeEClass, ONTOLOGY_TYPE__CODEC);
		createEAttribute(ontologyTypeEClass, ONTOLOGY_TYPE__INPUT_TYPE);
		createEReference(ontologyTypeEClass, ONTOLOGY_TYPE__CLASSPATH);

		testConfigTypeEClass = createEClass(TEST_CONFIG_TYPE);
		createEAttribute(testConfigTypeEClass, TEST_CONFIG_TYPE__PLATFORM);
		createEAttribute(testConfigTypeEClass, TEST_CONFIG_TYPE__PREFERED_STRATEGY);
		createEReference(testConfigTypeEClass, TEST_CONFIG_TYPE__TEST_SUITE_LIST);
		createEAttribute(testConfigTypeEClass, TEST_CONFIG_TYPE__PROTOCOL_PATH);
		createEAttribute(testConfigTypeEClass, TEST_CONFIG_TYPE__DOMAIN_DATA_PATH);
		createEAttribute(testConfigTypeEClass, TEST_CONFIG_TYPE__MAX_RANDOM_TC);
		createEAttribute(testConfigTypeEClass, TEST_CONFIG_TYPE__NUMBER_CYCLE);
		createEAttribute(testConfigTypeEClass, TEST_CONFIG_TYPE__AGENT_UNDER_TEST);
		createEAttribute(testConfigTypeEClass, TEST_CONFIG_TYPE__MAX_MUTATION_GEN);
		createEAttribute(testConfigTypeEClass, TEST_CONFIG_TYPE__MAX_MUTATION_PSIZE);
		createEAttribute(testConfigTypeEClass, TEST_CONFIG_TYPE__MUTATION_PROB);
		createEReference(testConfigTypeEClass, TEST_CONFIG_TYPE__ONTOLOGY_SETTING);
		createEReference(testConfigTypeEClass, TEST_CONFIG_TYPE__DITRIBUTED_NODE_CONFIG);

		testSuiteListTypeEClass = createEClass(TEST_SUITE_LIST_TYPE);
		createEAttribute(testSuiteListTypeEClass, TEST_SUITE_LIST_TYPE__TEST_SUITE_PATH);

		// Create enums
		classPathTypeEEnum = createEEnum(CLASS_PATH_TYPE);
		codecTypeEEnum = createEEnum(CODEC_TYPE);
		inputGenTypeEEnum = createEEnum(INPUT_GEN_TYPE);
		platformTypeEEnum = createEEnum(PLATFORM_TYPE);
		preferedStrategyTypeEEnum = createEEnum(PREFERED_STRATEGY_TYPE);

		// Create data types
		classPathTypeObjectEDataType = createEDataType(CLASS_PATH_TYPE_OBJECT);
		codecTypeObjectEDataType = createEDataType(CODEC_TYPE_OBJECT);
		inputGenTypeObjectEDataType = createEDataType(INPUT_GEN_TYPE_OBJECT);
		platformTypeObjectEDataType = createEDataType(PLATFORM_TYPE_OBJECT);
		preferedStrategyTypeObjectEDataType = createEDataType(PREFERED_STRATEGY_TYPE_OBJECT);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized) return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Obtain other dependent packages
		XMLTypePackage theXMLTypePackage = (XMLTypePackage)EPackage.Registry.INSTANCE.getEPackage(XMLTypePackage.eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes

		// Initialize classes and features; add operations and parameters
		initEClass(classpathentryTypeEClass, ClasspathentryType.class, "ClasspathentryType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getClasspathentryType_Kind(), this.getClassPathType(), "kind", "JAR", 0, 1, ClasspathentryType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getClasspathentryType_Path(), theXMLTypePackage.getString(), "path", null, 0, 1, ClasspathentryType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(ditributedNodeConfigTypeEClass, DitributedNodeConfigType.class, "DitributedNodeConfigType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getDitributedNodeConfigType_Node(), this.getNodeType(), null, "node", null, 1, -1, DitributedNodeConfigType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(documentRootEClass, DocumentRoot.class, "DocumentRoot", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getDocumentRoot_Mixed(), ecorePackage.getEFeatureMapEntry(), "mixed", null, 0, -1, null, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDocumentRoot_XMLNSPrefixMap(), ecorePackage.getEStringToStringMapEntry(), null, "xMLNSPrefixMap", null, 0, -1, null, IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDocumentRoot_XSISchemaLocation(), ecorePackage.getEStringToStringMapEntry(), null, "xSISchemaLocation", null, 0, -1, null, IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDocumentRoot_TestConfig(), this.getTestConfigType(), null, "testConfig", null, 0, -2, null, IS_TRANSIENT, IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, IS_DERIVED, IS_ORDERED);

		initEClass(javaPathTypeEClass, JavaPathType.class, "JavaPathType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getJavaPathType_Classpathentry(), this.getClasspathentryType(), null, "classpathentry", null, 1, -1, JavaPathType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(nodeTypeEClass, NodeType.class, "NodeType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getNodeType_NodeName(), theXMLTypePackage.getID(), "nodeName", null, 1, 1, NodeType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getNodeType_NodeAddress(), theXMLTypePackage.getString(), "nodeAddress", null, 1, 1, NodeType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getNodeType_NodeHap(), theXMLTypePackage.getString(), "nodeHap", null, 0, 1, NodeType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getNodeType_RemoteMonitoringAgent(), theXMLTypePackage.getString(), "remoteMonitoringAgent", null, 1, 1, NodeType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getNodeType_RecoveryAgent(), theXMLTypePackage.getString(), "recoveryAgent", null, 1, 1, NodeType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getNodeType_RemoteExecutorAgent(), theXMLTypePackage.getString(), "remoteExecutorAgent", null, 1, 1, NodeType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getNodeType_MonitoredAgentList(), theXMLTypePackage.getString(), "monitoredAgentList", null, 1, 1, NodeType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(ontologyTypeEClass, OntologyType.class, "OntologyType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getOntologyType_ProtegeOntologyPath(), theXMLTypePackage.getString(), "protegeOntologyPath", null, 1, 1, OntologyType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getOntologyType_OntologyName(), theXMLTypePackage.getString(), "ontologyName", null, 1, 1, OntologyType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getOntologyType_Language(), theXMLTypePackage.getString(), "language", null, 1, 1, OntologyType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getOntologyType_OntologyPackage(), theXMLTypePackage.getString(), "ontologyPackage", null, 1, 1, OntologyType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getOntologyType_Codec(), this.getCodecType(), "codec", "JavaXMLContentCodec", 1, 1, OntologyType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getOntologyType_InputType(), this.getInputGenType(), "inputType", "Valid", 1, 1, OntologyType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getOntologyType_Classpath(), this.getJavaPathType(), null, "classpath", null, 1, 1, OntologyType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(testConfigTypeEClass, TestConfigType.class, "TestConfigType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getTestConfigType_Platform(), this.getPlatformType(), "platform", "JADE", 1, 1, TestConfigType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTestConfigType_PreferedStrategy(), this.getPreferedStrategyType(), "preferedStrategy", "Manual", 1, 1, TestConfigType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTestConfigType_TestSuiteList(), this.getTestSuiteListType(), null, "testSuiteList", null, 0, 1, TestConfigType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTestConfigType_ProtocolPath(), theXMLTypePackage.getString(), "protocolPath", null, 0, 1, TestConfigType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTestConfigType_DomainDataPath(), theXMLTypePackage.getString(), "domainDataPath", null, 0, 1, TestConfigType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTestConfigType_MaxRandomTC(), theXMLTypePackage.getInt(), "maxRandomTC", null, 0, 1, TestConfigType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTestConfigType_NumberCycle(), theXMLTypePackage.getInt(), "numberCycle", null, 0, 1, TestConfigType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTestConfigType_AgentUnderTest(), theXMLTypePackage.getString(), "agentUnderTest", null, 0, 1, TestConfigType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTestConfigType_MaxMutationGen(), theXMLTypePackage.getInt(), "maxMutationGen", null, 0, 1, TestConfigType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTestConfigType_MaxMutationPsize(), theXMLTypePackage.getInt(), "maxMutationPsize", null, 0, 1, TestConfigType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTestConfigType_MutationProb(), theXMLTypePackage.getDouble(), "mutationProb", null, 0, 1, TestConfigType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTestConfigType_OntologySetting(), this.getOntologyType(), null, "ontologySetting", null, 0, 1, TestConfigType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTestConfigType_DitributedNodeConfig(), this.getDitributedNodeConfigType(), null, "ditributedNodeConfig", null, 1, 1, TestConfigType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(testSuiteListTypeEClass, TestSuiteListType.class, "TestSuiteListType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getTestSuiteListType_TestSuitePath(), theXMLTypePackage.getString(), "testSuitePath", null, 1, -1, TestSuiteListType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		// Initialize enums and add enum literals
		initEEnum(classPathTypeEEnum, ClassPathType.class, "ClassPathType");
		addEEnumLiteral(classPathTypeEEnum, ClassPathType.JAR);
		addEEnumLiteral(classPathTypeEEnum, ClassPathType.FOLDER);

		initEEnum(codecTypeEEnum, CodecType.class, "CodecType");
		addEEnumLiteral(codecTypeEEnum, CodecType.JAVA_XML_CONTENT_CODEC);
		addEEnumLiteral(codecTypeEEnum, CodecType.NUGGETS_XML_CONTENT_CODEC);
		addEEnumLiteral(codecTypeEEnum, CodecType.JADE_CONTENT_CODEC);

		initEEnum(inputGenTypeEEnum, InputGenType.class, "InputGenType");
		addEEnumLiteral(inputGenTypeEEnum, InputGenType.VALID);
		addEEnumLiteral(inputGenTypeEEnum, InputGenType.IN_VALID);
		addEEnumLiteral(inputGenTypeEEnum, InputGenType.INTERLEAVING);
		addEEnumLiteral(inputGenTypeEEnum, InputGenType.RANDOM);

		initEEnum(platformTypeEEnum, PlatformType.class, "PlatformType");
		addEEnumLiteral(platformTypeEEnum, PlatformType.JADE);
		addEEnumLiteral(platformTypeEEnum, PlatformType.JADEX);
		addEEnumLiteral(platformTypeEEnum, PlatformType.JACK);
		addEEnumLiteral(platformTypeEEnum, PlatformType.UNSPECIFIED);

		initEEnum(preferedStrategyTypeEEnum, PreferedStrategyType.class, "PreferedStrategyType");
		addEEnumLiteral(preferedStrategyTypeEEnum, PreferedStrategyType.MANUAL);
		addEEnumLiteral(preferedStrategyTypeEEnum, PreferedStrategyType.RANDOM);
		addEEnumLiteral(preferedStrategyTypeEEnum, PreferedStrategyType.MUTATION);
		addEEnumLiteral(preferedStrategyTypeEEnum, PreferedStrategyType.WHITE_BOX);
		addEEnumLiteral(preferedStrategyTypeEEnum, PreferedStrategyType.ONTO_BASED);
		addEEnumLiteral(preferedStrategyTypeEEnum, PreferedStrategyType.AUTO);

		// Initialize data types
		initEDataType(classPathTypeObjectEDataType, ClassPathType.class, "ClassPathTypeObject", IS_SERIALIZABLE, IS_GENERATED_INSTANCE_CLASS);
		initEDataType(codecTypeObjectEDataType, CodecType.class, "CodecTypeObject", IS_SERIALIZABLE, IS_GENERATED_INSTANCE_CLASS);
		initEDataType(inputGenTypeObjectEDataType, InputGenType.class, "InputGenTypeObject", IS_SERIALIZABLE, IS_GENERATED_INSTANCE_CLASS);
		initEDataType(platformTypeObjectEDataType, PlatformType.class, "PlatformTypeObject", IS_SERIALIZABLE, IS_GENERATED_INSTANCE_CLASS);
		initEDataType(preferedStrategyTypeObjectEDataType, PreferedStrategyType.class, "PreferedStrategyTypeObject", IS_SERIALIZABLE, IS_GENERATED_INSTANCE_CLASS);

		// Create resource
		createResource(eNS_URI);

		// Create annotations
		// http:///org/eclipse/emf/ecore/util/ExtendedMetaData
		createExtendedMetaDataAnnotations();
	}

	/**
	 * Initializes the annotations for <b>http:///org/eclipse/emf/ecore/util/ExtendedMetaData</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createExtendedMetaDataAnnotations() {
		String source = "http:///org/eclipse/emf/ecore/util/ExtendedMetaData";		
		addAnnotation
		  (classpathentryTypeEClass, 
		   source, 
		   new String[] {
			 "name", "classpathentry_._type",
			 "kind", "empty"
		   });		
		addAnnotation
		  (getClasspathentryType_Kind(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "kind"
		   });		
		addAnnotation
		  (getClasspathentryType_Path(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "path"
		   });		
		addAnnotation
		  (classPathTypeEEnum, 
		   source, 
		   new String[] {
			 "name", "ClassPathType"
		   });		
		addAnnotation
		  (classPathTypeObjectEDataType, 
		   source, 
		   new String[] {
			 "name", "ClassPathType:Object",
			 "baseType", "ClassPathType"
		   });		
		addAnnotation
		  (codecTypeEEnum, 
		   source, 
		   new String[] {
			 "name", "CodecType"
		   });		
		addAnnotation
		  (codecTypeObjectEDataType, 
		   source, 
		   new String[] {
			 "name", "CodecType:Object",
			 "baseType", "CodecType"
		   });		
		addAnnotation
		  (ditributedNodeConfigTypeEClass, 
		   source, 
		   new String[] {
			 "name", "DitributedNodeConfigType",
			 "kind", "elementOnly"
		   });		
		addAnnotation
		  (getDitributedNodeConfigType_Node(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "Node",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (documentRootEClass, 
		   source, 
		   new String[] {
			 "name", "",
			 "kind", "mixed"
		   });		
		addAnnotation
		  (getDocumentRoot_Mixed(), 
		   source, 
		   new String[] {
			 "kind", "elementWildcard",
			 "name", ":mixed"
		   });		
		addAnnotation
		  (getDocumentRoot_XMLNSPrefixMap(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "xmlns:prefix"
		   });		
		addAnnotation
		  (getDocumentRoot_XSISchemaLocation(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "xsi:schemaLocation"
		   });			
		addAnnotation
		  (getDocumentRoot_TestConfig(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "TestConfig",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (inputGenTypeEEnum, 
		   source, 
		   new String[] {
			 "name", "InputGenType"
		   });		
		addAnnotation
		  (inputGenTypeObjectEDataType, 
		   source, 
		   new String[] {
			 "name", "InputGenType:Object",
			 "baseType", "InputGenType"
		   });		
		addAnnotation
		  (javaPathTypeEClass, 
		   source, 
		   new String[] {
			 "name", "JavaPathType",
			 "kind", "elementOnly"
		   });		
		addAnnotation
		  (getJavaPathType_Classpathentry(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "classpathentry",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (nodeTypeEClass, 
		   source, 
		   new String[] {
			 "name", "NodeType",
			 "kind", "elementOnly"
		   });		
		addAnnotation
		  (getNodeType_NodeName(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "NodeName",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getNodeType_NodeAddress(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "NodeAddress",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getNodeType_NodeHap(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "NodeHap",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getNodeType_RemoteMonitoringAgent(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "RemoteMonitoringAgent",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getNodeType_RecoveryAgent(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "RecoveryAgent",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getNodeType_RemoteExecutorAgent(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "RemoteExecutorAgent",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getNodeType_MonitoredAgentList(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "MonitoredAgentList",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (ontologyTypeEClass, 
		   source, 
		   new String[] {
			 "name", "OntologyType",
			 "kind", "elementOnly"
		   });		
		addAnnotation
		  (getOntologyType_ProtegeOntologyPath(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "ProtegeOntologyPath",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getOntologyType_OntologyName(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "OntologyName",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getOntologyType_Language(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "Language",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getOntologyType_OntologyPackage(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "OntologyPackage",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getOntologyType_Codec(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "Codec",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getOntologyType_InputType(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "InputType",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getOntologyType_Classpath(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "Classpath",
			 "namespace", "##targetNamespace"
		   });			
		addAnnotation
		  (platformTypeEEnum, 
		   source, 
		   new String[] {
			 "name", "PlatformType"
		   });		
		addAnnotation
		  (platformTypeObjectEDataType, 
		   source, 
		   new String[] {
			 "name", "PlatformType:Object",
			 "baseType", "PlatformType"
		   });		
		addAnnotation
		  (preferedStrategyTypeEEnum, 
		   source, 
		   new String[] {
			 "name", "PreferedStrategyType"
		   });		
		addAnnotation
		  (preferedStrategyTypeObjectEDataType, 
		   source, 
		   new String[] {
			 "name", "PreferedStrategyType:Object",
			 "baseType", "PreferedStrategyType"
		   });		
		addAnnotation
		  (testConfigTypeEClass, 
		   source, 
		   new String[] {
			 "name", "TestConfig_._type",
			 "kind", "elementOnly"
		   });		
		addAnnotation
		  (getTestConfigType_Platform(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "Platform",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getTestConfigType_PreferedStrategy(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "PreferedStrategy",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getTestConfigType_TestSuiteList(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "TestSuiteList",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getTestConfigType_ProtocolPath(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "ProtocolPath",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getTestConfigType_DomainDataPath(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "DomainDataPath",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getTestConfigType_MaxRandomTC(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "MaxRandomTC",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getTestConfigType_NumberCycle(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "NumberCycle",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getTestConfigType_AgentUnderTest(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "AgentUnderTest",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getTestConfigType_MaxMutationGen(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "MaxMutationGen",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getTestConfigType_MaxMutationPsize(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "MaxMutationPsize",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getTestConfigType_MutationProb(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "MutationProb",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getTestConfigType_OntologySetting(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "OntologySetting",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getTestConfigType_DitributedNodeConfig(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "DitributedNodeConfig",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (testSuiteListTypeEClass, 
		   source, 
		   new String[] {
			 "name", "TestSuiteList_._type",
			 "kind", "elementOnly"
		   });		
		addAnnotation
		  (getTestSuiteListType_TestSuitePath(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "TestSuitePath",
			 "namespace", "##targetNamespace"
		   });
	}

} //ConfigPackageImpl
