/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package it.itc.sra.se.test.config.impl;

import it.itc.sra.se.test.config.ClasspathentryType;
import it.itc.sra.se.test.config.ConfigPackage;
import it.itc.sra.se.test.config.JavaPathType;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Java Path Type</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link it.itc.sra.se.test.config.impl.JavaPathTypeImpl#getClasspathentry <em>Classpathentry</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class JavaPathTypeImpl extends EObjectImpl implements JavaPathType {
	/**
	 * The cached value of the '{@link #getClasspathentry() <em>Classpathentry</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getClasspathentry()
	 * @generated
	 * @ordered
	 */
	protected EList<ClasspathentryType> classpathentry;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected JavaPathTypeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ConfigPackage.Literals.JAVA_PATH_TYPE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<ClasspathentryType> getClasspathentry() {
		if (classpathentry == null) {
			classpathentry = new EObjectContainmentEList<ClasspathentryType>(ClasspathentryType.class, this, ConfigPackage.JAVA_PATH_TYPE__CLASSPATHENTRY);
		}
		return classpathentry;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case ConfigPackage.JAVA_PATH_TYPE__CLASSPATHENTRY:
				return ((InternalEList<?>)getClasspathentry()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case ConfigPackage.JAVA_PATH_TYPE__CLASSPATHENTRY:
				return getClasspathentry();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case ConfigPackage.JAVA_PATH_TYPE__CLASSPATHENTRY:
				getClasspathentry().clear();
				getClasspathentry().addAll((Collection<? extends ClasspathentryType>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case ConfigPackage.JAVA_PATH_TYPE__CLASSPATHENTRY:
				getClasspathentry().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case ConfigPackage.JAVA_PATH_TYPE__CLASSPATHENTRY:
				return classpathentry != null && !classpathentry.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //JavaPathTypeImpl
