/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package it.itc.sra.se.test.config;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.Enumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>Codec Type</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see it.itc.sra.se.test.config.ConfigPackage#getCodecType()
 * @model extendedMetaData="name='CodecType'"
 * @generated
 */
public enum CodecType implements Enumerator {
	/**
	 * The '<em><b>Java XML Content Codec</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #JAVA_XML_CONTENT_CODEC_VALUE
	 * @generated
	 * @ordered
	 */
	JAVA_XML_CONTENT_CODEC(0, "JavaXMLContentCodec", "JavaXMLContentCodec"),

	/**
	 * The '<em><b>Nuggets XML Content Codec</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #NUGGETS_XML_CONTENT_CODEC_VALUE
	 * @generated
	 * @ordered
	 */
	NUGGETS_XML_CONTENT_CODEC(1, "NuggetsXMLContentCodec", "NuggetsXMLContentCodec"),

	/**
	 * The '<em><b>Jade Content Codec</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #JADE_CONTENT_CODEC_VALUE
	 * @generated
	 * @ordered
	 */
	JADE_CONTENT_CODEC(2, "JadeContentCodec", "JadeContentCodec");

	/**
	 * The '<em><b>Java XML Content Codec</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Java XML Content Codec</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #JAVA_XML_CONTENT_CODEC
	 * @model name="JavaXMLContentCodec"
	 * @generated
	 * @ordered
	 */
	public static final int JAVA_XML_CONTENT_CODEC_VALUE = 0;

	/**
	 * The '<em><b>Nuggets XML Content Codec</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Nuggets XML Content Codec</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #NUGGETS_XML_CONTENT_CODEC
	 * @model name="NuggetsXMLContentCodec"
	 * @generated
	 * @ordered
	 */
	public static final int NUGGETS_XML_CONTENT_CODEC_VALUE = 1;

	/**
	 * The '<em><b>Jade Content Codec</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Jade Content Codec</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #JADE_CONTENT_CODEC
	 * @model name="JadeContentCodec"
	 * @generated
	 * @ordered
	 */
	public static final int JADE_CONTENT_CODEC_VALUE = 2;

	/**
	 * An array of all the '<em><b>Codec Type</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final CodecType[] VALUES_ARRAY =
		new CodecType[] {
			JAVA_XML_CONTENT_CODEC,
			NUGGETS_XML_CONTENT_CODEC,
			JADE_CONTENT_CODEC,
		};

	/**
	 * A public read-only list of all the '<em><b>Codec Type</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final List<CodecType> VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>Codec Type</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static CodecType get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			CodecType result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Codec Type</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static CodecType getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			CodecType result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Codec Type</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static CodecType get(int value) {
		switch (value) {
			case JAVA_XML_CONTENT_CODEC_VALUE: return JAVA_XML_CONTENT_CODEC;
			case NUGGETS_XML_CONTENT_CODEC_VALUE: return NUGGETS_XML_CONTENT_CODEC;
			case JADE_CONTENT_CODEC_VALUE: return JADE_CONTENT_CODEC;
		}
		return null;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final int value;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String name;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String literal;

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private CodecType(int value, String name, String literal) {
		this.value = value;
		this.name = name;
		this.literal = literal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getValue() {
	  return value;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
	  return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLiteral() {
	  return literal;
	}

	/**
	 * Returns the literal value of the enumerator, which is its string representation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		return literal;
	}
	
} //CodecType
