/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package it.itc.sra.se.test.config;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Test Suite List Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link it.itc.sra.se.test.config.TestSuiteListType#getTestSuitePath <em>Test Suite Path</em>}</li>
 * </ul>
 * </p>
 *
 * @see it.itc.sra.se.test.config.ConfigPackage#getTestSuiteListType()
 * @model extendedMetaData="name='TestSuiteList_._type' kind='elementOnly'"
 * @generated
 */
public interface TestSuiteListType extends EObject {
	/**
	 * Returns the value of the '<em><b>Test Suite Path</b></em>' attribute list.
	 * The list contents are of type {@link java.lang.String}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Test Suite Path</em>' attribute list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Test Suite Path</em>' attribute list.
	 * @see it.itc.sra.se.test.config.ConfigPackage#getTestSuiteListType_TestSuitePath()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String" required="true"
	 *        extendedMetaData="kind='element' name='TestSuitePath' namespace='##targetNamespace'"
	 * @generated
	 */
	EList<String> getTestSuitePath();

} // TestSuiteListType
