/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package it.itc.sra.se.test.config;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Node Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link it.itc.sra.se.test.config.NodeType#getNodeName <em>Node Name</em>}</li>
 *   <li>{@link it.itc.sra.se.test.config.NodeType#getNodeAddress <em>Node Address</em>}</li>
 *   <li>{@link it.itc.sra.se.test.config.NodeType#getNodeHap <em>Node Hap</em>}</li>
 *   <li>{@link it.itc.sra.se.test.config.NodeType#getRemoteMonitoringAgent <em>Remote Monitoring Agent</em>}</li>
 *   <li>{@link it.itc.sra.se.test.config.NodeType#getRecoveryAgent <em>Recovery Agent</em>}</li>
 *   <li>{@link it.itc.sra.se.test.config.NodeType#getRemoteExecutorAgent <em>Remote Executor Agent</em>}</li>
 *   <li>{@link it.itc.sra.se.test.config.NodeType#getMonitoredAgentList <em>Monitored Agent List</em>}</li>
 * </ul>
 * </p>
 *
 * @see it.itc.sra.se.test.config.ConfigPackage#getNodeType()
 * @model extendedMetaData="name='NodeType' kind='elementOnly'"
 * @generated
 */
public interface NodeType extends EObject {
	/**
	 * Returns the value of the '<em><b>Node Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Node Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Node Name</em>' attribute.
	 * @see #setNodeName(String)
	 * @see it.itc.sra.se.test.config.ConfigPackage#getNodeType_NodeName()
	 * @model id="true" dataType="org.eclipse.emf.ecore.xml.type.ID" required="true"
	 *        extendedMetaData="kind='element' name='NodeName' namespace='##targetNamespace'"
	 * @generated
	 */
	String getNodeName();

	/**
	 * Sets the value of the '{@link it.itc.sra.se.test.config.NodeType#getNodeName <em>Node Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Node Name</em>' attribute.
	 * @see #getNodeName()
	 * @generated
	 */
	void setNodeName(String value);

	/**
	 * Returns the value of the '<em><b>Node Address</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Node Address</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Node Address</em>' attribute.
	 * @see #setNodeAddress(String)
	 * @see it.itc.sra.se.test.config.ConfigPackage#getNodeType_NodeAddress()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.String" required="true"
	 *        extendedMetaData="kind='element' name='NodeAddress' namespace='##targetNamespace'"
	 * @generated
	 */
	String getNodeAddress();

	/**
	 * Sets the value of the '{@link it.itc.sra.se.test.config.NodeType#getNodeAddress <em>Node Address</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Node Address</em>' attribute.
	 * @see #getNodeAddress()
	 * @generated
	 */
	void setNodeAddress(String value);

	/**
	 * Returns the value of the '<em><b>Node Hap</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Node Hap</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Node Hap</em>' attribute.
	 * @see #setNodeHap(String)
	 * @see it.itc.sra.se.test.config.ConfigPackage#getNodeType_NodeHap()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.String"
	 *        extendedMetaData="kind='element' name='NodeHap' namespace='##targetNamespace'"
	 * @generated
	 */
	String getNodeHap();

	/**
	 * Sets the value of the '{@link it.itc.sra.se.test.config.NodeType#getNodeHap <em>Node Hap</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Node Hap</em>' attribute.
	 * @see #getNodeHap()
	 * @generated
	 */
	void setNodeHap(String value);

	/**
	 * Returns the value of the '<em><b>Remote Monitoring Agent</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Remote Monitoring Agent</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Remote Monitoring Agent</em>' attribute.
	 * @see #setRemoteMonitoringAgent(String)
	 * @see it.itc.sra.se.test.config.ConfigPackage#getNodeType_RemoteMonitoringAgent()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.String" required="true"
	 *        extendedMetaData="kind='element' name='RemoteMonitoringAgent' namespace='##targetNamespace'"
	 * @generated
	 */
	String getRemoteMonitoringAgent();

	/**
	 * Sets the value of the '{@link it.itc.sra.se.test.config.NodeType#getRemoteMonitoringAgent <em>Remote Monitoring Agent</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Remote Monitoring Agent</em>' attribute.
	 * @see #getRemoteMonitoringAgent()
	 * @generated
	 */
	void setRemoteMonitoringAgent(String value);

	/**
	 * Returns the value of the '<em><b>Recovery Agent</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Recovery Agent</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Recovery Agent</em>' attribute.
	 * @see #setRecoveryAgent(String)
	 * @see it.itc.sra.se.test.config.ConfigPackage#getNodeType_RecoveryAgent()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.String" required="true"
	 *        extendedMetaData="kind='element' name='RecoveryAgent' namespace='##targetNamespace'"
	 * @generated
	 */
	String getRecoveryAgent();

	/**
	 * Sets the value of the '{@link it.itc.sra.se.test.config.NodeType#getRecoveryAgent <em>Recovery Agent</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Recovery Agent</em>' attribute.
	 * @see #getRecoveryAgent()
	 * @generated
	 */
	void setRecoveryAgent(String value);

	/**
	 * Returns the value of the '<em><b>Remote Executor Agent</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Remote Executor Agent</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Remote Executor Agent</em>' attribute.
	 * @see #setRemoteExecutorAgent(String)
	 * @see it.itc.sra.se.test.config.ConfigPackage#getNodeType_RemoteExecutorAgent()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.String" required="true"
	 *        extendedMetaData="kind='element' name='RemoteExecutorAgent' namespace='##targetNamespace'"
	 * @generated
	 */
	String getRemoteExecutorAgent();

	/**
	 * Sets the value of the '{@link it.itc.sra.se.test.config.NodeType#getRemoteExecutorAgent <em>Remote Executor Agent</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Remote Executor Agent</em>' attribute.
	 * @see #getRemoteExecutorAgent()
	 * @generated
	 */
	void setRemoteExecutorAgent(String value);

	/**
	 * Returns the value of the '<em><b>Monitored Agent List</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Monitored Agent List</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Monitored Agent List</em>' attribute.
	 * @see #setMonitoredAgentList(String)
	 * @see it.itc.sra.se.test.config.ConfigPackage#getNodeType_MonitoredAgentList()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.String" required="true"
	 *        extendedMetaData="kind='element' name='MonitoredAgentList' namespace='##targetNamespace'"
	 * @generated
	 */
	String getMonitoredAgentList();

	/**
	 * Sets the value of the '{@link it.itc.sra.se.test.config.NodeType#getMonitoredAgentList <em>Monitored Agent List</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Monitored Agent List</em>' attribute.
	 * @see #getMonitoredAgentList()
	 * @generated
	 */
	void setMonitoredAgentList(String value);

} // NodeType
