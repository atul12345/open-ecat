/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package it.itc.sra.se.test.config;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Ditributed Node Config Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link it.itc.sra.se.test.config.DitributedNodeConfigType#getNode <em>Node</em>}</li>
 * </ul>
 * </p>
 *
 * @see it.itc.sra.se.test.config.ConfigPackage#getDitributedNodeConfigType()
 * @model extendedMetaData="name='DitributedNodeConfigType' kind='elementOnly'"
 * @generated
 */
public interface DitributedNodeConfigType extends EObject {
	/**
	 * Returns the value of the '<em><b>Node</b></em>' containment reference list.
	 * The list contents are of type {@link it.itc.sra.se.test.config.NodeType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Node</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Node</em>' containment reference list.
	 * @see it.itc.sra.se.test.config.ConfigPackage#getDitributedNodeConfigType_Node()
	 * @model containment="true" required="true"
	 *        extendedMetaData="kind='element' name='Node' namespace='##targetNamespace'"
	 * @generated
	 */
	EList<NodeType> getNode();

} // DitributedNodeConfigType
