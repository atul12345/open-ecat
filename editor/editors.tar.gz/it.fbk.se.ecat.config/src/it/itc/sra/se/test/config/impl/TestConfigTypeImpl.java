/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package it.itc.sra.se.test.config.impl;

import it.itc.sra.se.test.config.ConfigPackage;
import it.itc.sra.se.test.config.DitributedNodeConfigType;
import it.itc.sra.se.test.config.OntologyType;
import it.itc.sra.se.test.config.PlatformType;
import it.itc.sra.se.test.config.PreferedStrategyType;
import it.itc.sra.se.test.config.TestConfigType;
import it.itc.sra.se.test.config.TestSuiteListType;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Test Config Type</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link it.itc.sra.se.test.config.impl.TestConfigTypeImpl#getPlatform <em>Platform</em>}</li>
 *   <li>{@link it.itc.sra.se.test.config.impl.TestConfigTypeImpl#getPreferedStrategy <em>Prefered Strategy</em>}</li>
 *   <li>{@link it.itc.sra.se.test.config.impl.TestConfigTypeImpl#getTestSuiteList <em>Test Suite List</em>}</li>
 *   <li>{@link it.itc.sra.se.test.config.impl.TestConfigTypeImpl#getProtocolPath <em>Protocol Path</em>}</li>
 *   <li>{@link it.itc.sra.se.test.config.impl.TestConfigTypeImpl#getDomainDataPath <em>Domain Data Path</em>}</li>
 *   <li>{@link it.itc.sra.se.test.config.impl.TestConfigTypeImpl#getMaxRandomTC <em>Max Random TC</em>}</li>
 *   <li>{@link it.itc.sra.se.test.config.impl.TestConfigTypeImpl#getNumberCycle <em>Number Cycle</em>}</li>
 *   <li>{@link it.itc.sra.se.test.config.impl.TestConfigTypeImpl#getAgentUnderTest <em>Agent Under Test</em>}</li>
 *   <li>{@link it.itc.sra.se.test.config.impl.TestConfigTypeImpl#getMaxMutationGen <em>Max Mutation Gen</em>}</li>
 *   <li>{@link it.itc.sra.se.test.config.impl.TestConfigTypeImpl#getMaxMutationPsize <em>Max Mutation Psize</em>}</li>
 *   <li>{@link it.itc.sra.se.test.config.impl.TestConfigTypeImpl#getMutationProb <em>Mutation Prob</em>}</li>
 *   <li>{@link it.itc.sra.se.test.config.impl.TestConfigTypeImpl#getOntologySetting <em>Ontology Setting</em>}</li>
 *   <li>{@link it.itc.sra.se.test.config.impl.TestConfigTypeImpl#getDitributedNodeConfig <em>Ditributed Node Config</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class TestConfigTypeImpl extends EObjectImpl implements TestConfigType {
	/**
	 * The default value of the '{@link #getPlatform() <em>Platform</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPlatform()
	 * @generated
	 * @ordered
	 */
	protected static final PlatformType PLATFORM_EDEFAULT = PlatformType.JADE;

	/**
	 * The cached value of the '{@link #getPlatform() <em>Platform</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPlatform()
	 * @generated
	 * @ordered
	 */
	protected PlatformType platform = PLATFORM_EDEFAULT;

	/**
	 * This is true if the Platform attribute has been set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	protected boolean platformESet;

	/**
	 * The default value of the '{@link #getPreferedStrategy() <em>Prefered Strategy</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPreferedStrategy()
	 * @generated
	 * @ordered
	 */
	protected static final PreferedStrategyType PREFERED_STRATEGY_EDEFAULT = PreferedStrategyType.MANUAL;

	/**
	 * The cached value of the '{@link #getPreferedStrategy() <em>Prefered Strategy</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPreferedStrategy()
	 * @generated
	 * @ordered
	 */
	protected PreferedStrategyType preferedStrategy = PREFERED_STRATEGY_EDEFAULT;

	/**
	 * This is true if the Prefered Strategy attribute has been set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	protected boolean preferedStrategyESet;

	/**
	 * The cached value of the '{@link #getTestSuiteList() <em>Test Suite List</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTestSuiteList()
	 * @generated
	 * @ordered
	 */
	protected TestSuiteListType testSuiteList;

	/**
	 * The default value of the '{@link #getProtocolPath() <em>Protocol Path</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProtocolPath()
	 * @generated
	 * @ordered
	 */
	protected static final String PROTOCOL_PATH_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getProtocolPath() <em>Protocol Path</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProtocolPath()
	 * @generated
	 * @ordered
	 */
	protected String protocolPath = PROTOCOL_PATH_EDEFAULT;

	/**
	 * The default value of the '{@link #getDomainDataPath() <em>Domain Data Path</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDomainDataPath()
	 * @generated
	 * @ordered
	 */
	protected static final String DOMAIN_DATA_PATH_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getDomainDataPath() <em>Domain Data Path</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDomainDataPath()
	 * @generated
	 * @ordered
	 */
	protected String domainDataPath = DOMAIN_DATA_PATH_EDEFAULT;

	/**
	 * The default value of the '{@link #getMaxRandomTC() <em>Max Random TC</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMaxRandomTC()
	 * @generated
	 * @ordered
	 */
	protected static final int MAX_RANDOM_TC_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getMaxRandomTC() <em>Max Random TC</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMaxRandomTC()
	 * @generated
	 * @ordered
	 */
	protected int maxRandomTC = MAX_RANDOM_TC_EDEFAULT;

	/**
	 * This is true if the Max Random TC attribute has been set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	protected boolean maxRandomTCESet;

	/**
	 * The default value of the '{@link #getNumberCycle() <em>Number Cycle</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNumberCycle()
	 * @generated
	 * @ordered
	 */
	protected static final int NUMBER_CYCLE_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getNumberCycle() <em>Number Cycle</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNumberCycle()
	 * @generated
	 * @ordered
	 */
	protected int numberCycle = NUMBER_CYCLE_EDEFAULT;

	/**
	 * This is true if the Number Cycle attribute has been set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	protected boolean numberCycleESet;

	/**
	 * The default value of the '{@link #getAgentUnderTest() <em>Agent Under Test</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAgentUnderTest()
	 * @generated
	 * @ordered
	 */
	protected static final String AGENT_UNDER_TEST_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getAgentUnderTest() <em>Agent Under Test</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAgentUnderTest()
	 * @generated
	 * @ordered
	 */
	protected String agentUnderTest = AGENT_UNDER_TEST_EDEFAULT;

	/**
	 * The default value of the '{@link #getMaxMutationGen() <em>Max Mutation Gen</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMaxMutationGen()
	 * @generated
	 * @ordered
	 */
	protected static final int MAX_MUTATION_GEN_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getMaxMutationGen() <em>Max Mutation Gen</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMaxMutationGen()
	 * @generated
	 * @ordered
	 */
	protected int maxMutationGen = MAX_MUTATION_GEN_EDEFAULT;

	/**
	 * This is true if the Max Mutation Gen attribute has been set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	protected boolean maxMutationGenESet;

	/**
	 * The default value of the '{@link #getMaxMutationPsize() <em>Max Mutation Psize</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMaxMutationPsize()
	 * @generated
	 * @ordered
	 */
	protected static final int MAX_MUTATION_PSIZE_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getMaxMutationPsize() <em>Max Mutation Psize</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMaxMutationPsize()
	 * @generated
	 * @ordered
	 */
	protected int maxMutationPsize = MAX_MUTATION_PSIZE_EDEFAULT;

	/**
	 * This is true if the Max Mutation Psize attribute has been set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	protected boolean maxMutationPsizeESet;

	/**
	 * The default value of the '{@link #getMutationProb() <em>Mutation Prob</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMutationProb()
	 * @generated
	 * @ordered
	 */
	protected static final double MUTATION_PROB_EDEFAULT = 0.0;

	/**
	 * The cached value of the '{@link #getMutationProb() <em>Mutation Prob</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMutationProb()
	 * @generated
	 * @ordered
	 */
	protected double mutationProb = MUTATION_PROB_EDEFAULT;

	/**
	 * This is true if the Mutation Prob attribute has been set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	protected boolean mutationProbESet;

	/**
	 * The cached value of the '{@link #getOntologySetting() <em>Ontology Setting</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOntologySetting()
	 * @generated
	 * @ordered
	 */
	protected OntologyType ontologySetting;

	/**
	 * The cached value of the '{@link #getDitributedNodeConfig() <em>Ditributed Node Config</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDitributedNodeConfig()
	 * @generated
	 * @ordered
	 */
	protected DitributedNodeConfigType ditributedNodeConfig;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TestConfigTypeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ConfigPackage.Literals.TEST_CONFIG_TYPE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PlatformType getPlatform() {
		return platform;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPlatform(PlatformType newPlatform) {
		PlatformType oldPlatform = platform;
		platform = newPlatform == null ? PLATFORM_EDEFAULT : newPlatform;
		boolean oldPlatformESet = platformESet;
		platformESet = true;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ConfigPackage.TEST_CONFIG_TYPE__PLATFORM, oldPlatform, platform, !oldPlatformESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetPlatform() {
		PlatformType oldPlatform = platform;
		boolean oldPlatformESet = platformESet;
		platform = PLATFORM_EDEFAULT;
		platformESet = false;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.UNSET, ConfigPackage.TEST_CONFIG_TYPE__PLATFORM, oldPlatform, PLATFORM_EDEFAULT, oldPlatformESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetPlatform() {
		return platformESet;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PreferedStrategyType getPreferedStrategy() {
		return preferedStrategy;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPreferedStrategy(PreferedStrategyType newPreferedStrategy) {
		PreferedStrategyType oldPreferedStrategy = preferedStrategy;
		preferedStrategy = newPreferedStrategy == null ? PREFERED_STRATEGY_EDEFAULT : newPreferedStrategy;
		boolean oldPreferedStrategyESet = preferedStrategyESet;
		preferedStrategyESet = true;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ConfigPackage.TEST_CONFIG_TYPE__PREFERED_STRATEGY, oldPreferedStrategy, preferedStrategy, !oldPreferedStrategyESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetPreferedStrategy() {
		PreferedStrategyType oldPreferedStrategy = preferedStrategy;
		boolean oldPreferedStrategyESet = preferedStrategyESet;
		preferedStrategy = PREFERED_STRATEGY_EDEFAULT;
		preferedStrategyESet = false;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.UNSET, ConfigPackage.TEST_CONFIG_TYPE__PREFERED_STRATEGY, oldPreferedStrategy, PREFERED_STRATEGY_EDEFAULT, oldPreferedStrategyESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetPreferedStrategy() {
		return preferedStrategyESet;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TestSuiteListType getTestSuiteList() {
		return testSuiteList;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetTestSuiteList(TestSuiteListType newTestSuiteList, NotificationChain msgs) {
		TestSuiteListType oldTestSuiteList = testSuiteList;
		testSuiteList = newTestSuiteList;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ConfigPackage.TEST_CONFIG_TYPE__TEST_SUITE_LIST, oldTestSuiteList, newTestSuiteList);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTestSuiteList(TestSuiteListType newTestSuiteList) {
		if (newTestSuiteList != testSuiteList) {
			NotificationChain msgs = null;
			if (testSuiteList != null)
				msgs = ((InternalEObject)testSuiteList).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - ConfigPackage.TEST_CONFIG_TYPE__TEST_SUITE_LIST, null, msgs);
			if (newTestSuiteList != null)
				msgs = ((InternalEObject)newTestSuiteList).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - ConfigPackage.TEST_CONFIG_TYPE__TEST_SUITE_LIST, null, msgs);
			msgs = basicSetTestSuiteList(newTestSuiteList, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ConfigPackage.TEST_CONFIG_TYPE__TEST_SUITE_LIST, newTestSuiteList, newTestSuiteList));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getProtocolPath() {
		return protocolPath;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setProtocolPath(String newProtocolPath) {
		String oldProtocolPath = protocolPath;
		protocolPath = newProtocolPath;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ConfigPackage.TEST_CONFIG_TYPE__PROTOCOL_PATH, oldProtocolPath, protocolPath));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getDomainDataPath() {
		return domainDataPath;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDomainDataPath(String newDomainDataPath) {
		String oldDomainDataPath = domainDataPath;
		domainDataPath = newDomainDataPath;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ConfigPackage.TEST_CONFIG_TYPE__DOMAIN_DATA_PATH, oldDomainDataPath, domainDataPath));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getMaxRandomTC() {
		return maxRandomTC;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setMaxRandomTC(int newMaxRandomTC) {
		int oldMaxRandomTC = maxRandomTC;
		maxRandomTC = newMaxRandomTC;
		boolean oldMaxRandomTCESet = maxRandomTCESet;
		maxRandomTCESet = true;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ConfigPackage.TEST_CONFIG_TYPE__MAX_RANDOM_TC, oldMaxRandomTC, maxRandomTC, !oldMaxRandomTCESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetMaxRandomTC() {
		int oldMaxRandomTC = maxRandomTC;
		boolean oldMaxRandomTCESet = maxRandomTCESet;
		maxRandomTC = MAX_RANDOM_TC_EDEFAULT;
		maxRandomTCESet = false;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.UNSET, ConfigPackage.TEST_CONFIG_TYPE__MAX_RANDOM_TC, oldMaxRandomTC, MAX_RANDOM_TC_EDEFAULT, oldMaxRandomTCESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetMaxRandomTC() {
		return maxRandomTCESet;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getNumberCycle() {
		return numberCycle;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setNumberCycle(int newNumberCycle) {
		int oldNumberCycle = numberCycle;
		numberCycle = newNumberCycle;
		boolean oldNumberCycleESet = numberCycleESet;
		numberCycleESet = true;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ConfigPackage.TEST_CONFIG_TYPE__NUMBER_CYCLE, oldNumberCycle, numberCycle, !oldNumberCycleESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetNumberCycle() {
		int oldNumberCycle = numberCycle;
		boolean oldNumberCycleESet = numberCycleESet;
		numberCycle = NUMBER_CYCLE_EDEFAULT;
		numberCycleESet = false;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.UNSET, ConfigPackage.TEST_CONFIG_TYPE__NUMBER_CYCLE, oldNumberCycle, NUMBER_CYCLE_EDEFAULT, oldNumberCycleESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetNumberCycle() {
		return numberCycleESet;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getAgentUnderTest() {
		return agentUnderTest;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAgentUnderTest(String newAgentUnderTest) {
		String oldAgentUnderTest = agentUnderTest;
		agentUnderTest = newAgentUnderTest;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ConfigPackage.TEST_CONFIG_TYPE__AGENT_UNDER_TEST, oldAgentUnderTest, agentUnderTest));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getMaxMutationGen() {
		return maxMutationGen;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setMaxMutationGen(int newMaxMutationGen) {
		int oldMaxMutationGen = maxMutationGen;
		maxMutationGen = newMaxMutationGen;
		boolean oldMaxMutationGenESet = maxMutationGenESet;
		maxMutationGenESet = true;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ConfigPackage.TEST_CONFIG_TYPE__MAX_MUTATION_GEN, oldMaxMutationGen, maxMutationGen, !oldMaxMutationGenESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetMaxMutationGen() {
		int oldMaxMutationGen = maxMutationGen;
		boolean oldMaxMutationGenESet = maxMutationGenESet;
		maxMutationGen = MAX_MUTATION_GEN_EDEFAULT;
		maxMutationGenESet = false;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.UNSET, ConfigPackage.TEST_CONFIG_TYPE__MAX_MUTATION_GEN, oldMaxMutationGen, MAX_MUTATION_GEN_EDEFAULT, oldMaxMutationGenESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetMaxMutationGen() {
		return maxMutationGenESet;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getMaxMutationPsize() {
		return maxMutationPsize;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setMaxMutationPsize(int newMaxMutationPsize) {
		int oldMaxMutationPsize = maxMutationPsize;
		maxMutationPsize = newMaxMutationPsize;
		boolean oldMaxMutationPsizeESet = maxMutationPsizeESet;
		maxMutationPsizeESet = true;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ConfigPackage.TEST_CONFIG_TYPE__MAX_MUTATION_PSIZE, oldMaxMutationPsize, maxMutationPsize, !oldMaxMutationPsizeESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetMaxMutationPsize() {
		int oldMaxMutationPsize = maxMutationPsize;
		boolean oldMaxMutationPsizeESet = maxMutationPsizeESet;
		maxMutationPsize = MAX_MUTATION_PSIZE_EDEFAULT;
		maxMutationPsizeESet = false;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.UNSET, ConfigPackage.TEST_CONFIG_TYPE__MAX_MUTATION_PSIZE, oldMaxMutationPsize, MAX_MUTATION_PSIZE_EDEFAULT, oldMaxMutationPsizeESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetMaxMutationPsize() {
		return maxMutationPsizeESet;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public double getMutationProb() {
		return mutationProb;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setMutationProb(double newMutationProb) {
		double oldMutationProb = mutationProb;
		mutationProb = newMutationProb;
		boolean oldMutationProbESet = mutationProbESet;
		mutationProbESet = true;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ConfigPackage.TEST_CONFIG_TYPE__MUTATION_PROB, oldMutationProb, mutationProb, !oldMutationProbESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetMutationProb() {
		double oldMutationProb = mutationProb;
		boolean oldMutationProbESet = mutationProbESet;
		mutationProb = MUTATION_PROB_EDEFAULT;
		mutationProbESet = false;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.UNSET, ConfigPackage.TEST_CONFIG_TYPE__MUTATION_PROB, oldMutationProb, MUTATION_PROB_EDEFAULT, oldMutationProbESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetMutationProb() {
		return mutationProbESet;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OntologyType getOntologySetting() {
		return ontologySetting;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetOntologySetting(OntologyType newOntologySetting, NotificationChain msgs) {
		OntologyType oldOntologySetting = ontologySetting;
		ontologySetting = newOntologySetting;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ConfigPackage.TEST_CONFIG_TYPE__ONTOLOGY_SETTING, oldOntologySetting, newOntologySetting);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setOntologySetting(OntologyType newOntologySetting) {
		if (newOntologySetting != ontologySetting) {
			NotificationChain msgs = null;
			if (ontologySetting != null)
				msgs = ((InternalEObject)ontologySetting).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - ConfigPackage.TEST_CONFIG_TYPE__ONTOLOGY_SETTING, null, msgs);
			if (newOntologySetting != null)
				msgs = ((InternalEObject)newOntologySetting).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - ConfigPackage.TEST_CONFIG_TYPE__ONTOLOGY_SETTING, null, msgs);
			msgs = basicSetOntologySetting(newOntologySetting, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ConfigPackage.TEST_CONFIG_TYPE__ONTOLOGY_SETTING, newOntologySetting, newOntologySetting));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DitributedNodeConfigType getDitributedNodeConfig() {
		return ditributedNodeConfig;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetDitributedNodeConfig(DitributedNodeConfigType newDitributedNodeConfig, NotificationChain msgs) {
		DitributedNodeConfigType oldDitributedNodeConfig = ditributedNodeConfig;
		ditributedNodeConfig = newDitributedNodeConfig;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ConfigPackage.TEST_CONFIG_TYPE__DITRIBUTED_NODE_CONFIG, oldDitributedNodeConfig, newDitributedNodeConfig);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDitributedNodeConfig(DitributedNodeConfigType newDitributedNodeConfig) {
		if (newDitributedNodeConfig != ditributedNodeConfig) {
			NotificationChain msgs = null;
			if (ditributedNodeConfig != null)
				msgs = ((InternalEObject)ditributedNodeConfig).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - ConfigPackage.TEST_CONFIG_TYPE__DITRIBUTED_NODE_CONFIG, null, msgs);
			if (newDitributedNodeConfig != null)
				msgs = ((InternalEObject)newDitributedNodeConfig).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - ConfigPackage.TEST_CONFIG_TYPE__DITRIBUTED_NODE_CONFIG, null, msgs);
			msgs = basicSetDitributedNodeConfig(newDitributedNodeConfig, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ConfigPackage.TEST_CONFIG_TYPE__DITRIBUTED_NODE_CONFIG, newDitributedNodeConfig, newDitributedNodeConfig));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case ConfigPackage.TEST_CONFIG_TYPE__TEST_SUITE_LIST:
				return basicSetTestSuiteList(null, msgs);
			case ConfigPackage.TEST_CONFIG_TYPE__ONTOLOGY_SETTING:
				return basicSetOntologySetting(null, msgs);
			case ConfigPackage.TEST_CONFIG_TYPE__DITRIBUTED_NODE_CONFIG:
				return basicSetDitributedNodeConfig(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case ConfigPackage.TEST_CONFIG_TYPE__PLATFORM:
				return getPlatform();
			case ConfigPackage.TEST_CONFIG_TYPE__PREFERED_STRATEGY:
				return getPreferedStrategy();
			case ConfigPackage.TEST_CONFIG_TYPE__TEST_SUITE_LIST:
				return getTestSuiteList();
			case ConfigPackage.TEST_CONFIG_TYPE__PROTOCOL_PATH:
				return getProtocolPath();
			case ConfigPackage.TEST_CONFIG_TYPE__DOMAIN_DATA_PATH:
				return getDomainDataPath();
			case ConfigPackage.TEST_CONFIG_TYPE__MAX_RANDOM_TC:
				return new Integer(getMaxRandomTC());
			case ConfigPackage.TEST_CONFIG_TYPE__NUMBER_CYCLE:
				return new Integer(getNumberCycle());
			case ConfigPackage.TEST_CONFIG_TYPE__AGENT_UNDER_TEST:
				return getAgentUnderTest();
			case ConfigPackage.TEST_CONFIG_TYPE__MAX_MUTATION_GEN:
				return new Integer(getMaxMutationGen());
			case ConfigPackage.TEST_CONFIG_TYPE__MAX_MUTATION_PSIZE:
				return new Integer(getMaxMutationPsize());
			case ConfigPackage.TEST_CONFIG_TYPE__MUTATION_PROB:
				return new Double(getMutationProb());
			case ConfigPackage.TEST_CONFIG_TYPE__ONTOLOGY_SETTING:
				return getOntologySetting();
			case ConfigPackage.TEST_CONFIG_TYPE__DITRIBUTED_NODE_CONFIG:
				return getDitributedNodeConfig();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case ConfigPackage.TEST_CONFIG_TYPE__PLATFORM:
				setPlatform((PlatformType)newValue);
				return;
			case ConfigPackage.TEST_CONFIG_TYPE__PREFERED_STRATEGY:
				setPreferedStrategy((PreferedStrategyType)newValue);
				return;
			case ConfigPackage.TEST_CONFIG_TYPE__TEST_SUITE_LIST:
				setTestSuiteList((TestSuiteListType)newValue);
				return;
			case ConfigPackage.TEST_CONFIG_TYPE__PROTOCOL_PATH:
				setProtocolPath((String)newValue);
				return;
			case ConfigPackage.TEST_CONFIG_TYPE__DOMAIN_DATA_PATH:
				setDomainDataPath((String)newValue);
				return;
			case ConfigPackage.TEST_CONFIG_TYPE__MAX_RANDOM_TC:
				setMaxRandomTC(((Integer)newValue).intValue());
				return;
			case ConfigPackage.TEST_CONFIG_TYPE__NUMBER_CYCLE:
				setNumberCycle(((Integer)newValue).intValue());
				return;
			case ConfigPackage.TEST_CONFIG_TYPE__AGENT_UNDER_TEST:
				setAgentUnderTest((String)newValue);
				return;
			case ConfigPackage.TEST_CONFIG_TYPE__MAX_MUTATION_GEN:
				setMaxMutationGen(((Integer)newValue).intValue());
				return;
			case ConfigPackage.TEST_CONFIG_TYPE__MAX_MUTATION_PSIZE:
				setMaxMutationPsize(((Integer)newValue).intValue());
				return;
			case ConfigPackage.TEST_CONFIG_TYPE__MUTATION_PROB:
				setMutationProb(((Double)newValue).doubleValue());
				return;
			case ConfigPackage.TEST_CONFIG_TYPE__ONTOLOGY_SETTING:
				setOntologySetting((OntologyType)newValue);
				return;
			case ConfigPackage.TEST_CONFIG_TYPE__DITRIBUTED_NODE_CONFIG:
				setDitributedNodeConfig((DitributedNodeConfigType)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case ConfigPackage.TEST_CONFIG_TYPE__PLATFORM:
				unsetPlatform();
				return;
			case ConfigPackage.TEST_CONFIG_TYPE__PREFERED_STRATEGY:
				unsetPreferedStrategy();
				return;
			case ConfigPackage.TEST_CONFIG_TYPE__TEST_SUITE_LIST:
				setTestSuiteList((TestSuiteListType)null);
				return;
			case ConfigPackage.TEST_CONFIG_TYPE__PROTOCOL_PATH:
				setProtocolPath(PROTOCOL_PATH_EDEFAULT);
				return;
			case ConfigPackage.TEST_CONFIG_TYPE__DOMAIN_DATA_PATH:
				setDomainDataPath(DOMAIN_DATA_PATH_EDEFAULT);
				return;
			case ConfigPackage.TEST_CONFIG_TYPE__MAX_RANDOM_TC:
				unsetMaxRandomTC();
				return;
			case ConfigPackage.TEST_CONFIG_TYPE__NUMBER_CYCLE:
				unsetNumberCycle();
				return;
			case ConfigPackage.TEST_CONFIG_TYPE__AGENT_UNDER_TEST:
				setAgentUnderTest(AGENT_UNDER_TEST_EDEFAULT);
				return;
			case ConfigPackage.TEST_CONFIG_TYPE__MAX_MUTATION_GEN:
				unsetMaxMutationGen();
				return;
			case ConfigPackage.TEST_CONFIG_TYPE__MAX_MUTATION_PSIZE:
				unsetMaxMutationPsize();
				return;
			case ConfigPackage.TEST_CONFIG_TYPE__MUTATION_PROB:
				unsetMutationProb();
				return;
			case ConfigPackage.TEST_CONFIG_TYPE__ONTOLOGY_SETTING:
				setOntologySetting((OntologyType)null);
				return;
			case ConfigPackage.TEST_CONFIG_TYPE__DITRIBUTED_NODE_CONFIG:
				setDitributedNodeConfig((DitributedNodeConfigType)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case ConfigPackage.TEST_CONFIG_TYPE__PLATFORM:
				return isSetPlatform();
			case ConfigPackage.TEST_CONFIG_TYPE__PREFERED_STRATEGY:
				return isSetPreferedStrategy();
			case ConfigPackage.TEST_CONFIG_TYPE__TEST_SUITE_LIST:
				return testSuiteList != null;
			case ConfigPackage.TEST_CONFIG_TYPE__PROTOCOL_PATH:
				return PROTOCOL_PATH_EDEFAULT == null ? protocolPath != null : !PROTOCOL_PATH_EDEFAULT.equals(protocolPath);
			case ConfigPackage.TEST_CONFIG_TYPE__DOMAIN_DATA_PATH:
				return DOMAIN_DATA_PATH_EDEFAULT == null ? domainDataPath != null : !DOMAIN_DATA_PATH_EDEFAULT.equals(domainDataPath);
			case ConfigPackage.TEST_CONFIG_TYPE__MAX_RANDOM_TC:
				return isSetMaxRandomTC();
			case ConfigPackage.TEST_CONFIG_TYPE__NUMBER_CYCLE:
				return isSetNumberCycle();
			case ConfigPackage.TEST_CONFIG_TYPE__AGENT_UNDER_TEST:
				return AGENT_UNDER_TEST_EDEFAULT == null ? agentUnderTest != null : !AGENT_UNDER_TEST_EDEFAULT.equals(agentUnderTest);
			case ConfigPackage.TEST_CONFIG_TYPE__MAX_MUTATION_GEN:
				return isSetMaxMutationGen();
			case ConfigPackage.TEST_CONFIG_TYPE__MAX_MUTATION_PSIZE:
				return isSetMaxMutationPsize();
			case ConfigPackage.TEST_CONFIG_TYPE__MUTATION_PROB:
				return isSetMutationProb();
			case ConfigPackage.TEST_CONFIG_TYPE__ONTOLOGY_SETTING:
				return ontologySetting != null;
			case ConfigPackage.TEST_CONFIG_TYPE__DITRIBUTED_NODE_CONFIG:
				return ditributedNodeConfig != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (platform: ");
		if (platformESet) result.append(platform); else result.append("<unset>");
		result.append(", preferedStrategy: ");
		if (preferedStrategyESet) result.append(preferedStrategy); else result.append("<unset>");
		result.append(", protocolPath: ");
		result.append(protocolPath);
		result.append(", domainDataPath: ");
		result.append(domainDataPath);
		result.append(", maxRandomTC: ");
		if (maxRandomTCESet) result.append(maxRandomTC); else result.append("<unset>");
		result.append(", numberCycle: ");
		if (numberCycleESet) result.append(numberCycle); else result.append("<unset>");
		result.append(", agentUnderTest: ");
		result.append(agentUnderTest);
		result.append(", maxMutationGen: ");
		if (maxMutationGenESet) result.append(maxMutationGen); else result.append("<unset>");
		result.append(", maxMutationPsize: ");
		if (maxMutationPsizeESet) result.append(maxMutationPsize); else result.append("<unset>");
		result.append(", mutationProb: ");
		if (mutationProbESet) result.append(mutationProb); else result.append("<unset>");
		result.append(')');
		return result.toString();
	}

} //TestConfigTypeImpl
