/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package it.itc.sra.se.test.config;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Ontology Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link it.itc.sra.se.test.config.OntologyType#getProtegeOntologyPath <em>Protege Ontology Path</em>}</li>
 *   <li>{@link it.itc.sra.se.test.config.OntologyType#getOntologyName <em>Ontology Name</em>}</li>
 *   <li>{@link it.itc.sra.se.test.config.OntologyType#getLanguage <em>Language</em>}</li>
 *   <li>{@link it.itc.sra.se.test.config.OntologyType#getOntologyPackage <em>Ontology Package</em>}</li>
 *   <li>{@link it.itc.sra.se.test.config.OntologyType#getCodec <em>Codec</em>}</li>
 *   <li>{@link it.itc.sra.se.test.config.OntologyType#getInputType <em>Input Type</em>}</li>
 *   <li>{@link it.itc.sra.se.test.config.OntologyType#getClasspath <em>Classpath</em>}</li>
 * </ul>
 * </p>
 *
 * @see it.itc.sra.se.test.config.ConfigPackage#getOntologyType()
 * @model extendedMetaData="name='OntologyType' kind='elementOnly'"
 * @generated
 */
public interface OntologyType extends EObject {
	/**
	 * Returns the value of the '<em><b>Protege Ontology Path</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Protege Ontology Path</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Protege Ontology Path</em>' attribute.
	 * @see #setProtegeOntologyPath(String)
	 * @see it.itc.sra.se.test.config.ConfigPackage#getOntologyType_ProtegeOntologyPath()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.String" required="true"
	 *        extendedMetaData="kind='element' name='ProtegeOntologyPath' namespace='##targetNamespace'"
	 * @generated
	 */
	String getProtegeOntologyPath();

	/**
	 * Sets the value of the '{@link it.itc.sra.se.test.config.OntologyType#getProtegeOntologyPath <em>Protege Ontology Path</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Protege Ontology Path</em>' attribute.
	 * @see #getProtegeOntologyPath()
	 * @generated
	 */
	void setProtegeOntologyPath(String value);

	/**
	 * Returns the value of the '<em><b>Ontology Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Ontology Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ontology Name</em>' attribute.
	 * @see #setOntologyName(String)
	 * @see it.itc.sra.se.test.config.ConfigPackage#getOntologyType_OntologyName()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.String" required="true"
	 *        extendedMetaData="kind='element' name='OntologyName' namespace='##targetNamespace'"
	 * @generated
	 */
	String getOntologyName();

	/**
	 * Sets the value of the '{@link it.itc.sra.se.test.config.OntologyType#getOntologyName <em>Ontology Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Ontology Name</em>' attribute.
	 * @see #getOntologyName()
	 * @generated
	 */
	void setOntologyName(String value);

	/**
	 * Returns the value of the '<em><b>Language</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Language</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Language</em>' attribute.
	 * @see #setLanguage(String)
	 * @see it.itc.sra.se.test.config.ConfigPackage#getOntologyType_Language()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.String" required="true"
	 *        extendedMetaData="kind='element' name='Language' namespace='##targetNamespace'"
	 * @generated
	 */
	String getLanguage();

	/**
	 * Sets the value of the '{@link it.itc.sra.se.test.config.OntologyType#getLanguage <em>Language</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Language</em>' attribute.
	 * @see #getLanguage()
	 * @generated
	 */
	void setLanguage(String value);

	/**
	 * Returns the value of the '<em><b>Ontology Package</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Ontology Package</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ontology Package</em>' attribute.
	 * @see #setOntologyPackage(String)
	 * @see it.itc.sra.se.test.config.ConfigPackage#getOntologyType_OntologyPackage()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.String" required="true"
	 *        extendedMetaData="kind='element' name='OntologyPackage' namespace='##targetNamespace'"
	 * @generated
	 */
	String getOntologyPackage();

	/**
	 * Sets the value of the '{@link it.itc.sra.se.test.config.OntologyType#getOntologyPackage <em>Ontology Package</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Ontology Package</em>' attribute.
	 * @see #getOntologyPackage()
	 * @generated
	 */
	void setOntologyPackage(String value);

	/**
	 * Returns the value of the '<em><b>Codec</b></em>' attribute.
	 * The default value is <code>"JavaXMLContentCodec"</code>.
	 * The literals are from the enumeration {@link it.itc.sra.se.test.config.CodecType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Codec</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Codec</em>' attribute.
	 * @see it.itc.sra.se.test.config.CodecType
	 * @see #isSetCodec()
	 * @see #unsetCodec()
	 * @see #setCodec(CodecType)
	 * @see it.itc.sra.se.test.config.ConfigPackage#getOntologyType_Codec()
	 * @model default="JavaXMLContentCodec" unsettable="true" required="true"
	 *        extendedMetaData="kind='element' name='Codec' namespace='##targetNamespace'"
	 * @generated
	 */
	CodecType getCodec();

	/**
	 * Sets the value of the '{@link it.itc.sra.se.test.config.OntologyType#getCodec <em>Codec</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Codec</em>' attribute.
	 * @see it.itc.sra.se.test.config.CodecType
	 * @see #isSetCodec()
	 * @see #unsetCodec()
	 * @see #getCodec()
	 * @generated
	 */
	void setCodec(CodecType value);

	/**
	 * Unsets the value of the '{@link it.itc.sra.se.test.config.OntologyType#getCodec <em>Codec</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetCodec()
	 * @see #getCodec()
	 * @see #setCodec(CodecType)
	 * @generated
	 */
	void unsetCodec();

	/**
	 * Returns whether the value of the '{@link it.itc.sra.se.test.config.OntologyType#getCodec <em>Codec</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Codec</em>' attribute is set.
	 * @see #unsetCodec()
	 * @see #getCodec()
	 * @see #setCodec(CodecType)
	 * @generated
	 */
	boolean isSetCodec();

	/**
	 * Returns the value of the '<em><b>Input Type</b></em>' attribute.
	 * The default value is <code>"Valid"</code>.
	 * The literals are from the enumeration {@link it.itc.sra.se.test.config.InputGenType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Input Type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Input Type</em>' attribute.
	 * @see it.itc.sra.se.test.config.InputGenType
	 * @see #isSetInputType()
	 * @see #unsetInputType()
	 * @see #setInputType(InputGenType)
	 * @see it.itc.sra.se.test.config.ConfigPackage#getOntologyType_InputType()
	 * @model default="Valid" unsettable="true" required="true"
	 *        extendedMetaData="kind='element' name='InputType' namespace='##targetNamespace'"
	 * @generated
	 */
	InputGenType getInputType();

	/**
	 * Sets the value of the '{@link it.itc.sra.se.test.config.OntologyType#getInputType <em>Input Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Input Type</em>' attribute.
	 * @see it.itc.sra.se.test.config.InputGenType
	 * @see #isSetInputType()
	 * @see #unsetInputType()
	 * @see #getInputType()
	 * @generated
	 */
	void setInputType(InputGenType value);

	/**
	 * Unsets the value of the '{@link it.itc.sra.se.test.config.OntologyType#getInputType <em>Input Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetInputType()
	 * @see #getInputType()
	 * @see #setInputType(InputGenType)
	 * @generated
	 */
	void unsetInputType();

	/**
	 * Returns whether the value of the '{@link it.itc.sra.se.test.config.OntologyType#getInputType <em>Input Type</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Input Type</em>' attribute is set.
	 * @see #unsetInputType()
	 * @see #getInputType()
	 * @see #setInputType(InputGenType)
	 * @generated
	 */
	boolean isSetInputType();

	/**
	 * Returns the value of the '<em><b>Classpath</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Classpath</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Classpath</em>' containment reference.
	 * @see #setClasspath(JavaPathType)
	 * @see it.itc.sra.se.test.config.ConfigPackage#getOntologyType_Classpath()
	 * @model containment="true" required="true"
	 *        extendedMetaData="kind='element' name='Classpath' namespace='##targetNamespace'"
	 * @generated
	 */
	JavaPathType getClasspath();

	/**
	 * Sets the value of the '{@link it.itc.sra.se.test.config.OntologyType#getClasspath <em>Classpath</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Classpath</em>' containment reference.
	 * @see #getClasspath()
	 * @generated
	 */
	void setClasspath(JavaPathType value);

} // OntologyType
