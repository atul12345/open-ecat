/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package it.itc.sra.se.test.config.impl;

import it.itc.sra.se.test.config.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class ConfigFactoryImpl extends EFactoryImpl implements ConfigFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static ConfigFactory init() {
		try {
			ConfigFactory theConfigFactory = (ConfigFactory)EPackage.Registry.INSTANCE.getEFactory("http://sra.itc.it/se/TestConfig"); 
			if (theConfigFactory != null) {
				return theConfigFactory;
			}
		}
		catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new ConfigFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ConfigFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
			case ConfigPackage.CLASSPATHENTRY_TYPE: return createClasspathentryType();
			case ConfigPackage.DITRIBUTED_NODE_CONFIG_TYPE: return createDitributedNodeConfigType();
			case ConfigPackage.DOCUMENT_ROOT: return createDocumentRoot();
			case ConfigPackage.JAVA_PATH_TYPE: return createJavaPathType();
			case ConfigPackage.NODE_TYPE: return createNodeType();
			case ConfigPackage.ONTOLOGY_TYPE: return createOntologyType();
			case ConfigPackage.TEST_CONFIG_TYPE: return createTestConfigType();
			case ConfigPackage.TEST_SUITE_LIST_TYPE: return createTestSuiteListType();
			default:
				throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object createFromString(EDataType eDataType, String initialValue) {
		switch (eDataType.getClassifierID()) {
			case ConfigPackage.CLASS_PATH_TYPE:
				return createClassPathTypeFromString(eDataType, initialValue);
			case ConfigPackage.CODEC_TYPE:
				return createCodecTypeFromString(eDataType, initialValue);
			case ConfigPackage.INPUT_GEN_TYPE:
				return createInputGenTypeFromString(eDataType, initialValue);
			case ConfigPackage.PLATFORM_TYPE:
				return createPlatformTypeFromString(eDataType, initialValue);
			case ConfigPackage.PREFERED_STRATEGY_TYPE:
				return createPreferedStrategyTypeFromString(eDataType, initialValue);
			case ConfigPackage.CLASS_PATH_TYPE_OBJECT:
				return createClassPathTypeObjectFromString(eDataType, initialValue);
			case ConfigPackage.CODEC_TYPE_OBJECT:
				return createCodecTypeObjectFromString(eDataType, initialValue);
			case ConfigPackage.INPUT_GEN_TYPE_OBJECT:
				return createInputGenTypeObjectFromString(eDataType, initialValue);
			case ConfigPackage.PLATFORM_TYPE_OBJECT:
				return createPlatformTypeObjectFromString(eDataType, initialValue);
			case ConfigPackage.PREFERED_STRATEGY_TYPE_OBJECT:
				return createPreferedStrategyTypeObjectFromString(eDataType, initialValue);
			default:
				throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String convertToString(EDataType eDataType, Object instanceValue) {
		switch (eDataType.getClassifierID()) {
			case ConfigPackage.CLASS_PATH_TYPE:
				return convertClassPathTypeToString(eDataType, instanceValue);
			case ConfigPackage.CODEC_TYPE:
				return convertCodecTypeToString(eDataType, instanceValue);
			case ConfigPackage.INPUT_GEN_TYPE:
				return convertInputGenTypeToString(eDataType, instanceValue);
			case ConfigPackage.PLATFORM_TYPE:
				return convertPlatformTypeToString(eDataType, instanceValue);
			case ConfigPackage.PREFERED_STRATEGY_TYPE:
				return convertPreferedStrategyTypeToString(eDataType, instanceValue);
			case ConfigPackage.CLASS_PATH_TYPE_OBJECT:
				return convertClassPathTypeObjectToString(eDataType, instanceValue);
			case ConfigPackage.CODEC_TYPE_OBJECT:
				return convertCodecTypeObjectToString(eDataType, instanceValue);
			case ConfigPackage.INPUT_GEN_TYPE_OBJECT:
				return convertInputGenTypeObjectToString(eDataType, instanceValue);
			case ConfigPackage.PLATFORM_TYPE_OBJECT:
				return convertPlatformTypeObjectToString(eDataType, instanceValue);
			case ConfigPackage.PREFERED_STRATEGY_TYPE_OBJECT:
				return convertPreferedStrategyTypeObjectToString(eDataType, instanceValue);
			default:
				throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ClasspathentryType createClasspathentryType() {
		ClasspathentryTypeImpl classpathentryType = new ClasspathentryTypeImpl();
		return classpathentryType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DitributedNodeConfigType createDitributedNodeConfigType() {
		DitributedNodeConfigTypeImpl ditributedNodeConfigType = new DitributedNodeConfigTypeImpl();
		return ditributedNodeConfigType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DocumentRoot createDocumentRoot() {
		DocumentRootImpl documentRoot = new DocumentRootImpl();
		return documentRoot;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public JavaPathType createJavaPathType() {
		JavaPathTypeImpl javaPathType = new JavaPathTypeImpl();
		return javaPathType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NodeType createNodeType() {
		NodeTypeImpl nodeType = new NodeTypeImpl();
		return nodeType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OntologyType createOntologyType() {
		OntologyTypeImpl ontologyType = new OntologyTypeImpl();
		return ontologyType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TestConfigType createTestConfigType() {
		TestConfigTypeImpl testConfigType = new TestConfigTypeImpl();
		return testConfigType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TestSuiteListType createTestSuiteListType() {
		TestSuiteListTypeImpl testSuiteListType = new TestSuiteListTypeImpl();
		return testSuiteListType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ClassPathType createClassPathTypeFromString(EDataType eDataType, String initialValue) {
		ClassPathType result = ClassPathType.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertClassPathTypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CodecType createCodecTypeFromString(EDataType eDataType, String initialValue) {
		CodecType result = CodecType.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertCodecTypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public InputGenType createInputGenTypeFromString(EDataType eDataType, String initialValue) {
		InputGenType result = InputGenType.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertInputGenTypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PlatformType createPlatformTypeFromString(EDataType eDataType, String initialValue) {
		PlatformType result = PlatformType.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertPlatformTypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PreferedStrategyType createPreferedStrategyTypeFromString(EDataType eDataType, String initialValue) {
		PreferedStrategyType result = PreferedStrategyType.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertPreferedStrategyTypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ClassPathType createClassPathTypeObjectFromString(EDataType eDataType, String initialValue) {
		return createClassPathTypeFromString(ConfigPackage.Literals.CLASS_PATH_TYPE, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertClassPathTypeObjectToString(EDataType eDataType, Object instanceValue) {
		return convertClassPathTypeToString(ConfigPackage.Literals.CLASS_PATH_TYPE, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CodecType createCodecTypeObjectFromString(EDataType eDataType, String initialValue) {
		return createCodecTypeFromString(ConfigPackage.Literals.CODEC_TYPE, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertCodecTypeObjectToString(EDataType eDataType, Object instanceValue) {
		return convertCodecTypeToString(ConfigPackage.Literals.CODEC_TYPE, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public InputGenType createInputGenTypeObjectFromString(EDataType eDataType, String initialValue) {
		return createInputGenTypeFromString(ConfigPackage.Literals.INPUT_GEN_TYPE, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertInputGenTypeObjectToString(EDataType eDataType, Object instanceValue) {
		return convertInputGenTypeToString(ConfigPackage.Literals.INPUT_GEN_TYPE, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PlatformType createPlatformTypeObjectFromString(EDataType eDataType, String initialValue) {
		return createPlatformTypeFromString(ConfigPackage.Literals.PLATFORM_TYPE, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertPlatformTypeObjectToString(EDataType eDataType, Object instanceValue) {
		return convertPlatformTypeToString(ConfigPackage.Literals.PLATFORM_TYPE, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PreferedStrategyType createPreferedStrategyTypeObjectFromString(EDataType eDataType, String initialValue) {
		return createPreferedStrategyTypeFromString(ConfigPackage.Literals.PREFERED_STRATEGY_TYPE, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertPreferedStrategyTypeObjectToString(EDataType eDataType, Object instanceValue) {
		return convertPreferedStrategyTypeToString(ConfigPackage.Literals.PREFERED_STRATEGY_TYPE, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ConfigPackage getConfigPackage() {
		return (ConfigPackage)getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static ConfigPackage getPackage() {
		return ConfigPackage.eINSTANCE;
	}

} //ConfigFactoryImpl
