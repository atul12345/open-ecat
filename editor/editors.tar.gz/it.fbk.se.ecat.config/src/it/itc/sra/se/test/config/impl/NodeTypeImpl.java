/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package it.itc.sra.se.test.config.impl;

import it.itc.sra.se.test.config.ConfigPackage;
import it.itc.sra.se.test.config.NodeType;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Node Type</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link it.itc.sra.se.test.config.impl.NodeTypeImpl#getNodeName <em>Node Name</em>}</li>
 *   <li>{@link it.itc.sra.se.test.config.impl.NodeTypeImpl#getNodeAddress <em>Node Address</em>}</li>
 *   <li>{@link it.itc.sra.se.test.config.impl.NodeTypeImpl#getNodeHap <em>Node Hap</em>}</li>
 *   <li>{@link it.itc.sra.se.test.config.impl.NodeTypeImpl#getRemoteMonitoringAgent <em>Remote Monitoring Agent</em>}</li>
 *   <li>{@link it.itc.sra.se.test.config.impl.NodeTypeImpl#getRecoveryAgent <em>Recovery Agent</em>}</li>
 *   <li>{@link it.itc.sra.se.test.config.impl.NodeTypeImpl#getRemoteExecutorAgent <em>Remote Executor Agent</em>}</li>
 *   <li>{@link it.itc.sra.se.test.config.impl.NodeTypeImpl#getMonitoredAgentList <em>Monitored Agent List</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class NodeTypeImpl extends EObjectImpl implements NodeType {
	/**
	 * The default value of the '{@link #getNodeName() <em>Node Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNodeName()
	 * @generated
	 * @ordered
	 */
	protected static final String NODE_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getNodeName() <em>Node Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNodeName()
	 * @generated
	 * @ordered
	 */
	protected String nodeName = NODE_NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getNodeAddress() <em>Node Address</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNodeAddress()
	 * @generated
	 * @ordered
	 */
	protected static final String NODE_ADDRESS_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getNodeAddress() <em>Node Address</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNodeAddress()
	 * @generated
	 * @ordered
	 */
	protected String nodeAddress = NODE_ADDRESS_EDEFAULT;

	/**
	 * The default value of the '{@link #getNodeHap() <em>Node Hap</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNodeHap()
	 * @generated
	 * @ordered
	 */
	protected static final String NODE_HAP_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getNodeHap() <em>Node Hap</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNodeHap()
	 * @generated
	 * @ordered
	 */
	protected String nodeHap = NODE_HAP_EDEFAULT;

	/**
	 * The default value of the '{@link #getRemoteMonitoringAgent() <em>Remote Monitoring Agent</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRemoteMonitoringAgent()
	 * @generated
	 * @ordered
	 */
	protected static final String REMOTE_MONITORING_AGENT_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getRemoteMonitoringAgent() <em>Remote Monitoring Agent</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRemoteMonitoringAgent()
	 * @generated
	 * @ordered
	 */
	protected String remoteMonitoringAgent = REMOTE_MONITORING_AGENT_EDEFAULT;

	/**
	 * The default value of the '{@link #getRecoveryAgent() <em>Recovery Agent</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRecoveryAgent()
	 * @generated
	 * @ordered
	 */
	protected static final String RECOVERY_AGENT_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getRecoveryAgent() <em>Recovery Agent</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRecoveryAgent()
	 * @generated
	 * @ordered
	 */
	protected String recoveryAgent = RECOVERY_AGENT_EDEFAULT;

	/**
	 * The default value of the '{@link #getRemoteExecutorAgent() <em>Remote Executor Agent</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRemoteExecutorAgent()
	 * @generated
	 * @ordered
	 */
	protected static final String REMOTE_EXECUTOR_AGENT_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getRemoteExecutorAgent() <em>Remote Executor Agent</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRemoteExecutorAgent()
	 * @generated
	 * @ordered
	 */
	protected String remoteExecutorAgent = REMOTE_EXECUTOR_AGENT_EDEFAULT;

	/**
	 * The default value of the '{@link #getMonitoredAgentList() <em>Monitored Agent List</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMonitoredAgentList()
	 * @generated
	 * @ordered
	 */
	protected static final String MONITORED_AGENT_LIST_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getMonitoredAgentList() <em>Monitored Agent List</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMonitoredAgentList()
	 * @generated
	 * @ordered
	 */
	protected String monitoredAgentList = MONITORED_AGENT_LIST_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected NodeTypeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ConfigPackage.Literals.NODE_TYPE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getNodeName() {
		return nodeName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setNodeName(String newNodeName) {
		String oldNodeName = nodeName;
		nodeName = newNodeName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ConfigPackage.NODE_TYPE__NODE_NAME, oldNodeName, nodeName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getNodeAddress() {
		return nodeAddress;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setNodeAddress(String newNodeAddress) {
		String oldNodeAddress = nodeAddress;
		nodeAddress = newNodeAddress;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ConfigPackage.NODE_TYPE__NODE_ADDRESS, oldNodeAddress, nodeAddress));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getNodeHap() {
		return nodeHap;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setNodeHap(String newNodeHap) {
		String oldNodeHap = nodeHap;
		nodeHap = newNodeHap;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ConfigPackage.NODE_TYPE__NODE_HAP, oldNodeHap, nodeHap));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getRemoteMonitoringAgent() {
		return remoteMonitoringAgent;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setRemoteMonitoringAgent(String newRemoteMonitoringAgent) {
		String oldRemoteMonitoringAgent = remoteMonitoringAgent;
		remoteMonitoringAgent = newRemoteMonitoringAgent;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ConfigPackage.NODE_TYPE__REMOTE_MONITORING_AGENT, oldRemoteMonitoringAgent, remoteMonitoringAgent));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getRecoveryAgent() {
		return recoveryAgent;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setRecoveryAgent(String newRecoveryAgent) {
		String oldRecoveryAgent = recoveryAgent;
		recoveryAgent = newRecoveryAgent;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ConfigPackage.NODE_TYPE__RECOVERY_AGENT, oldRecoveryAgent, recoveryAgent));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getRemoteExecutorAgent() {
		return remoteExecutorAgent;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setRemoteExecutorAgent(String newRemoteExecutorAgent) {
		String oldRemoteExecutorAgent = remoteExecutorAgent;
		remoteExecutorAgent = newRemoteExecutorAgent;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ConfigPackage.NODE_TYPE__REMOTE_EXECUTOR_AGENT, oldRemoteExecutorAgent, remoteExecutorAgent));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getMonitoredAgentList() {
		return monitoredAgentList;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setMonitoredAgentList(String newMonitoredAgentList) {
		String oldMonitoredAgentList = monitoredAgentList;
		monitoredAgentList = newMonitoredAgentList;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ConfigPackage.NODE_TYPE__MONITORED_AGENT_LIST, oldMonitoredAgentList, monitoredAgentList));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case ConfigPackage.NODE_TYPE__NODE_NAME:
				return getNodeName();
			case ConfigPackage.NODE_TYPE__NODE_ADDRESS:
				return getNodeAddress();
			case ConfigPackage.NODE_TYPE__NODE_HAP:
				return getNodeHap();
			case ConfigPackage.NODE_TYPE__REMOTE_MONITORING_AGENT:
				return getRemoteMonitoringAgent();
			case ConfigPackage.NODE_TYPE__RECOVERY_AGENT:
				return getRecoveryAgent();
			case ConfigPackage.NODE_TYPE__REMOTE_EXECUTOR_AGENT:
				return getRemoteExecutorAgent();
			case ConfigPackage.NODE_TYPE__MONITORED_AGENT_LIST:
				return getMonitoredAgentList();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case ConfigPackage.NODE_TYPE__NODE_NAME:
				setNodeName((String)newValue);
				return;
			case ConfigPackage.NODE_TYPE__NODE_ADDRESS:
				setNodeAddress((String)newValue);
				return;
			case ConfigPackage.NODE_TYPE__NODE_HAP:
				setNodeHap((String)newValue);
				return;
			case ConfigPackage.NODE_TYPE__REMOTE_MONITORING_AGENT:
				setRemoteMonitoringAgent((String)newValue);
				return;
			case ConfigPackage.NODE_TYPE__RECOVERY_AGENT:
				setRecoveryAgent((String)newValue);
				return;
			case ConfigPackage.NODE_TYPE__REMOTE_EXECUTOR_AGENT:
				setRemoteExecutorAgent((String)newValue);
				return;
			case ConfigPackage.NODE_TYPE__MONITORED_AGENT_LIST:
				setMonitoredAgentList((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case ConfigPackage.NODE_TYPE__NODE_NAME:
				setNodeName(NODE_NAME_EDEFAULT);
				return;
			case ConfigPackage.NODE_TYPE__NODE_ADDRESS:
				setNodeAddress(NODE_ADDRESS_EDEFAULT);
				return;
			case ConfigPackage.NODE_TYPE__NODE_HAP:
				setNodeHap(NODE_HAP_EDEFAULT);
				return;
			case ConfigPackage.NODE_TYPE__REMOTE_MONITORING_AGENT:
				setRemoteMonitoringAgent(REMOTE_MONITORING_AGENT_EDEFAULT);
				return;
			case ConfigPackage.NODE_TYPE__RECOVERY_AGENT:
				setRecoveryAgent(RECOVERY_AGENT_EDEFAULT);
				return;
			case ConfigPackage.NODE_TYPE__REMOTE_EXECUTOR_AGENT:
				setRemoteExecutorAgent(REMOTE_EXECUTOR_AGENT_EDEFAULT);
				return;
			case ConfigPackage.NODE_TYPE__MONITORED_AGENT_LIST:
				setMonitoredAgentList(MONITORED_AGENT_LIST_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case ConfigPackage.NODE_TYPE__NODE_NAME:
				return NODE_NAME_EDEFAULT == null ? nodeName != null : !NODE_NAME_EDEFAULT.equals(nodeName);
			case ConfigPackage.NODE_TYPE__NODE_ADDRESS:
				return NODE_ADDRESS_EDEFAULT == null ? nodeAddress != null : !NODE_ADDRESS_EDEFAULT.equals(nodeAddress);
			case ConfigPackage.NODE_TYPE__NODE_HAP:
				return NODE_HAP_EDEFAULT == null ? nodeHap != null : !NODE_HAP_EDEFAULT.equals(nodeHap);
			case ConfigPackage.NODE_TYPE__REMOTE_MONITORING_AGENT:
				return REMOTE_MONITORING_AGENT_EDEFAULT == null ? remoteMonitoringAgent != null : !REMOTE_MONITORING_AGENT_EDEFAULT.equals(remoteMonitoringAgent);
			case ConfigPackage.NODE_TYPE__RECOVERY_AGENT:
				return RECOVERY_AGENT_EDEFAULT == null ? recoveryAgent != null : !RECOVERY_AGENT_EDEFAULT.equals(recoveryAgent);
			case ConfigPackage.NODE_TYPE__REMOTE_EXECUTOR_AGENT:
				return REMOTE_EXECUTOR_AGENT_EDEFAULT == null ? remoteExecutorAgent != null : !REMOTE_EXECUTOR_AGENT_EDEFAULT.equals(remoteExecutorAgent);
			case ConfigPackage.NODE_TYPE__MONITORED_AGENT_LIST:
				return MONITORED_AGENT_LIST_EDEFAULT == null ? monitoredAgentList != null : !MONITORED_AGENT_LIST_EDEFAULT.equals(monitoredAgentList);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (nodeName: ");
		result.append(nodeName);
		result.append(", nodeAddress: ");
		result.append(nodeAddress);
		result.append(", nodeHap: ");
		result.append(nodeHap);
		result.append(", remoteMonitoringAgent: ");
		result.append(remoteMonitoringAgent);
		result.append(", recoveryAgent: ");
		result.append(recoveryAgent);
		result.append(", remoteExecutorAgent: ");
		result.append(remoteExecutorAgent);
		result.append(", monitoredAgentList: ");
		result.append(monitoredAgentList);
		result.append(')');
		return result.toString();
	}

} //NodeTypeImpl
