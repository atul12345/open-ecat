package suite.diagram.edit.helpers;

/**
 * @generated
 */
public class GoalPlanTypeEditHelper extends SuiteBaseEditHelper {
}
