package suite.diagram.edit.helpers;

/**
 * @generated
 */
public class TestSupportTypeEditHelper extends SuiteBaseEditHelper {
}
