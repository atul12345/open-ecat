package suite.diagram.edit.helpers;

/**
 * @generated
 */
public class TestCaseTypeEditHelper extends SuiteBaseEditHelper {
}
