package suite.diagram.edit.helpers;

/**
 * @generated
 */
public class TestScenarioTypeEditHelper extends SuiteBaseEditHelper {
}
