package suite.diagram.edit.helpers;

/**
 * @generated
 */
public class SetupTypeEditHelper extends SuiteBaseEditHelper {
}
