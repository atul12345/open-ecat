package suite.diagram.edit.helpers;

/**
 * @generated
 */
public class CheckTypeEditHelper extends SuiteBaseEditHelper {
}
