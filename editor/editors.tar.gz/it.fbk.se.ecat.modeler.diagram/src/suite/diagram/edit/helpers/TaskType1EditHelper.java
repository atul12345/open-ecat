package suite.diagram.edit.helpers;

/**
 * @generated
 */
public class TaskType1EditHelper extends SuiteBaseEditHelper {
}
