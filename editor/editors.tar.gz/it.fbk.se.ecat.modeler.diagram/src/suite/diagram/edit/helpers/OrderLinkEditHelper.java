package suite.diagram.edit.helpers;

/**
 * @generated
 */
public class OrderLinkEditHelper extends SuiteBaseEditHelper {
}
