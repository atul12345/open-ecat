package suite.diagram.edit.helpers;

/**
 * @generated
 */
public class FipaMessageTypeEditHelper extends SuiteBaseEditHelper {
}
