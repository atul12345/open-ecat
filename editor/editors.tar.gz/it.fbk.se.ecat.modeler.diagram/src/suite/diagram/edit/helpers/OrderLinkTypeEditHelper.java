package suite.diagram.edit.helpers;

/**
 * @generated
 */
public class OrderLinkTypeEditHelper extends SuiteBaseEditHelper {
}
