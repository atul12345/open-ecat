package suite.diagram.edit.helpers;

/**
 * @generated
 */
public class SendLinkTypeEditHelper extends SuiteBaseEditHelper {
}
