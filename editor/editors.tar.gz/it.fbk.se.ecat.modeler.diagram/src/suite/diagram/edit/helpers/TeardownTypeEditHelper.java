package suite.diagram.edit.helpers;

/**
 * @generated
 */
public class TeardownTypeEditHelper extends SuiteBaseEditHelper {
}
