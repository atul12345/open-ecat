package suite.diagram.edit.policies;

import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;

import suite.SuitePackage;
import suite.diagram.edit.commands.FipaMessageType2CreateCommand;
import suite.diagram.providers.SuiteElementTypes;

/**
 * @generated
 */
public class CheckTypeACLMessageCompartmentItemSemanticEditPolicy extends
		SuiteBaseItemSemanticEditPolicy {

	/**
	 * @generated
	 */
	protected Command getCreateCommand(CreateElementRequest req) {
		if (SuiteElementTypes.FipaMessageType_2008 == req.getElementType()) {
			if (req.getContainmentFeature() == null) {
				req.setContainmentFeature(SuitePackage.eINSTANCE
						.getCheckType_ExpectedValue());
			}
			return getGEFWrapper(new FipaMessageType2CreateCommand(req));
		}
		return super.getCreateCommand(req);
	}

}
