package suite.diagram.edit.policies;

import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;

import suite.SuitePackage;
import suite.diagram.edit.commands.TaskType1CreateCommand;
import suite.diagram.providers.SuiteElementTypes;

/**
 * @generated
 */
public class SetupTypeTestSupportCompartmentItemSemanticEditPolicy extends
		SuiteBaseItemSemanticEditPolicy {

	/**
	 * @generated
	 */
	protected Command getCreateCommand(CreateElementRequest req) {
		if (SuiteElementTypes.TaskType1_2002 == req.getElementType()) {
			if (req.getContainmentFeature() == null) {
				req.setContainmentFeature(SuitePackage.eINSTANCE
						.getTestSupportType_Task());
			}
			return getGEFWrapper(new TaskType1CreateCommand(req));
		}
		return super.getCreateCommand(req);
	}

}
