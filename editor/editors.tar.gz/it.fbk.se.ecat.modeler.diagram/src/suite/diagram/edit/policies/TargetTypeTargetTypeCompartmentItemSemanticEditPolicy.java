package suite.diagram.edit.policies;

import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;

import suite.SuitePackage;
import suite.diagram.edit.commands.GoalPlanTypeCreateCommand;
import suite.diagram.providers.SuiteElementTypes;

/**
 * @generated
 */
public class TargetTypeTargetTypeCompartmentItemSemanticEditPolicy extends
		SuiteBaseItemSemanticEditPolicy {

	/**
	 * @generated
	 */
	protected Command getCreateCommand(CreateElementRequest req) {
		if (SuiteElementTypes.GoalPlanType_2001 == req.getElementType()) {
			if (req.getContainmentFeature() == null) {
				req.setContainmentFeature(SuitePackage.eINSTANCE
						.getTargetType_GoalPlan());
			}
			return getGEFWrapper(new GoalPlanTypeCreateCommand(req));
		}
		return super.getCreateCommand(req);
	}

}
