package suite.diagram.edit.policies;

import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;

import schema.SchemaPackage;
import suite.diagram.edit.commands.ContentTypeCreateCommand;
import suite.diagram.providers.SuiteElementTypes;

/**
 * @generated
 */
public class FipaMessageTypeACLMessageContentCompartmentItemSemanticEditPolicy
		extends SuiteBaseItemSemanticEditPolicy {

	/**
	 * @generated
	 */
	protected Command getCreateCommand(CreateElementRequest req) {
		if (SuiteElementTypes.ContentType_2006 == req.getElementType()) {
			if (req.getContainmentFeature() == null) {
				req.setContainmentFeature(SchemaPackage.eINSTANCE
						.getFipaMessageType_Content());
			}
			return getGEFWrapper(new ContentTypeCreateCommand(req));
		}
		return super.getCreateCommand(req);
	}

}
