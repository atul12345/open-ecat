package suite.diagram.edit.policies;

import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import org.eclipse.gmf.runtime.diagram.ui.editpolicies.CanonicalEditPolicy;
import org.eclipse.gmf.runtime.notation.View;

import suite.SuitePackage;
import suite.diagram.edit.parts.TaskType12EditPart;
import suite.diagram.part.SuiteDiagramUpdater;
import suite.diagram.part.SuiteNodeDescriptor;
import suite.diagram.part.SuiteVisualIDRegistry;

/**
 * @generated
 */
public class TeardownTypeTestTeardownCompartmentCanonicalEditPolicy extends
		CanonicalEditPolicy {

	/**
	 * @generated
	 */
	Set myFeaturesToSynchronize;

	/**
	 * @generated
	 */
	protected List getSemanticChildrenList() {
		View viewObject = (View) getHost().getModel();
		List result = new LinkedList();
		for (Iterator it = SuiteDiagramUpdater
				.getTeardownTypeTestTeardownCompartment_5010SemanticChildren(
						viewObject).iterator(); it.hasNext();) {
			result.add(((SuiteNodeDescriptor) it.next()).getModelElement());
		}
		return result;
	}

	/**
	 * @generated
	 */
	protected boolean isOrphaned(Collection semanticChildren, final View view) {
		int visualID = SuiteVisualIDRegistry.getVisualID(view);
		switch (visualID) {
		case TaskType12EditPart.VISUAL_ID:
			return !semanticChildren.contains(view.getElement())
					|| visualID != SuiteVisualIDRegistry.getNodeVisualID(
							(View) getHost().getModel(), view.getElement());
		}
		return false;
	}

	/**
	 * @generated
	 */
	protected String getDefaultFactoryHint() {
		return null;
	}

	/**
	 * @generated
	 */
	protected Set getFeaturesToSynchronize() {
		if (myFeaturesToSynchronize == null) {
			myFeaturesToSynchronize = new HashSet();
			myFeaturesToSynchronize.add(SuitePackage.eINSTANCE
					.getTestSupportType_Task());
		}
		return myFeaturesToSynchronize;
	}

}
