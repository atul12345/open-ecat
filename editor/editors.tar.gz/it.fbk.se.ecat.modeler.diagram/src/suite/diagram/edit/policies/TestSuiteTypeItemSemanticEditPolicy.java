package suite.diagram.edit.policies;

import org.eclipse.emf.transaction.TransactionalEditingDomain;
import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.diagram.ui.editparts.IGraphicalEditPart;
import org.eclipse.gmf.runtime.emf.commands.core.commands.DuplicateEObjectsCommand;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;
import org.eclipse.gmf.runtime.emf.type.core.requests.DuplicateElementsRequest;

import suite.SuitePackage;
import suite.diagram.edit.commands.SetupTypeCreateCommand;
import suite.diagram.edit.commands.TargetTypeCreateCommand;
import suite.diagram.edit.commands.TeardownTypeCreateCommand;
import suite.diagram.edit.commands.TestCaseTypeCreateCommand;
import suite.diagram.edit.commands.TestSupportType2CreateCommand;
import suite.diagram.edit.commands.TestSupportTypeCreateCommand;
import suite.diagram.providers.SuiteElementTypes;

/**
 * @generated
 */
public class TestSuiteTypeItemSemanticEditPolicy extends
		SuiteBaseItemSemanticEditPolicy {

	/**
	 * @generated
	 */
	protected Command getCreateCommand(CreateElementRequest req) {
		if (SuiteElementTypes.TargetType_1001 == req.getElementType()) {
			if (req.getContainmentFeature() == null) {
				req.setContainmentFeature(SuitePackage.eINSTANCE
						.getTestSuiteType_Target());
			}
			return getGEFWrapper(new TargetTypeCreateCommand(req));
		}
		if (SuiteElementTypes.SetupType_1002 == req.getElementType()) {
			if (req.getContainmentFeature() == null) {
				req.setContainmentFeature(SuitePackage.eINSTANCE
						.getTestSuiteType_Setup());
			}
			return getGEFWrapper(new SetupTypeCreateCommand(req));
		}
		if (SuiteElementTypes.TestCaseType_1003 == req.getElementType()) {
			if (req.getContainmentFeature() == null) {
				req.setContainmentFeature(SuitePackage.eINSTANCE
						.getTestSuiteType_TestCase());
			}
			return getGEFWrapper(new TestCaseTypeCreateCommand(req));
		}
		if (SuiteElementTypes.TeardownType_1004 == req.getElementType()) {
			if (req.getContainmentFeature() == null) {
				req.setContainmentFeature(SuitePackage.eINSTANCE
						.getTestSuiteType_Teardown());
			}
			return getGEFWrapper(new TeardownTypeCreateCommand(req));
		}
		return super.getCreateCommand(req);
	}

	/**
	 * @generated
	 */
	protected Command getDuplicateCommand(DuplicateElementsRequest req) {
		TransactionalEditingDomain editingDomain = ((IGraphicalEditPart) getHost())
				.getEditingDomain();
		return getGEFWrapper(new DuplicateAnythingCommand(editingDomain, req));
	}

	/**
	 * @generated
	 */
	private static class DuplicateAnythingCommand extends
			DuplicateEObjectsCommand {

		/**
		 * @generated
		 */
		public DuplicateAnythingCommand(
				TransactionalEditingDomain editingDomain,
				DuplicateElementsRequest req) {
			super(editingDomain, req.getLabel(), req
					.getElementsToBeDuplicated(), req
					.getAllDuplicatedElementsMap());
		}

	}

}
