package suite.diagram.edit.policies;

import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;

import schema.SchemaPackage;
import suite.diagram.edit.commands.ContentType2CreateCommand;
import suite.diagram.providers.SuiteElementTypes;

/**
 * @generated
 */
public class FipaMessageTypeACLMessageContentCompartment2ItemSemanticEditPolicy
		extends SuiteBaseItemSemanticEditPolicy {

	/**
	 * @generated
	 */
	protected Command getCreateCommand(CreateElementRequest req) {
		if (SuiteElementTypes.ContentType_2009 == req.getElementType()) {
			if (req.getContainmentFeature() == null) {
				req.setContainmentFeature(SchemaPackage.eINSTANCE
						.getFipaMessageType_Content());
			}
			return getGEFWrapper(new ContentType2CreateCommand(req));
		}
		return super.getCreateCommand(req);
	}

}
