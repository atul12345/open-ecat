package suite.diagram.edit.policies;

import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;

import suite.SuitePackage;
import suite.diagram.edit.commands.TActionTypeCreateCommand;
import suite.diagram.providers.SuiteElementTypes;

/**
 * @generated
 */
public class TestScenarioTypeTestScenarioCompartmentItemSemanticEditPolicy
		extends SuiteBaseItemSemanticEditPolicy {

	/**
	 * @generated
	 */
	protected Command getCreateCommand(CreateElementRequest req) {
		if (SuiteElementTypes.TActionType_2004 == req.getElementType()) {
			if (req.getContainmentFeature() == null) {
				req.setContainmentFeature(SuitePackage.eINSTANCE
						.getTestScenarioType_TestAction());
			}
			return getGEFWrapper(new TActionTypeCreateCommand(req));
		}
		return super.getCreateCommand(req);
	}

}
