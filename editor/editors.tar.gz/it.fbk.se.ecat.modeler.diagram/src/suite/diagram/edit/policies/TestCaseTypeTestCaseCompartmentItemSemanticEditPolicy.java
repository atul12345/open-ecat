package suite.diagram.edit.policies;

import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;

import suite.SuitePackage;
import suite.diagram.edit.commands.TestScenarioTypeCreateCommand;
import suite.diagram.providers.SuiteElementTypes;

/**
 * @generated
 */
public class TestCaseTypeTestCaseCompartmentItemSemanticEditPolicy extends
		SuiteBaseItemSemanticEditPolicy {

	/**
	 * @generated
	 */
	protected Command getCreateCommand(CreateElementRequest req) {
		if (SuiteElementTypes.TestScenarioType_2003 == req.getElementType()) {
			if (req.getContainmentFeature() == null) {
				req.setContainmentFeature(SuitePackage.eINSTANCE
						.getTestCaseType_Scenario());
			}
			return getGEFWrapper(new TestScenarioTypeCreateCommand(req));
		}
		return super.getCreateCommand(req);
	}

}
