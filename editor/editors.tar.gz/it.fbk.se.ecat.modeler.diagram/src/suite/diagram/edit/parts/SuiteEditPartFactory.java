package suite.diagram.edit.parts;

import org.eclipse.draw2d.FigureUtilities;
import org.eclipse.draw2d.Label;
import org.eclipse.draw2d.geometry.Dimension;
import org.eclipse.draw2d.geometry.Rectangle;
import org.eclipse.gef.EditPart;
import org.eclipse.gef.EditPartFactory;
import org.eclipse.gef.tools.CellEditorLocator;
import org.eclipse.gmf.runtime.diagram.ui.editparts.ITextAwareEditPart;
import org.eclipse.gmf.runtime.draw2d.ui.figures.WrapLabel;
import org.eclipse.gmf.runtime.notation.View;
import org.eclipse.jface.viewers.CellEditor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Text;

import suite.diagram.part.SuiteVisualIDRegistry;

/**
 * @generated
 */
public class SuiteEditPartFactory implements EditPartFactory {

	/**
	 * @generated
	 */
	public EditPart createEditPart(EditPart context, Object model) {
		if (model instanceof View) {
			View view = (View) model;
			switch (SuiteVisualIDRegistry.getVisualID(view)) {

			case TestSuiteTypeEditPart.VISUAL_ID:
				return new TestSuiteTypeEditPart(view);

			case TargetTypeEditPart.VISUAL_ID:
				return new TargetTypeEditPart(view);

			case TargetTypeAgentEditPart.VISUAL_ID:
				return new TargetTypeAgentEditPart(view);

			case SetupTypeEditPart.VISUAL_ID:
				return new SetupTypeEditPart(view);

			case SetupTypeNameEditPart.VISUAL_ID:
				return new SetupTypeNameEditPart(view);

			case TestCaseTypeEditPart.VISUAL_ID:
				return new TestCaseTypeEditPart(view);

			case TestCaseTypeNameEditPart.VISUAL_ID:
				return new TestCaseTypeNameEditPart(view);

			case TeardownTypeEditPart.VISUAL_ID:
				return new TeardownTypeEditPart(view);

			case TeardownTypeNameEditPart.VISUAL_ID:
				return new TeardownTypeNameEditPart(view);

			case GoalPlanTypeEditPart.VISUAL_ID:
				return new GoalPlanTypeEditPart(view);

			case GoalPlanTypeGoalEditPart.VISUAL_ID:
				return new GoalPlanTypeGoalEditPart(view);

			case TaskType1EditPart.VISUAL_ID:
				return new TaskType1EditPart(view);

			case TaskType1NameEditPart.VISUAL_ID:
				return new TaskType1NameEditPart(view);

			case TestScenarioTypeEditPart.VISUAL_ID:
				return new TestScenarioTypeEditPart(view);

			case TActionTypeEditPart.VISUAL_ID:
				return new TActionTypeEditPart(view);

			case TActionTypeActTypeEditPart.VISUAL_ID:
				return new TActionTypeActTypeEditPart(view);

			case FipaMessageTypeEditPart.VISUAL_ID:
				return new FipaMessageTypeEditPart(view);

			case FipaMessageTypeIdActEditPart.VISUAL_ID:
				return new FipaMessageTypeIdActEditPart(view);

			case ContentTypeEditPart.VISUAL_ID:
				return new ContentTypeEditPart(view);

			case ContentTypeValueEditPart.VISUAL_ID:
				return new ContentTypeValueEditPart(view);

			case CheckTypeEditPart.VISUAL_ID:
				return new CheckTypeEditPart(view);

			case CheckTypeCheckOperatorEditPart.VISUAL_ID:
				return new CheckTypeCheckOperatorEditPart(view);

			case FipaMessageType2EditPart.VISUAL_ID:
				return new FipaMessageType2EditPart(view);

			case FipaMessageTypeActEditPart.VISUAL_ID:
				return new FipaMessageTypeActEditPart(view);

			case ContentType2EditPart.VISUAL_ID:
				return new ContentType2EditPart(view);

			case TaskType12EditPart.VISUAL_ID:
				return new TaskType12EditPart(view);

			case TaskType1Name2EditPart.VISUAL_ID:
				return new TaskType1Name2EditPart(view);

			case TargetTypeTargetTypeCompartmentEditPart.VISUAL_ID:
				return new TargetTypeTargetTypeCompartmentEditPart(view);

			case SetupTypeTestSupportCompartmentEditPart.VISUAL_ID:
				return new SetupTypeTestSupportCompartmentEditPart(view);

			case TestCaseTypeTestCaseCompartmentEditPart.VISUAL_ID:
				return new TestCaseTypeTestCaseCompartmentEditPart(view);

			case TestScenarioTypeTestScenarioCompartmentEditPart.VISUAL_ID:
				return new TestScenarioTypeTestScenarioCompartmentEditPart(view);

			case TActionTypeACLMessageCompartmentEditPart.VISUAL_ID:
				return new TActionTypeACLMessageCompartmentEditPart(view);

			case TActionTypeOracleCompartmentEditPart.VISUAL_ID:
				return new TActionTypeOracleCompartmentEditPart(view);

			case FipaMessageTypeACLMessageContentCompartmentEditPart.VISUAL_ID:
				return new FipaMessageTypeACLMessageContentCompartmentEditPart(
						view);

			case CheckTypeACLMessageCompartmentEditPart.VISUAL_ID:
				return new CheckTypeACLMessageCompartmentEditPart(view);

			case FipaMessageTypeACLMessageContentCompartment2EditPart.VISUAL_ID:
				return new FipaMessageTypeACLMessageContentCompartment2EditPart(
						view);

			case TeardownTypeTestTeardownCompartmentEditPart.VISUAL_ID:
				return new TeardownTypeTestTeardownCompartmentEditPart(view);

			case OrderLinkTypeEditPart.VISUAL_ID:
				return new OrderLinkTypeEditPart(view);

			case OrderLinkTypeDescEditPart.VISUAL_ID:
				return new OrderLinkTypeDescEditPart(view);

			case SendLinkTypeEditPart.VISUAL_ID:
				return new SendLinkTypeEditPart(view);

			case SendLinkTypeNameEditPart.VISUAL_ID:
				return new SendLinkTypeNameEditPart(view);

			case ReceiveLinkTypeEditPart.VISUAL_ID:
				return new ReceiveLinkTypeEditPart(view);

			case ReceiveLinkTypeNameEditPart.VISUAL_ID:
				return new ReceiveLinkTypeNameEditPart(view);

			case GoalLinkTypeEditPart.VISUAL_ID:
				return new GoalLinkTypeEditPart(view);

			case GoalLinkTypeNameEditPart.VISUAL_ID:
				return new GoalLinkTypeNameEditPart(view);
			}
		}
		return createUnrecognizedEditPart(context, model);
	}

	/**
	 * @generated
	 */
	private EditPart createUnrecognizedEditPart(EditPart context, Object model) {
		// Handle creation of unrecognized child node EditParts here
		return null;
	}

	/**
	 * @generated
	 */
	public static CellEditorLocator getTextCellEditorLocator(
			ITextAwareEditPart source) {
		if (source.getFigure() instanceof WrapLabel)
			return new TextCellEditorLocator((WrapLabel) source.getFigure());
		else {
			return new LabelCellEditorLocator((Label) source.getFigure());
		}
	}

	/**
	 * @generated
	 */
	static private class TextCellEditorLocator implements CellEditorLocator {

		/**
		 * @generated
		 */
		private WrapLabel wrapLabel;

		/**
		 * @generated
		 */
		public TextCellEditorLocator(WrapLabel wrapLabel) {
			this.wrapLabel = wrapLabel;
		}

		/**
		 * @generated
		 */
		public WrapLabel getWrapLabel() {
			return wrapLabel;
		}

		/**
		 * @generated
		 */
		public void relocate(CellEditor celleditor) {
			Text text = (Text) celleditor.getControl();
			Rectangle rect = getWrapLabel().getTextBounds().getCopy();
			getWrapLabel().translateToAbsolute(rect);
			if (getWrapLabel().isTextWrapped()
					&& getWrapLabel().getText().length() > 0) {
				rect.setSize(new Dimension(text.computeSize(rect.width,
						SWT.DEFAULT)));
			} else {
				int avr = FigureUtilities.getFontMetrics(text.getFont())
						.getAverageCharWidth();
				rect.setSize(new Dimension(text.computeSize(SWT.DEFAULT,
						SWT.DEFAULT)).expand(avr * 2, 0));
			}
			if (!rect.equals(new Rectangle(text.getBounds()))) {
				text.setBounds(rect.x, rect.y, rect.width, rect.height);
			}
		}

	}

	/**
	 * @generated
	 */
	private static class LabelCellEditorLocator implements CellEditorLocator {

		/**
		 * @generated
		 */
		private Label label;

		/**
		 * @generated
		 */
		public LabelCellEditorLocator(Label label) {
			this.label = label;
		}

		/**
		 * @generated
		 */
		public Label getLabel() {
			return label;
		}

		/**
		 * @generated
		 */
		public void relocate(CellEditor celleditor) {
			Text text = (Text) celleditor.getControl();
			Rectangle rect = getLabel().getTextBounds().getCopy();
			getLabel().translateToAbsolute(rect);
			int avr = FigureUtilities.getFontMetrics(text.getFont())
					.getAverageCharWidth();
			rect.setSize(new Dimension(text.computeSize(SWT.DEFAULT,
					SWT.DEFAULT)).expand(avr * 2, 0));
			if (!rect.equals(new Rectangle(text.getBounds()))) {
				text.setBounds(rect.x, rect.y, rect.width, rect.height);
			}
		}
	}
}
