package suite.diagram.edit.parts;

import org.eclipse.draw2d.Connection;
import org.eclipse.draw2d.PolylineDecoration;
import org.eclipse.draw2d.RotatableDecoration;
import org.eclipse.gef.EditPart;
import org.eclipse.gmf.runtime.diagram.ui.editparts.ConnectionNodeEditPart;
import org.eclipse.gmf.runtime.diagram.ui.editpolicies.EditPolicyRoles;
import org.eclipse.gmf.runtime.draw2d.ui.figures.PolylineConnectionEx;
import org.eclipse.gmf.runtime.draw2d.ui.figures.WrapLabel;
import org.eclipse.gmf.runtime.notation.View;

import suite.diagram.edit.policies.ReceiveLinkTypeItemSemanticEditPolicy;

/**
 * @generated
 */
public class ReceiveLinkTypeEditPart extends ConnectionNodeEditPart {

	/**
	 * @generated
	 */
	public static final int VISUAL_ID = 3003;

	/**
	 * @generated
	 */
	public ReceiveLinkTypeEditPart(View view) {
		super(view);
	}

	/**
	 * @generated
	 */
	protected void createDefaultEditPolicies() {
		super.createDefaultEditPolicies();
		installEditPolicy(EditPolicyRoles.SEMANTIC_ROLE,
				new ReceiveLinkTypeItemSemanticEditPolicy());
	}

	/**
	 * @generated
	 */
	protected boolean addFixedChild(EditPart childEditPart) {
		if (childEditPart instanceof ReceiveLinkTypeNameEditPart) {
			((ReceiveLinkTypeNameEditPart) childEditPart)
					.setLabel(getPrimaryShape()
							.getFigureReceiveLinkNameFigure());
			return true;
		}
		return false;
	}

	/**
	 * @generated
	 */
	protected void addChildVisual(EditPart childEditPart, int index) {
		if (addFixedChild(childEditPart)) {
			return;
		}
		super.addChildVisual(childEditPart, -1);
	}

	/**
	 * Creates figure for this edit part.
	 * 
	 * Body of this method does not depend on settings in generation model
	 * so you may safely remove <i>generated</i> tag and modify it.
	 * 
	 * @generated
	 */

	protected Connection createConnectionFigure() {
		return new ReceiveLinkFigure();
	}

	/**
	 * @generated
	 */
	public ReceiveLinkFigure getPrimaryShape() {
		return (ReceiveLinkFigure) getFigure();
	}

	/**
	 * @generated
	 */
	public class ReceiveLinkFigure extends PolylineConnectionEx {

		/**
		 * @generated
		 */
		private WrapLabel fFigureReceiveLinkNameFigure;

		/**
		 * @generated
		 */
		public ReceiveLinkFigure() {

			createContents();
			setTargetDecoration(createTargetDecoration());
		}

		/**
		 * @generated
		 */
		private void createContents() {

			fFigureReceiveLinkNameFigure = new WrapLabel();
			fFigureReceiveLinkNameFigure.setText("");

			this.add(fFigureReceiveLinkNameFigure);

		}

		/**
		 * @generated
		 */
		private RotatableDecoration createTargetDecoration() {
			PolylineDecoration df = new PolylineDecoration();
			return df;
		}

		/**
		 * @generated
		 */
		public WrapLabel getFigureReceiveLinkNameFigure() {
			return fFigureReceiveLinkNameFigure;
		}

	}

}
