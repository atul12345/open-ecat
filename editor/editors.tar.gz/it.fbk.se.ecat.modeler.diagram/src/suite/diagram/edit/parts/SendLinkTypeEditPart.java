package suite.diagram.edit.parts;

import org.eclipse.draw2d.Connection;
import org.eclipse.draw2d.PolylineDecoration;
import org.eclipse.draw2d.RotatableDecoration;
import org.eclipse.gef.EditPart;
import org.eclipse.gmf.runtime.diagram.ui.editparts.ConnectionNodeEditPart;
import org.eclipse.gmf.runtime.diagram.ui.editpolicies.EditPolicyRoles;
import org.eclipse.gmf.runtime.draw2d.ui.figures.PolylineConnectionEx;
import org.eclipse.gmf.runtime.draw2d.ui.figures.WrapLabel;
import org.eclipse.gmf.runtime.notation.View;

import suite.diagram.edit.policies.SendLinkTypeItemSemanticEditPolicy;

/**
 * @generated
 */
public class SendLinkTypeEditPart extends ConnectionNodeEditPart {

	/**
	 * @generated
	 */
	public static final int VISUAL_ID = 3002;

	/**
	 * @generated
	 */
	public SendLinkTypeEditPart(View view) {
		super(view);
	}

	/**
	 * @generated
	 */
	protected void createDefaultEditPolicies() {
		super.createDefaultEditPolicies();
		installEditPolicy(EditPolicyRoles.SEMANTIC_ROLE,
				new SendLinkTypeItemSemanticEditPolicy());
	}

	/**
	 * @generated
	 */
	protected boolean addFixedChild(EditPart childEditPart) {
		if (childEditPart instanceof SendLinkTypeNameEditPart) {
			((SendLinkTypeNameEditPart) childEditPart)
					.setLabel(getPrimaryShape().getFigureSendLinkNameFigure());
			return true;
		}
		return false;
	}

	/**
	 * @generated
	 */
	protected void addChildVisual(EditPart childEditPart, int index) {
		if (addFixedChild(childEditPart)) {
			return;
		}
		super.addChildVisual(childEditPart, -1);
	}

	/**
	 * Creates figure for this edit part.
	 * 
	 * Body of this method does not depend on settings in generation model
	 * so you may safely remove <i>generated</i> tag and modify it.
	 * 
	 * @generated
	 */

	protected Connection createConnectionFigure() {
		return new SendLinkFigure();
	}

	/**
	 * @generated
	 */
	public SendLinkFigure getPrimaryShape() {
		return (SendLinkFigure) getFigure();
	}

	/**
	 * @generated
	 */
	public class SendLinkFigure extends PolylineConnectionEx {

		/**
		 * @generated
		 */
		private WrapLabel fFigureSendLinkNameFigure;

		/**
		 * @generated
		 */
		public SendLinkFigure() {

			createContents();
			setTargetDecoration(createTargetDecoration());
		}

		/**
		 * @generated
		 */
		private void createContents() {

			fFigureSendLinkNameFigure = new WrapLabel();
			fFigureSendLinkNameFigure.setText("");

			this.add(fFigureSendLinkNameFigure);

		}

		/**
		 * @generated
		 */
		private RotatableDecoration createTargetDecoration() {
			PolylineDecoration df = new PolylineDecoration();
			return df;
		}

		/**
		 * @generated
		 */
		public WrapLabel getFigureSendLinkNameFigure() {
			return fFigureSendLinkNameFigure;
		}

	}

}
