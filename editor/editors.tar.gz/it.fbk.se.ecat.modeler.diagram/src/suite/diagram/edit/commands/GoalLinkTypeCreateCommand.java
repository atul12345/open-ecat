package suite.diagram.edit.commands;

import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.gmf.runtime.common.core.command.CommandResult;
import org.eclipse.gmf.runtime.emf.type.core.commands.CreateElementCommand;
import org.eclipse.gmf.runtime.emf.type.core.requests.ConfigureRequest;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateRelationshipRequest;

import suite.GoalLinkType;
import suite.GoalPlanType;
import suite.SuiteFactory;
import suite.SuitePackage;
import suite.TActionType;
import suite.TestSuiteType;
import suite.diagram.edit.policies.SuiteBaseItemSemanticEditPolicy;

/**
 * @generated
 */
public class GoalLinkTypeCreateCommand extends CreateElementCommand {

	/**
	 * @generated
	 */
	private final EObject source;

	/**
	 * @generated
	 */
	private final EObject target;

	/**
	 * @generated
	 */
	private TestSuiteType container;

	/**
	 * @generated
	 */
	public GoalLinkTypeCreateCommand(CreateRelationshipRequest request,
			EObject source, EObject target) {
		super(request);
		this.source = source;
		this.target = target;
		if (request.getContainmentFeature() == null) {
			setContainmentFeature(SuitePackage.eINSTANCE
					.getTestSuiteType_GoalLink());
		}

		// Find container element for the new link.
		// Climb up by containment hierarchy starting from the source
		// and return the first element that is instance of the container class.
		for (EObject element = source; element != null; element = element
				.eContainer()) {
			if (element instanceof TestSuiteType) {
				container = (TestSuiteType) element;
				super.setElementToEdit(container);
				break;
			}
		}
	}

	/**
	 * @generated
	 */
	public boolean canExecute() {
		if (source == null && target == null) {
			return false;
		}
		if (source != null && !(source instanceof TActionType)) {
			return false;
		}
		if (target != null && !(target instanceof GoalPlanType)) {
			return false;
		}
		if (getSource() == null) {
			return true; // link creation is in progress; source is not defined yet
		}
		// target may be null here but it's possible to check constraint
		if (getContainer() == null) {
			return false;
		}
		return SuiteBaseItemSemanticEditPolicy.LinkConstraints
				.canCreateGoalLinkType_3004(getContainer(), getSource(),
						getTarget());
	}

	/**
	 * @generated
	 */
	protected EObject doDefaultElementCreation() {
		// suite.GoalLinkType newElement = (suite.GoalLinkType) super.doDefaultElementCreation();
		GoalLinkType newElement = SuiteFactory.eINSTANCE.createGoalLinkType();
		getContainer().getGoalLink().add(newElement);
		newElement.setSource(getSource());
		newElement.setTarget(getTarget());
		return newElement;
	}

	/**
	 * @generated
	 */
	protected EClass getEClassToEdit() {
		return SuitePackage.eINSTANCE.getTestSuiteType();
	}

	/**
	 * @generated
	 */
	protected CommandResult doExecuteWithResult(IProgressMonitor monitor,
			IAdaptable info) throws ExecutionException {
		if (!canExecute()) {
			throw new ExecutionException(
					"Invalid arguments in create link command"); //$NON-NLS-1$
		}
		return super.doExecuteWithResult(monitor, info);
	}

	/**
	 * @generated
	 */
	protected ConfigureRequest createConfigureRequest() {
		ConfigureRequest request = super.createConfigureRequest();
		request.setParameter(CreateRelationshipRequest.SOURCE, getSource());
		request.setParameter(CreateRelationshipRequest.TARGET, getTarget());
		return request;
	}

	/**
	 * @generated
	 */
	protected void setElementToEdit(EObject element) {
		throw new UnsupportedOperationException();
	}

	/**
	 * @generated
	 */
	protected TActionType getSource() {
		return (TActionType) source;
	}

	/**
	 * @generated
	 */
	protected GoalPlanType getTarget() {
		return (GoalPlanType) target;
	}

	/**
	 * @generated
	 */
	public TestSuiteType getContainer() {
		return container;
	}
}
