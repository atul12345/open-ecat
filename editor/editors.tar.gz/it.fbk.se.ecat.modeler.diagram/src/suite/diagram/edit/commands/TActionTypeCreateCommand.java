package suite.diagram.edit.commands;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.gmf.runtime.emf.type.core.commands.CreateElementCommand;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;
import org.eclipse.gmf.runtime.notation.View;

import suite.SuitePackage;
import suite.TActionType;
import suite.diagram.providers.SuiteElementTypes;

/**
 * @generated
 */
public class TActionTypeCreateCommand extends CreateElementCommand {

	/**
	 * @generated
	 */
	public TActionTypeCreateCommand(CreateElementRequest req) {
		super(req);
	}

	/**
	 * @generated
	 */
	protected EObject getElementToEdit() {
		EObject container = ((CreateElementRequest) getRequest())
				.getContainer();
		if (container instanceof View) {
			container = ((View) container).getElement();
		}
		return container;
	}

	/**
	 * @generated
	 */
	protected EClass getEClassToEdit() {
		return SuitePackage.eINSTANCE.getTestScenarioType();
	}

	/**
	 * @generated
	 */
	protected EObject doDefaultElementCreation() {
		TActionType newElement = (TActionType) super.doDefaultElementCreation();
		if (newElement != null) {
			SuiteElementTypes.Initializers.TActionType_2004.init(newElement);
		}
		return newElement;
	}

}
