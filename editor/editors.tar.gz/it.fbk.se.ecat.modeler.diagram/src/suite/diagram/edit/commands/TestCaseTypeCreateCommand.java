package suite.diagram.edit.commands;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.gmf.runtime.emf.type.core.commands.CreateElementCommand;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;
import org.eclipse.gmf.runtime.notation.View;

import suite.SuitePackage;
import suite.TestCaseType;
import suite.diagram.providers.SuiteElementTypes;

/**
 * @generated
 */
public class TestCaseTypeCreateCommand extends CreateElementCommand {

	/**
	 * @generated
	 */
	public TestCaseTypeCreateCommand(CreateElementRequest req) {
		super(req);
	}

	/**
	 * @generated
	 */
	protected EObject getElementToEdit() {
		EObject container = ((CreateElementRequest) getRequest())
				.getContainer();
		if (container instanceof View) {
			container = ((View) container).getElement();
		}
		return container;
	}

	/**
	 * @generated
	 */
	protected EClass getEClassToEdit() {
		return SuitePackage.eINSTANCE.getTestSuiteType();
	}

	/**
	 * @generated
	 */
	protected EObject doDefaultElementCreation() {
		TestCaseType newElement = (TestCaseType) super
				.doDefaultElementCreation();
		if (newElement != null) {
			SuiteElementTypes.Initializers.TestCaseType_1003.init(newElement);
		}
		return newElement;
	}

}
