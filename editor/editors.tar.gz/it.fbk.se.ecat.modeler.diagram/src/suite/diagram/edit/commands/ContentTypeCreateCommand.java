package suite.diagram.edit.commands;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.gmf.runtime.emf.type.core.commands.CreateElementCommand;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;
import org.eclipse.gmf.runtime.notation.View;

import schema.ContentType;
import schema.FipaMessageType;
import schema.SchemaPackage;
import suite.diagram.providers.SuiteElementTypes;

/**
 * @generated
 */
public class ContentTypeCreateCommand extends CreateElementCommand {

	/**
	 * @generated
	 */
	public ContentTypeCreateCommand(CreateElementRequest req) {
		super(req);
	}

	/**
	 * @generated
	 */
	protected EObject getElementToEdit() {
		EObject container = ((CreateElementRequest) getRequest())
				.getContainer();
		if (container instanceof View) {
			container = ((View) container).getElement();
		}
		return container;
	}

	/**
	 * @generated
	 */
	public boolean canExecute() {
		FipaMessageType container = (FipaMessageType) getElementToEdit();
		if (container.getContent() != null) {
			return false;
		}
		return true;
	}

	/**
	 * @generated
	 */
	protected EClass getEClassToEdit() {
		return SchemaPackage.eINSTANCE.getFipaMessageType();
	}

	/**
	 * @generated
	 */
	protected EObject doDefaultElementCreation() {
		ContentType newElement = (ContentType) super.doDefaultElementCreation();
		if (newElement != null) {
			SuiteElementTypes.Initializers.ContentType_2006.init(newElement);
		}
		return newElement;
	}

}
