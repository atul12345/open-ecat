package suite.diagram.edit.commands;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.gmf.runtime.emf.type.core.commands.CreateElementCommand;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;
import org.eclipse.gmf.runtime.notation.View;

import suite.GoalPlanType;
import suite.SuitePackage;
import suite.diagram.providers.SuiteElementTypes;

/**
 * @generated
 */
public class GoalPlanTypeCreateCommand extends CreateElementCommand {

	/**
	 * @generated
	 */
	public GoalPlanTypeCreateCommand(CreateElementRequest req) {
		super(req);
	}

	/**
	 * @generated
	 */
	protected EObject getElementToEdit() {
		EObject container = ((CreateElementRequest) getRequest())
				.getContainer();
		if (container instanceof View) {
			container = ((View) container).getElement();
		}
		return container;
	}

	/**
	 * @generated
	 */
	protected EClass getEClassToEdit() {
		return SuitePackage.eINSTANCE.getTargetType();
	}

	/**
	 * @generated
	 */
	protected EObject doDefaultElementCreation() {
		GoalPlanType newElement = (GoalPlanType) super
				.doDefaultElementCreation();
		if (newElement != null) {
			SuiteElementTypes.Initializers.GoalPlanType_2001.init(newElement);
		}
		return newElement;
	}

}
