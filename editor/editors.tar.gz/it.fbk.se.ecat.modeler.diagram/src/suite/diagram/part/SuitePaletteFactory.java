package suite.diagram.part;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.gef.Tool;
import org.eclipse.gef.palette.PaletteContainer;
import org.eclipse.gef.palette.PaletteDrawer;
import org.eclipse.gef.palette.PaletteGroup;
import org.eclipse.gef.palette.PaletteRoot;
import org.eclipse.gef.palette.ToolEntry;
import org.eclipse.gmf.runtime.diagram.ui.tools.UnspecifiedTypeConnectionTool;
import org.eclipse.gmf.runtime.diagram.ui.tools.UnspecifiedTypeCreationTool;

import suite.diagram.providers.SuiteElementTypes;

/**
 * @generated
 */
public class SuitePaletteFactory {

	/**
	 * @generated
	 */
	public void fillPalette(PaletteRoot paletteRoot) {
		paletteRoot.add(createSuiteTool1Group());
		paletteRoot.add(createFIPAMessage2Group());
		paletteRoot.add(createLink3Group());
	}

	/**
	 * Creates "Suite Tool" palette tool group
	 * @generated
	 */
	private PaletteContainer createSuiteTool1Group() {
		PaletteDrawer paletteContainer = new PaletteDrawer(
				Messages.SuiteTool1Group_title);
		paletteContainer.setDescription(Messages.SuiteTool1Group_desc);
		paletteContainer.add(createOracle1CreationTool());
		paletteContainer.add(createGoalPlan2CreationTool());
		paletteContainer.add(createTestAction3CreationTool());
		paletteContainer.add(createTargetAgent4CreationTool());
		paletteContainer.add(createSupportAction5CreationTool());
		paletteContainer.add(createTestCase6CreationTool());
		paletteContainer.add(createTestScenario7CreationTool());
		paletteContainer.add(createSetup8CreationTool());
		paletteContainer.add(createTeardown9CreationTool());
		return paletteContainer;
	}

	/**
	 * Creates "FIPA Message" palette tool group
	 * @generated
	 */
	private PaletteContainer createFIPAMessage2Group() {
		PaletteDrawer paletteContainer = new PaletteDrawer(
				Messages.FIPAMessage2Group_title);
		paletteContainer.setDescription(Messages.FIPAMessage2Group_desc);
		paletteContainer.add(createACLMessage1CreationTool());
		paletteContainer.add(createContent2CreationTool());
		return paletteContainer;
	}

	/**
	 * Creates "Link" palette tool group
	 * @generated
	 */
	private PaletteContainer createLink3Group() {
		PaletteDrawer paletteContainer = new PaletteDrawer(
				Messages.Link3Group_title);
		paletteContainer.add(createSubsequenceLink1CreationTool());
		paletteContainer.add(createGoalLink2CreationTool());
		paletteContainer.add(createSendLink3CreationTool());
		paletteContainer.add(createReceiveLink4CreationTool());
		return paletteContainer;
	}

	/**
	 * @generated
	 */
	private ToolEntry createOracle1CreationTool() {
		List/*<IElementType>*/types = new ArrayList/*<IElementType>*/(1);
		types.add(SuiteElementTypes.CheckType_2007);
		NodeToolEntry entry = new NodeToolEntry(
				Messages.Oracle1CreationTool_title,
				Messages.Oracle1CreationTool_desc, types);
		entry.setSmallIcon(SuiteElementTypes
				.getImageDescriptor(SuiteElementTypes.CheckType_2007));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createGoalPlan2CreationTool() {
		List/*<IElementType>*/types = new ArrayList/*<IElementType>*/(1);
		types.add(SuiteElementTypes.GoalPlanType_2001);
		NodeToolEntry entry = new NodeToolEntry(
				Messages.GoalPlan2CreationTool_title,
				Messages.GoalPlan2CreationTool_desc, types);
		entry.setSmallIcon(SuiteElementTypes
				.getImageDescriptor(SuiteElementTypes.GoalPlanType_2001));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createTestAction3CreationTool() {
		List/*<IElementType>*/types = new ArrayList/*<IElementType>*/(1);
		types.add(SuiteElementTypes.TActionType_2004);
		NodeToolEntry entry = new NodeToolEntry(
				Messages.TestAction3CreationTool_title,
				Messages.TestAction3CreationTool_desc, types);
		entry.setSmallIcon(SuiteElementTypes
				.getImageDescriptor(SuiteElementTypes.TActionType_2004));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createTargetAgent4CreationTool() {
		List/*<IElementType>*/types = new ArrayList/*<IElementType>*/(1);
		types.add(SuiteElementTypes.TargetType_1001);
		NodeToolEntry entry = new NodeToolEntry(
				Messages.TargetAgent4CreationTool_title,
				Messages.TargetAgent4CreationTool_desc, types);
		entry.setSmallIcon(SuiteElementTypes
				.getImageDescriptor(SuiteElementTypes.TargetType_1001));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createSupportAction5CreationTool() {
		List/*<IElementType>*/types = new ArrayList/*<IElementType>*/(2);
		types.add(SuiteElementTypes.TaskType1_2002);
		types.add(SuiteElementTypes.TaskType1_2010);
		NodeToolEntry entry = new NodeToolEntry(
				Messages.SupportAction5CreationTool_title,
				Messages.SupportAction5CreationTool_desc, types);
		entry.setSmallIcon(SuiteElementTypes
				.getImageDescriptor(SuiteElementTypes.TaskType1_2002));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createTestCase6CreationTool() {
		List/*<IElementType>*/types = new ArrayList/*<IElementType>*/(1);
		types.add(SuiteElementTypes.TestCaseType_1003);
		NodeToolEntry entry = new NodeToolEntry(
				Messages.TestCase6CreationTool_title,
				Messages.TestCase6CreationTool_desc, types);
		entry.setSmallIcon(SuiteElementTypes
				.getImageDescriptor(SuiteElementTypes.TestCaseType_1003));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createTestScenario7CreationTool() {
		List/*<IElementType>*/types = new ArrayList/*<IElementType>*/(1);
		types.add(SuiteElementTypes.TestScenarioType_2003);
		NodeToolEntry entry = new NodeToolEntry(
				Messages.TestScenario7CreationTool_title,
				Messages.TestScenario7CreationTool_desc, types);
		entry.setSmallIcon(SuiteElementTypes
				.getImageDescriptor(SuiteElementTypes.TestScenarioType_2003));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createSetup8CreationTool() {
		List/*<IElementType>*/types = new ArrayList/*<IElementType>*/(1);
		types.add(SuiteElementTypes.SetupType_1002);
		NodeToolEntry entry = new NodeToolEntry(
				Messages.Setup8CreationTool_title,
				Messages.Setup8CreationTool_desc, types);
		entry.setSmallIcon(SuiteElementTypes
				.getImageDescriptor(SuiteElementTypes.SetupType_1002));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createTeardown9CreationTool() {
		List/*<IElementType>*/types = new ArrayList/*<IElementType>*/(1);
		types.add(SuiteElementTypes.TeardownType_1004);
		NodeToolEntry entry = new NodeToolEntry(
				Messages.Teardown9CreationTool_title,
				Messages.Teardown9CreationTool_desc, types);
		entry.setSmallIcon(SuiteElementTypes
				.getImageDescriptor(SuiteElementTypes.TeardownType_1004));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createACLMessage1CreationTool() {
		List/*<IElementType>*/types = new ArrayList/*<IElementType>*/(2);
		types.add(SuiteElementTypes.FipaMessageType_2005);
		types.add(SuiteElementTypes.FipaMessageType_2008);
		NodeToolEntry entry = new NodeToolEntry(
				Messages.ACLMessage1CreationTool_title,
				Messages.ACLMessage1CreationTool_desc, types);
		entry.setSmallIcon(SuiteElementTypes
				.getImageDescriptor(SuiteElementTypes.FipaMessageType_2005));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createContent2CreationTool() {
		List/*<IElementType>*/types = new ArrayList/*<IElementType>*/(2);
		types.add(SuiteElementTypes.ContentType_2006);
		types.add(SuiteElementTypes.ContentType_2009);
		NodeToolEntry entry = new NodeToolEntry(
				Messages.Content2CreationTool_title,
				Messages.Content2CreationTool_desc, types);
		entry.setSmallIcon(SuiteElementTypes
				.getImageDescriptor(SuiteElementTypes.ContentType_2006));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createSubsequenceLink1CreationTool() {
		List/*<IElementType>*/types = new ArrayList/*<IElementType>*/(1);
		types.add(SuiteElementTypes.OrderLinkType_3001);
		LinkToolEntry entry = new LinkToolEntry(
				Messages.SubsequenceLink1CreationTool_title,
				Messages.SubsequenceLink1CreationTool_desc, types);
		entry.setSmallIcon(SuiteElementTypes
				.getImageDescriptor(SuiteElementTypes.OrderLinkType_3001));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createGoalLink2CreationTool() {
		List/*<IElementType>*/types = new ArrayList/*<IElementType>*/(1);
		types.add(SuiteElementTypes.GoalLinkType_3004);
		LinkToolEntry entry = new LinkToolEntry(
				Messages.GoalLink2CreationTool_title,
				Messages.GoalLink2CreationTool_desc, types);
		entry.setSmallIcon(SuiteElementTypes
				.getImageDescriptor(SuiteElementTypes.GoalLinkType_3004));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createSendLink3CreationTool() {
		List/*<IElementType>*/types = new ArrayList/*<IElementType>*/(1);
		types.add(SuiteElementTypes.SendLinkType_3002);
		LinkToolEntry entry = new LinkToolEntry(
				Messages.SendLink3CreationTool_title,
				Messages.SendLink3CreationTool_desc, types);
		entry.setSmallIcon(SuiteElementTypes
				.getImageDescriptor(SuiteElementTypes.SendLinkType_3002));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createReceiveLink4CreationTool() {
		List/*<IElementType>*/types = new ArrayList/*<IElementType>*/(1);
		types.add(SuiteElementTypes.ReceiveLinkType_3003);
		LinkToolEntry entry = new LinkToolEntry(
				Messages.ReceiveLink4CreationTool_title,
				Messages.ReceiveLink4CreationTool_desc, types);
		entry.setSmallIcon(SuiteElementTypes
				.getImageDescriptor(SuiteElementTypes.ReceiveLinkType_3003));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private static class NodeToolEntry extends ToolEntry {

		/**
		 * @generated
		 */
		private final List elementTypes;

		/**
		 * @generated
		 */
		private NodeToolEntry(String title, String description,
				List elementTypes) {
			super(title, description, null, null);
			this.elementTypes = elementTypes;
		}

		/**
		 * @generated
		 */
		public Tool createTool() {
			Tool tool = new UnspecifiedTypeCreationTool(elementTypes);
			tool.setProperties(getToolProperties());
			return tool;
		}
	}

	/**
	 * @generated
	 */
	private static class LinkToolEntry extends ToolEntry {

		/**
		 * @generated
		 */
		private final List relationshipTypes;

		/**
		 * @generated
		 */
		private LinkToolEntry(String title, String description,
				List relationshipTypes) {
			super(title, description, null, null);
			this.relationshipTypes = relationshipTypes;
		}

		/**
		 * @generated
		 */
		public Tool createTool() {
			Tool tool = new UnspecifiedTypeConnectionTool(relationshipTypes);
			tool.setProperties(getToolProperties());
			return tool;
		}
	}
}
