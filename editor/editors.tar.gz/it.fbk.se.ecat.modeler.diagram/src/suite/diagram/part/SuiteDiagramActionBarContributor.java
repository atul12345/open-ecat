package suite.diagram.part;

import org.eclipse.gmf.runtime.diagram.ui.parts.DiagramActionBarContributor;

/**
 * @generated
 */
public class SuiteDiagramActionBarContributor extends
		DiagramActionBarContributor {

	/**
	 * @generated
	 */
	protected Class getEditorClass() {
		return SuiteDiagramEditor.class;
	}

	/**
	 * @generated
	 */
	protected String getEditorId() {
		return SuiteDiagramEditor.ID;
	}
}
