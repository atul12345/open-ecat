package suite.diagram.part;

import org.eclipse.osgi.util.NLS;

/**
 * @generated
 */
public class Messages extends NLS {

	/**
	 * @generated
	 */
	static {
		NLS.initializeMessages("messages", Messages.class); //$NON-NLS-1$
	}

	/**
	 * @generated
	 */
	private Messages() {
	}

	/**
	 * @generated
	 */
	public static String SuiteCreationWizardTitle;

	/**
	 * @generated
	 */
	public static String SuiteCreationWizard_DiagramModelFilePageTitle;

	/**
	 * @generated
	 */
	public static String SuiteCreationWizard_DiagramModelFilePageDescription;

	/**
	 * @generated
	 */
	public static String SuiteCreationWizard_DomainModelFilePageTitle;

	/**
	 * @generated
	 */
	public static String SuiteCreationWizard_DomainModelFilePageDescription;

	/**
	 * @generated
	 */
	public static String SuiteCreationWizardOpenEditorError;

	/**
	 * @generated
	 */
	public static String SuiteCreationWizardCreationError;

	/**
	 * @generated
	 */
	public static String SuiteCreationWizardPageExtensionError;

	/**
	 * @generated
	 */
	public static String SuiteDiagramEditorUtil_OpenModelResourceErrorDialogTitle;

	/**
	 * @generated
	 */
	public static String SuiteDiagramEditorUtil_OpenModelResourceErrorDialogMessage;

	/**
	 * @generated
	 */
	public static String SuiteDiagramEditorUtil_CreateDiagramProgressTask;

	/**
	 * @generated
	 */
	public static String SuiteDiagramEditorUtil_CreateDiagramCommandLabel;

	/**
	 * @generated
	 */
	public static String SuiteDocumentProvider_isModifiable;

	/**
	 * @generated
	 */
	public static String SuiteDocumentProvider_handleElementContentChanged;

	/**
	 * @generated
	 */
	public static String SuiteDocumentProvider_IncorrectInputError;

	/**
	 * @generated
	 */
	public static String SuiteDocumentProvider_NoDiagramInResourceError;

	/**
	 * @generated
	 */
	public static String SuiteDocumentProvider_DiagramLoadingError;

	/**
	 * @generated
	 */
	public static String SuiteDocumentProvider_UnsynchronizedFileSaveError;

	/**
	 * @generated
	 */
	public static String SuiteDocumentProvider_SaveDiagramTask;

	/**
	 * @generated
	 */
	public static String SuiteDocumentProvider_SaveNextResourceTask;

	/**
	 * @generated
	 */
	public static String SuiteDocumentProvider_SaveAsOperation;

	/**
	 * @generated
	 */
	public static String SuiteInitDiagramFileAction_InitDiagramFileResourceErrorDialogTitle;

	/**
	 * @generated
	 */
	public static String SuiteInitDiagramFileAction_InitDiagramFileResourceErrorDialogMessage;

	/**
	 * @generated
	 */
	public static String SuiteInitDiagramFileAction_InitDiagramFileWizardTitle;

	/**
	 * @generated
	 */
	public static String SuiteInitDiagramFileAction_OpenModelFileDialogTitle;

	/**
	 * @generated
	 */
	public static String SuiteNewDiagramFileWizard_CreationPageName;

	/**
	 * @generated
	 */
	public static String SuiteNewDiagramFileWizard_CreationPageTitle;

	/**
	 * @generated
	 */
	public static String SuiteNewDiagramFileWizard_CreationPageDescription;

	/**
	 * @generated
	 */
	public static String SuiteNewDiagramFileWizard_RootSelectionPageName;

	/**
	 * @generated
	 */
	public static String SuiteNewDiagramFileWizard_RootSelectionPageTitle;

	/**
	 * @generated
	 */
	public static String SuiteNewDiagramFileWizard_RootSelectionPageDescription;

	/**
	 * @generated
	 */
	public static String SuiteNewDiagramFileWizard_RootSelectionPageSelectionTitle;

	/**
	 * @generated
	 */
	public static String SuiteNewDiagramFileWizard_RootSelectionPageNoSelectionMessage;

	/**
	 * @generated
	 */
	public static String SuiteNewDiagramFileWizard_RootSelectionPageInvalidSelectionMessage;

	/**
	 * @generated
	 */
	public static String SuiteNewDiagramFileWizard_InitDiagramCommand;

	/**
	 * @generated
	 */
	public static String SuiteNewDiagramFileWizard_IncorrectRootError;

	/**
	 * @generated
	 */
	public static String SuiteDiagramEditor_SavingDeletedFile;

	/**
	 * @generated
	 */
	public static String SuiteDiagramEditor_SaveAsErrorTitle;

	/**
	 * @generated
	 */
	public static String SuiteDiagramEditor_SaveAsErrorMessage;

	/**
	 * @generated
	 */
	public static String SuiteDiagramEditor_SaveErrorTitle;

	/**
	 * @generated
	 */
	public static String SuiteDiagramEditor_SaveErrorMessage;

	/**
	 * @generated
	 */
	public static String SuiteElementChooserDialog_SelectModelElementTitle;

	/**
	 * @generated
	 */
	public static String ModelElementSelectionPageMessage;

	/**
	 * @generated
	 */
	public static String ValidateActionMessage;

	/**
	 * @generated
	 */
	public static String SuiteTool1Group_title;

	/**
	 * @generated
	 */
	public static String SuiteTool1Group_desc;

	/**
	 * @generated
	 */
	public static String FIPAMessage2Group_title;

	/**
	 * @generated
	 */
	public static String FIPAMessage2Group_desc;

	/**
	 * @generated
	 */
	public static String Link3Group_title;

	/**
	 * @generated
	 */
	public static String Oracle1CreationTool_title;

	/**
	 * @generated
	 */
	public static String Oracle1CreationTool_desc;

	/**
	 * @generated
	 */
	public static String GoalPlan2CreationTool_title;

	/**
	 * @generated
	 */
	public static String GoalPlan2CreationTool_desc;

	/**
	 * @generated
	 */
	public static String TestAction3CreationTool_title;

	/**
	 * @generated
	 */
	public static String TestAction3CreationTool_desc;

	/**
	 * @generated
	 */
	public static String TargetAgent4CreationTool_title;

	/**
	 * @generated
	 */
	public static String TargetAgent4CreationTool_desc;

	/**
	 * @generated
	 */
	public static String SupportAction5CreationTool_title;

	/**
	 * @generated
	 */
	public static String SupportAction5CreationTool_desc;

	/**
	 * @generated
	 */
	public static String TestCase6CreationTool_title;

	/**
	 * @generated
	 */
	public static String TestCase6CreationTool_desc;

	/**
	 * @generated
	 */
	public static String TestScenario7CreationTool_title;

	/**
	 * @generated
	 */
	public static String TestScenario7CreationTool_desc;

	/**
	 * @generated
	 */
	public static String Setup8CreationTool_title;

	/**
	 * @generated
	 */
	public static String Setup8CreationTool_desc;

	/**
	 * @generated
	 */
	public static String Teardown9CreationTool_title;

	/**
	 * @generated
	 */
	public static String Teardown9CreationTool_desc;

	/**
	 * @generated
	 */
	public static String ACLMessage1CreationTool_title;

	/**
	 * @generated
	 */
	public static String ACLMessage1CreationTool_desc;

	/**
	 * @generated
	 */
	public static String Content2CreationTool_title;

	/**
	 * @generated
	 */
	public static String Content2CreationTool_desc;

	/**
	 * @generated
	 */
	public static String SubsequenceLink1CreationTool_title;

	/**
	 * @generated
	 */
	public static String SubsequenceLink1CreationTool_desc;

	/**
	 * @generated
	 */
	public static String GoalLink2CreationTool_title;

	/**
	 * @generated
	 */
	public static String GoalLink2CreationTool_desc;

	/**
	 * @generated
	 */
	public static String SendLink3CreationTool_title;

	/**
	 * @generated
	 */
	public static String SendLink3CreationTool_desc;

	/**
	 * @generated
	 */
	public static String ReceiveLink4CreationTool_title;

	/**
	 * @generated
	 */
	public static String ReceiveLink4CreationTool_desc;

	/**
	 * @generated
	 */
	public static String TargetTypeTargetTypeCompartmentEditPart_title;

	/**
	 * @generated
	 */
	public static String SetupTypeTestSupportCompartmentEditPart_title;

	/**
	 * @generated
	 */
	public static String TestCaseTypeTestCaseCompartmentEditPart_title;

	/**
	 * @generated
	 */
	public static String TestScenarioTypeTestScenarioCompartmentEditPart_title;

	/**
	 * @generated
	 */
	public static String TActionTypeACLMessageCompartmentEditPart_title;

	/**
	 * @generated
	 */
	public static String TActionTypeOracleCompartmentEditPart_title;

	/**
	 * @generated
	 */
	public static String FipaMessageTypeACLMessageContentCompartmentEditPart_title;

	/**
	 * @generated
	 */
	public static String CheckTypeACLMessageCompartmentEditPart_title;

	/**
	 * @generated
	 */
	public static String FipaMessageTypeACLMessageContentCompartment2EditPart_title;

	/**
	 * @generated
	 */
	public static String TeardownTypeTestTeardownCompartmentEditPart_title;

	/**
	 * @generated
	 */
	public static String CommandName_OpenDiagram;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_TestSuiteType_79_links;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_TargetType_1001_incominglinks;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_TargetType_1001_outgoinglinks;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_GoalPlanType_2001_incominglinks;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_TActionType_2004_incominglinks;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_TActionType_2004_outgoinglinks;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_OrderLinkType_3001_target;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_OrderLinkType_3001_source;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_SendLinkType_3002_target;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_SendLinkType_3002_source;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_ReceiveLinkType_3003_target;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_ReceiveLinkType_3003_source;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_GoalLinkType_3004_target;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_GoalLinkType_3004_source;

	/**
	 * @generated
	 */
	public static String NavigatorActionProvider_OpenDiagramActionName;

	/**
	 * @generated
	 */
	public static String AbstractParser_UnexpectedValueTypeMessage;

	/**
	 * @generated
	 */
	public static String AbstractParser_WrongStringConversionMessage;

	/**
	 * @generated
	 */
	public static String AbstractParser_UnknownLiteralMessage;

	/**
	 * @generated
	 */
	public static String MessageFormatParser_InvalidInputError;

	/**
	 * @generated
	 */
	public static String SuiteModelingAssistantProviderTitle;

	/**
	 * @generated
	 */
	public static String SuiteModelingAssistantProviderMessage;

	//TODO: put accessor fields manually	
}
