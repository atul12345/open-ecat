package suite.diagram.part;

import org.eclipse.core.expressions.PropertyTester;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import schema.SchemaPackage;
import suite.SuitePackage;

/**
 * @generated
 */
public class SuiteDomainModelElementTester extends PropertyTester {

	/**
	 * @generated
	 */
	public boolean test(Object receiver, String method, Object[] args,
			Object expectedValue) {
		if (false == receiver instanceof EObject) {
			return false;
		}
		EObject eObject = (EObject) receiver;
		EClass eClass = eObject.eClass();
		if (eClass == SuitePackage.eINSTANCE.getCheckType()) {
			return true;
		}
		if (eClass == SuitePackage.eINSTANCE.getConditionType()) {
			return true;
		}
		if (eClass == SuitePackage.eINSTANCE.getDocumentRoot()) {
			return true;
		}
		if (eClass == SuitePackage.eINSTANCE.getExpressionType()) {
			return true;
		}
		if (eClass == SuitePackage.eINSTANCE.getGoalPlanType()) {
			return true;
		}
		if (eClass == SuitePackage.eINSTANCE.getParamType()) {
			return true;
		}
		if (eClass == SuitePackage.eINSTANCE.getTActionType()) {
			return true;
		}
		if (eClass == SuitePackage.eINSTANCE.getTargetType()) {
			return true;
		}
		if (eClass == SuitePackage.eINSTANCE.getTaskType1()) {
			return true;
		}
		if (eClass == SuitePackage.eINSTANCE.getTestCaseType()) {
			return true;
		}
		if (eClass == SuitePackage.eINSTANCE.getTestScenarioType()) {
			return true;
		}
		if (eClass == SuitePackage.eINSTANCE.getTestSuiteType()) {
			return true;
		}
		if (eClass == SuitePackage.eINSTANCE.getTestSupportType()) {
			return true;
		}
		if (eClass == SuitePackage.eINSTANCE.getOrderLinkType()) {
			return true;
		}
		if (eClass == SuitePackage.eINSTANCE.getSetupType()) {
			return true;
		}
		if (eClass == SuitePackage.eINSTANCE.getTeardownType()) {
			return true;
		}
		if (eClass == SuitePackage.eINSTANCE.getGoalLinkType()) {
			return true;
		}
		if (eClass == SuitePackage.eINSTANCE.getSendLinkType()) {
			return true;
		}
		if (eClass == SuitePackage.eINSTANCE.getReceiveLinkType()) {
			return true;
		}
		if (eClass == SchemaPackage.eINSTANCE.getAddressesType()) {
			return true;
		}
		if (eClass == SchemaPackage.eINSTANCE.getAgentIdentifierType()) {
			return true;
		}
		if (eClass == SchemaPackage.eINSTANCE.getContentType()) {
			return true;
		}
		if (eClass == SchemaPackage.eINSTANCE.getDocumentRoot()) {
			return true;
		}
		if (eClass == SchemaPackage.eINSTANCE.getFipaMessageType()) {
			return true;
		}
		if (eClass == SchemaPackage.eINSTANCE.getReceiverType()) {
			return true;
		}
		if (eClass == SchemaPackage.eINSTANCE.getReplyByType()) {
			return true;
		}
		if (eClass == SchemaPackage.eINSTANCE.getReplyToType()) {
			return true;
		}
		if (eClass == SchemaPackage.eINSTANCE.getResolversType()) {
			return true;
		}
		if (eClass == SchemaPackage.eINSTANCE.getSenderType()) {
			return true;
		}
		if (eClass == SchemaPackage.eINSTANCE.getUrlType()) {
			return true;
		}
		if (eClass == SchemaPackage.eINSTANCE.getUserDefinedType()) {
			return true;
		}
		return false;
	}

}
