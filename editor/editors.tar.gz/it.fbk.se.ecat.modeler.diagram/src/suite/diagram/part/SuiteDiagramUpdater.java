package suite.diagram.part;

import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.gmf.runtime.notation.View;

import schema.ContentType;
import schema.FipaMessageType;
import suite.CheckType;
import suite.GoalLinkType;
import suite.GoalPlanType;
import suite.OrderLinkType;
import suite.ReceiveLinkType;
import suite.SendLinkType;
import suite.SetupType;
import suite.SuitePackage;
import suite.TActionType;
import suite.TargetType;
import suite.TaskType1;
import suite.TeardownType;
import suite.TestCaseType;
import suite.TestScenarioType;
import suite.TestSuiteType;
import suite.TestSupportType;
import suite.diagram.edit.parts.CheckTypeACLMessageCompartmentEditPart;
import suite.diagram.edit.parts.CheckTypeEditPart;
import suite.diagram.edit.parts.ContentType2EditPart;
import suite.diagram.edit.parts.ContentTypeEditPart;
import suite.diagram.edit.parts.FipaMessageType2EditPart;
import suite.diagram.edit.parts.FipaMessageTypeACLMessageContentCompartment2EditPart;
import suite.diagram.edit.parts.FipaMessageTypeACLMessageContentCompartmentEditPart;
import suite.diagram.edit.parts.FipaMessageTypeEditPart;
import suite.diagram.edit.parts.GoalLinkTypeEditPart;
import suite.diagram.edit.parts.GoalPlanTypeEditPart;
import suite.diagram.edit.parts.OrderLinkTypeEditPart;
import suite.diagram.edit.parts.ReceiveLinkTypeEditPart;
import suite.diagram.edit.parts.SendLinkTypeEditPart;
import suite.diagram.edit.parts.SetupTypeEditPart;
import suite.diagram.edit.parts.SetupTypeTestSupportCompartmentEditPart;
import suite.diagram.edit.parts.TActionTypeACLMessageCompartmentEditPart;
import suite.diagram.edit.parts.TActionTypeEditPart;
import suite.diagram.edit.parts.TActionTypeOracleCompartmentEditPart;
import suite.diagram.edit.parts.TargetTypeEditPart;
import suite.diagram.edit.parts.TargetTypeTargetTypeCompartmentEditPart;
import suite.diagram.edit.parts.TaskType12EditPart;
import suite.diagram.edit.parts.TaskType1EditPart;
import suite.diagram.edit.parts.TeardownTypeEditPart;
import suite.diagram.edit.parts.TeardownTypeTestTeardownCompartmentEditPart;
import suite.diagram.edit.parts.TestCaseTypeEditPart;
import suite.diagram.edit.parts.TestCaseTypeTestCaseCompartmentEditPart;
import suite.diagram.edit.parts.TestScenarioTypeEditPart;
import suite.diagram.edit.parts.TestScenarioTypeTestScenarioCompartmentEditPart;
import suite.diagram.edit.parts.TestSuiteTypeEditPart;
import suite.diagram.providers.SuiteElementTypes;

/**
 * @generated
 */
public class SuiteDiagramUpdater {

	/**
	 * @generated
	 */
	public static List getSemanticChildren(View view) {
		switch (SuiteVisualIDRegistry.getVisualID(view)) {
		case TargetTypeTargetTypeCompartmentEditPart.VISUAL_ID:
			return getTargetTypeTargetTypeCompartment_5001SemanticChildren(view);
		case SetupTypeTestSupportCompartmentEditPart.VISUAL_ID:
			return getSetupTypeTestSupportCompartment_5002SemanticChildren(view);
		case TestCaseTypeTestCaseCompartmentEditPart.VISUAL_ID:
			return getTestCaseTypeTestCaseCompartment_5003SemanticChildren(view);
		case TestScenarioTypeTestScenarioCompartmentEditPart.VISUAL_ID:
			return getTestScenarioTypeTestScenarioCompartment_5004SemanticChildren(view);
		case TActionTypeACLMessageCompartmentEditPart.VISUAL_ID:
			return getTActionTypeACLMessageCompartment_5005SemanticChildren(view);
		case TActionTypeOracleCompartmentEditPart.VISUAL_ID:
			return getTActionTypeOracleCompartment_5006SemanticChildren(view);
		case FipaMessageTypeACLMessageContentCompartmentEditPart.VISUAL_ID:
			return getFipaMessageTypeACLMessageContentCompartment_5007SemanticChildren(view);
		case CheckTypeACLMessageCompartmentEditPart.VISUAL_ID:
			return getCheckTypeACLMessageCompartment_5008SemanticChildren(view);
		case FipaMessageTypeACLMessageContentCompartment2EditPart.VISUAL_ID:
			return getFipaMessageTypeACLMessageContentCompartment_5009SemanticChildren(view);
		case TeardownTypeTestTeardownCompartmentEditPart.VISUAL_ID:
			return getTeardownTypeTestTeardownCompartment_5010SemanticChildren(view);
		case TestSuiteTypeEditPart.VISUAL_ID:
			return getTestSuiteType_79SemanticChildren(view);
		}
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getTargetTypeTargetTypeCompartment_5001SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.EMPTY_LIST;
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.EMPTY_LIST;
		}
		TargetType modelElement = (TargetType) containerView.getElement();
		List result = new LinkedList();
		for (Iterator it = modelElement.getGoalPlan().iterator(); it.hasNext();) {
			GoalPlanType childElement = (GoalPlanType) it.next();
			int visualID = SuiteVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == GoalPlanTypeEditPart.VISUAL_ID) {
				result.add(new SuiteNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	public static List getSetupTypeTestSupportCompartment_5002SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.EMPTY_LIST;
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.EMPTY_LIST;
		}
		SetupType modelElement = (SetupType) containerView.getElement();
		List result = new LinkedList();
		for (Iterator it = modelElement.getTask().iterator(); it.hasNext();) {
			TaskType1 childElement = (TaskType1) it.next();
			int visualID = SuiteVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == TaskType1EditPart.VISUAL_ID) {
				result.add(new SuiteNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	public static List getTestCaseTypeTestCaseCompartment_5003SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.EMPTY_LIST;
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.EMPTY_LIST;
		}
		TestCaseType modelElement = (TestCaseType) containerView.getElement();
		List result = new LinkedList();
		{
			TestScenarioType childElement = modelElement.getScenario();
			int visualID = SuiteVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == TestScenarioTypeEditPart.VISUAL_ID) {
				result.add(new SuiteNodeDescriptor(childElement, visualID));
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	public static List getTestScenarioTypeTestScenarioCompartment_5004SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.EMPTY_LIST;
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.EMPTY_LIST;
		}
		TestScenarioType modelElement = (TestScenarioType) containerView
				.getElement();
		List result = new LinkedList();
		for (Iterator it = modelElement.getTestAction().iterator(); it
				.hasNext();) {
			TActionType childElement = (TActionType) it.next();
			int visualID = SuiteVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == TActionTypeEditPart.VISUAL_ID) {
				result.add(new SuiteNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	public static List getTActionTypeACLMessageCompartment_5005SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.EMPTY_LIST;
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.EMPTY_LIST;
		}
		TActionType modelElement = (TActionType) containerView.getElement();
		List result = new LinkedList();
		{
			FipaMessageType childElement = modelElement.getMessage();
			int visualID = SuiteVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == FipaMessageTypeEditPart.VISUAL_ID) {
				result.add(new SuiteNodeDescriptor(childElement, visualID));
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	public static List getTActionTypeOracleCompartment_5006SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.EMPTY_LIST;
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.EMPTY_LIST;
		}
		TActionType modelElement = (TActionType) containerView.getElement();
		List result = new LinkedList();
		{
			CheckType childElement = modelElement.getVerdict();
			int visualID = SuiteVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == CheckTypeEditPart.VISUAL_ID) {
				result.add(new SuiteNodeDescriptor(childElement, visualID));
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	public static List getFipaMessageTypeACLMessageContentCompartment_5007SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.EMPTY_LIST;
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.EMPTY_LIST;
		}
		FipaMessageType modelElement = (FipaMessageType) containerView
				.getElement();
		List result = new LinkedList();
		{
			ContentType childElement = modelElement.getContent();
			int visualID = SuiteVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == ContentTypeEditPart.VISUAL_ID) {
				result.add(new SuiteNodeDescriptor(childElement, visualID));
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	public static List getCheckTypeACLMessageCompartment_5008SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.EMPTY_LIST;
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.EMPTY_LIST;
		}
		CheckType modelElement = (CheckType) containerView.getElement();
		List result = new LinkedList();
		{
			FipaMessageType childElement = modelElement.getExpectedValue();
			int visualID = SuiteVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == FipaMessageType2EditPart.VISUAL_ID) {
				result.add(new SuiteNodeDescriptor(childElement, visualID));
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	public static List getFipaMessageTypeACLMessageContentCompartment_5009SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.EMPTY_LIST;
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.EMPTY_LIST;
		}
		FipaMessageType modelElement = (FipaMessageType) containerView
				.getElement();
		List result = new LinkedList();
		{
			ContentType childElement = modelElement.getContent();
			int visualID = SuiteVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == ContentType2EditPart.VISUAL_ID) {
				result.add(new SuiteNodeDescriptor(childElement, visualID));
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	public static List getTeardownTypeTestTeardownCompartment_5010SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.EMPTY_LIST;
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.EMPTY_LIST;
		}
		TeardownType modelElement = (TeardownType) containerView.getElement();
		List result = new LinkedList();
		for (Iterator it = modelElement.getTask().iterator(); it.hasNext();) {
			TaskType1 childElement = (TaskType1) it.next();
			int visualID = SuiteVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == TaskType12EditPart.VISUAL_ID) {
				result.add(new SuiteNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	public static List getTestSuiteType_79SemanticChildren(View view) {
		if (!view.isSetElement()) {
			return Collections.EMPTY_LIST;
		}
		TestSuiteType modelElement = (TestSuiteType) view.getElement();
		List result = new LinkedList();
		for (Iterator it = modelElement.getTarget().iterator(); it.hasNext();) {
			TargetType childElement = (TargetType) it.next();
			int visualID = SuiteVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == TargetTypeEditPart.VISUAL_ID) {
				result.add(new SuiteNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		{
			SetupType childElement = modelElement.getSetup();
			int visualID = SuiteVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == SetupTypeEditPart.VISUAL_ID) {
				result.add(new SuiteNodeDescriptor(childElement, visualID));
			}
		}
		for (Iterator it = modelElement.getTestCase().iterator(); it.hasNext();) {
			TestCaseType childElement = (TestCaseType) it.next();
			int visualID = SuiteVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == TestCaseTypeEditPart.VISUAL_ID) {
				result.add(new SuiteNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		{
			TeardownType childElement = modelElement.getTeardown();
			int visualID = SuiteVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == TeardownTypeEditPart.VISUAL_ID) {
				result.add(new SuiteNodeDescriptor(childElement, visualID));
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	public static List getContainedLinks(View view) {
		switch (SuiteVisualIDRegistry.getVisualID(view)) {
		case TestSuiteTypeEditPart.VISUAL_ID:
			return getTestSuiteType_79ContainedLinks(view);
		case TargetTypeEditPart.VISUAL_ID:
			return getTargetType_1001ContainedLinks(view);
		case SetupTypeEditPart.VISUAL_ID:
			return getSetupType_1002ContainedLinks(view);
		case TestCaseTypeEditPart.VISUAL_ID:
			return getTestCaseType_1003ContainedLinks(view);
		case TeardownTypeEditPart.VISUAL_ID:
			return getTeardownType_1004ContainedLinks(view);
		case GoalPlanTypeEditPart.VISUAL_ID:
			return getGoalPlanType_2001ContainedLinks(view);
		case TaskType1EditPart.VISUAL_ID:
			return getTaskType1_2002ContainedLinks(view);
		case TestScenarioTypeEditPart.VISUAL_ID:
			return getTestScenarioType_2003ContainedLinks(view);
		case TActionTypeEditPart.VISUAL_ID:
			return getTActionType_2004ContainedLinks(view);
		case FipaMessageTypeEditPart.VISUAL_ID:
			return getFipaMessageType_2005ContainedLinks(view);
		case ContentTypeEditPart.VISUAL_ID:
			return getContentType_2006ContainedLinks(view);
		case CheckTypeEditPart.VISUAL_ID:
			return getCheckType_2007ContainedLinks(view);
		case FipaMessageType2EditPart.VISUAL_ID:
			return getFipaMessageType_2008ContainedLinks(view);
		case ContentType2EditPart.VISUAL_ID:
			return getContentType_2009ContainedLinks(view);
		case TaskType12EditPart.VISUAL_ID:
			return getTaskType1_2010ContainedLinks(view);
		case OrderLinkTypeEditPart.VISUAL_ID:
			return getOrderLinkType_3001ContainedLinks(view);
		case SendLinkTypeEditPart.VISUAL_ID:
			return getSendLinkType_3002ContainedLinks(view);
		case ReceiveLinkTypeEditPart.VISUAL_ID:
			return getReceiveLinkType_3003ContainedLinks(view);
		case GoalLinkTypeEditPart.VISUAL_ID:
			return getGoalLinkType_3004ContainedLinks(view);
		}
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getIncomingLinks(View view) {
		switch (SuiteVisualIDRegistry.getVisualID(view)) {
		case TargetTypeEditPart.VISUAL_ID:
			return getTargetType_1001IncomingLinks(view);
		case SetupTypeEditPart.VISUAL_ID:
			return getSetupType_1002IncomingLinks(view);
		case TestCaseTypeEditPart.VISUAL_ID:
			return getTestCaseType_1003IncomingLinks(view);
		case TeardownTypeEditPart.VISUAL_ID:
			return getTeardownType_1004IncomingLinks(view);
		case GoalPlanTypeEditPart.VISUAL_ID:
			return getGoalPlanType_2001IncomingLinks(view);
		case TaskType1EditPart.VISUAL_ID:
			return getTaskType1_2002IncomingLinks(view);
		case TestScenarioTypeEditPart.VISUAL_ID:
			return getTestScenarioType_2003IncomingLinks(view);
		case TActionTypeEditPart.VISUAL_ID:
			return getTActionType_2004IncomingLinks(view);
		case FipaMessageTypeEditPart.VISUAL_ID:
			return getFipaMessageType_2005IncomingLinks(view);
		case ContentTypeEditPart.VISUAL_ID:
			return getContentType_2006IncomingLinks(view);
		case CheckTypeEditPart.VISUAL_ID:
			return getCheckType_2007IncomingLinks(view);
		case FipaMessageType2EditPart.VISUAL_ID:
			return getFipaMessageType_2008IncomingLinks(view);
		case ContentType2EditPart.VISUAL_ID:
			return getContentType_2009IncomingLinks(view);
		case TaskType12EditPart.VISUAL_ID:
			return getTaskType1_2010IncomingLinks(view);
		case OrderLinkTypeEditPart.VISUAL_ID:
			return getOrderLinkType_3001IncomingLinks(view);
		case SendLinkTypeEditPart.VISUAL_ID:
			return getSendLinkType_3002IncomingLinks(view);
		case ReceiveLinkTypeEditPart.VISUAL_ID:
			return getReceiveLinkType_3003IncomingLinks(view);
		case GoalLinkTypeEditPart.VISUAL_ID:
			return getGoalLinkType_3004IncomingLinks(view);
		}
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getOutgoingLinks(View view) {
		switch (SuiteVisualIDRegistry.getVisualID(view)) {
		case TargetTypeEditPart.VISUAL_ID:
			return getTargetType_1001OutgoingLinks(view);
		case SetupTypeEditPart.VISUAL_ID:
			return getSetupType_1002OutgoingLinks(view);
		case TestCaseTypeEditPart.VISUAL_ID:
			return getTestCaseType_1003OutgoingLinks(view);
		case TeardownTypeEditPart.VISUAL_ID:
			return getTeardownType_1004OutgoingLinks(view);
		case GoalPlanTypeEditPart.VISUAL_ID:
			return getGoalPlanType_2001OutgoingLinks(view);
		case TaskType1EditPart.VISUAL_ID:
			return getTaskType1_2002OutgoingLinks(view);
		case TestScenarioTypeEditPart.VISUAL_ID:
			return getTestScenarioType_2003OutgoingLinks(view);
		case TActionTypeEditPart.VISUAL_ID:
			return getTActionType_2004OutgoingLinks(view);
		case FipaMessageTypeEditPart.VISUAL_ID:
			return getFipaMessageType_2005OutgoingLinks(view);
		case ContentTypeEditPart.VISUAL_ID:
			return getContentType_2006OutgoingLinks(view);
		case CheckTypeEditPart.VISUAL_ID:
			return getCheckType_2007OutgoingLinks(view);
		case FipaMessageType2EditPart.VISUAL_ID:
			return getFipaMessageType_2008OutgoingLinks(view);
		case ContentType2EditPart.VISUAL_ID:
			return getContentType_2009OutgoingLinks(view);
		case TaskType12EditPart.VISUAL_ID:
			return getTaskType1_2010OutgoingLinks(view);
		case OrderLinkTypeEditPart.VISUAL_ID:
			return getOrderLinkType_3001OutgoingLinks(view);
		case SendLinkTypeEditPart.VISUAL_ID:
			return getSendLinkType_3002OutgoingLinks(view);
		case ReceiveLinkTypeEditPart.VISUAL_ID:
			return getReceiveLinkType_3003OutgoingLinks(view);
		case GoalLinkTypeEditPart.VISUAL_ID:
			return getGoalLinkType_3004OutgoingLinks(view);
		}
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getTestSuiteType_79ContainedLinks(View view) {
		TestSuiteType modelElement = (TestSuiteType) view.getElement();
		List result = new LinkedList();
		result
				.addAll(getContainedTypeModelFacetLinks_SendLinkType_3002(modelElement));
		result
				.addAll(getContainedTypeModelFacetLinks_ReceiveLinkType_3003(modelElement));
		result
				.addAll(getContainedTypeModelFacetLinks_GoalLinkType_3004(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List getTargetType_1001ContainedLinks(View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getSetupType_1002ContainedLinks(View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getTestCaseType_1003ContainedLinks(View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getTeardownType_1004ContainedLinks(View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getGoalPlanType_2001ContainedLinks(View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getTaskType1_2002ContainedLinks(View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getTestScenarioType_2003ContainedLinks(View view) {
		TestScenarioType modelElement = (TestScenarioType) view.getElement();
		List result = new LinkedList();
		result
				.addAll(getContainedTypeModelFacetLinks_OrderLinkType_3001(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List getTActionType_2004ContainedLinks(View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getFipaMessageType_2005ContainedLinks(View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getContentType_2006ContainedLinks(View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getCheckType_2007ContainedLinks(View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getFipaMessageType_2008ContainedLinks(View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getContentType_2009ContainedLinks(View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getTaskType1_2010ContainedLinks(View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getOrderLinkType_3001ContainedLinks(View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getSendLinkType_3002ContainedLinks(View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getReceiveLinkType_3003ContainedLinks(View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getGoalLinkType_3004ContainedLinks(View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getTargetType_1001IncomingLinks(View view) {
		TargetType modelElement = (TargetType) view.getElement();
		Map crossReferences = EcoreUtil.CrossReferencer.find(view.eResource()
				.getResourceSet().getResources());
		List result = new LinkedList();
		result.addAll(getIncomingTypeModelFacetLinks_SendLinkType_3002(
				modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List getSetupType_1002IncomingLinks(View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getTestCaseType_1003IncomingLinks(View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getTeardownType_1004IncomingLinks(View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getGoalPlanType_2001IncomingLinks(View view) {
		GoalPlanType modelElement = (GoalPlanType) view.getElement();
		Map crossReferences = EcoreUtil.CrossReferencer.find(view.eResource()
				.getResourceSet().getResources());
		List result = new LinkedList();
		result.addAll(getIncomingTypeModelFacetLinks_GoalLinkType_3004(
				modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List getTaskType1_2002IncomingLinks(View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getTestScenarioType_2003IncomingLinks(View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getTActionType_2004IncomingLinks(View view) {
		TActionType modelElement = (TActionType) view.getElement();
		Map crossReferences = EcoreUtil.CrossReferencer.find(view.eResource()
				.getResourceSet().getResources());
		List result = new LinkedList();
		result.addAll(getIncomingTypeModelFacetLinks_OrderLinkType_3001(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_ReceiveLinkType_3003(
				modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List getFipaMessageType_2005IncomingLinks(View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getContentType_2006IncomingLinks(View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getCheckType_2007IncomingLinks(View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getFipaMessageType_2008IncomingLinks(View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getContentType_2009IncomingLinks(View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getTaskType1_2010IncomingLinks(View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getOrderLinkType_3001IncomingLinks(View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getSendLinkType_3002IncomingLinks(View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getReceiveLinkType_3003IncomingLinks(View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getGoalLinkType_3004IncomingLinks(View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getTargetType_1001OutgoingLinks(View view) {
		TargetType modelElement = (TargetType) view.getElement();
		List result = new LinkedList();
		result
				.addAll(getOutgoingTypeModelFacetLinks_ReceiveLinkType_3003(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List getSetupType_1002OutgoingLinks(View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getTestCaseType_1003OutgoingLinks(View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getTeardownType_1004OutgoingLinks(View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getGoalPlanType_2001OutgoingLinks(View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getTaskType1_2002OutgoingLinks(View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getTestScenarioType_2003OutgoingLinks(View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getTActionType_2004OutgoingLinks(View view) {
		TActionType modelElement = (TActionType) view.getElement();
		List result = new LinkedList();
		result
				.addAll(getOutgoingTypeModelFacetLinks_OrderLinkType_3001(modelElement));
		result
				.addAll(getOutgoingTypeModelFacetLinks_SendLinkType_3002(modelElement));
		result
				.addAll(getOutgoingTypeModelFacetLinks_GoalLinkType_3004(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List getFipaMessageType_2005OutgoingLinks(View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getContentType_2006OutgoingLinks(View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getCheckType_2007OutgoingLinks(View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getFipaMessageType_2008OutgoingLinks(View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getContentType_2009OutgoingLinks(View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getTaskType1_2010OutgoingLinks(View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getOrderLinkType_3001OutgoingLinks(View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getSendLinkType_3002OutgoingLinks(View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getReceiveLinkType_3003OutgoingLinks(View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List getGoalLinkType_3004OutgoingLinks(View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	private static Collection getContainedTypeModelFacetLinks_OrderLinkType_3001(
			TestScenarioType container) {
		Collection result = new LinkedList();
		for (Iterator links = container.getLink().iterator(); links.hasNext();) {
			Object linkObject = links.next();
			if (false == linkObject instanceof OrderLinkType) {
				continue;
			}
			OrderLinkType link = (OrderLinkType) linkObject;
			if (OrderLinkTypeEditPart.VISUAL_ID != SuiteVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			TActionType dst = link.getTarget();
			TActionType src = link.getSource();
			result.add(new SuiteLinkDescriptor(src, dst, link,
					SuiteElementTypes.OrderLinkType_3001,
					OrderLinkTypeEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection getContainedTypeModelFacetLinks_SendLinkType_3002(
			TestSuiteType container) {
		Collection result = new LinkedList();
		for (Iterator links = container.getSendLink().iterator(); links
				.hasNext();) {
			Object linkObject = links.next();
			if (false == linkObject instanceof SendLinkType) {
				continue;
			}
			SendLinkType link = (SendLinkType) linkObject;
			if (SendLinkTypeEditPart.VISUAL_ID != SuiteVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			TargetType dst = link.getTarget();
			TActionType src = link.getSource();
			result.add(new SuiteLinkDescriptor(src, dst, link,
					SuiteElementTypes.SendLinkType_3002,
					SendLinkTypeEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection getContainedTypeModelFacetLinks_ReceiveLinkType_3003(
			TestSuiteType container) {
		Collection result = new LinkedList();
		for (Iterator links = container.getReceiveLink().iterator(); links
				.hasNext();) {
			Object linkObject = links.next();
			if (false == linkObject instanceof ReceiveLinkType) {
				continue;
			}
			ReceiveLinkType link = (ReceiveLinkType) linkObject;
			if (ReceiveLinkTypeEditPart.VISUAL_ID != SuiteVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			TActionType dst = link.getTarget();
			TargetType src = link.getSource();
			result.add(new SuiteLinkDescriptor(src, dst, link,
					SuiteElementTypes.ReceiveLinkType_3003,
					ReceiveLinkTypeEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection getContainedTypeModelFacetLinks_GoalLinkType_3004(
			TestSuiteType container) {
		Collection result = new LinkedList();
		for (Iterator links = container.getGoalLink().iterator(); links
				.hasNext();) {
			Object linkObject = links.next();
			if (false == linkObject instanceof GoalLinkType) {
				continue;
			}
			GoalLinkType link = (GoalLinkType) linkObject;
			if (GoalLinkTypeEditPart.VISUAL_ID != SuiteVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			GoalPlanType dst = link.getTarget();
			TActionType src = link.getSource();
			result.add(new SuiteLinkDescriptor(src, dst, link,
					SuiteElementTypes.GoalLinkType_3004,
					GoalLinkTypeEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection getIncomingTypeModelFacetLinks_OrderLinkType_3001(
			TActionType target, Map crossReferences) {
		Collection result = new LinkedList();
		Collection settings = (Collection) crossReferences.get(target);
		for (Iterator it = settings.iterator(); it.hasNext();) {
			EStructuralFeature.Setting setting = (EStructuralFeature.Setting) it
					.next();
			if (setting.getEStructuralFeature() != SuitePackage.eINSTANCE
					.getOrderLinkType_Target()
					|| false == setting.getEObject() instanceof OrderLinkType) {
				continue;
			}
			OrderLinkType link = (OrderLinkType) setting.getEObject();
			if (OrderLinkTypeEditPart.VISUAL_ID != SuiteVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			TActionType src = link.getSource();
			result.add(new SuiteLinkDescriptor(src, target, link,
					SuiteElementTypes.OrderLinkType_3001,
					OrderLinkTypeEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection getIncomingTypeModelFacetLinks_SendLinkType_3002(
			TargetType target, Map crossReferences) {
		Collection result = new LinkedList();
		Collection settings = (Collection) crossReferences.get(target);
		for (Iterator it = settings.iterator(); it.hasNext();) {
			EStructuralFeature.Setting setting = (EStructuralFeature.Setting) it
					.next();
			if (setting.getEStructuralFeature() != SuitePackage.eINSTANCE
					.getSendLinkType_Target()
					|| false == setting.getEObject() instanceof SendLinkType) {
				continue;
			}
			SendLinkType link = (SendLinkType) setting.getEObject();
			if (SendLinkTypeEditPart.VISUAL_ID != SuiteVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			TActionType src = link.getSource();
			result.add(new SuiteLinkDescriptor(src, target, link,
					SuiteElementTypes.SendLinkType_3002,
					SendLinkTypeEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection getIncomingTypeModelFacetLinks_ReceiveLinkType_3003(
			TActionType target, Map crossReferences) {
		Collection result = new LinkedList();
		Collection settings = (Collection) crossReferences.get(target);
		for (Iterator it = settings.iterator(); it.hasNext();) {
			EStructuralFeature.Setting setting = (EStructuralFeature.Setting) it
					.next();
			if (setting.getEStructuralFeature() != SuitePackage.eINSTANCE
					.getReceiveLinkType_Target()
					|| false == setting.getEObject() instanceof ReceiveLinkType) {
				continue;
			}
			ReceiveLinkType link = (ReceiveLinkType) setting.getEObject();
			if (ReceiveLinkTypeEditPart.VISUAL_ID != SuiteVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			TargetType src = link.getSource();
			result.add(new SuiteLinkDescriptor(src, target, link,
					SuiteElementTypes.ReceiveLinkType_3003,
					ReceiveLinkTypeEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection getIncomingTypeModelFacetLinks_GoalLinkType_3004(
			GoalPlanType target, Map crossReferences) {
		Collection result = new LinkedList();
		Collection settings = (Collection) crossReferences.get(target);
		for (Iterator it = settings.iterator(); it.hasNext();) {
			EStructuralFeature.Setting setting = (EStructuralFeature.Setting) it
					.next();
			if (setting.getEStructuralFeature() != SuitePackage.eINSTANCE
					.getGoalLinkType_Target()
					|| false == setting.getEObject() instanceof GoalLinkType) {
				continue;
			}
			GoalLinkType link = (GoalLinkType) setting.getEObject();
			if (GoalLinkTypeEditPart.VISUAL_ID != SuiteVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			TActionType src = link.getSource();
			result.add(new SuiteLinkDescriptor(src, target, link,
					SuiteElementTypes.GoalLinkType_3004,
					GoalLinkTypeEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection getOutgoingTypeModelFacetLinks_OrderLinkType_3001(
			TActionType source) {
		TestScenarioType container = null;
		// Find container element for the link.
		// Climb up by containment hierarchy starting from the source
		// and return the first element that is instance of the container class.
		for (EObject element = source; element != null && container == null; element = element
				.eContainer()) {
			if (element instanceof TestScenarioType) {
				container = (TestScenarioType) element;
			}
		}
		if (container == null) {
			return Collections.EMPTY_LIST;
		}
		Collection result = new LinkedList();
		for (Iterator links = container.getLink().iterator(); links.hasNext();) {
			Object linkObject = links.next();
			if (false == linkObject instanceof OrderLinkType) {
				continue;
			}
			OrderLinkType link = (OrderLinkType) linkObject;
			if (OrderLinkTypeEditPart.VISUAL_ID != SuiteVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			TActionType dst = link.getTarget();
			TActionType src = link.getSource();
			if (src != source) {
				continue;
			}
			result.add(new SuiteLinkDescriptor(src, dst, link,
					SuiteElementTypes.OrderLinkType_3001,
					OrderLinkTypeEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection getOutgoingTypeModelFacetLinks_SendLinkType_3002(
			TActionType source) {
		TestSuiteType container = null;
		// Find container element for the link.
		// Climb up by containment hierarchy starting from the source
		// and return the first element that is instance of the container class.
		for (EObject element = source; element != null && container == null; element = element
				.eContainer()) {
			if (element instanceof TestSuiteType) {
				container = (TestSuiteType) element;
			}
		}
		if (container == null) {
			return Collections.EMPTY_LIST;
		}
		Collection result = new LinkedList();
		for (Iterator links = container.getSendLink().iterator(); links
				.hasNext();) {
			Object linkObject = links.next();
			if (false == linkObject instanceof SendLinkType) {
				continue;
			}
			SendLinkType link = (SendLinkType) linkObject;
			if (SendLinkTypeEditPart.VISUAL_ID != SuiteVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			TargetType dst = link.getTarget();
			TActionType src = link.getSource();
			if (src != source) {
				continue;
			}
			result.add(new SuiteLinkDescriptor(src, dst, link,
					SuiteElementTypes.SendLinkType_3002,
					SendLinkTypeEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection getOutgoingTypeModelFacetLinks_ReceiveLinkType_3003(
			TargetType source) {
		TestSuiteType container = null;
		// Find container element for the link.
		// Climb up by containment hierarchy starting from the source
		// and return the first element that is instance of the container class.
		for (EObject element = source; element != null && container == null; element = element
				.eContainer()) {
			if (element instanceof TestSuiteType) {
				container = (TestSuiteType) element;
			}
		}
		if (container == null) {
			return Collections.EMPTY_LIST;
		}
		Collection result = new LinkedList();
		for (Iterator links = container.getReceiveLink().iterator(); links
				.hasNext();) {
			Object linkObject = links.next();
			if (false == linkObject instanceof ReceiveLinkType) {
				continue;
			}
			ReceiveLinkType link = (ReceiveLinkType) linkObject;
			if (ReceiveLinkTypeEditPart.VISUAL_ID != SuiteVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			TActionType dst = link.getTarget();
			TargetType src = link.getSource();
			if (src != source) {
				continue;
			}
			result.add(new SuiteLinkDescriptor(src, dst, link,
					SuiteElementTypes.ReceiveLinkType_3003,
					ReceiveLinkTypeEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection getOutgoingTypeModelFacetLinks_GoalLinkType_3004(
			TActionType source) {
		TestSuiteType container = null;
		// Find container element for the link.
		// Climb up by containment hierarchy starting from the source
		// and return the first element that is instance of the container class.
		for (EObject element = source; element != null && container == null; element = element
				.eContainer()) {
			if (element instanceof TestSuiteType) {
				container = (TestSuiteType) element;
			}
		}
		if (container == null) {
			return Collections.EMPTY_LIST;
		}
		Collection result = new LinkedList();
		for (Iterator links = container.getGoalLink().iterator(); links
				.hasNext();) {
			Object linkObject = links.next();
			if (false == linkObject instanceof GoalLinkType) {
				continue;
			}
			GoalLinkType link = (GoalLinkType) linkObject;
			if (GoalLinkTypeEditPart.VISUAL_ID != SuiteVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			GoalPlanType dst = link.getTarget();
			TActionType src = link.getSource();
			if (src != source) {
				continue;
			}
			result.add(new SuiteLinkDescriptor(src, dst, link,
					SuiteElementTypes.GoalLinkType_3004,
					GoalLinkTypeEditPart.VISUAL_ID));
		}
		return result;
	}

}
