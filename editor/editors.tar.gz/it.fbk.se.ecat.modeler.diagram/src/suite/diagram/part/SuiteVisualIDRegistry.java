package suite.diagram.part;

import org.eclipse.core.runtime.Platform;
import org.eclipse.emf.ecore.EAnnotation;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.gmf.runtime.notation.Diagram;
import org.eclipse.gmf.runtime.notation.View;

import schema.SchemaPackage;
import suite.SuitePackage;
import suite.TestSuiteType;
import suite.diagram.edit.parts.CheckTypeACLMessageCompartmentEditPart;
import suite.diagram.edit.parts.CheckTypeCheckOperatorEditPart;
import suite.diagram.edit.parts.CheckTypeEditPart;
import suite.diagram.edit.parts.ContentType2EditPart;
import suite.diagram.edit.parts.ContentTypeEditPart;
import suite.diagram.edit.parts.ContentTypeValueEditPart;
import suite.diagram.edit.parts.FipaMessageType2EditPart;
import suite.diagram.edit.parts.FipaMessageTypeACLMessageContentCompartment2EditPart;
import suite.diagram.edit.parts.FipaMessageTypeACLMessageContentCompartmentEditPart;
import suite.diagram.edit.parts.FipaMessageTypeActEditPart;
import suite.diagram.edit.parts.FipaMessageTypeEditPart;
import suite.diagram.edit.parts.FipaMessageTypeIdActEditPart;
import suite.diagram.edit.parts.GoalLinkTypeEditPart;
import suite.diagram.edit.parts.GoalLinkTypeNameEditPart;
import suite.diagram.edit.parts.GoalPlanTypeEditPart;
import suite.diagram.edit.parts.GoalPlanTypeGoalEditPart;
import suite.diagram.edit.parts.OrderLinkTypeDescEditPart;
import suite.diagram.edit.parts.OrderLinkTypeEditPart;
import suite.diagram.edit.parts.ReceiveLinkTypeEditPart;
import suite.diagram.edit.parts.ReceiveLinkTypeNameEditPart;
import suite.diagram.edit.parts.SendLinkTypeEditPart;
import suite.diagram.edit.parts.SendLinkTypeNameEditPart;
import suite.diagram.edit.parts.SetupTypeEditPart;
import suite.diagram.edit.parts.SetupTypeNameEditPart;
import suite.diagram.edit.parts.SetupTypeTestSupportCompartmentEditPart;
import suite.diagram.edit.parts.TActionTypeACLMessageCompartmentEditPart;
import suite.diagram.edit.parts.TActionTypeActTypeEditPart;
import suite.diagram.edit.parts.TActionTypeEditPart;
import suite.diagram.edit.parts.TActionTypeOracleCompartmentEditPart;
import suite.diagram.edit.parts.TargetTypeAgentEditPart;
import suite.diagram.edit.parts.TargetTypeEditPart;
import suite.diagram.edit.parts.TargetTypeTargetTypeCompartmentEditPart;
import suite.diagram.edit.parts.TaskType12EditPart;
import suite.diagram.edit.parts.TaskType1EditPart;
import suite.diagram.edit.parts.TaskType1Name2EditPart;
import suite.diagram.edit.parts.TaskType1NameEditPart;
import suite.diagram.edit.parts.TeardownTypeEditPart;
import suite.diagram.edit.parts.TeardownTypeNameEditPart;
import suite.diagram.edit.parts.TeardownTypeTestTeardownCompartmentEditPart;
import suite.diagram.edit.parts.TestCaseTypeEditPart;
import suite.diagram.edit.parts.TestCaseTypeNameEditPart;
import suite.diagram.edit.parts.TestCaseTypeTestCaseCompartmentEditPart;
import suite.diagram.edit.parts.TestScenarioTypeEditPart;
import suite.diagram.edit.parts.TestScenarioTypeTestScenarioCompartmentEditPart;
import suite.diagram.edit.parts.TestSuiteTypeEditPart;
import suite.diagram.expressions.SuiteAbstractExpression;

/**
 * This registry is used to determine which type of visual object should be
 * created for the corresponding Diagram, Node, ChildNode or Link represented
 * by a domain model object.
 * 
 * @generated
 */
public class SuiteVisualIDRegistry {

	/**
	 * @generated
	 */
	private static final String DEBUG_KEY = SuiteDiagramEditorPlugin
			.getInstance().getBundle().getSymbolicName()
			+ "/debug/visualID"; //$NON-NLS-1$

	/**
	 * @generated
	 */
	public static int getVisualID(View view) {
		if (view instanceof Diagram) {
			if (TestSuiteTypeEditPart.MODEL_ID.equals(view.getType())) {
				return TestSuiteTypeEditPart.VISUAL_ID;
			} else {
				return -1;
			}
		}
		return suite.diagram.part.SuiteVisualIDRegistry.getVisualID(view
				.getType());
	}

	/**
	 * @generated
	 */
	public static String getModelID(View view) {
		View diagram = view.getDiagram();
		while (view != diagram) {
			EAnnotation annotation = view.getEAnnotation("Shortcut"); //$NON-NLS-1$
			if (annotation != null) {
				return (String) annotation.getDetails().get("modelID"); //$NON-NLS-1$
			}
			view = (View) view.eContainer();
		}
		return diagram != null ? diagram.getType() : null;
	}

	/**
	 * @generated
	 */
	public static int getVisualID(String type) {
		try {
			return Integer.parseInt(type);
		} catch (NumberFormatException e) {
			if (Boolean.TRUE.toString().equalsIgnoreCase(
					Platform.getDebugOption(DEBUG_KEY))) {
				SuiteDiagramEditorPlugin.getInstance().logError(
						"Unable to parse view type as a visualID number: "
								+ type);
			}
		}
		return -1;
	}

	/**
	 * @generated
	 */
	public static String getType(int visualID) {
		return String.valueOf(visualID);
	}

	/**
	 * @generated
	 */
	public static int getDiagramVisualID(EObject domainElement) {
		if (domainElement == null) {
			return -1;
		}
		if (SuitePackage.eINSTANCE.getTestSuiteType().isSuperTypeOf(
				domainElement.eClass())
				&& isDiagram((TestSuiteType) domainElement)) {
			return TestSuiteTypeEditPart.VISUAL_ID;
		}
		return -1;
	}

	/**
	 * @generated
	 */
	public static int getNodeVisualID(View containerView, EObject domainElement) {
		if (domainElement == null) {
			return -1;
		}
		String containerModelID = suite.diagram.part.SuiteVisualIDRegistry
				.getModelID(containerView);
		if (!TestSuiteTypeEditPart.MODEL_ID.equals(containerModelID)) {
			return -1;
		}
		int containerVisualID;
		if (TestSuiteTypeEditPart.MODEL_ID.equals(containerModelID)) {
			containerVisualID = suite.diagram.part.SuiteVisualIDRegistry
					.getVisualID(containerView);
		} else {
			if (containerView instanceof Diagram) {
				containerVisualID = TestSuiteTypeEditPart.VISUAL_ID;
			} else {
				return -1;
			}
		}
		switch (containerVisualID) {
		case TargetTypeTargetTypeCompartmentEditPart.VISUAL_ID:
			if (SuitePackage.eINSTANCE.getGoalPlanType().isSuperTypeOf(
					domainElement.eClass())) {
				return GoalPlanTypeEditPart.VISUAL_ID;
			}
			break;
		case SetupTypeTestSupportCompartmentEditPart.VISUAL_ID:
			if (SuitePackage.eINSTANCE.getTaskType1().isSuperTypeOf(
					domainElement.eClass())) {
				return TaskType1EditPart.VISUAL_ID;
			}
			break;
		case TestCaseTypeTestCaseCompartmentEditPart.VISUAL_ID:
			if (SuitePackage.eINSTANCE.getTestScenarioType().isSuperTypeOf(
					domainElement.eClass())) {
				return TestScenarioTypeEditPart.VISUAL_ID;
			}
			break;
		case TestScenarioTypeTestScenarioCompartmentEditPart.VISUAL_ID:
			if (SuitePackage.eINSTANCE.getTActionType().isSuperTypeOf(
					domainElement.eClass())) {
				return TActionTypeEditPart.VISUAL_ID;
			}
			break;
		case TActionTypeACLMessageCompartmentEditPart.VISUAL_ID:
			if (SchemaPackage.eINSTANCE.getFipaMessageType().isSuperTypeOf(
					domainElement.eClass())) {
				return FipaMessageTypeEditPart.VISUAL_ID;
			}
			break;
		case TActionTypeOracleCompartmentEditPart.VISUAL_ID:
			if (SuitePackage.eINSTANCE.getCheckType().isSuperTypeOf(
					domainElement.eClass())) {
				return CheckTypeEditPart.VISUAL_ID;
			}
			break;
		case FipaMessageTypeACLMessageContentCompartmentEditPart.VISUAL_ID:
			if (SchemaPackage.eINSTANCE.getContentType().isSuperTypeOf(
					domainElement.eClass())) {
				return ContentTypeEditPart.VISUAL_ID;
			}
			break;
		case CheckTypeACLMessageCompartmentEditPart.VISUAL_ID:
			if (SchemaPackage.eINSTANCE.getFipaMessageType().isSuperTypeOf(
					domainElement.eClass())) {
				return FipaMessageType2EditPart.VISUAL_ID;
			}
			break;
		case FipaMessageTypeACLMessageContentCompartment2EditPart.VISUAL_ID:
			if (SchemaPackage.eINSTANCE.getContentType().isSuperTypeOf(
					domainElement.eClass())) {
				return ContentType2EditPart.VISUAL_ID;
			}
			break;
		case TeardownTypeTestTeardownCompartmentEditPart.VISUAL_ID:
			if (SuitePackage.eINSTANCE.getTaskType1().isSuperTypeOf(
					domainElement.eClass())) {
				return TaskType12EditPart.VISUAL_ID;
			}
			break;
		case TestSuiteTypeEditPart.VISUAL_ID:
			if (SuitePackage.eINSTANCE.getTargetType().isSuperTypeOf(
					domainElement.eClass())) {
				return TargetTypeEditPart.VISUAL_ID;
			}
			if (SuitePackage.eINSTANCE.getSetupType().isSuperTypeOf(
					domainElement.eClass())) {
				return SetupTypeEditPart.VISUAL_ID;
			}
			if (SuitePackage.eINSTANCE.getTestCaseType().isSuperTypeOf(
					domainElement.eClass())) {
				return TestCaseTypeEditPart.VISUAL_ID;
			}
			if (SuitePackage.eINSTANCE.getTeardownType().isSuperTypeOf(
					domainElement.eClass())) {
				return TeardownTypeEditPart.VISUAL_ID;
			}
			break;
		}
		return -1;
	}

	/**
	 * @generated
	 */
	public static boolean canCreateNode(View containerView, int nodeVisualID) {
		String containerModelID = suite.diagram.part.SuiteVisualIDRegistry
				.getModelID(containerView);
		if (!TestSuiteTypeEditPart.MODEL_ID.equals(containerModelID)) {
			return false;
		}
		int containerVisualID;
		if (TestSuiteTypeEditPart.MODEL_ID.equals(containerModelID)) {
			containerVisualID = suite.diagram.part.SuiteVisualIDRegistry
					.getVisualID(containerView);
		} else {
			if (containerView instanceof Diagram) {
				containerVisualID = TestSuiteTypeEditPart.VISUAL_ID;
			} else {
				return false;
			}
		}
		switch (containerVisualID) {
		case TargetTypeEditPart.VISUAL_ID:
			if (TargetTypeAgentEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (TargetTypeTargetTypeCompartmentEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case SetupTypeEditPart.VISUAL_ID:
			if (SetupTypeNameEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (SetupTypeTestSupportCompartmentEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case TestCaseTypeEditPart.VISUAL_ID:
			if (TestCaseTypeNameEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (TestCaseTypeTestCaseCompartmentEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case TeardownTypeEditPart.VISUAL_ID:
			if (TeardownTypeNameEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (TeardownTypeTestTeardownCompartmentEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case GoalPlanTypeEditPart.VISUAL_ID:
			if (GoalPlanTypeGoalEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case TaskType1EditPart.VISUAL_ID:
			if (TaskType1NameEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case TestScenarioTypeEditPart.VISUAL_ID:
			if (TestScenarioTypeTestScenarioCompartmentEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case TActionTypeEditPart.VISUAL_ID:
			if (TActionTypeActTypeEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (TActionTypeACLMessageCompartmentEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (TActionTypeOracleCompartmentEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case FipaMessageTypeEditPart.VISUAL_ID:
			if (FipaMessageTypeIdActEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (FipaMessageTypeACLMessageContentCompartmentEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case ContentTypeEditPart.VISUAL_ID:
			if (ContentTypeValueEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case CheckTypeEditPart.VISUAL_ID:
			if (CheckTypeCheckOperatorEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (CheckTypeACLMessageCompartmentEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case FipaMessageType2EditPart.VISUAL_ID:
			if (FipaMessageTypeActEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (FipaMessageTypeACLMessageContentCompartment2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case TaskType12EditPart.VISUAL_ID:
			if (TaskType1Name2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case TargetTypeTargetTypeCompartmentEditPart.VISUAL_ID:
			if (GoalPlanTypeEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case SetupTypeTestSupportCompartmentEditPart.VISUAL_ID:
			if (TaskType1EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case TestCaseTypeTestCaseCompartmentEditPart.VISUAL_ID:
			if (TestScenarioTypeEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case TestScenarioTypeTestScenarioCompartmentEditPart.VISUAL_ID:
			if (TActionTypeEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case TActionTypeACLMessageCompartmentEditPart.VISUAL_ID:
			if (FipaMessageTypeEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case TActionTypeOracleCompartmentEditPart.VISUAL_ID:
			if (CheckTypeEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case FipaMessageTypeACLMessageContentCompartmentEditPart.VISUAL_ID:
			if (ContentTypeEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case CheckTypeACLMessageCompartmentEditPart.VISUAL_ID:
			if (FipaMessageType2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case FipaMessageTypeACLMessageContentCompartment2EditPart.VISUAL_ID:
			if (ContentType2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case TeardownTypeTestTeardownCompartmentEditPart.VISUAL_ID:
			if (TaskType12EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case TestSuiteTypeEditPart.VISUAL_ID:
			if (TargetTypeEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (SetupTypeEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (TestCaseTypeEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (TeardownTypeEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case OrderLinkTypeEditPart.VISUAL_ID:
			if (OrderLinkTypeDescEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case SendLinkTypeEditPart.VISUAL_ID:
			if (SendLinkTypeNameEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case ReceiveLinkTypeEditPart.VISUAL_ID:
			if (ReceiveLinkTypeNameEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case GoalLinkTypeEditPart.VISUAL_ID:
			if (GoalLinkTypeNameEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		}
		return false;
	}

	/**
	 * @generated
	 */
	public static int getLinkWithClassVisualID(EObject domainElement) {
		if (domainElement == null) {
			return -1;
		}
		if (SuitePackage.eINSTANCE.getOrderLinkType().isSuperTypeOf(
				domainElement.eClass())) {
			return OrderLinkTypeEditPart.VISUAL_ID;
		}
		if (SuitePackage.eINSTANCE.getSendLinkType().isSuperTypeOf(
				domainElement.eClass())) {
			return SendLinkTypeEditPart.VISUAL_ID;
		}
		if (SuitePackage.eINSTANCE.getReceiveLinkType().isSuperTypeOf(
				domainElement.eClass())) {
			return ReceiveLinkTypeEditPart.VISUAL_ID;
		}
		if (SuitePackage.eINSTANCE.getGoalLinkType().isSuperTypeOf(
				domainElement.eClass())) {
			return GoalLinkTypeEditPart.VISUAL_ID;
		}
		return -1;
	}

	/**
	 * User can change implementation of this method to handle some specific
	 * situations not covered by default logic.
	 * 
	 * @generated
	 */
	private static boolean isDiagram(TestSuiteType element) {
		return true;
	}

	/**
	 * @generated
	 */
	private static boolean evaluate(SuiteAbstractExpression expression,
			Object element) {
		Object result = expression.evaluate(element);
		return result instanceof Boolean && ((Boolean) result).booleanValue();
	}

	/**
	 * @generated
	 */
	private static class JavaConstraints {

	}

}
