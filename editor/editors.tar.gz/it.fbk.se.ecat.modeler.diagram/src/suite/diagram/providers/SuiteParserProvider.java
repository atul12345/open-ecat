package suite.diagram.providers;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.gmf.runtime.common.core.service.AbstractProvider;
import org.eclipse.gmf.runtime.common.core.service.IOperation;
import org.eclipse.gmf.runtime.common.ui.services.parser.GetParserOperation;
import org.eclipse.gmf.runtime.common.ui.services.parser.IParser;
import org.eclipse.gmf.runtime.common.ui.services.parser.IParserProvider;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;
import org.eclipse.gmf.runtime.emf.ui.services.parser.ParserHintAdapter;
import org.eclipse.gmf.runtime.notation.View;

import schema.SchemaPackage;
import suite.SuitePackage;
import suite.diagram.edit.parts.CheckTypeCheckOperatorEditPart;
import suite.diagram.edit.parts.ContentTypeValueEditPart;
import suite.diagram.edit.parts.FipaMessageTypeActEditPart;
import suite.diagram.edit.parts.FipaMessageTypeIdActEditPart;
import suite.diagram.edit.parts.GoalLinkTypeNameEditPart;
import suite.diagram.edit.parts.GoalPlanTypeGoalEditPart;
import suite.diagram.edit.parts.OrderLinkTypeDescEditPart;
import suite.diagram.edit.parts.ReceiveLinkTypeNameEditPart;
import suite.diagram.edit.parts.SendLinkTypeNameEditPart;
import suite.diagram.edit.parts.SetupTypeNameEditPart;
import suite.diagram.edit.parts.TActionTypeActTypeEditPart;
import suite.diagram.edit.parts.TargetTypeAgentEditPart;
import suite.diagram.edit.parts.TaskType1Name2EditPart;
import suite.diagram.edit.parts.TaskType1NameEditPart;
import suite.diagram.edit.parts.TeardownTypeNameEditPart;
import suite.diagram.edit.parts.TestCaseTypeNameEditPart;
import suite.diagram.parsers.MessageFormatParser;
import suite.diagram.part.SuiteVisualIDRegistry;

/**
 * @generated
 */
public class SuiteParserProvider extends AbstractProvider implements
		IParserProvider {

	/**
	 * @generated
	 */
	private IParser targetTypeAgent_4002Parser;

	/**
	 * @generated
	 */
	private IParser getTargetTypeAgent_4002Parser() {
		if (targetTypeAgent_4002Parser == null) {
			targetTypeAgent_4002Parser = createTargetTypeAgent_4002Parser();
		}
		return targetTypeAgent_4002Parser;
	}

	/**
	 * @generated
	 */
	protected IParser createTargetTypeAgent_4002Parser() {
		EAttribute[] features = new EAttribute[] { SuitePackage.eINSTANCE
				.getTargetType_Agent(), };
		MessageFormatParser parser = new MessageFormatParser(features);
		return parser;
	}

	/**
	 * @generated
	 */
	private IParser setupTypeName_4004Parser;

	/**
	 * @generated
	 */
	private IParser getSetupTypeName_4004Parser() {
		if (setupTypeName_4004Parser == null) {
			setupTypeName_4004Parser = createSetupTypeName_4004Parser();
		}
		return setupTypeName_4004Parser;
	}

	/**
	 * @generated
	 */
	protected IParser createSetupTypeName_4004Parser() {
		EAttribute[] features = new EAttribute[] { SuitePackage.eINSTANCE
				.getTestSupportType_Name(), };
		MessageFormatParser parser = new MessageFormatParser(features);
		return parser;
	}

	/**
	 * @generated
	 */
	private IParser testCaseTypeName_4010Parser;

	/**
	 * @generated
	 */
	private IParser getTestCaseTypeName_4010Parser() {
		if (testCaseTypeName_4010Parser == null) {
			testCaseTypeName_4010Parser = createTestCaseTypeName_4010Parser();
		}
		return testCaseTypeName_4010Parser;
	}

	/**
	 * @generated
	 */
	protected IParser createTestCaseTypeName_4010Parser() {
		EAttribute[] features = new EAttribute[] { SuitePackage.eINSTANCE
				.getTestCaseType_Name(), };
		MessageFormatParser parser = new MessageFormatParser(features);
		return parser;
	}

	/**
	 * @generated
	 */
	private IParser teardownTypeName_4012Parser;

	/**
	 * @generated
	 */
	private IParser getTeardownTypeName_4012Parser() {
		if (teardownTypeName_4012Parser == null) {
			teardownTypeName_4012Parser = createTeardownTypeName_4012Parser();
		}
		return teardownTypeName_4012Parser;
	}

	/**
	 * @generated
	 */
	protected IParser createTeardownTypeName_4012Parser() {
		EAttribute[] features = new EAttribute[] { SuitePackage.eINSTANCE
				.getTestSupportType_Name(), };
		MessageFormatParser parser = new MessageFormatParser(features);
		return parser;
	}

	/**
	 * @generated
	 */
	private IParser goalPlanTypeGoal_4001Parser;

	/**
	 * @generated
	 */
	private IParser getGoalPlanTypeGoal_4001Parser() {
		if (goalPlanTypeGoal_4001Parser == null) {
			goalPlanTypeGoal_4001Parser = createGoalPlanTypeGoal_4001Parser();
		}
		return goalPlanTypeGoal_4001Parser;
	}

	/**
	 * @generated
	 */
	protected IParser createGoalPlanTypeGoal_4001Parser() {
		EAttribute[] features = new EAttribute[] { SuitePackage.eINSTANCE
				.getGoalPlanType_Goal(), };
		MessageFormatParser parser = new MessageFormatParser(features);
		return parser;
	}

	/**
	 * @generated
	 */
	private IParser taskType1Name_4003Parser;

	/**
	 * @generated
	 */
	private IParser getTaskType1Name_4003Parser() {
		if (taskType1Name_4003Parser == null) {
			taskType1Name_4003Parser = createTaskType1Name_4003Parser();
		}
		return taskType1Name_4003Parser;
	}

	/**
	 * @generated
	 */
	protected IParser createTaskType1Name_4003Parser() {
		EAttribute[] features = new EAttribute[] { SuitePackage.eINSTANCE
				.getTaskType1_Name(), };
		MessageFormatParser parser = new MessageFormatParser(features);
		return parser;
	}

	/**
	 * @generated
	 */
	private IParser tActionTypeActType_4009Parser;

	/**
	 * @generated
	 */
	private IParser getTActionTypeActType_4009Parser() {
		if (tActionTypeActType_4009Parser == null) {
			tActionTypeActType_4009Parser = createTActionTypeActType_4009Parser();
		}
		return tActionTypeActType_4009Parser;
	}

	/**
	 * @generated
	 */
	protected IParser createTActionTypeActType_4009Parser() {
		EAttribute[] features = new EAttribute[] { SuitePackage.eINSTANCE
				.getTActionType_ActType(), };
		MessageFormatParser parser = new MessageFormatParser(features);
		return parser;
	}

	/**
	 * @generated
	 */
	private IParser fipaMessageTypeIdAct_4006Parser;

	/**
	 * @generated
	 */
	private IParser getFipaMessageTypeIdAct_4006Parser() {
		if (fipaMessageTypeIdAct_4006Parser == null) {
			fipaMessageTypeIdAct_4006Parser = createFipaMessageTypeIdAct_4006Parser();
		}
		return fipaMessageTypeIdAct_4006Parser;
	}

	/**
	 * @generated
	 */
	protected IParser createFipaMessageTypeIdAct_4006Parser() {
		EAttribute[] features = new EAttribute[] {
				SchemaPackage.eINSTANCE.getFipaMessageType_Id(),
				SchemaPackage.eINSTANCE.getFipaMessageType_Act(), };
		MessageFormatParser parser = new MessageFormatParser(features);
		return parser;
	}

	/**
	 * @generated
	 */
	private IParser contentTypeValue_4005Parser;

	/**
	 * @generated
	 */
	private IParser getContentTypeValue_4005Parser() {
		if (contentTypeValue_4005Parser == null) {
			contentTypeValue_4005Parser = createContentTypeValue_4005Parser();
		}
		return contentTypeValue_4005Parser;
	}

	/**
	 * @generated
	 */
	protected IParser createContentTypeValue_4005Parser() {
		EAttribute[] features = new EAttribute[] { SchemaPackage.eINSTANCE
				.getContentType_Value(), };
		MessageFormatParser parser = new MessageFormatParser(features);
		return parser;
	}

	/**
	 * @generated
	 */
	private IParser checkTypeCheckOperator_4008Parser;

	/**
	 * @generated
	 */
	private IParser getCheckTypeCheckOperator_4008Parser() {
		if (checkTypeCheckOperator_4008Parser == null) {
			checkTypeCheckOperator_4008Parser = createCheckTypeCheckOperator_4008Parser();
		}
		return checkTypeCheckOperator_4008Parser;
	}

	/**
	 * @generated
	 */
	protected IParser createCheckTypeCheckOperator_4008Parser() {
		EAttribute[] features = new EAttribute[] { SuitePackage.eINSTANCE
				.getCheckType_CheckOperator(), };
		MessageFormatParser parser = new MessageFormatParser(features);
		return parser;
	}

	/**
	 * @generated
	 */
	private IParser fipaMessageTypeAct_4007Parser;

	/**
	 * @generated
	 */
	private IParser getFipaMessageTypeAct_4007Parser() {
		if (fipaMessageTypeAct_4007Parser == null) {
			fipaMessageTypeAct_4007Parser = createFipaMessageTypeAct_4007Parser();
		}
		return fipaMessageTypeAct_4007Parser;
	}

	/**
	 * @generated
	 */
	protected IParser createFipaMessageTypeAct_4007Parser() {
		EAttribute[] features = new EAttribute[] { SchemaPackage.eINSTANCE
				.getFipaMessageType_Act(), };
		MessageFormatParser parser = new MessageFormatParser(features);
		return parser;
	}

	/**
	 * @generated
	 */
	private IParser taskType1Name_4011Parser;

	/**
	 * @generated
	 */
	private IParser getTaskType1Name_4011Parser() {
		if (taskType1Name_4011Parser == null) {
			taskType1Name_4011Parser = createTaskType1Name_4011Parser();
		}
		return taskType1Name_4011Parser;
	}

	/**
	 * @generated
	 */
	protected IParser createTaskType1Name_4011Parser() {
		EAttribute[] features = new EAttribute[] { SuitePackage.eINSTANCE
				.getTaskType1_Name(), };
		MessageFormatParser parser = new MessageFormatParser(features);
		return parser;
	}

	/**
	 * @generated
	 */
	private IParser orderLinkTypeDesc_4013Parser;

	/**
	 * @generated
	 */
	private IParser getOrderLinkTypeDesc_4013Parser() {
		if (orderLinkTypeDesc_4013Parser == null) {
			orderLinkTypeDesc_4013Parser = createOrderLinkTypeDesc_4013Parser();
		}
		return orderLinkTypeDesc_4013Parser;
	}

	/**
	 * @generated
	 */
	protected IParser createOrderLinkTypeDesc_4013Parser() {
		EAttribute[] features = new EAttribute[] { SuitePackage.eINSTANCE
				.getOrderLinkType_Desc(), };
		MessageFormatParser parser = new MessageFormatParser(features);
		return parser;
	}

	/**
	 * @generated
	 */
	private IParser sendLinkTypeName_4014Parser;

	/**
	 * @generated
	 */
	private IParser getSendLinkTypeName_4014Parser() {
		if (sendLinkTypeName_4014Parser == null) {
			sendLinkTypeName_4014Parser = createSendLinkTypeName_4014Parser();
		}
		return sendLinkTypeName_4014Parser;
	}

	/**
	 * @generated
	 */
	protected IParser createSendLinkTypeName_4014Parser() {
		EAttribute[] features = new EAttribute[] { SuitePackage.eINSTANCE
				.getSendLinkType_Name(), };
		MessageFormatParser parser = new MessageFormatParser(features);
		return parser;
	}

	/**
	 * @generated
	 */
	private IParser receiveLinkTypeName_4015Parser;

	/**
	 * @generated
	 */
	private IParser getReceiveLinkTypeName_4015Parser() {
		if (receiveLinkTypeName_4015Parser == null) {
			receiveLinkTypeName_4015Parser = createReceiveLinkTypeName_4015Parser();
		}
		return receiveLinkTypeName_4015Parser;
	}

	/**
	 * @generated
	 */
	protected IParser createReceiveLinkTypeName_4015Parser() {
		EAttribute[] features = new EAttribute[] { SuitePackage.eINSTANCE
				.getReceiveLinkType_Name(), };
		MessageFormatParser parser = new MessageFormatParser(features);
		return parser;
	}

	/**
	 * @generated
	 */
	private IParser goalLinkTypeName_4016Parser;

	/**
	 * @generated
	 */
	private IParser getGoalLinkTypeName_4016Parser() {
		if (goalLinkTypeName_4016Parser == null) {
			goalLinkTypeName_4016Parser = createGoalLinkTypeName_4016Parser();
		}
		return goalLinkTypeName_4016Parser;
	}

	/**
	 * @generated
	 */
	protected IParser createGoalLinkTypeName_4016Parser() {
		EAttribute[] features = new EAttribute[] { SuitePackage.eINSTANCE
				.getGoalLinkType_Name(), };
		MessageFormatParser parser = new MessageFormatParser(features);
		return parser;
	}

	/**
	 * @generated
	 */
	protected IParser getParser(int visualID) {
		switch (visualID) {
		case TargetTypeAgentEditPart.VISUAL_ID:
			return getTargetTypeAgent_4002Parser();
		case SetupTypeNameEditPart.VISUAL_ID:
			return getSetupTypeName_4004Parser();
		case TestCaseTypeNameEditPart.VISUAL_ID:
			return getTestCaseTypeName_4010Parser();
		case TeardownTypeNameEditPart.VISUAL_ID:
			return getTeardownTypeName_4012Parser();
		case GoalPlanTypeGoalEditPart.VISUAL_ID:
			return getGoalPlanTypeGoal_4001Parser();
		case TaskType1NameEditPart.VISUAL_ID:
			return getTaskType1Name_4003Parser();
		case TActionTypeActTypeEditPart.VISUAL_ID:
			return getTActionTypeActType_4009Parser();
		case FipaMessageTypeIdActEditPart.VISUAL_ID:
			return getFipaMessageTypeIdAct_4006Parser();
		case ContentTypeValueEditPart.VISUAL_ID:
			return getContentTypeValue_4005Parser();
		case CheckTypeCheckOperatorEditPart.VISUAL_ID:
			return getCheckTypeCheckOperator_4008Parser();
		case FipaMessageTypeActEditPart.VISUAL_ID:
			return getFipaMessageTypeAct_4007Parser();
		case TaskType1Name2EditPart.VISUAL_ID:
			return getTaskType1Name_4011Parser();
		case OrderLinkTypeDescEditPart.VISUAL_ID:
			return getOrderLinkTypeDesc_4013Parser();
		case SendLinkTypeNameEditPart.VISUAL_ID:
			return getSendLinkTypeName_4014Parser();
		case ReceiveLinkTypeNameEditPart.VISUAL_ID:
			return getReceiveLinkTypeName_4015Parser();
		case GoalLinkTypeNameEditPart.VISUAL_ID:
			return getGoalLinkTypeName_4016Parser();
		}
		return null;
	}

	/**
	 * @generated
	 */
	public IParser getParser(IAdaptable hint) {
		String vid = (String) hint.getAdapter(String.class);
		if (vid != null) {
			return getParser(SuiteVisualIDRegistry.getVisualID(vid));
		}
		View view = (View) hint.getAdapter(View.class);
		if (view != null) {
			return getParser(SuiteVisualIDRegistry.getVisualID(view));
		}
		return null;
	}

	/**
	 * @generated
	 */
	public boolean provides(IOperation operation) {
		if (operation instanceof GetParserOperation) {
			IAdaptable hint = ((GetParserOperation) operation).getHint();
			if (SuiteElementTypes.getElement(hint) == null) {
				return false;
			}
			return getParser(hint) != null;
		}
		return false;
	}

	/**
	 * @generated
	 */
	public static class HintAdapter extends ParserHintAdapter {

		/**
		 * @generated
		 */
		private final IElementType elementType;

		/**
		 * @generated
		 */
		public HintAdapter(IElementType type, EObject object, String parserHint) {
			super(object, parserHint);
			assert type != null;
			elementType = type;
		}

		/**
		 * @generated
		 */
		public Object getAdapter(Class adapter) {
			if (IElementType.class.equals(adapter)) {
				return elementType;
			}
			return super.getAdapter(adapter);
		}
	}

}
