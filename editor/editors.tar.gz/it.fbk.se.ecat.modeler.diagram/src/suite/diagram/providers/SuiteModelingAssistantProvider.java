package suite.diagram.providers;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.edit.ui.provider.AdapterFactoryLabelProvider;
import org.eclipse.gmf.runtime.diagram.ui.editparts.IGraphicalEditPart;
import org.eclipse.gmf.runtime.emf.type.core.ElementTypeRegistry;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;
import org.eclipse.gmf.runtime.emf.ui.services.modelingassistant.ModelingAssistantProvider;
import org.eclipse.gmf.runtime.notation.Diagram;
import org.eclipse.jface.viewers.ILabelProvider;
import org.eclipse.jface.window.Window;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.dialogs.ElementListSelectionDialog;

import suite.diagram.edit.parts.CheckTypeACLMessageCompartmentEditPart;
import suite.diagram.edit.parts.FipaMessageType2EditPart;
import suite.diagram.edit.parts.FipaMessageTypeACLMessageContentCompartment2EditPart;
import suite.diagram.edit.parts.FipaMessageTypeACLMessageContentCompartmentEditPart;
import suite.diagram.edit.parts.FipaMessageTypeEditPart;
import suite.diagram.edit.parts.GoalPlanTypeEditPart;
import suite.diagram.edit.parts.SetupTypeTestSupportCompartmentEditPart;
import suite.diagram.edit.parts.TActionTypeACLMessageCompartmentEditPart;
import suite.diagram.edit.parts.TActionTypeEditPart;
import suite.diagram.edit.parts.TActionTypeOracleCompartmentEditPart;
import suite.diagram.edit.parts.TargetTypeEditPart;
import suite.diagram.edit.parts.TargetTypeTargetTypeCompartmentEditPart;
import suite.diagram.edit.parts.TeardownTypeTestTeardownCompartmentEditPart;
import suite.diagram.edit.parts.TestCaseTypeTestCaseCompartmentEditPart;
import suite.diagram.edit.parts.TestScenarioTypeTestScenarioCompartmentEditPart;
import suite.diagram.edit.parts.TestSuiteTypeEditPart;
import suite.diagram.part.Messages;
import suite.diagram.part.SuiteDiagramEditorPlugin;

/**
 * @generated
 */
public class SuiteModelingAssistantProvider extends ModelingAssistantProvider {

	/**
	 * @generated
	 */
	public List getTypesForPopupBar(IAdaptable host) {
		IGraphicalEditPart editPart = (IGraphicalEditPart) host
				.getAdapter(IGraphicalEditPart.class);
		if (editPart instanceof TargetTypeTargetTypeCompartmentEditPart) {
			List types = new ArrayList();
			types.add(SuiteElementTypes.GoalPlanType_2001);
			return types;
		}
		if (editPart instanceof SetupTypeTestSupportCompartmentEditPart) {
			List types = new ArrayList();
			types.add(SuiteElementTypes.TaskType1_2002);
			return types;
		}
		if (editPart instanceof TestCaseTypeTestCaseCompartmentEditPart) {
			List types = new ArrayList();
			types.add(SuiteElementTypes.TestScenarioType_2003);
			return types;
		}
		if (editPart instanceof TestScenarioTypeTestScenarioCompartmentEditPart) {
			List types = new ArrayList();
			types.add(SuiteElementTypes.TActionType_2004);
			return types;
		}
		if (editPart instanceof TActionTypeACLMessageCompartmentEditPart) {
			List types = new ArrayList();
			types.add(SuiteElementTypes.FipaMessageType_2005);
			return types;
		}
		if (editPart instanceof TActionTypeOracleCompartmentEditPart) {
			List types = new ArrayList();
			types.add(SuiteElementTypes.CheckType_2007);
			return types;
		}
		if (editPart instanceof FipaMessageTypeACLMessageContentCompartmentEditPart) {
			List types = new ArrayList();
			types.add(SuiteElementTypes.ContentType_2006);
			return types;
		}
		if (editPart instanceof CheckTypeACLMessageCompartmentEditPart) {
			List types = new ArrayList();
			types.add(SuiteElementTypes.FipaMessageType_2008);
			return types;
		}
		if (editPart instanceof FipaMessageTypeACLMessageContentCompartment2EditPart) {
			List types = new ArrayList();
			types.add(SuiteElementTypes.ContentType_2009);
			return types;
		}
		if (editPart instanceof TeardownTypeTestTeardownCompartmentEditPart) {
			List types = new ArrayList();
			types.add(SuiteElementTypes.TaskType1_2010);
			return types;
		}
		if (editPart instanceof TestSuiteTypeEditPart) {
			List types = new ArrayList();
			types.add(SuiteElementTypes.TargetType_1001);
			types.add(SuiteElementTypes.SetupType_1002);
			types.add(SuiteElementTypes.TestCaseType_1003);
			types.add(SuiteElementTypes.TeardownType_1004);
			return types;
		}
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public List getRelTypesOnSource(IAdaptable source) {
		IGraphicalEditPart sourceEditPart = (IGraphicalEditPart) source
				.getAdapter(IGraphicalEditPart.class);
		if (sourceEditPart instanceof TargetTypeEditPart) {
			List types = new ArrayList();
			types.add(SuiteElementTypes.ReceiveLinkType_3003);
			return types;
		}
		if (sourceEditPart instanceof TActionTypeEditPart) {
			List types = new ArrayList();
			types.add(SuiteElementTypes.OrderLinkType_3001);
			types.add(SuiteElementTypes.SendLinkType_3002);
			types.add(SuiteElementTypes.GoalLinkType_3004);
			return types;
		}
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public List getRelTypesOnTarget(IAdaptable target) {
		IGraphicalEditPart targetEditPart = (IGraphicalEditPart) target
				.getAdapter(IGraphicalEditPart.class);
		if (targetEditPart instanceof TargetTypeEditPart) {
			List types = new ArrayList();
			types.add(SuiteElementTypes.SendLinkType_3002);
			return types;
		}
		if (targetEditPart instanceof GoalPlanTypeEditPart) {
			List types = new ArrayList();
			types.add(SuiteElementTypes.GoalLinkType_3004);
			return types;
		}
		if (targetEditPart instanceof TActionTypeEditPart) {
			List types = new ArrayList();
			types.add(SuiteElementTypes.OrderLinkType_3001);
			types.add(SuiteElementTypes.ReceiveLinkType_3003);
			return types;
		}
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public List getRelTypesOnSourceAndTarget(IAdaptable source,
			IAdaptable target) {
		IGraphicalEditPart sourceEditPart = (IGraphicalEditPart) source
				.getAdapter(IGraphicalEditPart.class);
		IGraphicalEditPart targetEditPart = (IGraphicalEditPart) target
				.getAdapter(IGraphicalEditPart.class);
		if (sourceEditPart instanceof TargetTypeEditPart) {
			List types = new ArrayList();
			if (targetEditPart instanceof TActionTypeEditPart) {
				types.add(SuiteElementTypes.ReceiveLinkType_3003);
			}
			return types;
		}
		if (sourceEditPart instanceof TActionTypeEditPart) {
			List types = new ArrayList();
			if (targetEditPart instanceof TActionTypeEditPart) {
				types.add(SuiteElementTypes.OrderLinkType_3001);
			}
			if (targetEditPart instanceof TargetTypeEditPart) {
				types.add(SuiteElementTypes.SendLinkType_3002);
			}
			if (targetEditPart instanceof GoalPlanTypeEditPart) {
				types.add(SuiteElementTypes.GoalLinkType_3004);
			}
			return types;
		}
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public List getTypesForSource(IAdaptable target,
			IElementType relationshipType) {
		IGraphicalEditPart targetEditPart = (IGraphicalEditPart) target
				.getAdapter(IGraphicalEditPart.class);
		if (targetEditPart instanceof TargetTypeEditPart) {
			List types = new ArrayList();
			if (relationshipType == SuiteElementTypes.SendLinkType_3002) {
				types.add(SuiteElementTypes.TActionType_2004);
			}
			return types;
		}
		if (targetEditPart instanceof GoalPlanTypeEditPart) {
			List types = new ArrayList();
			if (relationshipType == SuiteElementTypes.GoalLinkType_3004) {
				types.add(SuiteElementTypes.TActionType_2004);
			}
			return types;
		}
		if (targetEditPart instanceof TActionTypeEditPart) {
			List types = new ArrayList();
			if (relationshipType == SuiteElementTypes.OrderLinkType_3001) {
				types.add(SuiteElementTypes.TActionType_2004);
			}
			if (relationshipType == SuiteElementTypes.ReceiveLinkType_3003) {
				types.add(SuiteElementTypes.TargetType_1001);
			}
			return types;
		}
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public List getTypesForTarget(IAdaptable source,
			IElementType relationshipType) {
		IGraphicalEditPart sourceEditPart = (IGraphicalEditPart) source
				.getAdapter(IGraphicalEditPart.class);
		if (sourceEditPart instanceof TargetTypeEditPart) {
			List types = new ArrayList();
			if (relationshipType == SuiteElementTypes.ReceiveLinkType_3003) {
				types.add(SuiteElementTypes.TActionType_2004);
			}
			return types;
		}
		if (sourceEditPart instanceof TActionTypeEditPart) {
			List types = new ArrayList();
			if (relationshipType == SuiteElementTypes.OrderLinkType_3001) {
				types.add(SuiteElementTypes.TActionType_2004);
			}
			if (relationshipType == SuiteElementTypes.SendLinkType_3002) {
				types.add(SuiteElementTypes.TargetType_1001);
			}
			if (relationshipType == SuiteElementTypes.GoalLinkType_3004) {
				types.add(SuiteElementTypes.GoalPlanType_2001);
			}
			return types;
		}
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public EObject selectExistingElementForSource(IAdaptable target,
			IElementType relationshipType) {
		return selectExistingElement(target, getTypesForSource(target,
				relationshipType));
	}

	/**
	 * @generated
	 */
	public EObject selectExistingElementForTarget(IAdaptable source,
			IElementType relationshipType) {
		return selectExistingElement(source, getTypesForTarget(source,
				relationshipType));
	}

	/**
	 * @generated
	 */
	protected EObject selectExistingElement(IAdaptable host, Collection types) {
		if (types.isEmpty()) {
			return null;
		}
		IGraphicalEditPart editPart = (IGraphicalEditPart) host
				.getAdapter(IGraphicalEditPart.class);
		if (editPart == null) {
			return null;
		}
		Diagram diagram = (Diagram) editPart.getRoot().getContents().getModel();
		Collection elements = new HashSet();
		for (Iterator it = diagram.getElement().eAllContents(); it.hasNext();) {
			EObject element = (EObject) it.next();
			if (isApplicableElement(element, types)) {
				elements.add(element);
			}
		}
		if (elements.isEmpty()) {
			return null;
		}
		return selectElement((EObject[]) elements.toArray(new EObject[elements
				.size()]));
	}

	/**
	 * @generated
	 */
	protected boolean isApplicableElement(EObject element, Collection types) {
		IElementType type = ElementTypeRegistry.getInstance().getElementType(
				element);
		return types.contains(type);
	}

	/**
	 * @generated
	 */
	protected EObject selectElement(EObject[] elements) {
		Shell shell = Display.getCurrent().getActiveShell();
		ILabelProvider labelProvider = new AdapterFactoryLabelProvider(
				SuiteDiagramEditorPlugin.getInstance()
						.getItemProvidersAdapterFactory());
		ElementListSelectionDialog dialog = new ElementListSelectionDialog(
				shell, labelProvider);
		dialog.setMessage(Messages.SuiteModelingAssistantProviderMessage);
		dialog.setTitle(Messages.SuiteModelingAssistantProviderTitle);
		dialog.setMultipleSelection(false);
		dialog.setElements(elements);
		EObject selected = null;
		if (dialog.open() == Window.OK) {
			selected = (EObject) dialog.getFirstResult();
		}
		return selected;
	}
}
