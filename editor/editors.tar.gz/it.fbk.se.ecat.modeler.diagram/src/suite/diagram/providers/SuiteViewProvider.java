package suite.diagram.providers;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.gmf.runtime.diagram.core.providers.AbstractViewProvider;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;
import org.eclipse.gmf.runtime.emf.type.core.IHintedType;
import org.eclipse.gmf.runtime.notation.View;

import suite.diagram.edit.parts.CheckTypeACLMessageCompartmentEditPart;
import suite.diagram.edit.parts.CheckTypeCheckOperatorEditPart;
import suite.diagram.edit.parts.CheckTypeEditPart;
import suite.diagram.edit.parts.ContentType2EditPart;
import suite.diagram.edit.parts.ContentTypeEditPart;
import suite.diagram.edit.parts.ContentTypeValueEditPart;
import suite.diagram.edit.parts.FipaMessageType2EditPart;
import suite.diagram.edit.parts.FipaMessageTypeACLMessageContentCompartment2EditPart;
import suite.diagram.edit.parts.FipaMessageTypeACLMessageContentCompartmentEditPart;
import suite.diagram.edit.parts.FipaMessageTypeActEditPart;
import suite.diagram.edit.parts.FipaMessageTypeEditPart;
import suite.diagram.edit.parts.FipaMessageTypeIdActEditPart;
import suite.diagram.edit.parts.GoalLinkTypeEditPart;
import suite.diagram.edit.parts.GoalLinkTypeNameEditPart;
import suite.diagram.edit.parts.GoalPlanTypeEditPart;
import suite.diagram.edit.parts.GoalPlanTypeGoalEditPart;
import suite.diagram.edit.parts.OrderLinkTypeDescEditPart;
import suite.diagram.edit.parts.OrderLinkTypeEditPart;
import suite.diagram.edit.parts.ReceiveLinkTypeEditPart;
import suite.diagram.edit.parts.ReceiveLinkTypeNameEditPart;
import suite.diagram.edit.parts.SendLinkTypeEditPart;
import suite.diagram.edit.parts.SendLinkTypeNameEditPart;
import suite.diagram.edit.parts.SetupTypeEditPart;
import suite.diagram.edit.parts.SetupTypeNameEditPart;
import suite.diagram.edit.parts.SetupTypeTestSupportCompartmentEditPart;
import suite.diagram.edit.parts.TActionTypeACLMessageCompartmentEditPart;
import suite.diagram.edit.parts.TActionTypeActTypeEditPart;
import suite.diagram.edit.parts.TActionTypeEditPart;
import suite.diagram.edit.parts.TActionTypeOracleCompartmentEditPart;
import suite.diagram.edit.parts.TargetTypeAgentEditPart;
import suite.diagram.edit.parts.TargetTypeEditPart;
import suite.diagram.edit.parts.TargetTypeTargetTypeCompartmentEditPart;
import suite.diagram.edit.parts.TaskType12EditPart;
import suite.diagram.edit.parts.TaskType1EditPart;
import suite.diagram.edit.parts.TaskType1Name2EditPart;
import suite.diagram.edit.parts.TaskType1NameEditPart;
import suite.diagram.edit.parts.TeardownTypeEditPart;
import suite.diagram.edit.parts.TeardownTypeNameEditPart;
import suite.diagram.edit.parts.TeardownTypeTestTeardownCompartmentEditPart;
import suite.diagram.edit.parts.TestCaseTypeEditPart;
import suite.diagram.edit.parts.TestCaseTypeNameEditPart;
import suite.diagram.edit.parts.TestCaseTypeTestCaseCompartmentEditPart;
import suite.diagram.edit.parts.TestScenarioTypeEditPart;
import suite.diagram.edit.parts.TestScenarioTypeTestScenarioCompartmentEditPart;
import suite.diagram.edit.parts.TestSuiteTypeEditPart;
import suite.diagram.part.SuiteVisualIDRegistry;
import suite.diagram.view.factories.CheckTypeACLMessageCompartmentViewFactory;
import suite.diagram.view.factories.CheckTypeCheckOperatorViewFactory;
import suite.diagram.view.factories.CheckTypeViewFactory;
import suite.diagram.view.factories.ContentType2ViewFactory;
import suite.diagram.view.factories.ContentTypeValueViewFactory;
import suite.diagram.view.factories.ContentTypeViewFactory;
import suite.diagram.view.factories.FipaMessageType2ViewFactory;
import suite.diagram.view.factories.FipaMessageTypeACLMessageContentCompartment2ViewFactory;
import suite.diagram.view.factories.FipaMessageTypeACLMessageContentCompartmentViewFactory;
import suite.diagram.view.factories.FipaMessageTypeActViewFactory;
import suite.diagram.view.factories.FipaMessageTypeIdActViewFactory;
import suite.diagram.view.factories.FipaMessageTypeViewFactory;
import suite.diagram.view.factories.GoalLinkTypeNameViewFactory;
import suite.diagram.view.factories.GoalLinkTypeViewFactory;
import suite.diagram.view.factories.GoalPlanTypeGoalViewFactory;
import suite.diagram.view.factories.GoalPlanTypeViewFactory;
import suite.diagram.view.factories.OrderLinkDescViewFactory;
import suite.diagram.view.factories.OrderLinkTypeDescViewFactory;
import suite.diagram.view.factories.OrderLinkTypeViewFactory;
import suite.diagram.view.factories.ReceiveLinkTypeNameViewFactory;
import suite.diagram.view.factories.ReceiveLinkTypeViewFactory;
import suite.diagram.view.factories.SendLinkTypeNameViewFactory;
import suite.diagram.view.factories.SendLinkTypeViewFactory;
import suite.diagram.view.factories.SetupTypeNameViewFactory;
import suite.diagram.view.factories.SetupTypeTestSupportCompartmentViewFactory;
import suite.diagram.view.factories.SetupTypeViewFactory;
import suite.diagram.view.factories.TActionTypeACLMessageCompartmentViewFactory;
import suite.diagram.view.factories.TActionTypeActTypeViewFactory;
import suite.diagram.view.factories.TActionTypeOracleCompartmentViewFactory;
import suite.diagram.view.factories.TActionTypeViewFactory;
import suite.diagram.view.factories.TargetTypeAgentViewFactory;
import suite.diagram.view.factories.TargetTypeTargetTypeCompartmentViewFactory;
import suite.diagram.view.factories.TargetTypeViewFactory;
import suite.diagram.view.factories.TaskType12ViewFactory;
import suite.diagram.view.factories.TaskType1Name2ViewFactory;
import suite.diagram.view.factories.TaskType1NameViewFactory;
import suite.diagram.view.factories.TaskType1ViewFactory;
import suite.diagram.view.factories.TeardownTypeNameViewFactory;
import suite.diagram.view.factories.TeardownTypeTestTeardownCompartmentViewFactory;
import suite.diagram.view.factories.TeardownTypeViewFactory;
import suite.diagram.view.factories.TestCaseTypeNameViewFactory;
import suite.diagram.view.factories.TestCaseTypeTestCaseCompartmentViewFactory;
import suite.diagram.view.factories.TestCaseTypeViewFactory;
import suite.diagram.view.factories.TestScenarioTypeTestScenarioCompartmentViewFactory;
import suite.diagram.view.factories.TestScenarioTypeViewFactory;
import suite.diagram.view.factories.TestSuiteTypeViewFactory;

/**
 * @generated
 */
public class SuiteViewProvider extends AbstractViewProvider {

	/**
	 * @generated
	 */
	protected Class getDiagramViewClass(IAdaptable semanticAdapter,
			String diagramKind) {
		EObject semanticElement = getSemanticElement(semanticAdapter);
		if (TestSuiteTypeEditPart.MODEL_ID.equals(diagramKind)
				&& SuiteVisualIDRegistry.getDiagramVisualID(semanticElement) != -1) {
			return TestSuiteTypeViewFactory.class;
		}
		return null;
	}

	/**
	 * @generated
	 */
	protected Class getNodeViewClass(IAdaptable semanticAdapter,
			View containerView, String semanticHint) {
		if (containerView == null) {
			return null;
		}
		IElementType elementType = getSemanticElementType(semanticAdapter);
		EObject domainElement = getSemanticElement(semanticAdapter);
		int visualID;
		if (semanticHint == null) {
			// Semantic hint is not specified. Can be a result of call from CanonicalEditPolicy.
			// In this situation there should be NO elementType, visualID will be determined
			// by VisualIDRegistry.getNodeVisualID() for domainElement.
			if (elementType != null || domainElement == null) {
				return null;
			}
			visualID = SuiteVisualIDRegistry.getNodeVisualID(containerView,
					domainElement);
		} else {
			visualID = SuiteVisualIDRegistry.getVisualID(semanticHint);
			if (elementType != null) {
				// Semantic hint is specified together with element type.
				// Both parameters should describe exactly the same diagram element.
				// In addition we check that visualID returned by VisualIDRegistry.getNodeVisualID() for
				// domainElement (if specified) is the same as in element type.
				if (!SuiteElementTypes.isKnownElementType(elementType)
						|| (!(elementType instanceof IHintedType))) {
					return null; // foreign element type
				}
				String elementTypeHint = ((IHintedType) elementType)
						.getSemanticHint();
				if (!semanticHint.equals(elementTypeHint)) {
					return null; // if semantic hint is specified it should be the same as in element type
				}
				if (domainElement != null
						&& visualID != SuiteVisualIDRegistry.getNodeVisualID(
								containerView, domainElement)) {
					return null; // visual id for node EClass should match visual id from element type
				}
			} else {
				// Element type is not specified. Domain element should be present (except pure design elements).
				// This method is called with EObjectAdapter as parameter from:
				//   - ViewService.createNode(View container, EObject eObject, String type, PreferencesHint preferencesHint) 
				//   - generated ViewFactory.decorateView() for parent element
				if (!TestSuiteTypeEditPart.MODEL_ID
						.equals(SuiteVisualIDRegistry.getModelID(containerView))) {
					return null; // foreign diagram
				}
				switch (visualID) {
				case TargetTypeEditPart.VISUAL_ID:
				case SetupTypeEditPart.VISUAL_ID:
				case TestCaseTypeEditPart.VISUAL_ID:
				case TeardownTypeEditPart.VISUAL_ID:
				case GoalPlanTypeEditPart.VISUAL_ID:
				case TaskType1EditPart.VISUAL_ID:
				case TestScenarioTypeEditPart.VISUAL_ID:
				case TActionTypeEditPart.VISUAL_ID:
				case FipaMessageTypeEditPart.VISUAL_ID:
				case ContentTypeEditPart.VISUAL_ID:
				case CheckTypeEditPart.VISUAL_ID:
				case FipaMessageType2EditPart.VISUAL_ID:
				case ContentType2EditPart.VISUAL_ID:
				case TaskType12EditPart.VISUAL_ID:
					if (domainElement == null
							|| visualID != SuiteVisualIDRegistry
									.getNodeVisualID(containerView,
											domainElement)) {
						return null; // visual id in semantic hint should match visual id for domain element
					}
					break;
				case TargetTypeAgentEditPart.VISUAL_ID:
				case TargetTypeTargetTypeCompartmentEditPart.VISUAL_ID:
					if (TargetTypeEditPart.VISUAL_ID != SuiteVisualIDRegistry
							.getVisualID(containerView)
							|| containerView.getElement() != domainElement) {
						return null; // wrong container
					}
					break;
				case SetupTypeNameEditPart.VISUAL_ID:
				case SetupTypeTestSupportCompartmentEditPart.VISUAL_ID:
					if (SetupTypeEditPart.VISUAL_ID != SuiteVisualIDRegistry
							.getVisualID(containerView)
							|| containerView.getElement() != domainElement) {
						return null; // wrong container
					}
					break;
				case TestCaseTypeNameEditPart.VISUAL_ID:
				case TestCaseTypeTestCaseCompartmentEditPart.VISUAL_ID:
					if (TestCaseTypeEditPart.VISUAL_ID != SuiteVisualIDRegistry
							.getVisualID(containerView)
							|| containerView.getElement() != domainElement) {
						return null; // wrong container
					}
					break;
				case TeardownTypeNameEditPart.VISUAL_ID:
				case TeardownTypeTestTeardownCompartmentEditPart.VISUAL_ID:
					if (TeardownTypeEditPart.VISUAL_ID != SuiteVisualIDRegistry
							.getVisualID(containerView)
							|| containerView.getElement() != domainElement) {
						return null; // wrong container
					}
					break;
				case GoalPlanTypeGoalEditPart.VISUAL_ID:
					if (GoalPlanTypeEditPart.VISUAL_ID != SuiteVisualIDRegistry
							.getVisualID(containerView)
							|| containerView.getElement() != domainElement) {
						return null; // wrong container
					}
					break;
				case TaskType1NameEditPart.VISUAL_ID:
					if (TaskType1EditPart.VISUAL_ID != SuiteVisualIDRegistry
							.getVisualID(containerView)
							|| containerView.getElement() != domainElement) {
						return null; // wrong container
					}
					break;
				case TestScenarioTypeTestScenarioCompartmentEditPart.VISUAL_ID:
					if (TestScenarioTypeEditPart.VISUAL_ID != SuiteVisualIDRegistry
							.getVisualID(containerView)
							|| containerView.getElement() != domainElement) {
						return null; // wrong container
					}
					break;
				case TActionTypeActTypeEditPart.VISUAL_ID:
				case TActionTypeACLMessageCompartmentEditPart.VISUAL_ID:
				case TActionTypeOracleCompartmentEditPart.VISUAL_ID:
					if (TActionTypeEditPart.VISUAL_ID != SuiteVisualIDRegistry
							.getVisualID(containerView)
							|| containerView.getElement() != domainElement) {
						return null; // wrong container
					}
					break;
				case FipaMessageTypeIdActEditPart.VISUAL_ID:
				case FipaMessageTypeACLMessageContentCompartmentEditPart.VISUAL_ID:
					if (FipaMessageTypeEditPart.VISUAL_ID != SuiteVisualIDRegistry
							.getVisualID(containerView)
							|| containerView.getElement() != domainElement) {
						return null; // wrong container
					}
					break;
				case ContentTypeValueEditPart.VISUAL_ID:
					if (ContentTypeEditPart.VISUAL_ID != SuiteVisualIDRegistry
							.getVisualID(containerView)
							|| containerView.getElement() != domainElement) {
						return null; // wrong container
					}
					break;
				case CheckTypeCheckOperatorEditPart.VISUAL_ID:
				case CheckTypeACLMessageCompartmentEditPart.VISUAL_ID:
					if (CheckTypeEditPart.VISUAL_ID != SuiteVisualIDRegistry
							.getVisualID(containerView)
							|| containerView.getElement() != domainElement) {
						return null; // wrong container
					}
					break;
				case FipaMessageTypeActEditPart.VISUAL_ID:
				case FipaMessageTypeACLMessageContentCompartment2EditPart.VISUAL_ID:
					if (FipaMessageType2EditPart.VISUAL_ID != SuiteVisualIDRegistry
							.getVisualID(containerView)
							|| containerView.getElement() != domainElement) {
						return null; // wrong container
					}
					break;
				case TaskType1Name2EditPart.VISUAL_ID:
					if (TaskType12EditPart.VISUAL_ID != SuiteVisualIDRegistry
							.getVisualID(containerView)
							|| containerView.getElement() != domainElement) {
						return null; // wrong container
					}
					break;
				case OrderLinkTypeDescEditPart.VISUAL_ID:
					if (OrderLinkTypeEditPart.VISUAL_ID != SuiteVisualIDRegistry
							.getVisualID(containerView)
							|| containerView.getElement() != domainElement) {
						return null; // wrong container
					}
					break;
				case SendLinkTypeNameEditPart.VISUAL_ID:
					if (SendLinkTypeEditPart.VISUAL_ID != SuiteVisualIDRegistry
							.getVisualID(containerView)
							|| containerView.getElement() != domainElement) {
						return null; // wrong container
					}
					break;
				case ReceiveLinkTypeNameEditPart.VISUAL_ID:
					if (ReceiveLinkTypeEditPart.VISUAL_ID != SuiteVisualIDRegistry
							.getVisualID(containerView)
							|| containerView.getElement() != domainElement) {
						return null; // wrong container
					}
					break;
				case GoalLinkTypeNameEditPart.VISUAL_ID:
					if (GoalLinkTypeEditPart.VISUAL_ID != SuiteVisualIDRegistry
							.getVisualID(containerView)
							|| containerView.getElement() != domainElement) {
						return null; // wrong container
					}
					break;
				default:
					return null;
				}
			}
		}
		return getNodeViewClass(containerView, visualID);
	}

	/**
	 * @generated
	 */
	protected Class getNodeViewClass(View containerView, int visualID) {
		if (containerView == null
				|| !SuiteVisualIDRegistry
						.canCreateNode(containerView, visualID)) {
			return null;
		}
		switch (visualID) {
		case TargetTypeEditPart.VISUAL_ID:
			return TargetTypeViewFactory.class;
		case TargetTypeAgentEditPart.VISUAL_ID:
			return TargetTypeAgentViewFactory.class;
		case SetupTypeEditPart.VISUAL_ID:
			return SetupTypeViewFactory.class;
		case SetupTypeNameEditPart.VISUAL_ID:
			return SetupTypeNameViewFactory.class;
		case TestCaseTypeEditPart.VISUAL_ID:
			return TestCaseTypeViewFactory.class;
		case TestCaseTypeNameEditPart.VISUAL_ID:
			return TestCaseTypeNameViewFactory.class;
		case TeardownTypeEditPart.VISUAL_ID:
			return TeardownTypeViewFactory.class;
		case TeardownTypeNameEditPart.VISUAL_ID:
			return TeardownTypeNameViewFactory.class;
		case GoalPlanTypeEditPart.VISUAL_ID:
			return GoalPlanTypeViewFactory.class;
		case GoalPlanTypeGoalEditPart.VISUAL_ID:
			return GoalPlanTypeGoalViewFactory.class;
		case TaskType1EditPart.VISUAL_ID:
			return TaskType1ViewFactory.class;
		case TaskType1NameEditPart.VISUAL_ID:
			return TaskType1NameViewFactory.class;
		case TestScenarioTypeEditPart.VISUAL_ID:
			return TestScenarioTypeViewFactory.class;
		case TActionTypeEditPart.VISUAL_ID:
			return TActionTypeViewFactory.class;
		case TActionTypeActTypeEditPart.VISUAL_ID:
			return TActionTypeActTypeViewFactory.class;
		case FipaMessageTypeEditPart.VISUAL_ID:
			return FipaMessageTypeViewFactory.class;
		case FipaMessageTypeIdActEditPart.VISUAL_ID:
			return FipaMessageTypeIdActViewFactory.class;
		case ContentTypeEditPart.VISUAL_ID:
			return ContentTypeViewFactory.class;
		case ContentTypeValueEditPart.VISUAL_ID:
			return ContentTypeValueViewFactory.class;
		case CheckTypeEditPart.VISUAL_ID:
			return CheckTypeViewFactory.class;
		case CheckTypeCheckOperatorEditPart.VISUAL_ID:
			return CheckTypeCheckOperatorViewFactory.class;
		case FipaMessageType2EditPart.VISUAL_ID:
			return FipaMessageType2ViewFactory.class;
		case FipaMessageTypeActEditPart.VISUAL_ID:
			return FipaMessageTypeActViewFactory.class;
		case ContentType2EditPart.VISUAL_ID:
			return ContentType2ViewFactory.class;
		case TaskType12EditPart.VISUAL_ID:
			return TaskType12ViewFactory.class;
		case TaskType1Name2EditPart.VISUAL_ID:
			return TaskType1Name2ViewFactory.class;
		case TargetTypeTargetTypeCompartmentEditPart.VISUAL_ID:
			return TargetTypeTargetTypeCompartmentViewFactory.class;
		case SetupTypeTestSupportCompartmentEditPart.VISUAL_ID:
			return SetupTypeTestSupportCompartmentViewFactory.class;
		case TestCaseTypeTestCaseCompartmentEditPart.VISUAL_ID:
			return TestCaseTypeTestCaseCompartmentViewFactory.class;
		case TestScenarioTypeTestScenarioCompartmentEditPart.VISUAL_ID:
			return TestScenarioTypeTestScenarioCompartmentViewFactory.class;
		case TActionTypeACLMessageCompartmentEditPart.VISUAL_ID:
			return TActionTypeACLMessageCompartmentViewFactory.class;
		case TActionTypeOracleCompartmentEditPart.VISUAL_ID:
			return TActionTypeOracleCompartmentViewFactory.class;
		case FipaMessageTypeACLMessageContentCompartmentEditPart.VISUAL_ID:
			return FipaMessageTypeACLMessageContentCompartmentViewFactory.class;
		case CheckTypeACLMessageCompartmentEditPart.VISUAL_ID:
			return CheckTypeACLMessageCompartmentViewFactory.class;
		case FipaMessageTypeACLMessageContentCompartment2EditPart.VISUAL_ID:
			return FipaMessageTypeACLMessageContentCompartment2ViewFactory.class;
		case TeardownTypeTestTeardownCompartmentEditPart.VISUAL_ID:
			return TeardownTypeTestTeardownCompartmentViewFactory.class;
		case OrderLinkTypeDescEditPart.VISUAL_ID:
			return OrderLinkTypeDescViewFactory.class;
		case SendLinkTypeNameEditPart.VISUAL_ID:
			return SendLinkTypeNameViewFactory.class;
		case ReceiveLinkTypeNameEditPart.VISUAL_ID:
			return ReceiveLinkTypeNameViewFactory.class;
		case GoalLinkTypeNameEditPart.VISUAL_ID:
			return GoalLinkTypeNameViewFactory.class;
		}
		return null;
	}

	/**
	 * @generated
	 */
	protected Class getEdgeViewClass(IAdaptable semanticAdapter,
			View containerView, String semanticHint) {
		IElementType elementType = getSemanticElementType(semanticAdapter);
		if (!SuiteElementTypes.isKnownElementType(elementType)
				|| (!(elementType instanceof IHintedType))) {
			return null; // foreign element type
		}
		String elementTypeHint = ((IHintedType) elementType).getSemanticHint();
		if (elementTypeHint == null) {
			return null; // our hint is visual id and must be specified
		}
		if (semanticHint != null && !semanticHint.equals(elementTypeHint)) {
			return null; // if semantic hint is specified it should be the same as in element type
		}
		int visualID = SuiteVisualIDRegistry.getVisualID(elementTypeHint);
		EObject domainElement = getSemanticElement(semanticAdapter);
		if (domainElement != null
				&& visualID != SuiteVisualIDRegistry
						.getLinkWithClassVisualID(domainElement)) {
			return null; // visual id for link EClass should match visual id from element type
		}
		return getEdgeViewClass(visualID);
	}

	/**
	 * @generated
	 */
	protected Class getEdgeViewClass(int visualID) {
		switch (visualID) {
		case OrderLinkTypeEditPart.VISUAL_ID:
			return OrderLinkTypeViewFactory.class;
		case SendLinkTypeEditPart.VISUAL_ID:
			return SendLinkTypeViewFactory.class;
		case ReceiveLinkTypeEditPart.VISUAL_ID:
			return ReceiveLinkTypeViewFactory.class;
		case GoalLinkTypeEditPart.VISUAL_ID:
			return GoalLinkTypeViewFactory.class;
		}
		return null;
	}

	/**
	 * @generated
	 */
	private IElementType getSemanticElementType(IAdaptable semanticAdapter) {
		if (semanticAdapter == null) {
			return null;
		}
		return (IElementType) semanticAdapter.getAdapter(IElementType.class);
	}
}
