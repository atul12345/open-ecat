package suite.diagram.providers;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import java.util.Map;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;

import schema.SchemaPackage;
import suite.SuitePackage;
import suite.TActionType;
import suite.diagram.expressions.SuiteAbstractExpression;
import suite.diagram.expressions.SuiteOCLFactory;
import suite.diagram.part.SuiteDiagramEditorPlugin;

/**
 * @generated
 */
public class ElementInitializers {

	/**
	 * @generated
	 */
	public static class Initializers {

		/**
		 * @generated
		 */
		public static final IObjectInitializer TestCaseType_1003 = new ObjectInitializer(
				SuitePackage.eINSTANCE.getTestCaseType()) {

			protected void init() {
				add(createExpressionFeatureInitializer(SuitePackage.eINSTANCE
						.getTestCaseType_Active(), SuiteOCLFactory
						.getExpression("true", //$NON-NLS-1$
								SuitePackage.eINSTANCE.getTestCaseType())));
				add(createExpressionFeatureInitializer(SuitePackage.eINSTANCE
						.getTestCaseType_Priority(), SuiteOCLFactory
						.getExpression("0", //$NON-NLS-1$
								SuitePackage.eINSTANCE.getTestCaseType())));
			}
		};
		/**
		 * @generated
		 */
		public static final IObjectInitializer GoalPlanType_2001 = new ObjectInitializer(
				SuitePackage.eINSTANCE.getGoalPlanType()) {

			protected void init() {
				add(createExpressionFeatureInitializer(SuitePackage.eINSTANCE
						.getGoalPlanType_Relationship(), SuiteOCLFactory
						.getExpression("RelationshipType::MeansEnd", //$NON-NLS-1$
								SuitePackage.eINSTANCE.getGoalPlanType())));
			}
		};
		/**
		 * @generated
		 */
		public static final IObjectInitializer TActionType_2004 = new ObjectInitializer(
				SuitePackage.eINSTANCE.getTActionType()) {

			protected void init() {
				add(createExpressionFeatureInitializer(SuitePackage.eINSTANCE
						.getTActionType_ActType(), SuiteOCLFactory
						.getExpression("AType::Communication", //$NON-NLS-1$
								SuitePackage.eINSTANCE.getTActionType())));
				add(createExpressionFeatureInitializer(SuitePackage.eINSTANCE
						.getTActionType_ID(), new SuiteAbstractExpression(
						SuitePackage.eINSTANCE.getTActionType()) {

					protected Object doEvaluate(Object context, Map env) {
						TActionType self = (TActionType) context;
						return Java.generateNewTAID(self);
					}
				}));
				add(createExpressionFeatureInitializer(SuitePackage.eINSTANCE
						.getTActionType_Timeout(), SuiteOCLFactory
						.getExpression("1000", //$NON-NLS-1$
								SuitePackage.eINSTANCE.getTActionType())));
			}
		};

		/**
		 * @generated
		 */
		public static final IObjectInitializer ContentType_2006 = new ObjectInitializer(
				SchemaPackage.eINSTANCE.getContentType()) {

			protected void init() {
				add(createExpressionFeatureInitializer(SchemaPackage.eINSTANCE
						.getContentType_Class(), SuiteOCLFactory.getExpression(
						"\'String\'", //$NON-NLS-1$
						SchemaPackage.eINSTANCE.getContentType())));
			}
		};

		/**
		 * @generated
		 */
		public static final IObjectInitializer OrderLinkType_3001 = new ObjectInitializer(
				SuitePackage.eINSTANCE.getOrderLinkType()) {

			protected void init() {
				add(createExpressionFeatureInitializer(SuitePackage.eINSTANCE
						.getOrderLinkType_OrderType(), SuiteOCLFactory
						.getExpression("OrderType::Subsequence", //$NON-NLS-1$
								SuitePackage.eINSTANCE.getOrderLinkType())));
			}
		};

		/**
		 * @generated
		 */
		private Initializers() {
		}

		/**
		 * @generated
		 */
		public static interface IObjectInitializer {

			/**
			 * @generated
			 */
			public void init(EObject instance);
		}

		/**
		 * @generated
		 */
		public static abstract class ObjectInitializer implements
				IObjectInitializer {

			/**
			 * @generated
			 */
			final EClass element;

			/**
			 * @generated
			 */
			private List featureInitializers = new ArrayList();

			/**
			 * @generated
			 */
			ObjectInitializer(EClass element) {
				this.element = element;
				init();
			}

			/**
			 * @generated
			 */
			protected abstract void init();

			/**
			 * @generated
			 */
			protected final IFeatureInitializer add(
					IFeatureInitializer initializer) {
				featureInitializers.add(initializer);
				return initializer;
			}

			/**
			 * @generated
			 */
			public void init(EObject instance) {
				for (Iterator it = featureInitializers.iterator(); it.hasNext();) {
					IFeatureInitializer nextExpr = (IFeatureInitializer) it
							.next();
					try {
						nextExpr.init(instance);
					} catch (RuntimeException e) {
						SuiteDiagramEditorPlugin.getInstance().logError(
								"Feature initialization failed", e); //$NON-NLS-1$						
					}
				}
			}
		}

		/**
		 * @generated
		 */
		interface IFeatureInitializer {

			/**
			 * @generated
			 */
			void init(EObject contextInstance);
		}

		/**
		 * @generated
		 */
		static IFeatureInitializer createNewElementFeatureInitializer(
				EStructuralFeature initFeature,
				ObjectInitializer[] newObjectInitializers) {
			final EStructuralFeature feature = initFeature;
			final ObjectInitializer[] initializers = newObjectInitializers;
			return new IFeatureInitializer() {

				public void init(EObject contextInstance) {
					for (int i = 0; i < initializers.length; i++) {
						EObject newInstance = initializers[i].element
								.getEPackage().getEFactoryInstance().create(
										initializers[i].element);
						if (feature.isMany()) {
							((Collection) contextInstance.eGet(feature))
									.add(newInstance);
						} else {
							contextInstance.eSet(feature, newInstance);
						}
						initializers[i].init(newInstance);
					}
				}
			};
		}

		/**
		 * @generated
		 */
		static IFeatureInitializer createExpressionFeatureInitializer(
				EStructuralFeature initFeature,
				SuiteAbstractExpression valueExpression) {
			final EStructuralFeature feature = initFeature;
			final SuiteAbstractExpression expression = valueExpression;
			return new IFeatureInitializer() {

				public void init(EObject contextInstance) {
					expression.assignTo(feature, contextInstance);
				}
			};
		}

		/**
		 * @generated
		 */
		static class Java {

			/**
			 * @generated NOT
			 */
			private static String generateNewTAID(TActionType self) {
				String genId = "TA" + Long.toString(System.currentTimeMillis());
				self.setID(genId);
				return genId;
			}
		}
	}
}
