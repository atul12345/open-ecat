package suite.diagram.providers;

import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Set;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EClassifier;
import org.eclipse.emf.ecore.ENamedElement;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.gmf.runtime.emf.type.core.ElementTypeRegistry;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.resource.ImageRegistry;
import org.eclipse.swt.graphics.Image;

import schema.SchemaPackage;
import suite.SuitePackage;
import suite.diagram.part.SuiteDiagramEditorPlugin;

/**
 * @generated
 */
public class SuiteElementTypes extends ElementInitializers {

	/**
	 * @generated
	 */
	private SuiteElementTypes() {
	}

	/**
	 * @generated
	 */
	private static Map elements;

	/**
	 * @generated
	 */
	private static ImageRegistry imageRegistry;

	/**
	 * @generated
	 */
	private static Set KNOWN_ELEMENT_TYPES;

	/**
	 * @generated
	 */
	public static final IElementType TestSuiteType_79 = getElementType("it.fbk.se.ecat.modeler.diagram.TestSuiteType_79"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType TargetType_1001 = getElementType("it.fbk.se.ecat.modeler.diagram.TargetType_1001"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType SetupType_1002 = getElementType("it.fbk.se.ecat.modeler.diagram.SetupType_1002"); //$NON-NLS-1$

	/**
	 * @generated
	 */
	public static final IElementType TestCaseType_1003 = getElementType("it.fbk.se.ecat.modeler.diagram.TestCaseType_1003"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType TeardownType_1004 = getElementType("it.fbk.se.ecat.modeler.diagram.TeardownType_1004"); //$NON-NLS-1$

	/**
	 * @generated
	 */
	public static final IElementType GoalPlanType_2001 = getElementType("it.fbk.se.ecat.modeler.diagram.GoalPlanType_2001"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType TaskType1_2002 = getElementType("it.fbk.se.ecat.modeler.diagram.TaskType1_2002"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType TestScenarioType_2003 = getElementType("it.fbk.se.ecat.modeler.diagram.TestScenarioType_2003"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType TActionType_2004 = getElementType("it.fbk.se.ecat.modeler.diagram.TActionType_2004"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType FipaMessageType_2005 = getElementType("it.fbk.se.ecat.modeler.diagram.FipaMessageType_2005"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType ContentType_2006 = getElementType("it.fbk.se.ecat.modeler.diagram.ContentType_2006"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType CheckType_2007 = getElementType("it.fbk.se.ecat.modeler.diagram.CheckType_2007"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType FipaMessageType_2008 = getElementType("it.fbk.se.ecat.modeler.diagram.FipaMessageType_2008"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType ContentType_2009 = getElementType("it.fbk.se.ecat.modeler.diagram.ContentType_2009"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType TaskType1_2010 = getElementType("it.fbk.se.ecat.modeler.diagram.TaskType1_2010"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType OrderLinkType_3001 = getElementType("it.fbk.se.ecat.modeler.diagram.OrderLinkType_3001"); //$NON-NLS-1$

	/**
	 * @generated
	 */
	public static final IElementType SendLinkType_3002 = getElementType("it.fbk.se.ecat.modeler.diagram.SendLinkType_3002"); //$NON-NLS-1$

	/**
	 * @generated
	 */
	public static final IElementType ReceiveLinkType_3003 = getElementType("it.fbk.se.ecat.modeler.diagram.ReceiveLinkType_3003"); //$NON-NLS-1$

	/**
	 * @generated
	 */
	public static final IElementType GoalLinkType_3004 = getElementType("it.fbk.se.ecat.modeler.diagram.GoalLinkType_3004"); //$NON-NLS-1$

	/**
	 * @generated
	 */
	private static ImageRegistry getImageRegistry() {
		if (imageRegistry == null) {
			imageRegistry = new ImageRegistry();
		}
		return imageRegistry;
	}

	/**
	 * @generated
	 */
	private static String getImageRegistryKey(ENamedElement element) {
		return element.getName();
	}

	/**
	 * @generated
	 */
	private static ImageDescriptor getProvidedImageDescriptor(
			ENamedElement element) {
		if (element instanceof EStructuralFeature) {
			EStructuralFeature feature = ((EStructuralFeature) element);
			EClass eContainingClass = feature.getEContainingClass();
			EClassifier eType = feature.getEType();
			if (eContainingClass != null && !eContainingClass.isAbstract()) {
				element = eContainingClass;
			} else if (eType instanceof EClass
					&& !((EClass) eType).isAbstract()) {
				element = eType;
			}
		}
		if (element instanceof EClass) {
			EClass eClass = (EClass) element;
			if (!eClass.isAbstract()) {
				return SuiteDiagramEditorPlugin.getInstance()
						.getItemImageDescriptor(
								eClass.getEPackage().getEFactoryInstance()
										.create(eClass));
			}
		}
		// TODO : support structural features
		return null;
	}

	/**
	 * @generated
	 */
	public static ImageDescriptor getImageDescriptor(ENamedElement element) {
		String key = getImageRegistryKey(element);
		ImageDescriptor imageDescriptor = getImageRegistry().getDescriptor(key);
		if (imageDescriptor == null) {
			imageDescriptor = getProvidedImageDescriptor(element);
			if (imageDescriptor == null) {
				imageDescriptor = ImageDescriptor.getMissingImageDescriptor();
			}
			getImageRegistry().put(key, imageDescriptor);
		}
		return imageDescriptor;
	}

	/**
	 * @generated
	 */
	public static Image getImage(ENamedElement element) {
		String key = getImageRegistryKey(element);
		Image image = getImageRegistry().get(key);
		if (image == null) {
			ImageDescriptor imageDescriptor = getProvidedImageDescriptor(element);
			if (imageDescriptor == null) {
				imageDescriptor = ImageDescriptor.getMissingImageDescriptor();
			}
			getImageRegistry().put(key, imageDescriptor);
			image = getImageRegistry().get(key);
		}
		return image;
	}

	/**
	 * @generated
	 */
	public static ImageDescriptor getImageDescriptor(IAdaptable hint) {
		ENamedElement element = getElement(hint);
		if (element == null) {
			return null;
		}
		return getImageDescriptor(element);
	}

	/**
	 * @generated
	 */
	public static Image getImage(IAdaptable hint) {
		ENamedElement element = getElement(hint);
		if (element == null) {
			return null;
		}
		return getImage(element);
	}

	/**
	 * Returns 'type' of the ecore object associated with the hint.
	 * 
	 * @generated
	 */
	public static ENamedElement getElement(IAdaptable hint) {
		Object type = hint.getAdapter(IElementType.class);
		if (elements == null) {
			elements = new IdentityHashMap();

			elements.put(TestSuiteType_79, SuitePackage.eINSTANCE
					.getTestSuiteType());

			elements.put(TargetType_1001, SuitePackage.eINSTANCE
					.getTargetType());

			elements.put(SetupType_1002, SuitePackage.eINSTANCE.getSetupType());

			elements.put(TestCaseType_1003, SuitePackage.eINSTANCE
					.getTestCaseType());

			elements.put(TeardownType_1004, SuitePackage.eINSTANCE
					.getTeardownType());

			elements.put(GoalPlanType_2001, SuitePackage.eINSTANCE
					.getGoalPlanType());

			elements.put(TaskType1_2002, SuitePackage.eINSTANCE.getTaskType1());

			elements.put(TestScenarioType_2003, SuitePackage.eINSTANCE
					.getTestScenarioType());

			elements.put(TActionType_2004, SuitePackage.eINSTANCE
					.getTActionType());

			elements.put(FipaMessageType_2005, SchemaPackage.eINSTANCE
					.getFipaMessageType());

			elements.put(ContentType_2006, SchemaPackage.eINSTANCE
					.getContentType());

			elements.put(CheckType_2007, SuitePackage.eINSTANCE.getCheckType());

			elements.put(FipaMessageType_2008, SchemaPackage.eINSTANCE
					.getFipaMessageType());

			elements.put(ContentType_2009, SchemaPackage.eINSTANCE
					.getContentType());

			elements.put(TaskType1_2010, SuitePackage.eINSTANCE.getTaskType1());

			elements.put(OrderLinkType_3001, SuitePackage.eINSTANCE
					.getOrderLinkType());

			elements.put(SendLinkType_3002, SuitePackage.eINSTANCE
					.getSendLinkType());

			elements.put(ReceiveLinkType_3003, SuitePackage.eINSTANCE
					.getReceiveLinkType());

			elements.put(GoalLinkType_3004, SuitePackage.eINSTANCE
					.getGoalLinkType());
		}
		return (ENamedElement) elements.get(type);
	}

	/**
	 * @generated
	 */
	private static IElementType getElementType(String id) {
		return ElementTypeRegistry.getInstance().getType(id);
	}

	/**
	 * @generated
	 */
	public static boolean isKnownElementType(IElementType elementType) {
		if (KNOWN_ELEMENT_TYPES == null) {
			KNOWN_ELEMENT_TYPES = new HashSet();
			KNOWN_ELEMENT_TYPES.add(TestSuiteType_79);
			KNOWN_ELEMENT_TYPES.add(TargetType_1001);
			KNOWN_ELEMENT_TYPES.add(SetupType_1002);
			KNOWN_ELEMENT_TYPES.add(TestCaseType_1003);
			KNOWN_ELEMENT_TYPES.add(TeardownType_1004);
			KNOWN_ELEMENT_TYPES.add(GoalPlanType_2001);
			KNOWN_ELEMENT_TYPES.add(TaskType1_2002);
			KNOWN_ELEMENT_TYPES.add(TestScenarioType_2003);
			KNOWN_ELEMENT_TYPES.add(TActionType_2004);
			KNOWN_ELEMENT_TYPES.add(FipaMessageType_2005);
			KNOWN_ELEMENT_TYPES.add(ContentType_2006);
			KNOWN_ELEMENT_TYPES.add(CheckType_2007);
			KNOWN_ELEMENT_TYPES.add(FipaMessageType_2008);
			KNOWN_ELEMENT_TYPES.add(ContentType_2009);
			KNOWN_ELEMENT_TYPES.add(TaskType1_2010);
			KNOWN_ELEMENT_TYPES.add(OrderLinkType_3001);
			KNOWN_ELEMENT_TYPES.add(SendLinkType_3002);
			KNOWN_ELEMENT_TYPES.add(ReceiveLinkType_3003);
			KNOWN_ELEMENT_TYPES.add(GoalLinkType_3004);
		}
		return KNOWN_ELEMENT_TYPES.contains(elementType);
	}

}
