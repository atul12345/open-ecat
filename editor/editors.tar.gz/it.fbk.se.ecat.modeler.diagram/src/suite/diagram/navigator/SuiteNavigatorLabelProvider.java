package suite.diagram.navigator;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.gmf.runtime.common.ui.services.parser.IParser;
import org.eclipse.gmf.runtime.common.ui.services.parser.ParserOptions;
import org.eclipse.gmf.runtime.common.ui.services.parser.ParserService;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;
import org.eclipse.gmf.runtime.notation.View;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.resource.ImageRegistry;
import org.eclipse.jface.viewers.ITreePathLabelProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.TreePath;
import org.eclipse.jface.viewers.ViewerLabel;
import org.eclipse.swt.graphics.Image;
import org.eclipse.ui.IMemento;
import org.eclipse.ui.navigator.ICommonContentExtensionSite;
import org.eclipse.ui.navigator.ICommonLabelProvider;

import schema.ContentType;
import suite.TestSuiteType;
import suite.diagram.edit.parts.CheckTypeCheckOperatorEditPart;
import suite.diagram.edit.parts.CheckTypeEditPart;
import suite.diagram.edit.parts.ContentType2EditPart;
import suite.diagram.edit.parts.ContentTypeEditPart;
import suite.diagram.edit.parts.ContentTypeValueEditPart;
import suite.diagram.edit.parts.FipaMessageType2EditPart;
import suite.diagram.edit.parts.FipaMessageTypeActEditPart;
import suite.diagram.edit.parts.FipaMessageTypeEditPart;
import suite.diagram.edit.parts.FipaMessageTypeIdActEditPart;
import suite.diagram.edit.parts.GoalLinkTypeEditPart;
import suite.diagram.edit.parts.GoalLinkTypeNameEditPart;
import suite.diagram.edit.parts.GoalPlanTypeEditPart;
import suite.diagram.edit.parts.GoalPlanTypeGoalEditPart;
import suite.diagram.edit.parts.OrderLinkTypeDescEditPart;
import suite.diagram.edit.parts.OrderLinkTypeEditPart;
import suite.diagram.edit.parts.ReceiveLinkTypeEditPart;
import suite.diagram.edit.parts.ReceiveLinkTypeNameEditPart;
import suite.diagram.edit.parts.SendLinkTypeEditPart;
import suite.diagram.edit.parts.SendLinkTypeNameEditPart;
import suite.diagram.edit.parts.SetupTypeEditPart;
import suite.diagram.edit.parts.SetupTypeNameEditPart;
import suite.diagram.edit.parts.TActionTypeActTypeEditPart;
import suite.diagram.edit.parts.TActionTypeEditPart;
import suite.diagram.edit.parts.TargetTypeAgentEditPart;
import suite.diagram.edit.parts.TargetTypeEditPart;
import suite.diagram.edit.parts.TaskType12EditPart;
import suite.diagram.edit.parts.TaskType1EditPart;
import suite.diagram.edit.parts.TaskType1Name2EditPart;
import suite.diagram.edit.parts.TaskType1NameEditPart;
import suite.diagram.edit.parts.TeardownTypeEditPart;
import suite.diagram.edit.parts.TeardownTypeNameEditPart;
import suite.diagram.edit.parts.TestCaseTypeEditPart;
import suite.diagram.edit.parts.TestCaseTypeNameEditPart;
import suite.diagram.edit.parts.TestScenarioTypeEditPart;
import suite.diagram.edit.parts.TestSuiteTypeEditPart;
import suite.diagram.part.SuiteDiagramEditorPlugin;
import suite.diagram.part.SuiteVisualIDRegistry;
import suite.diagram.providers.SuiteElementTypes;
import suite.diagram.providers.SuiteParserProvider;

/**
 * @generated
 */
public class SuiteNavigatorLabelProvider extends LabelProvider implements
		ICommonLabelProvider, ITreePathLabelProvider {

	/**
	 * @generated
	 */
	static {
		SuiteDiagramEditorPlugin
				.getInstance()
				.getImageRegistry()
				.put(
						"Navigator?UnknownElement", ImageDescriptor.getMissingImageDescriptor()); //$NON-NLS-1$
		SuiteDiagramEditorPlugin
				.getInstance()
				.getImageRegistry()
				.put(
						"Navigator?ImageNotFound", ImageDescriptor.getMissingImageDescriptor()); //$NON-NLS-1$
	}

	/**
	 * @generated
	 */
	public void updateLabel(ViewerLabel label, TreePath elementPath) {
		Object element = elementPath.getLastSegment();
		if (element instanceof SuiteNavigatorItem
				&& !isOwnView(((SuiteNavigatorItem) element).getView())) {
			return;
		}
		label.setText(getText(element));
		label.setImage(getImage(element));
	}

	/**
	 * @generated
	 */
	public Image getImage(Object element) {
		if (element instanceof SuiteNavigatorGroup) {
			SuiteNavigatorGroup group = (SuiteNavigatorGroup) element;
			return SuiteDiagramEditorPlugin.getInstance().getBundledImage(
					group.getIcon());
		}

		if (element instanceof SuiteNavigatorItem) {
			SuiteNavigatorItem navigatorItem = (SuiteNavigatorItem) element;
			if (!isOwnView(navigatorItem.getView())) {
				return super.getImage(element);
			}
			return getImage(navigatorItem.getView());
		}

		return super.getImage(element);
	}

	/**
	 * @generated
	 */
	public Image getImage(View view) {
		switch (SuiteVisualIDRegistry.getVisualID(view)) {
		case TestSuiteTypeEditPart.VISUAL_ID:
			return getImage(
					"Navigator?Diagram?http://sra.itc.it/se/TestSuite?TestSuiteType", SuiteElementTypes.TestSuiteType_79); //$NON-NLS-1$
		case TargetTypeEditPart.VISUAL_ID:
			return getImage(
					"Navigator?TopLevelNode?http://sra.itc.it/se/TestSuite?TargetType", SuiteElementTypes.TargetType_1001); //$NON-NLS-1$
		case SetupTypeEditPart.VISUAL_ID:
			return getImage(
					"Navigator?TopLevelNode?http://sra.itc.it/se/TestSuite?SetupType", SuiteElementTypes.SetupType_1002); //$NON-NLS-1$
		case TestCaseTypeEditPart.VISUAL_ID:
			return getImage(
					"Navigator?TopLevelNode?http://sra.itc.it/se/TestSuite?TestCaseType", SuiteElementTypes.TestCaseType_1003); //$NON-NLS-1$
		case TeardownTypeEditPart.VISUAL_ID:
			return getImage(
					"Navigator?TopLevelNode?http://sra.itc.it/se/TestSuite?TeardownType", SuiteElementTypes.TeardownType_1004); //$NON-NLS-1$
		case GoalPlanTypeEditPart.VISUAL_ID:
			return getImage(
					"Navigator?Node?http://sra.itc.it/se/TestSuite?GoalPlanType", SuiteElementTypes.GoalPlanType_2001); //$NON-NLS-1$
		case TaskType1EditPart.VISUAL_ID:
			return getImage(
					"Navigator?Node?http://sra.itc.it/se/TestSuite?TaskType1", SuiteElementTypes.TaskType1_2002); //$NON-NLS-1$
		case TestScenarioTypeEditPart.VISUAL_ID:
			return getImage(
					"Navigator?Node?http://sra.itc.it/se/TestSuite?TestScenarioType", SuiteElementTypes.TestScenarioType_2003); //$NON-NLS-1$
		case TActionTypeEditPart.VISUAL_ID:
			return getImage(
					"Navigator?Node?http://sra.itc.it/se/TestSuite?TActionType", SuiteElementTypes.TActionType_2004); //$NON-NLS-1$
		case FipaMessageTypeEditPart.VISUAL_ID:
			return getImage(
					"Navigator?Node?http://www.fipa.org/ACLSchema?FipaMessageType", SuiteElementTypes.FipaMessageType_2005); //$NON-NLS-1$
		case ContentTypeEditPart.VISUAL_ID:
			return getImage(
					"Navigator?Node?http://www.fipa.org/ACLSchema?ContentType", SuiteElementTypes.ContentType_2006); //$NON-NLS-1$
		case CheckTypeEditPart.VISUAL_ID:
			return getImage(
					"Navigator?Node?http://sra.itc.it/se/TestSuite?CheckType", SuiteElementTypes.CheckType_2007); //$NON-NLS-1$
		case FipaMessageType2EditPart.VISUAL_ID:
			return getImage(
					"Navigator?Node?http://www.fipa.org/ACLSchema?FipaMessageType", SuiteElementTypes.FipaMessageType_2008); //$NON-NLS-1$
		case ContentType2EditPart.VISUAL_ID:
			return getImage(
					"Navigator?Node?http://www.fipa.org/ACLSchema?ContentType", SuiteElementTypes.ContentType_2009); //$NON-NLS-1$
		case TaskType12EditPart.VISUAL_ID:
			return getImage(
					"Navigator?Node?http://sra.itc.it/se/TestSuite?TaskType1", SuiteElementTypes.TaskType1_2010); //$NON-NLS-1$
		case OrderLinkTypeEditPart.VISUAL_ID:
			return getImage(
					"Navigator?Link?http://sra.itc.it/se/TestSuite?OrderLinkType", SuiteElementTypes.OrderLinkType_3001); //$NON-NLS-1$
		case SendLinkTypeEditPart.VISUAL_ID:
			return getImage(
					"Navigator?Link?http://sra.itc.it/se/TestSuite?SendLinkType", SuiteElementTypes.SendLinkType_3002); //$NON-NLS-1$
		case ReceiveLinkTypeEditPart.VISUAL_ID:
			return getImage(
					"Navigator?Link?http://sra.itc.it/se/TestSuite?ReceiveLinkType", SuiteElementTypes.ReceiveLinkType_3003); //$NON-NLS-1$
		case GoalLinkTypeEditPart.VISUAL_ID:
			return getImage(
					"Navigator?Link?http://sra.itc.it/se/TestSuite?GoalLinkType", SuiteElementTypes.GoalLinkType_3004); //$NON-NLS-1$
		}
		return getImage("Navigator?UnknownElement", null); //$NON-NLS-1$
	}

	/**
	 * @generated
	 */
	private Image getImage(String key, IElementType elementType) {
		ImageRegistry imageRegistry = SuiteDiagramEditorPlugin.getInstance()
				.getImageRegistry();
		Image image = imageRegistry.get(key);
		if (image == null && elementType != null
				&& SuiteElementTypes.isKnownElementType(elementType)) {
			image = SuiteElementTypes.getImage(elementType);
			imageRegistry.put(key, image);
		}

		if (image == null) {
			image = imageRegistry.get("Navigator?ImageNotFound"); //$NON-NLS-1$
			imageRegistry.put(key, image);
		}
		return image;
	}

	/**
	 * @generated
	 */
	public String getText(Object element) {
		if (element instanceof SuiteNavigatorGroup) {
			SuiteNavigatorGroup group = (SuiteNavigatorGroup) element;
			return group.getGroupName();
		}

		if (element instanceof SuiteNavigatorItem) {
			SuiteNavigatorItem navigatorItem = (SuiteNavigatorItem) element;
			if (!isOwnView(navigatorItem.getView())) {
				return null;
			}
			return getText(navigatorItem.getView());
		}

		return super.getText(element);
	}

	/**
	 * @generated
	 */
	public String getText(View view) {
		if (view.getElement() != null && view.getElement().eIsProxy()) {
			return getUnresolvedDomainElementProxyText(view);
		}
		switch (SuiteVisualIDRegistry.getVisualID(view)) {
		case TestSuiteTypeEditPart.VISUAL_ID:
			return getTestSuiteType_79Text(view);
		case TargetTypeEditPart.VISUAL_ID:
			return getTargetType_1001Text(view);
		case SetupTypeEditPart.VISUAL_ID:
			return getSetupType_1002Text(view);
		case TestCaseTypeEditPart.VISUAL_ID:
			return getTestCaseType_1003Text(view);
		case TeardownTypeEditPart.VISUAL_ID:
			return getTeardownType_1004Text(view);
		case GoalPlanTypeEditPart.VISUAL_ID:
			return getGoalPlanType_2001Text(view);
		case TaskType1EditPart.VISUAL_ID:
			return getTaskType1_2002Text(view);
		case TestScenarioTypeEditPart.VISUAL_ID:
			return getTestScenarioType_2003Text(view);
		case TActionTypeEditPart.VISUAL_ID:
			return getTActionType_2004Text(view);
		case FipaMessageTypeEditPart.VISUAL_ID:
			return getFipaMessageType_2005Text(view);
		case ContentTypeEditPart.VISUAL_ID:
			return getContentType_2006Text(view);
		case CheckTypeEditPart.VISUAL_ID:
			return getCheckType_2007Text(view);
		case FipaMessageType2EditPart.VISUAL_ID:
			return getFipaMessageType_2008Text(view);
		case ContentType2EditPart.VISUAL_ID:
			return getContentType_2009Text(view);
		case TaskType12EditPart.VISUAL_ID:
			return getTaskType1_2010Text(view);
		case OrderLinkTypeEditPart.VISUAL_ID:
			return getOrderLinkType_3001Text(view);
		case SendLinkTypeEditPart.VISUAL_ID:
			return getSendLinkType_3002Text(view);
		case ReceiveLinkTypeEditPart.VISUAL_ID:
			return getReceiveLinkType_3003Text(view);
		case GoalLinkTypeEditPart.VISUAL_ID:
			return getGoalLinkType_3004Text(view);
		}
		return getUnknownElementText(view);
	}

	/**
	 * @generated
	 */
	private String getTestSuiteType_79Text(View view) {
		TestSuiteType domainModelElement = (TestSuiteType) view.getElement();
		if (domainModelElement != null) {
			return String.valueOf(domainModelElement.getName());
		} else {
			SuiteDiagramEditorPlugin.getInstance().logError(
					"No domain element for view with visualID = " + 79); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getTargetType_1001Text(View view) {
		IAdaptable hintAdapter = new SuiteParserProvider.HintAdapter(
				SuiteElementTypes.TargetType_1001,
				(view.getElement() != null ? view.getElement() : view),
				SuiteVisualIDRegistry
						.getType(TargetTypeAgentEditPart.VISUAL_ID));
		IParser parser = ParserService.getInstance().getParser(hintAdapter);

		if (parser != null) {
			return parser.getPrintString(hintAdapter, ParserOptions.NONE
					.intValue());
		} else {
			SuiteDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 4002); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}

	}

	/**
	 * @generated
	 */
	private String getSetupType_1002Text(View view) {
		IAdaptable hintAdapter = new SuiteParserProvider.HintAdapter(
				SuiteElementTypes.SetupType_1002,
				(view.getElement() != null ? view.getElement() : view),
				SuiteVisualIDRegistry.getType(SetupTypeNameEditPart.VISUAL_ID));
		IParser parser = ParserService.getInstance().getParser(hintAdapter);

		if (parser != null) {
			return parser.getPrintString(hintAdapter, ParserOptions.NONE
					.intValue());
		} else {
			SuiteDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 4004); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}

	}

	/**
	 * @generated
	 */
	private String getTestCaseType_1003Text(View view) {
		IAdaptable hintAdapter = new SuiteParserProvider.HintAdapter(
				SuiteElementTypes.TestCaseType_1003,
				(view.getElement() != null ? view.getElement() : view),
				SuiteVisualIDRegistry
						.getType(TestCaseTypeNameEditPart.VISUAL_ID));
		IParser parser = ParserService.getInstance().getParser(hintAdapter);

		if (parser != null) {
			return parser.getPrintString(hintAdapter, ParserOptions.NONE
					.intValue());
		} else {
			SuiteDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 4010); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}

	}

	/**
	 * @generated
	 */
	private String getTeardownType_1004Text(View view) {
		IAdaptable hintAdapter = new SuiteParserProvider.HintAdapter(
				SuiteElementTypes.TeardownType_1004,
				(view.getElement() != null ? view.getElement() : view),
				SuiteVisualIDRegistry
						.getType(TeardownTypeNameEditPart.VISUAL_ID));
		IParser parser = ParserService.getInstance().getParser(hintAdapter);

		if (parser != null) {
			return parser.getPrintString(hintAdapter, ParserOptions.NONE
					.intValue());
		} else {
			SuiteDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 4012); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}

	}

	/**
	 * @generated
	 */
	private String getGoalPlanType_2001Text(View view) {
		IAdaptable hintAdapter = new SuiteParserProvider.HintAdapter(
				SuiteElementTypes.GoalPlanType_2001,
				(view.getElement() != null ? view.getElement() : view),
				SuiteVisualIDRegistry
						.getType(GoalPlanTypeGoalEditPart.VISUAL_ID));
		IParser parser = ParserService.getInstance().getParser(hintAdapter);

		if (parser != null) {
			return parser.getPrintString(hintAdapter, ParserOptions.NONE
					.intValue());
		} else {
			SuiteDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 4001); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}

	}

	/**
	 * @generated
	 */
	private String getTaskType1_2002Text(View view) {
		IAdaptable hintAdapter = new SuiteParserProvider.HintAdapter(
				SuiteElementTypes.TaskType1_2002,
				(view.getElement() != null ? view.getElement() : view),
				SuiteVisualIDRegistry.getType(TaskType1NameEditPart.VISUAL_ID));
		IParser parser = ParserService.getInstance().getParser(hintAdapter);

		if (parser != null) {
			return parser.getPrintString(hintAdapter, ParserOptions.NONE
					.intValue());
		} else {
			SuiteDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 4003); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}

	}

	/**
	 * @generated
	 */
	private String getTestScenarioType_2003Text(View view) {
		return ""; //$NON-NLS-1$
	}

	/**
	 * @generated
	 */
	private String getTActionType_2004Text(View view) {
		IAdaptable hintAdapter = new SuiteParserProvider.HintAdapter(
				SuiteElementTypes.TActionType_2004,
				(view.getElement() != null ? view.getElement() : view),
				SuiteVisualIDRegistry
						.getType(TActionTypeActTypeEditPart.VISUAL_ID));
		IParser parser = ParserService.getInstance().getParser(hintAdapter);

		if (parser != null) {
			return parser.getPrintString(hintAdapter, ParserOptions.NONE
					.intValue());
		} else {
			SuiteDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 4009); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}

	}

	/**
	 * @generated
	 */
	private String getFipaMessageType_2005Text(View view) {
		IAdaptable hintAdapter = new SuiteParserProvider.HintAdapter(
				SuiteElementTypes.FipaMessageType_2005,
				(view.getElement() != null ? view.getElement() : view),
				SuiteVisualIDRegistry
						.getType(FipaMessageTypeIdActEditPart.VISUAL_ID));
		IParser parser = ParserService.getInstance().getParser(hintAdapter);

		if (parser != null) {
			return parser.getPrintString(hintAdapter, ParserOptions.NONE
					.intValue());
		} else {
			SuiteDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 4006); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}

	}

	/**
	 * @generated
	 */
	private String getContentType_2006Text(View view) {
		IAdaptable hintAdapter = new SuiteParserProvider.HintAdapter(
				SuiteElementTypes.ContentType_2006,
				(view.getElement() != null ? view.getElement() : view),
				SuiteVisualIDRegistry
						.getType(ContentTypeValueEditPart.VISUAL_ID));
		IParser parser = ParserService.getInstance().getParser(hintAdapter);

		if (parser != null) {
			return parser.getPrintString(hintAdapter, ParserOptions.NONE
					.intValue());
		} else {
			SuiteDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 4005); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}

	}

	/**
	 * @generated
	 */
	private String getCheckType_2007Text(View view) {
		IAdaptable hintAdapter = new SuiteParserProvider.HintAdapter(
				SuiteElementTypes.CheckType_2007,
				(view.getElement() != null ? view.getElement() : view),
				SuiteVisualIDRegistry
						.getType(CheckTypeCheckOperatorEditPart.VISUAL_ID));
		IParser parser = ParserService.getInstance().getParser(hintAdapter);

		if (parser != null) {
			return parser.getPrintString(hintAdapter, ParserOptions.NONE
					.intValue());
		} else {
			SuiteDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 4008); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}

	}

	/**
	 * @generated
	 */
	private String getFipaMessageType_2008Text(View view) {
		IAdaptable hintAdapter = new SuiteParserProvider.HintAdapter(
				SuiteElementTypes.FipaMessageType_2008,
				(view.getElement() != null ? view.getElement() : view),
				SuiteVisualIDRegistry
						.getType(FipaMessageTypeActEditPart.VISUAL_ID));
		IParser parser = ParserService.getInstance().getParser(hintAdapter);

		if (parser != null) {
			return parser.getPrintString(hintAdapter, ParserOptions.NONE
					.intValue());
		} else {
			SuiteDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 4007); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}

	}

	/**
	 * @generated
	 */
	private String getContentType_2009Text(View view) {
		ContentType domainModelElement = (ContentType) view.getElement();
		if (domainModelElement != null) {
			return String.valueOf(domainModelElement.getId());
		} else {
			SuiteDiagramEditorPlugin.getInstance().logError(
					"No domain element for view with visualID = " + 2009); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getTaskType1_2010Text(View view) {
		IAdaptable hintAdapter = new SuiteParserProvider.HintAdapter(
				SuiteElementTypes.TaskType1_2010,
				(view.getElement() != null ? view.getElement() : view),
				SuiteVisualIDRegistry.getType(TaskType1Name2EditPart.VISUAL_ID));
		IParser parser = ParserService.getInstance().getParser(hintAdapter);

		if (parser != null) {
			return parser.getPrintString(hintAdapter, ParserOptions.NONE
					.intValue());
		} else {
			SuiteDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 4011); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}

	}

	/**
	 * @generated
	 */
	private String getOrderLinkType_3001Text(View view) {
		IAdaptable hintAdapter = new SuiteParserProvider.HintAdapter(
				SuiteElementTypes.OrderLinkType_3001,
				(view.getElement() != null ? view.getElement() : view),
				SuiteVisualIDRegistry
						.getType(OrderLinkTypeDescEditPart.VISUAL_ID));
		IParser parser = ParserService.getInstance().getParser(hintAdapter);

		if (parser != null) {
			return parser.getPrintString(hintAdapter, ParserOptions.NONE
					.intValue());
		} else {
			SuiteDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 4013); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}

	}

	/**
	 * @generated
	 */
	private String getSendLinkType_3002Text(View view) {
		IAdaptable hintAdapter = new SuiteParserProvider.HintAdapter(
				SuiteElementTypes.SendLinkType_3002,
				(view.getElement() != null ? view.getElement() : view),
				SuiteVisualIDRegistry
						.getType(SendLinkTypeNameEditPart.VISUAL_ID));
		IParser parser = ParserService.getInstance().getParser(hintAdapter);

		if (parser != null) {
			return parser.getPrintString(hintAdapter, ParserOptions.NONE
					.intValue());
		} else {
			SuiteDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 4014); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}

	}

	/**
	 * @generated
	 */
	private String getReceiveLinkType_3003Text(View view) {
		IAdaptable hintAdapter = new SuiteParserProvider.HintAdapter(
				SuiteElementTypes.ReceiveLinkType_3003,
				(view.getElement() != null ? view.getElement() : view),
				SuiteVisualIDRegistry
						.getType(ReceiveLinkTypeNameEditPart.VISUAL_ID));
		IParser parser = ParserService.getInstance().getParser(hintAdapter);

		if (parser != null) {
			return parser.getPrintString(hintAdapter, ParserOptions.NONE
					.intValue());
		} else {
			SuiteDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 4015); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}

	}

	/**
	 * @generated
	 */
	private String getGoalLinkType_3004Text(View view) {
		IAdaptable hintAdapter = new SuiteParserProvider.HintAdapter(
				SuiteElementTypes.GoalLinkType_3004,
				(view.getElement() != null ? view.getElement() : view),
				SuiteVisualIDRegistry
						.getType(GoalLinkTypeNameEditPart.VISUAL_ID));
		IParser parser = ParserService.getInstance().getParser(hintAdapter);

		if (parser != null) {
			return parser.getPrintString(hintAdapter, ParserOptions.NONE
					.intValue());
		} else {
			SuiteDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 4016); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}

	}

	/**
	 * @generated
	 */
	private String getUnknownElementText(View view) {
		return "<UnknownElement Visual_ID = " + view.getType() + ">"; //$NON-NLS-1$ //$NON-NLS-2$
	}

	/**
	 * @generated
	 */
	private String getUnresolvedDomainElementProxyText(View view) {
		return "<Unresolved domain element Visual_ID = " + view.getType() + ">"; //$NON-NLS-1$ //$NON-NLS-2$
	}

	/**
	 * @generated
	 */
	public void init(ICommonContentExtensionSite aConfig) {
	}

	/**
	 * @generated
	 */
	public void restoreState(IMemento aMemento) {
	}

	/**
	 * @generated
	 */
	public void saveState(IMemento aMemento) {
	}

	/**
	 * @generated
	 */
	public String getDescription(Object anElement) {
		return null;
	}

	/**
	 * @generated
	 */
	private boolean isOwnView(View view) {
		return TestSuiteTypeEditPart.MODEL_ID.equals(SuiteVisualIDRegistry
				.getModelID(view));
	}

}
