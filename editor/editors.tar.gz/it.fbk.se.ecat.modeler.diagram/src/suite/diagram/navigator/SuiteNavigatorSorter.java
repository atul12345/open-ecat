package suite.diagram.navigator;

import org.eclipse.jface.viewers.ViewerSorter;

import suite.diagram.part.SuiteVisualIDRegistry;

/**
 * @generated
 */
public class SuiteNavigatorSorter extends ViewerSorter {

	/**
	 * @generated
	 */
	private static final int GROUP_CATEGORY = 5012;

	/**
	 * @generated
	 */
	public int category(Object element) {
		if (element instanceof SuiteNavigatorItem) {
			SuiteNavigatorItem item = (SuiteNavigatorItem) element;
			return SuiteVisualIDRegistry.getVisualID(item.getView());
		}
		return GROUP_CATEGORY;
	}

}
