/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package suite.provider;


import java.util.Collection;
import java.util.List;

import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.ResourceLocator;

import org.eclipse.emf.ecore.EStructuralFeature;

import org.eclipse.emf.edit.provider.ComposeableAdapterFactory;
import org.eclipse.emf.edit.provider.IEditingDomainItemProvider;
import org.eclipse.emf.edit.provider.IItemLabelProvider;
import org.eclipse.emf.edit.provider.IItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.IItemPropertySource;
import org.eclipse.emf.edit.provider.IStructuredItemContentProvider;
import org.eclipse.emf.edit.provider.ITreeItemContentProvider;
import org.eclipse.emf.edit.provider.ItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.ItemProviderAdapter;
import org.eclipse.emf.edit.provider.ViewerNotification;

import suite.SuiteFactory;
import suite.SuitePackage;
import suite.TestSuiteType;

/**
 * This is the item provider adapter for a {@link suite.TestSuiteType} object.
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class TestSuiteTypeItemProvider
	extends ItemProviderAdapter
	implements	
		IEditingDomainItemProvider,	
		IStructuredItemContentProvider,	
		ITreeItemContentProvider,	
		IItemLabelProvider,	
		IItemPropertySource {
	/**
	 * This constructs an instance from a factory and a notifier.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TestSuiteTypeItemProvider(AdapterFactory adapterFactory) {
		super(adapterFactory);
	}

	/**
	 * This returns the property descriptors for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public List<IItemPropertyDescriptor> getPropertyDescriptors(Object object) {
		if (itemPropertyDescriptors == null) {
			super.getPropertyDescriptors(object);

			addIDPropertyDescriptor(object);
			addNamePropertyDescriptor(object);
			addCreatedByPropertyDescriptor(object);
			addVersionPropertyDescriptor(object);
			addCreatedDatePropertyDescriptor(object);
			addDescriptionPropertyDescriptor(object);
		}
		return itemPropertyDescriptors;
	}

	/**
	 * This adds a property descriptor for the ID feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addIDPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_TestSuiteType_iD_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_TestSuiteType_iD_feature", "_UI_TestSuiteType_type"),
				 SuitePackage.Literals.TEST_SUITE_TYPE__ID,
				 true,
				 false,
				 false,
				 ItemPropertyDescriptor.GENERIC_VALUE_IMAGE,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the Name feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addNamePropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_TestSuiteType_name_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_TestSuiteType_name_feature", "_UI_TestSuiteType_type"),
				 SuitePackage.Literals.TEST_SUITE_TYPE__NAME,
				 true,
				 false,
				 false,
				 ItemPropertyDescriptor.GENERIC_VALUE_IMAGE,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the Created By feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addCreatedByPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_TestSuiteType_createdBy_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_TestSuiteType_createdBy_feature", "_UI_TestSuiteType_type"),
				 SuitePackage.Literals.TEST_SUITE_TYPE__CREATED_BY,
				 true,
				 false,
				 false,
				 ItemPropertyDescriptor.GENERIC_VALUE_IMAGE,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the Version feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addVersionPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_TestSuiteType_version_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_TestSuiteType_version_feature", "_UI_TestSuiteType_type"),
				 SuitePackage.Literals.TEST_SUITE_TYPE__VERSION,
				 true,
				 false,
				 false,
				 ItemPropertyDescriptor.GENERIC_VALUE_IMAGE,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the Created Date feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addCreatedDatePropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_TestSuiteType_createdDate_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_TestSuiteType_createdDate_feature", "_UI_TestSuiteType_type"),
				 SuitePackage.Literals.TEST_SUITE_TYPE__CREATED_DATE,
				 true,
				 false,
				 false,
				 ItemPropertyDescriptor.GENERIC_VALUE_IMAGE,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the Description feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addDescriptionPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_TestSuiteType_description_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_TestSuiteType_description_feature", "_UI_TestSuiteType_type"),
				 SuitePackage.Literals.TEST_SUITE_TYPE__DESCRIPTION,
				 true,
				 false,
				 false,
				 ItemPropertyDescriptor.GENERIC_VALUE_IMAGE,
				 null,
				 null));
	}

	/**
	 * This specifies how to implement {@link #getChildren} and is used to deduce an appropriate feature for an
	 * {@link org.eclipse.emf.edit.command.AddCommand}, {@link org.eclipse.emf.edit.command.RemoveCommand} or
	 * {@link org.eclipse.emf.edit.command.MoveCommand} in {@link #createCommand}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Collection<? extends EStructuralFeature> getChildrenFeatures(Object object) {
		if (childrenFeatures == null) {
			super.getChildrenFeatures(object);
			childrenFeatures.add(SuitePackage.Literals.TEST_SUITE_TYPE__TARGET);
			childrenFeatures.add(SuitePackage.Literals.TEST_SUITE_TYPE__TEST_CASE);
			childrenFeatures.add(SuitePackage.Literals.TEST_SUITE_TYPE__SETUP);
			childrenFeatures.add(SuitePackage.Literals.TEST_SUITE_TYPE__TEARDOWN);
			childrenFeatures.add(SuitePackage.Literals.TEST_SUITE_TYPE__GOAL_LINK);
			childrenFeatures.add(SuitePackage.Literals.TEST_SUITE_TYPE__SEND_LINK);
			childrenFeatures.add(SuitePackage.Literals.TEST_SUITE_TYPE__RECEIVE_LINK);
		}
		return childrenFeatures;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EStructuralFeature getChildFeature(Object object, Object child) {
		// Check the type of the specified child object and return the proper feature to use for
		// adding (see {@link AddCommand}) it as a child.

		return super.getChildFeature(object, child);
	}

	/**
	 * This returns TestSuiteType.gif.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object getImage(Object object) {
		return overlayImage(object, getResourceLocator().getImage("full/obj16/TestSuiteType"));
	}

	/**
	 * This returns the label text for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getText(Object object) {
		String label = ((TestSuiteType)object).getName();
		return label == null || label.length() == 0 ?
			getString("_UI_TestSuiteType_type") :
			getString("_UI_TestSuiteType_type") + " " + label;
	}

	/**
	 * This handles model notifications by calling {@link #updateChildren} to update any cached
	 * children and by creating a viewer notification, which it passes to {@link #fireNotifyChanged}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void notifyChanged(Notification notification) {
		updateChildren(notification);

		switch (notification.getFeatureID(TestSuiteType.class)) {
			case SuitePackage.TEST_SUITE_TYPE__ID:
			case SuitePackage.TEST_SUITE_TYPE__NAME:
			case SuitePackage.TEST_SUITE_TYPE__CREATED_BY:
			case SuitePackage.TEST_SUITE_TYPE__VERSION:
			case SuitePackage.TEST_SUITE_TYPE__CREATED_DATE:
			case SuitePackage.TEST_SUITE_TYPE__DESCRIPTION:
				fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), false, true));
				return;
			case SuitePackage.TEST_SUITE_TYPE__TARGET:
			case SuitePackage.TEST_SUITE_TYPE__TEST_CASE:
			case SuitePackage.TEST_SUITE_TYPE__SETUP:
			case SuitePackage.TEST_SUITE_TYPE__TEARDOWN:
			case SuitePackage.TEST_SUITE_TYPE__GOAL_LINK:
			case SuitePackage.TEST_SUITE_TYPE__SEND_LINK:
			case SuitePackage.TEST_SUITE_TYPE__RECEIVE_LINK:
				fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), true, false));
				return;
		}
		super.notifyChanged(notification);
	}

	/**
	 * This adds {@link org.eclipse.emf.edit.command.CommandParameter}s describing the children
	 * that can be created under this object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected void collectNewChildDescriptors(Collection<Object> newChildDescriptors, Object object) {
		super.collectNewChildDescriptors(newChildDescriptors, object);

		newChildDescriptors.add
			(createChildParameter
				(SuitePackage.Literals.TEST_SUITE_TYPE__TARGET,
				 SuiteFactory.eINSTANCE.createTargetType()));

		newChildDescriptors.add
			(createChildParameter
				(SuitePackage.Literals.TEST_SUITE_TYPE__TEST_CASE,
				 SuiteFactory.eINSTANCE.createTestCaseType()));

		newChildDescriptors.add
			(createChildParameter
				(SuitePackage.Literals.TEST_SUITE_TYPE__SETUP,
				 SuiteFactory.eINSTANCE.createSetupType()));

		newChildDescriptors.add
			(createChildParameter
				(SuitePackage.Literals.TEST_SUITE_TYPE__TEARDOWN,
				 SuiteFactory.eINSTANCE.createTeardownType()));

		newChildDescriptors.add
			(createChildParameter
				(SuitePackage.Literals.TEST_SUITE_TYPE__GOAL_LINK,
				 SuiteFactory.eINSTANCE.createGoalLinkType()));

		newChildDescriptors.add
			(createChildParameter
				(SuitePackage.Literals.TEST_SUITE_TYPE__SEND_LINK,
				 SuiteFactory.eINSTANCE.createSendLinkType()));

		newChildDescriptors.add
			(createChildParameter
				(SuitePackage.Literals.TEST_SUITE_TYPE__RECEIVE_LINK,
				 SuiteFactory.eINSTANCE.createReceiveLinkType()));
	}

	/**
	 * Return the resource locator for this item provider's resources.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ResourceLocator getResourceLocator() {
		return SuiteEditPlugin.INSTANCE;
	}

}
