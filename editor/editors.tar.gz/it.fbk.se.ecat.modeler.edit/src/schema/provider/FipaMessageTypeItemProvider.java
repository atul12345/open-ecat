/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package schema.provider;


import java.util.Collection;
import java.util.List;

import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.ResourceLocator;

import org.eclipse.emf.ecore.EStructuralFeature;

import org.eclipse.emf.edit.provider.ComposeableAdapterFactory;
import org.eclipse.emf.edit.provider.IEditingDomainItemProvider;
import org.eclipse.emf.edit.provider.IItemLabelProvider;
import org.eclipse.emf.edit.provider.IItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.IItemPropertySource;
import org.eclipse.emf.edit.provider.IStructuredItemContentProvider;
import org.eclipse.emf.edit.provider.ITreeItemContentProvider;
import org.eclipse.emf.edit.provider.ItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.ItemProviderAdapter;
import org.eclipse.emf.edit.provider.ViewerNotification;

import schema.FipaMessageType;
import schema.SchemaFactory;
import schema.SchemaPackage;

import suite.provider.SuiteEditPlugin;

/**
 * This is the item provider adapter for a {@link schema.FipaMessageType} object.
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class FipaMessageTypeItemProvider
	extends ItemProviderAdapter
	implements	
		IEditingDomainItemProvider,	
		IStructuredItemContentProvider,	
		ITreeItemContentProvider,	
		IItemLabelProvider,	
		IItemPropertySource {
	/**
	 * This constructs an instance from a factory and a notifier.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FipaMessageTypeItemProvider(AdapterFactory adapterFactory) {
		super(adapterFactory);
	}

	/**
	 * This returns the property descriptors for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public List<IItemPropertyDescriptor> getPropertyDescriptors(Object object) {
		if (itemPropertyDescriptors == null) {
			super.getPropertyDescriptors(object);

			addContentPropertyDescriptor(object);
			addLanguagePropertyDescriptor(object);
			addEncodingPropertyDescriptor(object);
			addOntologyPropertyDescriptor(object);
			addProtocolPropertyDescriptor(object);
			addReplyWithPropertyDescriptor(object);
			addInReplyToPropertyDescriptor(object);
			addConversationIdPropertyDescriptor(object);
			addActPropertyDescriptor(object);
			addIdPropertyDescriptor(object);
		}
		return itemPropertyDescriptors;
	}

	/**
	 * This adds a property descriptor for the Content feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addContentPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_FipaMessageType_content_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_FipaMessageType_content_feature", "_UI_FipaMessageType_type"),
				 SchemaPackage.Literals.FIPA_MESSAGE_TYPE__CONTENT,
				 false,
				 false,
				 false,
				 null,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the Language feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addLanguagePropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_FipaMessageType_language_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_FipaMessageType_language_feature", "_UI_FipaMessageType_type"),
				 SchemaPackage.Literals.FIPA_MESSAGE_TYPE__LANGUAGE,
				 true,
				 false,
				 false,
				 ItemPropertyDescriptor.GENERIC_VALUE_IMAGE,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the Encoding feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addEncodingPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_FipaMessageType_encoding_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_FipaMessageType_encoding_feature", "_UI_FipaMessageType_type"),
				 SchemaPackage.Literals.FIPA_MESSAGE_TYPE__ENCODING,
				 true,
				 false,
				 false,
				 ItemPropertyDescriptor.GENERIC_VALUE_IMAGE,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the Ontology feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addOntologyPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_FipaMessageType_ontology_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_FipaMessageType_ontology_feature", "_UI_FipaMessageType_type"),
				 SchemaPackage.Literals.FIPA_MESSAGE_TYPE__ONTOLOGY,
				 true,
				 false,
				 false,
				 ItemPropertyDescriptor.GENERIC_VALUE_IMAGE,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the Protocol feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addProtocolPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_FipaMessageType_protocol_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_FipaMessageType_protocol_feature", "_UI_FipaMessageType_type"),
				 SchemaPackage.Literals.FIPA_MESSAGE_TYPE__PROTOCOL,
				 true,
				 false,
				 false,
				 ItemPropertyDescriptor.GENERIC_VALUE_IMAGE,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the Reply With feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addReplyWithPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_FipaMessageType_replyWith_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_FipaMessageType_replyWith_feature", "_UI_FipaMessageType_type"),
				 SchemaPackage.Literals.FIPA_MESSAGE_TYPE__REPLY_WITH,
				 true,
				 false,
				 false,
				 ItemPropertyDescriptor.GENERIC_VALUE_IMAGE,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the In Reply To feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addInReplyToPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_FipaMessageType_inReplyTo_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_FipaMessageType_inReplyTo_feature", "_UI_FipaMessageType_type"),
				 SchemaPackage.Literals.FIPA_MESSAGE_TYPE__IN_REPLY_TO,
				 true,
				 false,
				 false,
				 ItemPropertyDescriptor.GENERIC_VALUE_IMAGE,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the Conversation Id feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addConversationIdPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_FipaMessageType_conversationId_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_FipaMessageType_conversationId_feature", "_UI_FipaMessageType_type"),
				 SchemaPackage.Literals.FIPA_MESSAGE_TYPE__CONVERSATION_ID,
				 true,
				 false,
				 false,
				 ItemPropertyDescriptor.GENERIC_VALUE_IMAGE,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the Act feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addActPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_FipaMessageType_act_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_FipaMessageType_act_feature", "_UI_FipaMessageType_type"),
				 SchemaPackage.Literals.FIPA_MESSAGE_TYPE__ACT,
				 true,
				 false,
				 false,
				 ItemPropertyDescriptor.GENERIC_VALUE_IMAGE,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the Id feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addIdPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_FipaMessageType_id_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_FipaMessageType_id_feature", "_UI_FipaMessageType_type"),
				 SchemaPackage.Literals.FIPA_MESSAGE_TYPE__ID,
				 true,
				 false,
				 false,
				 ItemPropertyDescriptor.GENERIC_VALUE_IMAGE,
				 null,
				 null));
	}

	/**
	 * This specifies how to implement {@link #getChildren} and is used to deduce an appropriate feature for an
	 * {@link org.eclipse.emf.edit.command.AddCommand}, {@link org.eclipse.emf.edit.command.RemoveCommand} or
	 * {@link org.eclipse.emf.edit.command.MoveCommand} in {@link #createCommand}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Collection<? extends EStructuralFeature> getChildrenFeatures(Object object) {
		if (childrenFeatures == null) {
			super.getChildrenFeatures(object);
			childrenFeatures.add(SchemaPackage.Literals.FIPA_MESSAGE_TYPE__SENDER);
			childrenFeatures.add(SchemaPackage.Literals.FIPA_MESSAGE_TYPE__RECEIVER);
			childrenFeatures.add(SchemaPackage.Literals.FIPA_MESSAGE_TYPE__CONTENT);
			childrenFeatures.add(SchemaPackage.Literals.FIPA_MESSAGE_TYPE__REPLY_BY);
			childrenFeatures.add(SchemaPackage.Literals.FIPA_MESSAGE_TYPE__REPLY_TO);
			childrenFeatures.add(SchemaPackage.Literals.FIPA_MESSAGE_TYPE__USER_DEFINED);
		}
		return childrenFeatures;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EStructuralFeature getChildFeature(Object object, Object child) {
		// Check the type of the specified child object and return the proper feature to use for
		// adding (see {@link AddCommand}) it as a child.

		return super.getChildFeature(object, child);
	}

	/**
	 * This returns FipaMessageType.gif.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object getImage(Object object) {
		return overlayImage(object, getResourceLocator().getImage("full/obj16/FipaMessageType"));
	}

	/**
	 * This returns the label text for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getText(Object object) {
		String label = ((FipaMessageType)object).getId();
		return label == null || label.length() == 0 ?
			getString("_UI_FipaMessageType_type") :
			getString("_UI_FipaMessageType_type") + " " + label;
	}

	/**
	 * This handles model notifications by calling {@link #updateChildren} to update any cached
	 * children and by creating a viewer notification, which it passes to {@link #fireNotifyChanged}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void notifyChanged(Notification notification) {
		updateChildren(notification);

		switch (notification.getFeatureID(FipaMessageType.class)) {
			case SchemaPackage.FIPA_MESSAGE_TYPE__LANGUAGE:
			case SchemaPackage.FIPA_MESSAGE_TYPE__ENCODING:
			case SchemaPackage.FIPA_MESSAGE_TYPE__ONTOLOGY:
			case SchemaPackage.FIPA_MESSAGE_TYPE__PROTOCOL:
			case SchemaPackage.FIPA_MESSAGE_TYPE__REPLY_WITH:
			case SchemaPackage.FIPA_MESSAGE_TYPE__IN_REPLY_TO:
			case SchemaPackage.FIPA_MESSAGE_TYPE__CONVERSATION_ID:
			case SchemaPackage.FIPA_MESSAGE_TYPE__ACT:
			case SchemaPackage.FIPA_MESSAGE_TYPE__ID:
				fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), false, true));
				return;
			case SchemaPackage.FIPA_MESSAGE_TYPE__SENDER:
			case SchemaPackage.FIPA_MESSAGE_TYPE__RECEIVER:
			case SchemaPackage.FIPA_MESSAGE_TYPE__CONTENT:
			case SchemaPackage.FIPA_MESSAGE_TYPE__REPLY_BY:
			case SchemaPackage.FIPA_MESSAGE_TYPE__REPLY_TO:
			case SchemaPackage.FIPA_MESSAGE_TYPE__USER_DEFINED:
				fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), true, false));
				return;
		}
		super.notifyChanged(notification);
	}

	/**
	 * This adds {@link org.eclipse.emf.edit.command.CommandParameter}s describing the children
	 * that can be created under this object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected void collectNewChildDescriptors(Collection<Object> newChildDescriptors, Object object) {
		super.collectNewChildDescriptors(newChildDescriptors, object);

		newChildDescriptors.add
			(createChildParameter
				(SchemaPackage.Literals.FIPA_MESSAGE_TYPE__SENDER,
				 SchemaFactory.eINSTANCE.createSenderType()));

		newChildDescriptors.add
			(createChildParameter
				(SchemaPackage.Literals.FIPA_MESSAGE_TYPE__RECEIVER,
				 SchemaFactory.eINSTANCE.createReceiverType()));

		newChildDescriptors.add
			(createChildParameter
				(SchemaPackage.Literals.FIPA_MESSAGE_TYPE__CONTENT,
				 SchemaFactory.eINSTANCE.createContentType()));

		newChildDescriptors.add
			(createChildParameter
				(SchemaPackage.Literals.FIPA_MESSAGE_TYPE__REPLY_BY,
				 SchemaFactory.eINSTANCE.createReplyByType()));

		newChildDescriptors.add
			(createChildParameter
				(SchemaPackage.Literals.FIPA_MESSAGE_TYPE__REPLY_TO,
				 SchemaFactory.eINSTANCE.createReplyToType()));

		newChildDescriptors.add
			(createChildParameter
				(SchemaPackage.Literals.FIPA_MESSAGE_TYPE__USER_DEFINED,
				 SchemaFactory.eINSTANCE.createUserDefinedType()));
	}

	/**
	 * Return the resource locator for this item provider's resources.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ResourceLocator getResourceLocator() {
		return SuiteEditPlugin.INSTANCE;
	}

}
