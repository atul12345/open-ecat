/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package schema.provider;


import java.util.Collection;
import java.util.List;

import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.ResourceLocator;

import org.eclipse.emf.ecore.EStructuralFeature;

import org.eclipse.emf.ecore.xml.type.XMLTypeFactory;

import org.eclipse.emf.edit.provider.ComposeableAdapterFactory;
import org.eclipse.emf.edit.provider.IEditingDomainItemProvider;
import org.eclipse.emf.edit.provider.IItemLabelProvider;
import org.eclipse.emf.edit.provider.IItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.IItemPropertySource;
import org.eclipse.emf.edit.provider.IStructuredItemContentProvider;
import org.eclipse.emf.edit.provider.ITreeItemContentProvider;
import org.eclipse.emf.edit.provider.ItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.ItemProviderAdapter;
import org.eclipse.emf.edit.provider.ViewerNotification;

import schema.AgentIdentifierType;
import schema.SchemaFactory;
import schema.SchemaPackage;

import suite.SuiteFactory;

import suite.provider.SuiteEditPlugin;

/**
 * This is the item provider adapter for a {@link schema.AgentIdentifierType} object.
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class AgentIdentifierTypeItemProvider
	extends ItemProviderAdapter
	implements	
		IEditingDomainItemProvider,	
		IStructuredItemContentProvider,	
		ITreeItemContentProvider,	
		IItemLabelProvider,	
		IItemPropertySource {
	/**
	 * This constructs an instance from a factory and a notifier.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AgentIdentifierTypeItemProvider(AdapterFactory adapterFactory) {
		super(adapterFactory);
	}

	/**
	 * This returns the property descriptors for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public List<IItemPropertyDescriptor> getPropertyDescriptors(Object object) {
		if (itemPropertyDescriptors == null) {
			super.getPropertyDescriptors(object);

			addNamePropertyDescriptor(object);
		}
		return itemPropertyDescriptors;
	}

	/**
	 * This adds a property descriptor for the Name feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addNamePropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_AgentIdentifierType_name_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_AgentIdentifierType_name_feature", "_UI_AgentIdentifierType_type"),
				 SchemaPackage.Literals.AGENT_IDENTIFIER_TYPE__NAME,
				 true,
				 false,
				 false,
				 ItemPropertyDescriptor.GENERIC_VALUE_IMAGE,
				 null,
				 null));
	}

	/**
	 * This specifies how to implement {@link #getChildren} and is used to deduce an appropriate feature for an
	 * {@link org.eclipse.emf.edit.command.AddCommand}, {@link org.eclipse.emf.edit.command.RemoveCommand} or
	 * {@link org.eclipse.emf.edit.command.MoveCommand} in {@link #createCommand}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Collection<? extends EStructuralFeature> getChildrenFeatures(Object object) {
		if (childrenFeatures == null) {
			super.getChildrenFeatures(object);
			childrenFeatures.add(SchemaPackage.Literals.AGENT_IDENTIFIER_TYPE__ADDRESSES);
			childrenFeatures.add(SchemaPackage.Literals.AGENT_IDENTIFIER_TYPE__RESOLVERS);
			childrenFeatures.add(SchemaPackage.Literals.AGENT_IDENTIFIER_TYPE__USER_DEFINED);
		}
		return childrenFeatures;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EStructuralFeature getChildFeature(Object object, Object child) {
		// Check the type of the specified child object and return the proper feature to use for
		// adding (see {@link AddCommand}) it as a child.

		return super.getChildFeature(object, child);
	}

	/**
	 * This returns AgentIdentifierType.gif.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object getImage(Object object) {
		return overlayImage(object, getResourceLocator().getImage("full/obj16/AgentIdentifierType"));
	}

	/**
	 * This returns the label text for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getText(Object object) {
		String label = ((AgentIdentifierType)object).getName();
		return label == null || label.length() == 0 ?
			getString("_UI_AgentIdentifierType_type") :
			getString("_UI_AgentIdentifierType_type") + " " + label;
	}

	/**
	 * This handles model notifications by calling {@link #updateChildren} to update any cached
	 * children and by creating a viewer notification, which it passes to {@link #fireNotifyChanged}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void notifyChanged(Notification notification) {
		updateChildren(notification);

		switch (notification.getFeatureID(AgentIdentifierType.class)) {
			case SchemaPackage.AGENT_IDENTIFIER_TYPE__NAME:
				fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), false, true));
				return;
			case SchemaPackage.AGENT_IDENTIFIER_TYPE__ADDRESSES:
			case SchemaPackage.AGENT_IDENTIFIER_TYPE__RESOLVERS:
			case SchemaPackage.AGENT_IDENTIFIER_TYPE__USER_DEFINED:
				fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), true, false));
				return;
		}
		super.notifyChanged(notification);
	}

	/**
	 * This adds {@link org.eclipse.emf.edit.command.CommandParameter}s describing the children
	 * that can be created under this object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected void collectNewChildDescriptors(Collection<Object> newChildDescriptors, Object object) {
		super.collectNewChildDescriptors(newChildDescriptors, object);

		newChildDescriptors.add
			(createChildParameter
				(SchemaPackage.Literals.AGENT_IDENTIFIER_TYPE__ADDRESSES,
				 SchemaFactory.eINSTANCE.createAddressesType()));

		newChildDescriptors.add
			(createChildParameter
				(SchemaPackage.Literals.AGENT_IDENTIFIER_TYPE__RESOLVERS,
				 SchemaFactory.eINSTANCE.createAddressesType()));

		newChildDescriptors.add
			(createChildParameter
				(SchemaPackage.Literals.AGENT_IDENTIFIER_TYPE__RESOLVERS,
				 SchemaFactory.eINSTANCE.createAgentIdentifierType()));

		newChildDescriptors.add
			(createChildParameter
				(SchemaPackage.Literals.AGENT_IDENTIFIER_TYPE__RESOLVERS,
				 SchemaFactory.eINSTANCE.createContentType()));

		newChildDescriptors.add
			(createChildParameter
				(SchemaPackage.Literals.AGENT_IDENTIFIER_TYPE__RESOLVERS,
				 SchemaFactory.eINSTANCE.createFipaMessageType()));

		newChildDescriptors.add
			(createChildParameter
				(SchemaPackage.Literals.AGENT_IDENTIFIER_TYPE__RESOLVERS,
				 SchemaFactory.eINSTANCE.createReceiverType()));

		newChildDescriptors.add
			(createChildParameter
				(SchemaPackage.Literals.AGENT_IDENTIFIER_TYPE__RESOLVERS,
				 SchemaFactory.eINSTANCE.createReplyByType()));

		newChildDescriptors.add
			(createChildParameter
				(SchemaPackage.Literals.AGENT_IDENTIFIER_TYPE__RESOLVERS,
				 SchemaFactory.eINSTANCE.createReplyToType()));

		newChildDescriptors.add
			(createChildParameter
				(SchemaPackage.Literals.AGENT_IDENTIFIER_TYPE__RESOLVERS,
				 SchemaFactory.eINSTANCE.createResolversType()));

		newChildDescriptors.add
			(createChildParameter
				(SchemaPackage.Literals.AGENT_IDENTIFIER_TYPE__RESOLVERS,
				 SchemaFactory.eINSTANCE.createSenderType()));

		newChildDescriptors.add
			(createChildParameter
				(SchemaPackage.Literals.AGENT_IDENTIFIER_TYPE__RESOLVERS,
				 SchemaFactory.eINSTANCE.createUrlType()));

		newChildDescriptors.add
			(createChildParameter
				(SchemaPackage.Literals.AGENT_IDENTIFIER_TYPE__RESOLVERS,
				 SchemaFactory.eINSTANCE.createUserDefinedType()));

		newChildDescriptors.add
			(createChildParameter
				(SchemaPackage.Literals.AGENT_IDENTIFIER_TYPE__RESOLVERS,
				 SuiteFactory.eINSTANCE.createCheckType()));

		newChildDescriptors.add
			(createChildParameter
				(SchemaPackage.Literals.AGENT_IDENTIFIER_TYPE__RESOLVERS,
				 SuiteFactory.eINSTANCE.createConditionType()));

		newChildDescriptors.add
			(createChildParameter
				(SchemaPackage.Literals.AGENT_IDENTIFIER_TYPE__RESOLVERS,
				 SuiteFactory.eINSTANCE.createGoalPlanType()));

		newChildDescriptors.add
			(createChildParameter
				(SchemaPackage.Literals.AGENT_IDENTIFIER_TYPE__RESOLVERS,
				 SuiteFactory.eINSTANCE.createParamType()));

		newChildDescriptors.add
			(createChildParameter
				(SchemaPackage.Literals.AGENT_IDENTIFIER_TYPE__RESOLVERS,
				 SuiteFactory.eINSTANCE.createTActionType()));

		newChildDescriptors.add
			(createChildParameter
				(SchemaPackage.Literals.AGENT_IDENTIFIER_TYPE__RESOLVERS,
				 SuiteFactory.eINSTANCE.createTargetType()));

		newChildDescriptors.add
			(createChildParameter
				(SchemaPackage.Literals.AGENT_IDENTIFIER_TYPE__RESOLVERS,
				 SuiteFactory.eINSTANCE.createTestCaseType()));

		newChildDescriptors.add
			(createChildParameter
				(SchemaPackage.Literals.AGENT_IDENTIFIER_TYPE__RESOLVERS,
				 SuiteFactory.eINSTANCE.createTestScenarioType()));

		newChildDescriptors.add
			(createChildParameter
				(SchemaPackage.Literals.AGENT_IDENTIFIER_TYPE__RESOLVERS,
				 SuiteFactory.eINSTANCE.createTestSupportType()));

		newChildDescriptors.add
			(createChildParameter
				(SchemaPackage.Literals.AGENT_IDENTIFIER_TYPE__RESOLVERS,
				 SuiteFactory.eINSTANCE.createOrderLinkType()));

		newChildDescriptors.add
			(createChildParameter
				(SchemaPackage.Literals.AGENT_IDENTIFIER_TYPE__RESOLVERS,
				 SuiteFactory.eINSTANCE.createSetupType()));

		newChildDescriptors.add
			(createChildParameter
				(SchemaPackage.Literals.AGENT_IDENTIFIER_TYPE__RESOLVERS,
				 SuiteFactory.eINSTANCE.createTeardownType()));

		newChildDescriptors.add
			(createChildParameter
				(SchemaPackage.Literals.AGENT_IDENTIFIER_TYPE__RESOLVERS,
				 SuiteFactory.eINSTANCE.createGoalLinkType()));

		newChildDescriptors.add
			(createChildParameter
				(SchemaPackage.Literals.AGENT_IDENTIFIER_TYPE__RESOLVERS,
				 SuiteFactory.eINSTANCE.createSendLinkType()));

		newChildDescriptors.add
			(createChildParameter
				(SchemaPackage.Literals.AGENT_IDENTIFIER_TYPE__RESOLVERS,
				 SuiteFactory.eINSTANCE.createReceiveLinkType()));

		newChildDescriptors.add
			(createChildParameter
				(SchemaPackage.Literals.AGENT_IDENTIFIER_TYPE__RESOLVERS,
				 XMLTypeFactory.eINSTANCE.createAnyType()));

		newChildDescriptors.add
			(createChildParameter
				(SchemaPackage.Literals.AGENT_IDENTIFIER_TYPE__USER_DEFINED,
				 SchemaFactory.eINSTANCE.createUserDefinedType()));
	}

	/**
	 * This returns the label text for {@link org.eclipse.emf.edit.command.CreateChildCommand}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getCreateChildText(Object owner, Object feature, Object child, Collection<?> selection) {
		Object childFeature = feature;
		Object childObject = child;

		boolean qualify =
			childFeature == SchemaPackage.Literals.AGENT_IDENTIFIER_TYPE__ADDRESSES ||
			childFeature == SchemaPackage.Literals.AGENT_IDENTIFIER_TYPE__RESOLVERS ||
			childFeature == SchemaPackage.Literals.AGENT_IDENTIFIER_TYPE__USER_DEFINED;

		if (qualify) {
			return getString
				("_UI_CreateChild_text2",
				 new Object[] { getTypeText(childObject), getFeatureText(childFeature), getTypeText(owner) });
		}
		return super.getCreateChildText(owner, feature, child, selection);
	}

	/**
	 * Return the resource locator for this item provider's resources.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ResourceLocator getResourceLocator() {
		return SuiteEditPlugin.INSTANCE;
	}

}
